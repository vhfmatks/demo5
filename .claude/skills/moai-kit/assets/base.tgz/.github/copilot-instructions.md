이 저장소의 모든 규칙은 루트 `AGENTS.md` 와 `docs/conventions/*.md` 에 있다. 그대로 따른다.
핵심: 새 도메인은 `npm run gen` 으로 생성, 읽기는 Server Component→service, 쓰기는 useMutation→REST(api() 래퍼),
인증 예제는 features/requests, 공개 예제는 features/publicNotes(프로젝트에 없으면(예제 없이 init) `.claude/skills/moai-kit/references/examples/` 아래 같은 경로에서 읽는다). 통신·CRUD 규칙은 docs/conventions/communication.md. 공개 생성은 --auth=public이며 API/UI 시험도 생성한다.
오류는 features/<x>/errors.ts에 DOMAIN_REASON 코드·category·공개 메시지를 선언(규칙: docs/conventions/errors.md), UI 는 "@/components/ui" 만, 권한은 features/<x>/policy.ts 로 service 에서 강제.
API는 nodejs runtime·api()·공유 params 스키마(규칙: docs/conventions/api.md). E2E는 ./fixtures·고정 TC ID·격리 runner(규칙: docs/conventions/testing.md).
변경 후 npm run lint의 정적 계약 검사를 확인하고 E2E는 npm run test:e2e -- <파일>로 실행한다.
