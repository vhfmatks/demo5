<!-- BEGIN:nextjs-agent-rules -->

## This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->

## Project conventions (read these instead of the Next.js docs)
All rules for this repo live in this file (below) and `docs/conventions/*.md`; they were verified against Next.js 16.4 (route handlers, PageProps/RouteContext, server/client boundaries, dynamic rendering without Cache Components).
Open `node_modules/next/dist/docs/` only for an API not covered there, and read just that one file.

## 프로젝트 규칙 (항상 이 규칙을 따른다)

Stack: Next.js 16 App Router · React 19 · TypeScript · Drizzle ORM + SQLite(@libsql/client, 비동기) · zod 4 · Tailwind 4 · Vitest · Playwright
이 문서와 docs/conventions/*.md 는 Next 16.4 기준으로 검증됨 → node_modules 문서·소스를 읽지 말 것(에러로 막힐 때만 해당 파일 1개).

### 토큰 절약 작업 규칙
1. 새 도메인은 **먼저 `npm run gen -- <entity> <한글라벨>`** → 생성된 파일만 수정. 공개 CRUD는 `--auth=public`. 인증/공개별 API·UI 시험도 생성한다. 시험 제외는 `--skip-tests`. 손으로 CRUD를 새로 쓰지 않는다.
2. 인증·상태전이 레퍼런스는 `src/features/requests/`, 공개 CRUD는 `src/features/publicNotes/`, 마스터+시간 범위·겹침 충돌·동시성·타임라인 화면은 `src/features/bookings/`. 해당 작업에 맞는 한 곳만 본다. 프로젝트에 없으면(예제 없이 init) `.claude/skills/moai-kit/references/examples/` 아래 같은 경로에서 읽는다.
3. 탐색 금지 경로: `node_modules/ .next/ drizzle/meta/ data/ test-results/ package-lock.json`.
4. 파일 전체 재작성 대신 부분 수정. 변경하지 않은 코드는 출력·요약하지 않는다.
5. 검증은 좁게 → 넓게: `npx vitest run <파일>` / `npm run test:e2e -- <파일>` → 커밋 전 `npm run verify` 1회. E2E는 격리 runner를 통해서만 실행한다.
6. 규칙 문서는 필요한 것만: 통신·CRUD `docs/conventions/communication.md`, API `api.md`, 오류 계약 `errors.md`, 화면·컴포넌트 `ui.md`, DB `data.md`, 테스트 `testing.md`, 버전·보안 `dependencies.md`, lint 오류 `lint.md`, 관리자 포털·운영 설정 `admin.md`, 권한 `rbac.md`, AI 기능 `ai.md`.
7. 의존성은 정확한 버전으로 고정하고 `npm ci`로 설치한다. 기본 lint는 Biome(+`lint/*.grit`), 타입 기반·디자인 lint는 oxlint(`oxlint-tsgolint`·`@shadcn/lint`). 규칙표는 `docs/conventions/lint.md`, lint를 끄거나 우회하지 않는다. TypeScript 7 CLI와 TypeScript 6 API를 병행하며 alias를 임의로 제거하지 않는다.

### 구조 (feature 폴더 = 도메인 1개)
```
src/features/<x>/schema.ts      [공유] enum·라벨·zod 입력·DTO 타입 ("@/" 금지, 상대경로만)
src/features/<x>/errors.ts      [공유] defineErrors({ DOMAIN_REASON: {category,message} }) 오류 카탈로그
src/features/<x>/policy.ts      [공유] 권한 규칙 순수 함수 (서버 강제, 클라는 표시용)
src/features/<x>/service.ts     [서버] 유일한 DB 접근. 첫 인자 actor, AppError throw, DTO 반환, audit()
src/features/<x>/components/    *Table·*Filters = Server / *Form·*Actions = Client
src/app/api/v1/<x>/**/route.ts  REST. api() 래퍼 + body()/query() + ok()/created()/noContent() 만 사용
src/app/(app)/<x>/**/page.tsx   로그인 필수 화면. requireUser() → service 직접 호출 → load()
src/app/(public)/<x>/**/page.tsx 공개 화면. 선택적 getCurrentUser() → service 직접 호출 → load()
src/app/admin/<x>/**/page.tsx  관리자 포털. requirePermission("<권한>") → service. 메뉴 admin/nav.ts (사용자·감사로그·설정 내장)
src/server/{db,http,auth}       공통 인프라 (수정 최소화)
src/components/ui               디자인 시스템. 기능 코드는 "@/components/ui" 에서만 import
src/lib                         api-client·use-mutation·error-codes·format (공용)
```

### 절대 규칙
- 읽기 = Server Component 에서 service 직접 호출 (자기 API fetch 금지). 쓰기 = Client 에서 `useMutation` + `apiClient` → REST.
- `"use client"` 는 이벤트·상태가 필요한 가장 작은 컴포넌트에만. 페이지·레이아웃에 붙이지 않는다.
- 권한은 service 안에서 policy 로 강제. 볼 권한 없음 = 404, 볼 수 있으나 행위 불가 = 403, 상태 불가 = 409(category: INVALID_STATE).
- RBAC: 역할이 아니라 권한을 검사한다 `can(user,"x.y")`·`requirePermission`·`api(fn,{permission})`·`assertPermission`. `role === "..."` 비교 금지. 권한·역할 매핑은 `src/lib/permissions.ts` 한 곳(`docs/conventions/rbac.md`).
- API는 기본 인증 필수. 공개 API만 메서드별로 `{auth:"public"}`을 명시하고 service의 actor는 `SessionUser | null`로 받는다. 공개 메모는 모든 사용자가 같은 데이터를 CRUD하는 예제다.
- Route는 `api()`·`runtime="nodejs"`, 동적 경로는 `{params:IdParams}`. 쓰기 Origin 필수·전체 일치, JSON 64KiB, body는 strictObject. `npm run lint:contracts`로 Route·E2E 작성 규칙을 검사한다.
- E2E는 `./fixtures`의 test·expect·apiAs/pageAs를 사용하며 TC-DOMAIN-API/UI-001로 이름을 붙인다. 격리 runner만 사용하고 only/skip·고정 sleep·기존 서버 재사용은 금지한다.
- 쓰기와 감사로그는 같은 `db.transaction`에서 실행한다. `audit(..., detail, tx)`에 같은 tx를 전달한다. 상태·version 조건도 실제 쓰기에 포함한다.
- 오류는 `features/<x>/errors.ts`에 `DOMAIN_REASON` 코드·공개 메시지·category를 선언하고 `new AppError(정의)`로 발생시킨다. HTTP 상태는 공통 category가 결정한다. 상세 규칙은 `docs/conventions/errors.md`.
- 응답은 `{data, meta?}` 또는 `{error:{code,category,message,traceId,retryable,fieldErrors?,issues?,retryAfterSeconds?}}`. 공통 처리는 category, 도메인 분기는 code를 사용한다. 메시지 문자열로 분기하지 않는다.
- 입력 검증은 zod 스키마 1곳(features/<x>/schema.ts). 폼은 useMutation의 schema 옵션으로 같은 스키마를 재사용하며, 별도 클라이언트 검증 규칙을 복제하지 않는다. 서버 검증은 항상 유지한다.
- 색상 hex·임의 px 금지 → 토큰 유틸(bg-primary, text-muted, border-line …)과 ui 컴포넌트만.
- 디자인 설계·사용: `docs/design-system/README.md` → 화면 계약 `docs/conventions/ui.md`. KDS 20261012 기준 화면은 `/design-system/kds`·`public/kds/templates`·`examples`. 검색은 `SearchField`, 날짜는 `DatePicker`(표시 점·제출 ISO), 모바일 업무는 `Section`·`CtaBar`, PC 전환은 `lg:`(1280). 원본 컨트롤을 32/36px로 축소하지 않는다. 제공 원문 API는 설치된 React API가 아니며 `@/components/ui` export만 사용한다.
- 시드·테스트는 합성 데이터만. 비밀번호·토큰·개인정보를 코드·로그·프롬프트에 넣지 않는다.
- `docs/security-policy.md` 는 수정 금지.

### 추적성 (검증 근거)
REQ-xx(docs/prd.md) → AC-xx-k → Issue `[REQ-xx] 제목` → 커밋 `feat(x): ... (#이슈)` → TC-DOMAIN-API/UI-001(테스트 이름 접두어, §2 경계·E2E·단위 시험 파일) → docs/e2e-test.md 결과(실행 환경·소스 SHA·시각·PASS/FAIL/SKIP·근거 경로).
보안 테스트는 TC 제목 끝에 `docs/security-policy.md`의 SEC 번호를 `(SEC-03)`처럼 붙인다. kit은 주최 측 SEC-01~12 번호를 쓰며 공식 원문 번호가 다르면 함께 바꾼다. 미실행·미검증은 그대로 "미검증"으로 적는다.

### 명령
`npm run dev` · `npm run db:reset`(초기화+시드) · `npm run db:generate -- --name <x>` → `npm run db:migrate`
`npm run test` · `npm run test:e2e` · `npm run verify` · `npm run evidence`(SHA·결과를 docs/evidence 에 기록)
데모 계정: user1@ / user2@ / user3@(비밀번호 변경 TC 전용) / approver@ / auditor@ / admin@demo.local · `Credit!23`
