# 개발 플레이북

팀이 `intent → grilling → spec → Issue → 구현 → 검증 → 문서 갱신 → 통합 → 릴리스`를 릴리스마다 반복하고, 실제 근거가 포함된 소스를 배포하기 위한 운영 기준이다.
운영 담당자는 이 문서를 사용하고, 구현 에이전트에는 해당 Issue의 작업 정보와 필요한 규칙만 전달한다.
마감이 정해진 행사(해커톤 등)에서 쓰면 [부록 A 이벤트 모드](#부록-a-이벤트-모드-해커톤-등)의 시간표·제출 절차를 덧붙인다.

## 1. 시작 전 확인

키트가 제공하는 scaffold(인증·공개 CRUD, 생성기, API·E2E 표준, 오류 계약, 병렬 runner, KDS UI)는 이 프로젝트에서 직접 실행한 결과만 근거로 쓴다. 규칙은 [AGENTS.md](AGENTS.md)와 [conventions](docs/conventions/)가 원본이다.
lint·typecheck·build 통과는 실제 CRUD·동시 처리·권한 시나리오의 검증을 대신하지 않는다.

| 우선순위 | 확인할 부분 | 완료 조건 |
|---|---|---|
| P1 | 상태 조건(인증 예제 `src/features/requests/service.ts`)·version 조건(공개 예제 `src/features/publicNotes/service.ts`) | 상태 전이와 수정·삭제가 겹칠 때 허용 상태 유지·오래된 version 거부 확인 |
| P1 | 업무 데이터 변경과 [감사로그](src/server/audit.ts)의 같은 트랜잭션 | 로그 실패 시 업무 변경도 취소되는지 확인 |
| P1 | [생성기](scripts/gen-module.mts)의 사전 확인·쓰기 실패 복구 | 인증 모듈·충돌·쓰기 실패·재시도 리허설 |
| P1 | [E2E runner](scripts/e2e-run.mts)·[근거 기록](scripts/evidence.mts) | sourceChanged·보고서 누락 거부 시나리오 확인 |
| P2 | 업무 입력 유형(숫자·boolean·기간·다중값·관계) | 실제 AC별 시험 확보 |
| P2 | 로그인 시도 제한·실패 처리 시간 균일화 | 조직 보안 정책에 맞는 인증 기준과 실패 처리 검증 |
| P2 | [의존성](docs/conventions/dependencies.md) | 재설치·lint·타입·빌드 확인, 개발 중 보안 감사 반복 |

## 2. 팀 역할과 작업 소유권

3인 팀 기준 예시다. 인원이 다르면 A의 책임은 한 사람에게 두고 B·C를 늘리거나 줄인다.

| 역할 | 주 책임 | 교차 검토·문서 책임 |
|---|---|---|
| A — 요구사항·통합 | 범위 확정, 공통 준비 작업, Issue 배정, 순차 통합, 릴리스 | Project Brief·PRD·Architecture·README, 개발 이력 취합 |
| B — 기능 흐름 1 | 담당 기능의 UI·API·데이터·시험을 포함한 전체 구현 | 다른 기능의 KDS·사용성 확인, Experience |
| C — 기능 흐름 2 | 담당 기능의 UI·API·데이터·시험을 포함한 전체 구현 | 다른 기능의 권한·데이터 무결성 확인, Security Compliance·E2E |

- Issue 하나는 독립적으로 시연하거나 검증할 수 있는 작은 기능 단위로 만든다.
- 새 엔티티 생성·초기 마이그레이션·공통 nav 변경을 먼저 통합한 뒤 병렬 구현을 시작한다.
- `src/server/db/schema.ts`, `src/app/(app)/nav.ts`, 공통 인프라·시험 설정을 수정하는 작업은 A가 충돌을 확인하고 순서를 정한다.
- 기능 작업은 승인된 UI·variant·토큰을 조합한다. UI 구현·토큰·디자인 lint 변경은 별도 작업으로 관리한다.
- 같은 `service.ts` 등 수정 범위가 겹치는 Issue는 동시에 배정하지 않는다. 범위 확대가 필요하면 작업 정보를 갱신한다.
- 승인된 spec은 부모 GitHub Issue에 보관하고, `docs/prd.md`에 REQ·AC와 실제 연결 정보를 반영한다.

## 3. 사전 준비 (프로젝트 시작 시 1회)

- [ ] 저장소 접근 권한·Git remote·Issue 양식을 확인한다.
- [ ] 각 PC의 네이티브 터미널에서 도구·npm·`gh`의 동작을 확인한다.
- [ ] `/moai-setup`으로 `AGENTS.md`·`docs/agents/issue-tracker.md`·라벨·워커 루프를 설치한다(G0).
- [ ] KDS v2.0 키트와 [ui.md](docs/conventions/ui.md)의 컴포넌트 대응·화면 패턴을 확인한다. KT Flow 글꼴은 사용 허가 범위를 확인하고 각자 PC에 설치한다(저장소 업로드 금지).
- [ ] [통신·CRUD 규칙](docs/conventions/communication.md)에서 인증·공개 범위와 필드·정책을 확정한다.
- [ ] [오류 계약](docs/conventions/errors.md)의 도메인 코드·category·HTTP 상태와 직접 API 소비자의 호환성을 확인한다.
- [ ] 주최 측 보안 정책을 `docs/security-policy.md`로 받아 적용 범위를 확인한다. kit의 TC·문서는 주최 측 SEC-01~12 번호를 쓴다. 원문 번호가 다르면 맞춰 바꾸고, 원문이 없으면 공식 준수 여부를 미확인으로 기록한다.
- [ ] 합성 개발·시험 DB에서 아래 설치·검증을 완료하고 실제 결과를 기록한다.

PowerShell 예시:

```powershell
npm ci
npm run db:reset
npm run verify
$env:PW_CHANNEL = "msedge"
npm run test:e2e
```

`verify`는 lint·typecheck·단위 시험·build·전체 보안 감사를 수행한다. E2E는 별도 실행한다.
macOS 등 POSIX 셸에서는 `PW_CHANNEL=msedge npm run test:e2e`처럼 환경변수를 지정할 수 있다.
설치 문제는 사내 npm 레지스트리와 `@libsql/*` 플랫폼 패키지부터 확인한다.

## 4. 릴리스 주기의 시작: 요구 확정

| 단계 | 할 일 | 다음 단계에 필요한 결과 |
|---|---|---|
| 요구 수집 | 요구 원문을 `intent.md`에 보관하고 필수 요구·완료 조건·보안 적용 범위를 추출 | 필수 요구와 팀 추가 아이디어 구분 |
| grilling (G1) | `/moai-grill`로 결정 사항을 확정 | 사용자·권한·상태·예외·제외 범위·효과 측정 방법 합의, `docs/project-brief.md` |
| spec·Issue (G2) | `/moai-spec`으로 부모 spec·작업 Issue 발행, 선행 관계 검토 | REQ·AC·시험 인터페이스·시나리오, 담당 PC와 실행 가능한 Issue |
| 기반 구현 (G3) | 엔티티·공통 계약을 준비하고 가장 작은 사용자 흐름 하나를 끝까지 구현 | 인증 → 생성 → 조회 → 새로고침 후 저장 확인, 정상·오류·권한 검증 |
| 병렬 구현 (G4) | 워커 PC가 독립적인 기능 Issue 구현, A가 순차 통합 | 검증된 기능과 Issue·문서·근거의 연결 |

해당 작업의 요구·AC·권한·시험 방법이 확정되어야 구현에 진입한다.
미해결 질문은 부모 spec에 남기고 영향을 받는 작업만 대기시킨다.
다음 릴리스는 같은 단계를 다시 밟는다. REQ 번호는 이어서 매기고(01부터 다시 시작하지 않는다), 기존 ID는 유지한다.

새 도메인은 `npm run gen -- <entity> <라벨>`로 시작한다. 생성·마이그레이션 절차와 참고 코드는 [AGENTS.md](AGENTS.md)·[통신 규칙](docs/conventions/communication.md)에서 필요한 것만 읽는다.

## 5. Issue별 구현·검증·통합

```text
실행 가능한 Issue 선택 → 배정 → 구현·좁은 검증 → 코드 리뷰
→ 최신 통합 브랜치에서 검증 → 관련 문서·근거 반영 → 완료
```

1. **A가 배정한다.** 승인된 작업 Issue 중 선행 구현이 통합되었고, 실행 중인 작업과 수정 범위가 겹치지 않는 것을 선택한다.
2. **작업 정보를 고정한다.** Issue·spec 버전, REQ·AC, 시작 커밋(`baseSha`), 관련 파일·규칙·레퍼런스, 검증 명령을 기록한다.
3. **worker가 구현한다.** `/moai-work`가 spec 통합 브랜치(`spec-<p>`)를 만들고, 실행 가능한 Issue마다 구현자를 자기 worktree·`issue-<n>` 브랜치에서 백그라운드로 돌리며 merger가 끝난 Issue를 하나씩 병합한다. 리뷰는 spec 전체에 한 번이다. 절차는 [AGENTS.md](AGENTS.md)와 `.claude/skills/moai-work/SKILL.md`가 원본이다. 합의된 인터페이스에서 시험부터 작성한다.
4. **좁게 검증하고 리뷰한다.** 관련 단위·API·UI 시험부터 실행하고 시작 커밋과 spec·Issue를 리뷰에 전달한다. 전체 `npm run verify`·E2E는 spec 게이트에서 수행한다.
5. **작업을 보고한다.** 커밋·변경 범위·시험 결과·문서 변경 사항을 PR 본문에 적고 Issue와 연결한다.
6. **A가 순차 통합한다.** 최신 통합 브랜치에서 변경에 필요한 회귀·E2E를 확인한 뒤 반영한다. 시험 DB·포트·근거 경로는 worker·후보 간 분리한다.
7. **문서와 근거를 반영한다.** 실제 시험 SHA·실행 시각·명령·결과·보관 경로를 REQ·AC·TC와 연결하고 관련 문서를 갱신한다.
8. **완료 처리한다.** 통합된 구현의 AC와 근거를 확인한 뒤 `Close as completed`로 닫는다. 부모 spec은 모든 필수 AC와 최종 검증·문서 확인 후 완료 처리한다.

worker의 완료 보고는 통합 검증의 입력이다. Issue 체크박스·파일 존재만으로 완료를 판정하지 않는다.

- 행동 계약과 AC는 Issue에 남기고, 실행 시점의 구체적인 파일 경로는 작업 정보에 넣는다.
- 실패 로그는 핵심 오류와 마지막 20줄을 우선 전달하고 원본 근거 경로를 함께 남긴다.

## 6. runner 운영 계약

| 구성 | 책임 |
|---|---|
| Tracker | GitHub Issue·댓글·선행 관계·PR 조회 및 갱신 (`docs/agents/issue-tracker.md`) |
| Coordinator | 실행 대상 선택·배정, 수정 범위 충돌 방지 (`/moai-spec`이 spec 단위로 PC 배정) |
| Worker | 배정된 Issue 구현, 프로세스·검증 결과 수집 (`scripts/moai-loop.ps1` → `/moai-work`) |
| Integrator | 후보를 순차 검증·통합하고 완료 처리 |

- 배정 권한은 A 하나에 둔다. 워커 PC는 각자 배정된 작업만 실행한다.
- `kind:spec`과 일반 작업 Issue를 구분하고, 상태 라벨(`status:ready → status:in-progress → 완료 | status:needs-human`)로 관리한다.
- 선행 관계는 Issue 본문의 `Blocked by`로 기록하고, 선행 Issue의 종료 사유와 통합된 구현을 함께 확인한다.
- 동시 구현 수(`MAX_PARALLEL`), 같은 작업 재시도 횟수, 실행 시간·예산 상한을 `AGENTS.md`에 정한다.
- 재개 시 기존 브랜치·PR·시험·완료 기록을 조회하고, 이미 처리한 배정·통합·댓글·버그 Issue를 중복 생성하지 않는다.

| 실패 유형 | 처리 |
|---|---|
| 구현 중 lint·type·시험 실패 | 같은 Issue에서 재현 시험을 기준으로 수정·재시도 |
| 통합 후 제품 동작 오류 | 재현 조건·실패 AC/TC·시험 SHA·근거가 있는 버그 Issue 생성 (`/moai-diagnose`) |
| 설치·인증·브라우저·서버 기동 실패 | 환경 문제로 분류하고 복구 상태 기록 |
| 요구·권한·계약 불명확 | 해당 작업을 needs-human으로 두고 질문·결정 사항 기록 |
| 반복 실패·상한 도달 | 작업을 중단하고 근거·남은 사항을 담당자에게 전달 |

버그는 AC/TC·증상·원인으로 기존 Issue와 중복을 확인한다. 수정은 실패를 재현하는 시험부터 시작한다.

## 7. 프로젝트 문서 8종의 lifecycle 게이트

8종 = `README.md` + `docs/`의 project-brief·prd·arch·experience·development·security-compliance·e2e-test. REQ → AC → Issue·코드 → TC → 실제 결과의 연결이 리뷰·감사의 근거다.
**8종은 PC1만 고친다.** 워커 PC는 문서를 고치지 않고 PR 본문에 AC→TC·결과를 보고한다. PC1이 `/moai-docs`로 옮긴다. 게이트마다 main에 커밋·push한다.
G0은 프로젝트당 한 번, G1~G8은 릴리스마다 반복한다.

| 게이트 | 시점 | 실행 | 확정할 문서·내용 | 상태 표기 |
|---|---|---|---|---|
| G0 준비 | 저장소 생성 직후 | `/moai-setup` (+ `/moai-kit init`) | README 실행 절차, development 진행 방식·AI 규칙, security-compliance는 정책 확보 즉시 SEC 매핑 | - |
| G1 기획 확정 | grilling 종료 | `/moai-grill` 끝 | **project-brief**: 문제·사용자·필수/추가/제외 범위·기대 효과. GLOSSARY | 확정 |
| G2 명세 확정 ★ | Issue 발행 직전 | `/moai-spec` | **prd** REQ·AC·권한·데이터, **e2e-test** AC별 TC(REQ·경계·GIVEN/WHEN/THEN)·예상 결과, **security-compliance** 적용 SEC·이유·검증 방법, **experience** 핵심 흐름·비교 대상·측정 방법, **arch** 데이터·API·화면 초안 → push → Issue 발행 → prd Issue 칸 채워 push | 미실행·예상 |
| G3 기반 머지 | 병렬 구현 전 | `/moai-docs arch` | **arch**를 실제 스키마·라우트·화면과 대조해 확정 | 확정 |
| G4 개발 중 | wave 머지마다 | `/moai-docs sync` | **prd** Issue·PR·TC·상태, **e2e-test** TC 행, **development** AI 사례·일정, **security-compliance** 코드 위치 | 구현(PR #) |
| G5 범위 동결 | 릴리스 계획의 동결 시점 | `/moai-docs freeze` | 열린 Issue 정리(DROP → 미구현 또는 다음 릴리스), **experience** 실측·스크린샷, **project-brief** 실제 제공 범위 | 측정·미구현 |
| G6 시험 커밋 C | 동결 후 | `/moai-docs final` | main에서 verify·test:unit:evidence·test:e2e·evidence → **e2e-test** 시험 SHA C·PASS/FAIL/SKIP, **security-compliance** 정상·거부 결과, **prd** 최종 상태 | 검증(C)·실패·미검증 |
| G7 문서 커밋 D | C 검증 후 | 〃 | **README** 8종·근거 링크, **development** 일정 기록. `git diff --name-only C D`가 문서·근거뿐인지 확인 | 동결 |
| G8 릴리스 | D push 후 | 〃 | 원격 40자 SHA 확인 → 태그 `v<x>` push (필요하면 GitHub Release 노트) | - |

상태 표기는 `미실행 → 구현(PR #m) → 검증(SHA) | 실패 | 미검증 | 미구현`만 쓴다. "완료"·예시·계획을 검증으로 쓰지 않는다. 효과는 예상/측정을 구분한다.
G6 이후 코드·시험·설정이 바뀌면 영향받는 항목을 미검증으로 되돌리고 G6부터 다시 한다.

- REQ·AC·권한 규칙을 변경하면 부모 spec에 이유·영향을 기록하고 관련 Issue·시험·문서를 갱신한다. 기존 ID는 유지하고 변경 이력을 남긴다.
- `docs/security-policy.md`는 조직이 정한 원본으로 별도 관리하며 수정하지 않는다. 그 SEC 번호를 사용하고 해당 없음·예외에는 이유와 검토 상태를 기록한다.
- `docs/evidence/`는 공통 근거 보관 위치다.

`/moai-docs sync`가 PR 보고를 옮길 때 쓰는 표:

| 변경 | 갱신할 문서 |
|---|---|
| 기능 구현·AC 검증 | PRD·E2E |
| 데이터·API·공통 구조 변경 | Architecture, 사용 방법이 바뀌면 README |
| 권한·세션·입력 검증 변경 | Security Compliance·E2E |
| 사용자 흐름 완성 | Experience |
| AI 제안을 사람이 확인·수정 | Development |
| 합의된 범위 변경 | Project Brief·PRD와 관련 작업·시험 |

문서 작성 완료와 기능 목표 달성은 별도로 판정한다. 실패·미검증을 정확히 기록해 문서를 완성할 수 있지만, 해당 AC는 충족된 것으로 처리하지 않는다.

**문서별 성격과 관리 계약** — 8종 역할의 단일 원본이다. 개별 문서와 스킬은 이 표를 링크하고 규칙을 복제하지 않는다. 갱신은 모두 PC1이 위 게이트에서 한다.

| 문서 | 성격 · 답하는 질문 | 원본 → 담는 것 | 넣지 않는 것 (소유 문서) | 갱신 시점 |
|---|---|---|---|---|
| README | 진입. 어떻게 읽고 실행·검증하나 | package.json·`docs/evidence`·Git → 실행 명령, 문서 지도, 증적 링크, 버전 | 요구·설계·시험 상세 (각 문서) | G0 실행 절차, G7 8종·근거·버전, 사용법 변경 시 |
| project-brief | 범위 합의. 누구의 어떤 문제를 어디까지 풀기로 했나 | 요구 원문·grill → 문제, 대상, 목표, 필수/추가/제외, 기대 효과(예상), 팀 | AC·구현 위치 (prd·arch), 측정 결과 (experience) | G1, 범위 변경 시, G5 실제 제공 범위 |
| prd | 행동 계약. 무엇이 어떻게 동작해야 하고 지금 어디까지 왔나 | brief 범위 → REQ·AC, 권한, 상태 전이, 데이터, Issue·PR·TC 연결, 요구 상태 | 구현 구조 (arch), 시험 절차·결과 (e2e-test), SEC 대응 (security-compliance) | G1 요구 본문(grill 소유), G2 Issue·TC 연결, G4 PR·상태, G6 최종 상태 |
| arch | 구현 구조와 이유. 실제로 어떻게 만들었고 왜 | 코드(스키마·route·화면) → 구성·관계, API, 화면, 흐름, 결정, 제약 | 요구·권한 본문 (prd), 시험 결과 (e2e-test), 변경 과정 (development) | G2 초안, G3 코드 대조 확정, 구조 변경 시 |
| development | 개발 판단 이력. AI 제안을 사람이 어떻게 검토·수정·검증했나 | PR·커밋·Issue → 제안, 검토, 수정, 검증, 링크, 일정 | 현재 설계 (arch), 상세 로그 (evidence), 비밀·개인정보 | G0 진행 방식·AI 규칙, G4 AI 사례, G7 일정 마감 |
| experience | 사용 흐름과 효과. 사용자가 어떻게 쓰고 효과가 있었나 | 실제 화면·측정 → 흐름, 화면 근거, 비교 대상, 측정 방법·결과, 예상/측정 구분, 한계 | 기대 효과 선언 (brief), AC 판정 (prd) | G2 흐름·측정 계획(예상), G5 실측·스크린샷 |
| security-compliance | 정책 대응과 위험. 정책별로 적용되고 어디서 막혀 검증됐나 | `docs/security-policy.md` → SEC별 적용 여부·사유, 구현 위치, TC, 증적, 상태, 제약·예외 | 권한 규칙 본문 (prd), 강제 구조 설명 (arch), 정책 원문 | 정책 수령 즉시, G2 계획, G4 코드 위치, G6 정상·거부 결과 |
| e2e-test | 시험 계획·재현·검증. 무엇을 어떻게 재현했고 결과는 | `tests/e2e`·`tests/unit`·runner·evidence → REQ·AC → TC(GIVEN·WHEN·THEN, 정상·오류·권한·재조회 경계) → 시험 파일(E2E·단위), 환경, 명령, 소스 SHA, 시각, PASS/FAIL/SKIP, 근거 경로, 한계 | AC 충족 판정 (prd), 상세 로그·화면 (evidence 링크) | G2 TC 계획, G4 TC 행, G6 SHA·결과 |

- 한 사실은 한 문서가 소유하고 나머지는 짧은 요약과 링크만 쓴다. 규칙·명령·코드 규약은 `docs/conventions`·`AGENTS.md`를 가리키고 복제하지 않는다. 상세 로그·화면은 `docs/evidence`에 둔다.
- 경계: brief의 기대 효과(예상)와 experience의 측정 결과. prd의 권한 규칙, arch의 강제 구조, security-compliance의 SEC 대응. e2e-test의 TC 결과와 prd의 AC 판정. arch의 현재 설계와 development의 변경 과정.
- 통과한 TC는 그 TC만 증명한다. REQ 전부 충족은 prd의 AC 판정이며 `검증(SHA)`는 해당 AC의 TC가 그 실행에서 통과했을 때만 쓴다.
- 변경이 영향을 주는 문서만 갱신한다(위 변경 표). 코드·시험·설정이 바뀌면 영향 항목의 검증 상태를 다시 판단한다. 근거가 없는 값은 `미정`·`미실행`·`미검증`으로 두고 가짜 정보를 쓰지 않는다.
- 문장이 소유 경계를 지키는지는 자동 검사하지 않는다. 게이트 리뷰에서 사람이 확인한다.

## 8. 시험 근거와 릴리스 SHA

```text
커밋 C를 시험 → 실제 결과·문서·근거 보관 → 문서 커밋 D → D에 릴리스 태그
```

1. 통합된 코드·시험·설정을 커밋하고 작업 트리의 변경 상태를 확인한다. 시험 대상 SHA를 실행 전에 기록한다.
2. `npm run verify`와 `npm run test:e2e`를 실행하고 종료코드·실제 결과·실행 시각·환경을 기록한다. 필수 AC의 실패·미실행·SKIP는 충족으로 처리하지 않는다.
3. `npm run evidence`로 결과 초안을 만들고 원본 실행과 대조한다. 선택한 JSON·로그·합성 데이터 화면을 `docs/evidence/<runId>/`에 보관한다.
4. 8종 문서에서 실제 시험 대상 C와 보관 경로를 연결한다. 결과 문서를 작성한 시점의 HEAD로 시험 SHA를 바꾸지 않는다.
5. 문서·근거를 포함한 릴리스 커밋 D를 만든다. C 이후 변경이 문서·근거뿐인지 확인한다. 코드·시험·설정·AC·정책이 바뀌었으면 필요한 검증을 다시 수행한다.
6. D를 push하고 원격에서 확인한 전체 40자 SHA에 태그 `v<x>`를 붙여 push한다. 태그 메시지에 시험 SHA C를 적는다.

`test:e2e`는 실행 전 Git SHA·파일 SHA-256을 고정하고 새 runId의 보고서와 연결한다. 실행 중 소스 변경·실패·skip·flaky·빈 결과는 완료로 처리하지 않는다.
`evidence`는 그 manifest/report를 다시 확인하며 단위 시험을 실행하거나 현재 HEAD로 시험 SHA를 바꾸지 않는다.
API/UI 구분·TC·fixture·격리·근거 작성의 상세 규칙은 [E2E 표준](docs/conventions/testing.md)을 따른다.

PowerShell에서 시험 전 기록할 값:

```powershell
$testSha = git rev-parse HEAD
git status --short
```

문서·근거를 커밋한 뒤 같은 터미널에서 `git diff --name-only $testSha HEAD`로 변경 범위를 확인한다. 재개한 터미널에서는 실행 기록의 시험 SHA를 다시 지정한다.
최종 근거는 `test-results/`의 임시 파일에만 남기지 않고 릴리스 커밋에 포함되는 경로에 보관한다.

## 9. 릴리스 체크리스트

- [ ] 필수/추가 요구와 실제 구현·미구현·실패·미검증 상태가 구분되어 있다.
- [ ] REQ → AC → Issue·코드 → TC → 실제 결과가 연결되어 있다.
- [ ] 보안 항목의 적용·미검증·해당 없음·예외와 이유·검토 상태가 기록되어 있다.
- [ ] AI 활용 사례와 사용자 효과에 실제 확인 근거가 있으며 예시·계획·미측정을 완료로 표시하지 않았다.
- [ ] 8종 문서의 빈 템플릿·예시 번호를 실제 내용으로 정리하고 README에서 문서·시험 결과에 접근할 수 있다.
- [ ] 코드·시험·문서·필요한 JSON·로그·스크린샷이 릴리스 커밋에 포함되어 있고 링크가 유효하다.
- [ ] 시험 SHA와 릴리스 SHA의 관계를 확인했다. 태그가 원격 저장소에서 확인된다.
- [ ] 완료한 작업에는 검증 근거가 연결되어 있고 Issue 종료 사유가 `completed`다. 취소·중복은 사유와 함께 닫았다.
- [ ] 다음 릴리스로 넘긴 Issue·AC가 project-brief와 prd에 표시되어 있다.

## 부록 A. 이벤트 모드 (해커톤 등)

마감 시각과 제출처가 정해진 행사에서는 위 절차를 그대로 쓰고 아래만 덧붙인다. 공식 일정·양식·채점 기준은 주최 측 최종 공지가 우선한다.

**사전 준비 추가**
- [ ] 사전 소스·템플릿·생성기·스킬의 반입 허용 범위를 스태프에게 확인하고 허용된 자료만 사용한다.
- [ ] 배정 저장소·계정·VPN·AI 활용 기록 도구(행사 지정)의 동작과 팀 연결을 확인한다.
- [ ] 주최 측 `docs/security-policy.md`를 수령해 공식 SEC 번호로 매핑한다.
- [ ] 제공 디자인 자료(글꼴 등)의 사용 허가가 참가자 한정이면 저장소에 넣지 않는다.

**주제 공개(T0) 후 시간표** — 팀 운영 목표다.

| 시점 | 게이트 |
|---|---|
| T0 ~ +20분 | 주제 원문을 `intent.md`에 보관, 필수 요구 추출. prd 출처는 `필수`(주제) / `추가`(팀) |
| T0+1h | G1 grilling 종료 |
| T0+1.5h | G2 spec·Issue 발행 |
| 이후 1시간 | G3 기반 머지 |
| 이후 | G4 병렬 구현·sync |

**마감 역산** (마감 = D)

| 목표 시점 | 게이트 | 할 일 |
|---|---|---|
| D − 90분 | G5 | 기능 범위 동결. 남은 요구·알려진 문제 기록 |
| D − 60분 | G6 | 최종 통합·보안·사용자 흐름 시험 결과 확보. 실패 시 수정·재검증 |
| D − 30분 | G7 | 8종의 상태·링크·근거 대조, 제출 버전 동결 |
| D − 20분 | G8 | 원격 40자 SHA 확인 → 주최 측 제출처(포털 등)에 저장. 릴리스 태그는 선택 |

**제출 체크리스트 추가**
- [ ] 8종 문서가 주최 측 양식과 채점 기준(REQ → AC → Issue·코드 → TC → 실제 결과 연결 등)을 따른다.
- [ ] A가 제출처에서 전체 40자 SHA·필수 설명을 저장하고 제출 완료 상태를 확인했다.
- [ ] 별도 마감의 발표자료를 제출하고 보관을 확인했다.

동결 후 수정이 필요하면 영향받는 시험·문서·근거를 갱신하고 새 제출 버전을 확인한다. 시간 도달만으로 검증을 완료 처리하지 않는다.
