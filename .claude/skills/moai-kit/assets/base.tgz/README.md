# Moai Kit — Next.js 풀스택 스타터

Next.js 16 (React 19) + Drizzle/SQLite 단일 앱. 제출 문서 8종은 이 README와 아래 7종이다. 진입 문서로 실행·검증 명령, 문서 지도, 증적·버전만 둔다. 요구·설계·시험 상세는 각 문서가 소유하며 여기에는 링크만 쓴다. 문서별 경계는 [PLAYBOOK](PLAYBOOK.md) §7.

| 문서 | 내용 |
|---|---|
| [project-brief](docs/project-brief.md) · [prd](docs/prd.md) | 문제·범위, REQ/AC |
| [arch](docs/arch.md) · [development](docs/development.md) | 구조, 개발 과정·AI 활용 |
| [security-compliance](docs/security-compliance.md) · [e2e-test](docs/e2e-test.md) | SEC 적용·검증, 시험 재현·결과 |
| [experience](docs/experience.md) | 사용 흐름, 효과와 한계 |
| `docs/evidence/latest.md` (시험 실행 후 생성) | 마지막 시험 실행 근거(SHA·결과) |

## 실행
```bash
npm ci
npm run db:reset      # 마이그레이션 + 합성 데이터
npm run dev           # http://localhost:3000  (user1@demo.local / Credit!23)
npm run verify        # lint + typecheck + unit + build + audit
npm run test:e2e      # 새 DB·빈 포트→빌드→기동→API/UI→근거 기록 (PW_CHANNEL=msedge 가능)
npm run evidence      # docs/evidence/latest.md 갱신
```

## 새 도메인 추가
```bash
npm run gen -- booking 예약          # 테이블·서비스·API·화면 4종·API/UI 시험 생성
# 필드 수정: src/features/bookings/schema.ts + src/server/db/schema.ts
npm run db:generate -- --name add_bookings && npm run db:migrate
```
## 규칙 문서

- 개발 규칙: [AGENTS.md](AGENTS.md) · [conventions](docs/conventions/) (통신 [communication](docs/conventions/communication.md), [API](docs/conventions/api.md), [오류](docs/conventions/errors.md), [시험](docs/conventions/testing.md), [의존성·보안](docs/conventions/dependencies.md), [lint](docs/conventions/lint.md))
- UI: [KDS 설계·사용 가이드](docs/design-system/README.md) · [컴포넌트 API](docs/design-system/components.md) · [화면 계약](docs/conventions/ui.md). 개발 서버의 `/design-system`에서 조합을 확인한다.
- 시험 결과: [E2E 문서](docs/e2e-test.md)와 `docs/evidence/`. 실행 전에는 모두 미실행이다.

## 예제 도메인

`moai-kit init --example`로 만든 경우에만 포함된다(요청·승인 `/requests`, 공개 메모 `/publicNotes`, 회의실 예약). 예제 원본은 `.claude/skills/moai-kit/references/examples/`에 있다. 예제를 지울 때는 시험 파일과 [E2E 문서](docs/e2e-test.md) §2의 `예시` 행을 함께 지운다.
