# 아키텍처

구현 구조와 그 이유를 적는 문서다. 요구·권한 본문은 [prd](prd.md), 시험 결과는 [e2e-test](e2e-test.md), 변경 과정은 [development](development.md)가 소유하며 여기에는 현재 설계만 둔다.

구현 규칙은 [AGENTS.md](../AGENTS.md)와 [conventions](conventions/)가 원본이다. 이 문서는 이 프로젝트의 실제 구성·데이터·API·화면과 기술 결정만 적는다.

## 구성
```
브라우저 ──(HTML/RSC)── Next.js 16 App Router (단일 프로세스)
   │ Client Component: useMutation → apiClient ──JSON──▶ /api/v1/** Route Handler ─ api() 래퍼(인증·Origin·에러 변환)
   │ Server Component(page) ───────────────────────────────▶ features/<x>/service.ts (권한=policy, audit)
   ▼                                                                    │ Drizzle ORM
 쿠키 sid(httpOnly) ── sessions 테이블                                    ▼
                                                                   SQLite (data/dev.db)
```
| 계층 | 위치 | 책임 |
|---|---|---|
| 화면 | src/app/(app)/**/page.tsx | 로그인 확인, service 직접 호출(읽기), 권한 결과를 props 로 전달 |
| UI | src/components/ui | 디자인 시스템(KDS 2.0 `kds-*` 클래스 래퍼, 원본 CSS·아이콘은 public/kds) |
| API | src/app/api/v1/** | REST 계약, 입력 파싱(zod), 표준 응답·에러 봉투 |
| 도메인 | src/features/<x>/ | schema(입력·DTO) · policy(권한 순수함수) · service(DB·감사) |
| 인프라 | src/server/{db,http,auth} | DB 연결, 세션, 에러 변환 |

## 기술 선택과 이유
| 선택 | 이유 |
|---|---|
| Next.js 단일 앱(프론트+API) | React 필수 조건 충족, 배포·기동 명령 1개, 재현 쉬움 |
| Drizzle + SQLite(libsql) | 사내망에서 외부 다운로드·C++ 컴파일 없이 설치(Prisma 엔진·better-sqlite3 빌드 차단 리스크 회피), 파일 1개로 초기화 |
| 세션 쿠키(DB) | 서버에서 즉시 무효화 가능, 토큰은 해시로만 저장 |
| Cache Components 비활성 + force-dynamic | 저장 직후 화면 반영 보장(캐시 무효화 버그 제거) |

## 데이터 · API · 화면

요구 확정 후 채운다. 데이터는 엔티티·FK, API는 `METHOD /api/v1/<path>` · 목적 · 권한 · REQ([api](conventions/api.md)), 화면은 경로 · 역할 · REQ.

## 주요 흐름
(요구 확정 후 핵심 흐름 1~2개를 순서도로: 예) 등록 → 목록 → 승인 → 상태 반영)
