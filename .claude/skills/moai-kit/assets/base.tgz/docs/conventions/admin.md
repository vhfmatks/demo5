# 관리자 포털 (/admin)

사용자 화면 `(app)`과 분리된 관리자 영역. 접근·메뉴·기능은 역할이 아니라 권한으로 결정한다([RBAC](rbac.md)). 권한이 없으면 화면 404, API 403(`AUTH_PERMISSION_REQUIRED`), 비로그인은 로그인 이동/401. 진입점은 상단 메뉴가 아니라 `/me`(내 정보)의 "관리자 포털" 링크(`admin.access`)다.

| 화면 | 경로 | 기능 | 코드 |
|---|---|---|---|
| 개요 | `/admin` | 역할별 사용자 수 · 점검 모드 · 최근 감사로그 | `app/admin/page.tsx` |
| 사용자 | `/admin/users` | 검색 · 역할 변경(즉시 적용, 본인 불가) | `features/users/` |
| 회의실 | `/admin/rooms` | 등록 · 수정 · 사용 중지/재개(삭제 없음). 이름 중복 409, 예정 예약이 있으면 중지·인원 축소 409 | `features/rooms/` |
| 역할·권한 | `/admin/roles` | 역할 설명 · 역할×권한 매트릭스(읽기 전용) | `lib/permissions.ts` |
| 감사로그 | `/admin/audit` | 행위(접두어)·대상·수행자·기간(Asia/Seoul) 필터 | `features/auditLogs/` |
| 설정 | `/admin/settings` | 운영 설정 변경 → 즉시 적용 · 변경분 감사로그 | `features/settings/` |

API: `GET|POST /api/v1/admin/rooms` · `GET|PATCH /api/v1/admin/rooms/{id}` · `GET /api/v1/admin/auditLogs` · `GET|PATCH /api/v1/admin/settings` · `GET /api/v1/admin/users` · `PATCH /api/v1/admin/users/{id}` `{role}`

## 색상

관리자 포털은 사용자 화면과 구분되도록 **KDS 공식 `dark` 모드**를 `src/app/admin/layout.tsx` 의 최상위 요소(`data-mode="dark"`)에만 적용한다. 토큰 값만 바뀌므로 hex·새 색 정의를 하지 않는다. `globals.css` 의 `--ds-*` 가 `:root, [data-mode]` 에 선언돼 있어 `bg-surface`·`text-muted` 같은 유틸도 모드를 따른다. KT 로고는 원본 SVG 를 그대로 두고 다크 영역에서만 CSS 필터로 반전한다.

## 공통 부품 (새 관리 기능에 그대로 사용)

| 부품 | 사용 |
|---|---|
| 화면 가드 | `const user = await requirePermission("<권한>")` — 권한 없으면 404 |
| API 가드 | `api(fn, { permission: "<권한>" })` |
| service 강제 | `assertPermission(actor, "<권한>")` (`@/server/auth/session`) |
| 메뉴 | `src/app/admin/nav.ts` 의 `ADMIN_NAV` 에 `{ href, label, permission }` 한 줄 (권한 없으면 숨김) |
| 레이아웃 | `src/app/admin/layout.tsx` 가 GNB·로그아웃·사용자 화면 이동을 제공 |
| 감사로그 | 서비스 쓰기에서 `audit(actor.id, "<entity>.<action>", entity, id, detail, tx)` → `/admin/audit` 에 자동 표시 |
| 설정 읽기 | 어디서든 `(await getSettings()).<key>` (요청당 1회 조회) |

AI 공급자·모델 등록·시험은 관리자 포털 > AI (`ai.manage`). 규칙과 기능 코드 사용법은 [ai.md](ai.md).

## 새 관리 화면 추가

1. 도메인은 평소처럼 `npm run gen -- <entity> <라벨>` 로 만든다.
2. 화면을 `src/app/admin/<xs>/` 로 옮기고 `requireUser()` → `requirePermission("<권한>")`, 링크 경로 앞에 `/admin` 을 붙인다.
3. `lib/permissions.ts` 에 권한을 추가하고 route `{ permission }`·service `assertPermission` 으로 강제한다.
4. `ADMIN_NAV` 에 메뉴를 추가하고 `(app)/nav.ts` 에 생성된 항목은 지운다.

## 운영 설정 추가

`features/settings/schema.ts` 의 `SETTING_FIELDS` 에 `{ label, hint, schema, default }` 한 줄. 마이그레이션·폼 수정은 필요 없다(입력 종류는 default 타입: 문자열·불리언·숫자).
저장값이 스키마와 맞지 않으면 기본값으로 동작한다. 비밀값(키·토큰)은 설정이 아니라 `.env` 에 둔다.

| 설정 | 적용 위치 |
|---|---|
| `noticeBanner` | `(app)`·`(public)` layout 상단 `SettingsNotice` |
| `maintenanceMode` | `server/http/handler.ts` — `maintenance.bypass` 권한 외 쓰기 503 `SETTINGS_MAINTENANCE_MODE` (로그인·로그아웃 제외) |
| `sessionTtlHours` | `server/auth/session.ts` `createSession()` — 새 로그인부터 |

시험: `tests/unit/admin.service.test.ts` · `TC-ADMIN-API-001~005` · `TC-ADMIN-UI-001~003`. 설정은 전역 상태이므로 E2E 는 `finally` 에서 기본값으로 되돌린다.
