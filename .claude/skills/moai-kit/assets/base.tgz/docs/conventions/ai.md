# AI 기능 (공급자 → 모델 → 사용)

관리자가 공급자와 모델을 **시험한 뒤 등록**하고, 기능 코드는 등록된 모델을 이름으로 부른다. 키는 코드·`.env`가 아니라 관리자 화면에 넣는다.

| 단계 | 위치 | 동작 |
|---|---|---|
| 1. 공급자 시험·등록 | 관리자 포털 > AI (`ai.manage`, ADMIN) | 종류(OpenAI 호환 · Anthropic)·주소·키 → [연결 테스트] = 모델 목록 조회 → [등록] = 서버가 **다시 시험**하고 통과해야 저장 |
| 2. 모델 시험·등록 | 같은 화면 | 공급자 선택 → 모델 ID 제안 → [모델 시험] = 짧은 질문·응답·시간 → [등록] = 다시 시험 후 저장. 첫 모델은 기본, 기본은 하나 |
| 3. 사용 | `features/<x>/service.ts` | `aiComplete`(글) · `aiJson`(zod 검증 객체), 기본 모델 또는 호출 이름(`model: "요약"`) |

- OpenAI 호환 = OpenAI · Ollama(`http://localhost:11434/v1`) · vLLM · LM Studio · OpenRouter 등 `/models`·`/chat/completions` 를 주는 서버. Anthropic = `/v1/models`·`/v1/messages`.
- 코드: 화면 `app/admin/ai/page.tsx`, 기능 `features/ai/`(schema·client 어댑터·service), 외부 호출 `server/outbound.ts`, 키 암호화 `server/secret.ts`.

## 기능에서 쓰기

```ts
// service.ts — 다른 feature 의 service 는 import 할 수 있다
import { aiJson } from "@/features/ai/service";

const Suggestion = z.object({ category: z.enum(REQUEST_CATEGORIES), reason: z.string().max(200) });

export async function suggestCategory(actor: SessionUser, input: SuggestInput) {
  return aiJson(actor, {
    feature: "request.suggest",                       // 감사로그 구분
    system: `분류: ${REQUEST_CATEGORIES.join(", ")} 중 하나`,
    prompt: `제목: ${input.title}\n내용: ${input.description}`,
    schema: Suggestion,                               // 형식이 틀리면 502
    maxTokens: 300,
  });
}
// route: export const POST = api(async ({ req, user }) => ok(await suggestCategory(user, await body(req, SuggestInput))));
```

- 화면은 서버에서 `aiAvailable()`(기본 모델 있음)로 버튼을 보일지 정한다. 결과는 **제안**으로 보여 주고 사용자가 확인·수정해 저장한다.
- `aiComplete`는 기존 `{ text, model, ms }`에 `meta: { callId, providerId, modelId, inputTokens, outputTokens }`를 덧붙인다. `callId`는 서버가 생성한 UUID다. `aiJson<T>`는 검증된 데이터만 반환하는 계약을 유지한다.
- 서버 호출 옵션은 `timeoutMs` 정수 1000~60000ms(기본 60000), `maxTokens` 정수 1~4096(기본 1024), prompt+system 합계 16000자 이하다. `aiJson`이 덧붙이는 JSON 지시도 입력 한도에 포함한다. 잘못된 옵션은 외부 호출 전에 거부한다. 글자 수는 컨텍스트 토큰 수가 아니며, 출력 토큰 요청 상한은 공급자의 준수나 정확한 비용을 보장하지 않는다.

## 규칙

| 항목 | 규칙 |
|---|---|
| 출력 신뢰 | AI 출력은 사용자 입력과 같다. 권한·상태 판단·SQL·HTML 로 쓰지 않는다. 구조가 필요하면 `aiJson` + zod, 화면에는 글자로만 보인다 |
| 프롬프트 주입 | 사용자 글은 `prompt` 안 구분된 칸(`제목: …`)에 넣고 지시는 `system` 에 둔다. 다른 사용자의 자료를 프롬프트에 넣을 때는 조회 권한(policy)을 먼저 확인한다 |
| 개인정보 | 프롬프트에 필요한 필드만 넣는다. 외부 공급자로 나가면 `lib/mask` 로 가린다. 대회 정책상 외부 전송이 금지면 로컬 모델(Ollama)을 등록한다 |
| 오류 | 미등록 503 `AI_NOT_CONFIGURED`, 공급자 오류 502 `UPSTREAM_ERROR`, 시간 초과 504, 사용자당 분당 20회 초과 429. 관리자 시험만 원인(HTTP 401·404 등)을 보여 준다 |
| 기록 | 실제 호출의 최종 결과를 `ai.call`로 한 번 기록한다. callId·feature·공급자 ID·실제 모델 ID/label·ok·ms·사용량·실패 분류를 남긴다. JSON 파싱/스키마 실패는 성공으로 기록하지 않는다. 사용량 미제공은 null이며 프롬프트·응답·키·공급자 오류 원문은 남기지 않는다. callId는 HTTP 오류 traceId와 별개다. 옵션 위반·호출 제한·미설정·키 복호화 실패처럼 공급자 호출 전 실패는 ai.call 대상이 아니며 기존 오류 계약으로 처리한다 |
| 키 | AES-256-GCM 암호화 저장, 화면·응답은 끝 4자리. 암호화 키 `APP_SECRET`(없으면 DB 옆 `app-secret.key`, git 제외). 키를 바꾸면 공급자를 다시 등록한다 |
| 주소 | https 만, http 는 localhost·127.0.0.1(로컬 모델). 계정·query 포함 주소 거부, 리다이렉트 따라가지 않음, 시간 제한·응답 2MB 상한(`server/outbound.ts`) |

## 사내 Gateway

- 별도 Gateway 종류를 만들지 않는다. 관리자 화면에서 기존 OpenAI 호환 또는 Anthropic 종류와 HTTPS `baseUrl`·키를 등록한다. 경로 prefix가 있는 주소도 해당 규격의 endpoint가 있어야 한다.
- 등록은 모델 목록 조회를 요구한다. `/models` 또는 `/v1/models`가 없는 Gateway는 현재 등록 흐름에서 지원하지 않는다. 채팅만 되는 서버를 연결 가능하다고 주장하지 않는다.
- 키 암호화·서버 재시험·리다이렉트 거부·응답 2MB 제한을 그대로 적용한다. 사설 HTTP 허용·임의 인증 헤더·mTLS·사내 CA 설치를 자동 지원하지 않는다. 실제 사내 Gateway 인증서/네트워크/인증은 배포 환경에서 별도 검증한다.
- 사용자당 분당 20회 제한은 단일 프로세스 메모리 기준이다. 다중 서버의 통합 제한·부서 예산·정확한 과금·자동 대체 모델 기능은 제공하지 않는다.

## 안전한 수행계획 예제

- `init --example`의 요청 예제에서만 제공한다. 현재 해커톤 앱의 요청 도메인과 상태·권한·필드가 다르므로 예제 파일을 기존 앱에 통째로 덮어쓰지 않는다.
- 저장된 요청의 제목·내용과 정수 version을 기준으로 수행계획을 생성한다. 서버는 생성 전후 작성자·대기 상태·version을 검사한다. AI는 업무 상태나 확정값을 바꾸지 않는다.
- 초안은 별도 미리보기다. 사람이 명시적으로 편집칸에 반영하고 수정·저장한다. 저장은 권한과 version을 다시 검사하며 변경·감사를 같은 transaction으로 처리한다. 오래된 초안은 409로 거부한다. 계획 원문은 감사에 기록하지 않는다.
- AI 미설정·장애 시에도 수동 작성과 저장이 가능하다. 임의 코드·도구 실행, 범용 승인, 장시간 실행은 제공하지 않는다.
- 사용자 내용을 system 지시와 분리하는 것은 최소 방어이지 prompt injection의 완전한 방어가 아니다. 실제 기업 데이터 전송은 별도 정책 승인 없이는 검증하지 않는다.

## 시험

- 외부 키 없이 `tests/ai-mock.ts` 가짜 공급자(OpenAI 호환·Anthropic, 키 `MOCK_AI_KEY`, 모델 `missing` = 404, `/redirect/**` = 302)를 띄운다. 프롬프트에 "JSON" 이 있으면 `startMockAi(reply)` 의 객체를 JSON 으로 돌려준다(`aiJson` 의 system 지시에 들어 있다).
- E2E 는 `test.beforeAll` 에서 띄우고 관리자 API 로 공급자·모델을 등록한 뒤 기능을 부른다. 끝나면 공급자를 삭제한다(기본 모델이 남지 않게).
- 예: `tests/e2e/ai.api.spec.ts`(등록 흐름·권한·주소), `tests/unit/ai.service.test.ts`(aiComplete·aiJson·오류·호출 제한).
