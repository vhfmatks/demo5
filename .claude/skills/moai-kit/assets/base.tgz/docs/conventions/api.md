# API Route 표준

통신 흐름은 [communication.md](communication.md), 세부 오류는 [errors.md](errors.md), 검증은 [testing.md](testing.md).

## 1. 경로와 성공 응답

| 동작 | 메서드 · 경로 | 응답 |
|---|---|---|
| 목록 | GET `/api/v1/<xs>` | 200 `{data:[],meta:{page,pageSize,total}}` |
| 상세 | GET `/api/v1/<xs>/{id}` | 200 `{data}` |
| 생성 | POST `/api/v1/<xs>` | 201 `{data}` |
| 부분 수정 | PATCH `/api/v1/<xs>/{id}` | 200 `{data}` |
| 삭제 | DELETE `/api/v1/<xs>/{id}` | 204, 본문 없음 |
| 상태 전이 | POST `/api/v1/<xs>/{id}/transition` | 200 `{data}` |
| 집계 | GET `/api/v1/<xs>/stats` | 200 `{data}` |
| 내보내기 | GET `/api/v1/<xs>/export` | 200 파일(`download("이름.csv", toCsv(rows, columns))`). 목록과 같은 query·권한 범위 |
| 가져오기 | POST `/api/v1/<xs>/import` (multipart `file`) | 201 `{data:{created}}`. 한 행이라도 틀리면 400 전부 거부(`fieldErrors["3행 분류"]`) |

현재 생성기는 복수 camelCase 경로를 사용한다. JSON 필드는 camelCase, 날짜는 ISO 문자열, ID는 UUID다.
`PUT` 대신 PATCH를 사용한다. 로그인은 POST 200, 로그아웃은 POST 204인 세션 동작이다.
모든 래퍼 응답은 `X-Trace-Id` · `Cache-Control: no-store`를 포함한다. 응답 데이터는 service의 DTO만 사용한다.
미등록 경로·미지원 메서드는 Next 기본 404/405 응답이다. 이 응답까지 JSON 봉투를 보장하지 않는다.

## 2. Route 작성 계약

- `export const runtime = "nodejs"`와 `export const METHOD = api(...)`를 사용한다.
- Route는 HTTP 파싱 → service 호출 → 응답 헬퍼만 담당한다. DB·ORM·업무 분기·직접 try/catch·직접 Response 생성은 넣지 않는다.
- 기본 인증은 required다. 공개 API에만 메서드별 `{auth:"public"}`을 선언한다.
- 동적 경로는 `{params:IdParams}`로 검증한다. UUID 형식 오류는 400, 올바른 UUID의 없는 자료·볼 권한 없는 자료는 404다.
- 입력은 기능 `schema.ts`, 권한·상태는 `policy.ts`, 데이터·감사·실제 권한 강제는 `service.ts`에 둔다.
- `permission:"audit.read"`는 공통 권한 제한이다([RBAC](rbac.md)). 역할로 제한하지 않는다. 소유자·상태·세부 업무 권한은 반드시 service에서 확인한다.
- 파일 응답은 `download()`(handler)만 쓴다. 내용은 `@/lib/csv` `toCsv()` — 엑셀용 BOM·수식 주입(`=` `+` `-` `@` 시작 셀) 무력화가 들어 있다. 개인정보 열은 `@/lib/mask`로 가린다.
- 파일 업로드는 `upload(req, { extensions })`(handler)만 쓴다. 표(.csv/.xlsx)는 service 에서 `@/server/import` `readTable` → `parseRows` 로 읽는다(아래 예). 화면은 `@/components/app/ImportForm`.
- 세션 쿠키를 지우는 auth route는 인증 인프라 호출을 허용한다. 일반 도메인 route는 HTTP 래퍼·기능 schema/service만 import한다.

```ts
import { api, body, created, IdParams, ok } from "@/server/http/handler";
import { CreateBookingInput, UpdateBookingInput } from "@/features/bookings/schema";
import { createBooking, updateBooking } from "@/features/bookings/service";

export const runtime = "nodejs";
// collection route.ts
export const POST = api(async ({ req, user }) =>
  created(await createBooking(user, await body(req, CreateBookingInput))));
// [id]/route.ts
export const PATCH = api<{ id: string }>(async ({ req, params, user }) =>
  ok(await updateBooking(user, params.id, await body(req, UpdateBookingInput))),
{ params: IdParams });
// 공개 route: 같은 래퍼에 auth:"public"을 추가하고 service는 SessionUser | null을 받는다.
```

가져오기(엑셀·CSV 업로드):

```ts
// import/route.ts
export const POST = api(async ({ req, user }) =>
  created(await importBookings(user, await upload(req, { extensions: [".csv", ".xlsx"] }))));
// service.ts — 머리행 이름 → 필드, 생성 스키마로 행마다 검사, 한 트랜잭션에 일괄 insert + 감사 1건
const IMPORT_COLUMNS: ImportColumn[] = [
  { header: "제목", key: "title" },
  { header: "분류", key: "category", value: fromLabel(CATEGORY_LABEL) }, // "장비" 또는 "EQUIPMENT"
  { header: "금액", key: "amount", value: toNumber, optional: true },     // "1,000" → 1000, 열이 없으면 기본값
];
export async function importBookings(actor: SessionUser, file: File) {
  const items = parseRows(await readTable(file), IMPORT_COLUMNS, CreateBookingInput);
  await db.transaction(async (tx) => {
    await tx.insert(bookings).values(items.map((i) => ({ ...i, ownerId: actor.id }))).run();
    await audit(actor.id, "booking.import", "booking", null, { count: items.length }, tx);
  });
  return { created: items.length };
}
```

- 엑셀 날짜·일시 서식 셀은 `YYYY-MM-DD`·`YYYY-MM-DDTHH:mm`(gen `date`·`datetime` 형식), 불리언은 `TRUE`/`FALSE`, 수식은 저장된 계산값으로 읽힌다. 첫 시트만 읽는다.
- `ref` 필드는 파일에 이름이 오므로 `value` 에서 이름 → id 로 바꾼다(대상 목록을 먼저 읽어 Map). 중복 검사·정제(공백·전각 등)도 `value` 또는 스키마에서 한다.
- 행 수가 1,000을 넘거나 같은 파일을 나눠 올려야 하면 `MAX_IMPORT_ROWS` 와 insert 묶음(SQLite 변수 한도 32,766개 ÷ 열 수)을 같이 조정한다.

소스 예제: [인증 API](../../src/app/api/v1/requests/route.ts) · [공개 API](../../src/app/api/v1/publicNotes/route.ts) · [공통 래퍼](../../src/server/http/handler.ts).

## 3. 입력·출처·보안

| 입력 | 규칙 | 거부 |
|---|---|---|
| 쓰기 Origin | GET/HEAD 외에는 필수. scheme·host·port 전체 일치 | 403 `HTTP_ORIGIN_REQUIRED` / `HTTP_INVALID_ORIGIN` / `HTTP_ORIGIN_REJECTED` |
| 신뢰 출처 | `APP_ORIGIN`의 경로 없는 http(s) origin. 미설정 시 현재 요청 URL origin | 배포·프록시 환경에서는 실제 HTTPS 주소를 설정 |
| 본문 형식 | `body()`는 `application/json`, charset 파라미터 허용 | 415 `HTTP_CONTENT_TYPE_UNSUPPORTED` |
| JSON 크기 | 64KiB. Content-Length와 실제 읽은 바이트를 확인 | 413 `HTTP_PAYLOAD_TOO_LARGE` |
| JSON 문법·UTF-8 | 엄격하게 파싱 | 400 `HTTP_INVALID_JSON` |
| 파일 업로드 | `upload()`는 `multipart/form-data`, 파일 5MB(기본, 실제 읽은 바이트로 확인)·확장자 | 415 · 413 `HTTP_PAYLOAD_TOO_LARGE` · 400 `fieldErrors.file` |
| 표 파일 | `readTable()` .csv(UTF-8, 실패 시 CP949)·.xlsx 첫 시트. 1,000행·100열·압축 해제 30MB 상한, .xls 거부 | 400 `fieldErrors.file` |
| 가져오기 행 | `parseRows()` 머리행 필수 열·행마다 생성 스키마 | 400 `fieldErrors["<행>행 <열>"]`, 저장 없음 |
| 생성·수정·로그인 필드 | `z.strictObject`, 허용되지 않은 키 거부 | 400 `VALIDATION_ERROR` |
| PATCH | 생략 필드 유지, 생성 기본값 분리, 빈 변경 거부 | 400 `VALIDATION_ERROR` |
| 목록 query | page 1 · pageSize 10, 최대 100. 잘못된 필터·페이지는 스키마의 기본값으로 보정 | 스키마에 명시된 정책 |

Origin은 인증 수단이 아니다. API 소비자는 세션과 올바른 Origin을 함께 보내야 한다.
`APP_ORIGIN=https://example.com`처럼 설정한다. 마지막 `/`, 경로·쿼리·userinfo를 넣지 않는다.
공개 쓰기도 Origin·JSON 검사를 적용한다. 로그인 실패는 계정 존재 여부를 구분하지 않는다.
쿠키는 서버에서 설정하고 클라이언트에 토큰을 복제하지 않는다. `INSECURE_COOKIE=1`은 격리된 로컬 E2E에만 사용한다.
쓰기·감사로그는 같은 트랜잭션이며 상태/version 조건을 실제 UPDATE/DELETE에 포함한다.
호출 제한·외부 서비스 timeout·업로드·idempotency는 해당 기능 spec에 맞춰 추가한다.

## 4. 실패와 클라이언트

실패 봉투: `{error:{code,category,message,traceId,retryable,fieldErrors?,issues?,retryAfterSeconds?}}`.
category가 HTTP 상태를 결정하고 code는 세부 원인이다. 문자열 메시지로 분기하지 않는다.
검증 실패는 필드·경로·규칙 정보를 제공하고, 5xx는 승인된 공개 메시지만 사용한다.
HTTP 예외를 route에서 다시 catch하지 않는다. 예상 DB 제약·외부 서비스 실패만 service에서 도메인 오류로 변환한다.
Client는 `useMutation` · `apiClient`를 사용하며 변경 성공 후 서버 화면을 갱신한다. 쓰기를 자동 재시도하지 않는다.

## 5. 강제 검사와 완료 조건

`npm run lint`는 Biome 뒤에 `lint:contracts` AST 검사를 실행한다.
HTTP 메서드의 api 래퍼·nodejs runtime·동적 params 선언·import 경계·route 업무 분기를 검사한다.
이 검사는 정적 작성 규칙의 검사이며 인증·권한·데이터 무결성의 실제 동작은 E2E로 확인한다.
새 API의 정상 응답·입력 실패·인증/권한 거부·거부 후 값 불변·상태/version 충돌을 [E2E 표준](testing.md)에 따라 확인하고 AC에 연결한다.

출처 정책은 [OWASP의 Origin 검증](https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html#using-standard-headers-to-verify-origin)을 참고했다.
