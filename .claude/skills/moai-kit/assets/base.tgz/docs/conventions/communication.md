# Next.js 프론트엔드 · 백엔드 통신과 CRUD

이 kit는 Next.js 단일 앱에서 Server Component 조회와 REST 쓰기를 사용한다.
인증 예제는 [requests](../../src/features/requests/), 공개 예제는 [publicNotes](../../src/features/publicNotes/)다.

## 1. 통신 경로

```mermaid
flowchart LR
  Page[Server Component] --> Session[서버 세션 확인]
  Session --> Service[도메인 service]
  Service --> DB[(DB)]
  Service --> DTO[직렬화 가능한 DTO]
  DTO --> UI[화면 렌더링]
  Form[Client Form · Actions] --> Mutation[useMutation · apiClient]
  Mutation --> Route[REST · api 래퍼]
  Route --> Validate[세션 · Origin · Zod]
  Validate --> Service
  Service --> Tx[변경 · 감사로그 트랜잭션]
  Tx --> DB
  Route --> Response[성공 · 오류 봉투]
  Response --> Mutation
  Mutation --> Refresh[router.refresh · 페이지 이동]
  Refresh --> Page
```

| 상황 | 시작 위치 | 사용할 방법 |
|---|---|---|
| 목록·상세·URL 검색·페이지 이동 | Server page | 세션 확인 → query 스키마 → service 직접 호출 |
| 등록·수정·삭제·상태 전이 | Client Form / Actions | `useMutation` → `apiClient` → REST |
| 정상 변경 후 최신 데이터 | Client | `router.refresh()` 기본 동작. 필요하면 `onSuccess`에서 상세·목록으로 이동 |
| REST를 직접 사용하는 외부 소비자 | HTTP | 동일한 `/api/v1/**` 계약과 세션·권한 적용 |

Server Component에서 자기 `/api/v1`을 fetch하지 않는다. 서버 service를 클라이언트에 import하지 않는다.
page·layout·Table·Filters는 Server로 유지하고, 이벤트·상태가 필요한 Form·Actions에만 `"use client"`를 붙인다.

## 2. 책임과 데이터 계약

| 위치 | 책임 |
|---|---|
| `features/<x>/schema.ts` | 공유 enum·필드 검증·생성/수정 입력·조회 query·DTO |
| `features/<x>/policy.ts` | 소유자·역할·상태 또는 명시적인 공개 범위 |
| `features/<x>/errors.ts` | 세부 오류 code·공통 category·공개 메시지 |
| `features/<x>/service.ts` | 정책 강제·업무 조건·DB·트랜잭션·감사·DTO |
| `app/api/v1/**/route.ts` | 인증 모드 선택·입력 파싱·service 호출·응답 헬퍼 |
| Server page | 인증/선택적 세션·service 조회·표시할 권한 계산 |
| Client Form / Actions | 입력 수집·변경 요청·대기/오류 표시·성공 후 이동 |

- 날짜는 ISO 문자열, ID는 문자열, JSON 필드는 camelCase. DB 행을 그대로 반환하지 않는다.
- Server → Client에는 DTO·문자열·boolean·배열 등 직렬화 가능한 값만 전달한다.
- actor·ownerId·role을 클라이언트가 결정하지 않는다. actor는 서버 세션, 소유자는 service에서 정한다.
- 입력 검증은 공유 Zod 스키마를 서버에서 수행한다. 클라이언트에 다른 검증 규칙을 복제하지 않는다.
- `formValues()`는 문자열 중심 폼에 사용한다. 숫자·checkbox·다중값·파일은 별도 입력 변환 계약이 필요하다.
- 생성 기본값과 PATCH 필드는 분리한다. PATCH 생략 필드는 유지하고 빈 문자열은 명시적으로 비운다. 빈 PATCH는 400이다.
- 쓰기와 감사로그는 같은 tx를 사용한다. `audit(actorId, action, entity, id, detail, tx)`로 연결한다.

## 3. 인증 포함 · 불포함

| 항목 | 인증 CRUD: 요청 | 공개 CRUD: 메모 |
|---|---|---|
| 화면 | `(app)/requests/**` | `(public)/publicNotes/**` |
| API | `/api/v1/requests/**` | `/api/v1/publicNotes/**` |
| Route 설정 | `api(fn)`의 기본 required | 모든 메서드에서 `api(fn, {auth:"public"})` 명시 |
| Server page | `requireUser()` | 필요할 때 `getCurrentUser()`; null이어도 조회 가능 |
| service actor | `SessionUser` | `SessionUser | null` |
| 데이터 범위 | 일반 사용자는 본인 자료, 직원 역할은 정책 범위 | 모든 사용자가 같은 메모를 조회·수정·삭제 |
| 감사 actorId | 현재 사용자 ID | 로그인 사용자 ID 또는 익명 null |
| 추가 무결성 | 수정·삭제·전이 시 허용 상태 조건 | 수정·삭제 시 읽었던 `version` 조건 |

`auth: "public"`은 로그인 필수 검사를 해제한다. Origin 검사·입력 검증·service 정책·에러 변환은 계속 적용된다.
공개 메모는 작성자별 소유권이 없는 공유 CRUD 예제다. 공개 조회·인증 쓰기 방식은 HTTP 메서드별 auth와 service 정책을 함께 설계한다.

### 로그인과 인증 실패

1. `/login`의 Client Form이 `POST /api/v1/auth/login`에 이메일·비밀번호 JSON을 보낸다.
2. 서버가 확인하고 `httpOnly` 세션 쿠키를 설정한다. 클라이언트는 쿠키·토큰을 직접 저장하거나 Authorization 헤더에 복제하지 않는다.
3. `apiClient`의 `credentials: "same-origin"`으로 같은 앱 요청에 세션 쿠키가 전달된다.
4. 보호 API에서 세션을 사용할 수 없으면 401 `AUTH_REQUIRED`, 로그인 실패는 401 `AUTH_INVALID_CREDENTIALS`다.
5. `useMutation`은 UNAUTHENTICATED category를 `/login` 이동으로 처리한다. 로그인 화면에서는 실패 메시지를 표시한다.
6. Server page의 `requireUser()`는 비로그인 사용자를 `/login`으로 보낸다. API는 HTML 로그인 이동 대신 JSON 401을 반환한다.

볼 수 없는 자료는 존재하지 않는 자료와 같은 404 코드다. 이미 볼 수 있지만 행위가 금지되면 403, 상태·version 충돌이면 409다.

## 4. 인증 CRUD 예제

실제 소스: [collection route](../../src/app/api/v1/requests/route.ts), [item route](../../src/app/api/v1/requests/[id]/route.ts), [service](../../src/features/requests/service.ts), [form](../../src/features/requests/components/RequestForm.tsx).

```ts
// 보호 API: user는 api()에서 확인한 SessionUser다.
export const POST = api(async ({ req, user }) =>
  created(await createRequest(user, await body(req, CreateRequestInput))),
);
export const PATCH = api<{ id: string }>(async ({ req, params, user }) =>
  ok(await updateRequest(user, params.id, await body(req, UpdateRequestInput))),
);
```

```tsx
// Server page: 세션과 데이터 조회를 서버에서 처리한다.
const user = await requireUser();
const request = await load(getRequest(user, (await params).id));
return <RequestForm initial={request} />;
```

```ts
// Client Form: 권한은 서버가 강제한다. 여기서는 요청·결과 표시만 수행한다.
const m = useMutation((values: Record<string, string>) => initial
  ? apiClient.patch<RequestDto>(`/api/v1/requests/${initial.id}`, values)
  : apiClient.post<RequestDto>("/api/v1/requests", values),
{ onSuccess: (row) => router.push(`/requests/${row.id}`) });
// onSubmit: preventDefault() → m.run(formValues(form))
// UI: loading={m.pending}, Alert에 m.error, Field에 m.fieldErrors.title
```

service는 policy를 확인한 뒤 실제 UPDATE·DELETE에도 상태 조건을 포함한다.
업무 쓰기·감사·반환할 DTO 조회를 같은 `db.transaction`에서 수행한다.

## 5. 공개 CRUD 예제

실제 소스: [collection route](../../src/app/api/v1/publicNotes/route.ts), [item route](../../src/app/api/v1/publicNotes/[id]/route.ts), [service](../../src/features/publicNotes/service.ts), [form](../../src/features/publicNotes/components/PublicNoteForm.tsx), [actions](../../src/features/publicNotes/components/PublicNoteActions.tsx).

```ts
// user는 SessionUser | null이다. 익명이어도 service를 실행한다.
export const POST = api(async ({ req, user }) =>
  created(await createPublicNote(user, await body(req, CreatePublicNoteInput))),
{ auth: "public" });
```

```tsx
// 공개 Server page: requireUser()를 사용하지 않는다.
const actor = await getCurrentUser();
const note = await load(getPublicNote(actor, (await params).id));
return <PublicNoteForm initial={note} />;
```

```ts
// Client 변경: 쿠키가 없어도 같은 API client를 사용한다.
apiClient.post<PublicNoteDto>("/api/v1/publicNotes", { title: "합성 메모", memo: "공유 예제" });
apiClient.patch<PublicNoteDto>(`/api/v1/publicNotes/${note.id}`, { title: "수정 제목", version: note.version });
apiClient.del(`/api/v1/publicNotes/${note.id}?version=${note.version}`);
```

PATCH는 현재 version과 맞으면 1을 증가시키고 변경된 DTO를 반환한다. DELETE도 같은 조건으로 실행한다.
대상이 없으면 404 `PUBLIC_NOTE_NOT_FOUND`, 대상은 있지만 version이 다르면 409 `PUBLIC_NOTE_VERSION_CONFLICT`다.
성공한 수정 이후 재수정·삭제에는 새 DTO의 version을 사용한다. 오래된 화면은 새로고침 후 다시 시도한다.
버전은 변경 감지용이며 인증·소유권·호출 제한을 대신하지 않는다.

## 6. REST와 오류 응답

경로·메서드·성공 응답 표는 [API 표준 §1](api.md)이 원본이다. 공개 예제는 PATCH 본문과 DELETE query에 `version`을 포함한다.
브라우저의 API client는 `/api/v1/**` 상대 경로만 허용하고 성공 응답의 data를 반환한다. 목록 meta는 Server page가 service의 결과로 받아 Pagination에 전달한다.
HTTP 상태는 오류 [category](errors.md)가 결정하며 code는 세부 원인이다. 응답 봉투와 예시는 [오류 계약](errors.md)을 따른다.
검증 오류는 fieldErrors·issues를 제공한다. UI는 message를 표시하고 동작은 `m.failure?.code/category`로 판단한다.
5xx 원인·스택·DB 정보는 공개하지 않는다. retryable만으로 쓰기 요청을 자동 재시도하지 않는다.

## 7. 재사용 · 실행

```powershell
# 인증 모듈이 기본값. 시험이 필요하지 않으면 --skip-tests.
npm run gen -- booking '예약' --skip-tests
# 공개 CRUD: 별도 정책·version·API/UI 시험 포함
npm run gen -- publicItem '공개 항목' --auth=public
npm run db:generate -- --name add_public_items
npm run db:migrate
```

새 모듈은 필드·DTO·폼·policy·오류·업무 조건을 실제 프로젝트에 맞게 바꾼다. 처음부터 합성 데이터로 준비할 때는 `npm run db:reset`(개발 DB 삭제·재생성) 후 `npm run dev`로 기동한다.
예제 도메인은 `init --example`로 만든 경우에만 있다(`/requests`, `/publicNotes`).

## 8. 범위와 참고

타입·lint·build와 실제 사용자/API 시나리오는 서로 다른 확인이다. 실행한 결과만 개발 기록에 남긴다.
쓰기 Origin·JSON 크기·UUID 검증은 [API 표준 §3](api.md)을 따르고, 배포·프록시 환경은 `APP_ORIGIN`을 설정한다. 호출 제한·업로드·외부 AI 호출·회원가입은 기능 spec에서 추가한다.

PATCH 기본값 분리는 [Zod 4의 optional 내부 기본값 동작](https://zod.dev/v4/changelog#defaults-applied-within-optional-fields), 쓰기 원자성은 [Drizzle 트랜잭션](https://orm.drizzle.team/docs/transactions)을 참고했다.
