# 데이터 · DB

- 모든 테이블은 `src/server/db/schema.ts` 한 파일. 공통 컬럼 헬퍼 `id() createdAt() updatedAt()` 사용.
- id: UUID 문자열 / 시간: `integer timestamp_ms` / enum: `text({ enum: X_VALUES })` — 값 배열은 features/<x>/schema.ts 에 정의 후 상대경로 import.
- FK 는 `.references(() => users.id)`, 조회 조건 컬럼에는 index. 새 엔티티의 FK 는 `gen --fields='roomId:ref(rooms)!:회의실'`로 만든다 → FK·index·존재 확인(400)·폼 선택지·표시 이름까지 생성. 필수 ref 는 대상 삭제 시 함께 삭제(cascade), 선택 ref 는 비움(set null).
- 실수·음수(금액 증감·실적)는 `num`(real), 일시는 `datetime`(text `YYYY-MM-DDTHH:mm`, KST 벽시계 — 문자열 비교로 정렬·겹침 검사 가능).
- 변경 절차: schema.ts 수정 → `npm run db:generate -- --name <설명>` → `npm run db:migrate`. 망가지면 `npm run db:reset`.
- 쿼리는 drizzle 빌더만(`eq, and, like, desc, count`). 원자적 카운터 등은 값이 바인딩되는 `sql` 태그를 사용할 수 있다. 문자열 SQL 결합 금지. 모든 쿼리는 `await`(`.get() .all() .run()`). 영향 행 수는 `rowsAffected`.
- 상태 갱신은 WHERE 에 기존 상태를 포함(경합 방지): `.where(and(eq(t.id, id), eq(t.status, current)))` → `rowsAffected === 0`이면 도메인별 동시 변경 코드(category: INVALID_STATE, HTTP 409).
- DTO 변환 함수 `toDto()` 로만 내보낸다(passwordHash 등 내부 컬럼 노출 금지). 날짜는 `.toISOString()`.
- 시드(`scripts/db-seed.mts`)는 합성 데이터. 데모 계정 비밀번호 `Credit!23`.
- 쓰기와 감사로그를 같은 `db.transaction(async tx => ...)`에 묶는다. `audit(actor.id, "<entity>.<action>", entity, id, detail, tx)`로 같은 tx를 전달하고 DTO도 tx에서 조회한 값으로 만든다. 공개 CRUD의 익명 actorId는 null이다. detail에 민감정보 금지.
- 생성 스키마의 기본값을 PATCH에 재사용하지 않는다. 기본값 없는 공유 필드로 수정 스키마를 만들고, 생략은 유지·빈 문자열은 명시적 비움·빈 PATCH는 400으로 처리한다.

## 정원(capacity) 검사

같은 슬롯·좌석에 최대 N건까지 받는 신청(상담 예약 정원, 셔틀 좌석)은 **세는 것과 쓰는 것을 같은 쓰기 tx 안에서** 한다.
libsql 의 쓰기 tx 는 `BEGIN IMMEDIATE` 라 동시 신청이 직렬화된다(동시 8건·정원 3 → 정확히 3건 201, 나머지 409 확인).
tx 밖에서 센 뒤 쓰면 경합 때 정원을 넘는다.

```ts
// errors.ts: SEAT_FULL: { category: "CONFLICT", message: "정원이 찼습니다." }
export async function applySeat(actor: SessionUser, input: ApplySeatInput): Promise<SeatDto> {
  return db.transaction(async (tx) => {
    const slot = await tx.select().from(slots).where(eq(slots.id, input.slotId)).get();
    if (!slot) throw Errors.validation({ slotId: ["선택한 시간을 찾을 수 없습니다."] });
    const used = (await tx.select({ n: count() }).from(seats)
      .where(and(eq(seats.slotId, input.slotId), eq(seats.status, "CONFIRMED"))).get())?.n ?? 0;
    if (used >= slot.capacity) throw new AppError(SeatErrors.SEAT_FULL);
    const r = await tx.insert(seats).values({ ...input, ownerId: actor.id }).returning({ id: seats.id }).get();
    await audit(actor.id, "seat.apply", "seat", r.id, { slotId: input.slotId }, tx);
    return toDto(await load(r.id, tx));
  });
}
```

- 같은 사람 중복 신청은 DB 로 막는다: `uniqueIndex("seats_slot_owner_uq").on(t.slotId, t.ownerId)` + tx 안 사전 조회로 409.
- 시간 범위 정원(겹치는 예약 수 < N)은 위 `count` 조건에 겹침 조건을 더한다: `lt(t.startAt, end), gt(t.endAt, start)` (예제 `bookings/service.ts` `checkSlot`).
- 시험: 동시성은 메모리 DB(단일 연결)로 검증할 수 없다. E2E 에서 `Promise.all` 로 정원+α 건을 보내 상태 코드 목록을 확인한다(예제 TC-BOOKING-API-005).
