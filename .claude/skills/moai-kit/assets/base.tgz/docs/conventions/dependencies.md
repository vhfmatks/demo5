# 의존성 버전 · 보안 관리

버전은 갱신 시점의 `https://registry.npmjs.org/` `latest` 태그와 npm 보안 감사로 정하고, 확인 날짜는 변경 기록에 남긴다.
직접 의존성은 확인한 안정 버전으로 고정하고, 실제 하위 의존성은 `package-lock.json`과 `npm ci`로 재현한다.
`latest` 문자열이나 넓은 버전 범위를 manifest에 저장하지 않는다. `.npmrc`의 `save-exact=true`를 따른다.

## 1. 버전 기준

정확한 직접 의존성 버전은 `package.json`과 `package-lock.json`이 원본이다. 아래는 함께 움직이거나 이유가 있는 고정만 적는다.

| 항목 | 규칙 |
|---|---|
| TypeScript | CLI `@typescript/native`(npm:typescript 7)와 API `typescript`(npm:@typescript/typescript6) 병행. 아래 §2 |
| oxlint · `oxlint-tsgolint` | tsgolint는 TypeScript 7 기반이므로 TS 버전과 함께 올린다 |
| esbuild | drizzle-kit의 오래된 loader 경로 때문에 override로 고정(§3) |
| Node.js · npm | Node 24 또는 26 이상(Vitest 지원 범위), npm 11 이상 |

`@types/node`의 최신 선언을 설치했다고 런타임이 갱신되지는 않는다. 새 Node API는 실제 팀 런타임의 지원 여부를 확인한다.

## 2. TypeScript 6 · 7 병행

TypeScript 7의 `typescript` 패키지는 이전 JavaScript Compiler API를 제공하지 않는다.
Next.js의 타입 검사·설정·에디터 플러그인에 필요한 API는 TypeScript 6 호환 패키지로 제공하고, CLI는 7을 사용한다.
이는 [TypeScript 공식 병행 설치 방식](https://devblogs.microsoft.com/typescript/announcing-typescript-7-0/#running-side-by-side-with-typescript-60)을 따른다.

```json
{
  "devDependencies": {
    "@typescript/native": "npm:typescript@7.0.2",
    "typescript": "npm:@typescript/typescript6@6.0.2"
  }
}
```

- `npm run typecheck`: Next 타입 생성 → TypeScript 7의 `tsc --noEmit`.
- `npm run typecheck:compat`: Next 타입 생성 → TypeScript 6의 `tsc6 --noEmit`.
- `npm run build`: Next.js가 TypeScript 6 API를 사용한다. 빌드의 타입 검사를 끄지 않는다.
- `tsconfig.json`은 전역 타입을 `types: ["node"]`로 명시한다.

## 3. 취약점 경로와 보완

감사에서 확인되어 구성으로 막아 둔 경로다. 다시 감사해 필요 여부를 확인한다.

| 경로 | 확인한 문제 | 구성 변경 |
|---|---|---|
| eslint-config-next → @next/eslint-plugin-next → fast-glob → micromatch → braces | braces 3.0.3까지 재귀 깊이 DoS, 수정 버전 미발행 | 기본 lint를 Biome으로 전환해 해당 의존성 경로 제거 |
| drizzle-kit → @esbuild-kit/esm-loader → @esbuild-kit/core-utils → esbuild | esbuild 0.18.20의 개발 서버 CORS 취약점 | esbuild를 0.28.2로 override |

근거: [braces 보안 공지](https://github.com/advisories/GHSA-vfj7-8cjw-p6xm), [esbuild 보안 공지](https://github.com/advisories/GHSA-67mh-4wv8-2f99).
Drizzle의 오래된 loader는 여전히 deprecated다. esbuild override를 적용했으며, Drizzle가 해당 의존성을 제거하면 override의 필요성을 다시 확인한다.

`biome.json`은 Next · React 도메인과 Drizzle where 규칙(nursery, `drizzleObjectName` 지정), import 경계, GritQL 플러그인(`lint/*.grit`)을 활성화한다. 규칙표는 [lint.md](lint.md). 검사 대상에서 생성 결과·DB·템플릿·잠금 파일을 제외한다.
Biome 규칙은 ESLint와 완전히 같지 않으므로 [Biome의 Next 도메인](https://biomejs.dev/linter/domains/#next)과 [이관 차이](https://biomejs.dev/installation/migrate-eslint-prettier/)를 참고한다.
oxlint(`npm run lint:oxlint`, 설정 `.oxlintrc.json`)는 type-aware 규칙 3개(`oxlint-tsgolint`, TypeScript 7 기반이라 tsgolint 버전은 TS 버전과 함께 올린다)와 KDS 디자인 검사 `@shadcn/lint`만 실행한다. Oxlint 기본 규칙은 끄고 Biome과 겹치지 않게 한다. ESLint는 설치하지 않는다(peer 의존성이 optional, typescript-eslint는 TS 7 미지원). `public/kds`(KDS 키트 원본)는 lint 대상에서 제외한다.

## 4. 갱신 절차

```powershell
npm ci
npm outdated
npm view next@latest version
npm run audit
npm run audit:prod
npm run lint
npm run typecheck
npm run typecheck:compat
npm run build
```

1. 버전과 peerDependencies · engines · 보안 공지를 확인한다.
2. `package.json`을 정확한 버전으로 변경하고 `npm install`로 잠금 파일을 갱신한다.
3. `npm ci`로 다시 설치한 뒤 lint · 두 컴파일러 · build · 전체 보안 감사를 확인한다.
4. 업무 시험은 해당 변경의 검증 단계에서 별도로 수행하고 실제 결과만 기록한다.

`npm run verify`에는 마지막에 전체 보안 감사가 포함된다. 단위 시험도 포함하므로 시험 실행 단계에서 사용한다.
`npm audit fix --force`로 Next 버전을 낮추거나 peer 검사를 우회하지 않는다. 감사 실패를 ignore 목록으로 숨기지 않는다.
감사 0건은 해당 날짜의 npm DB에 알려진 취약점이 없다는 의미다. 이후 공개되는 취약점까지 보장하지 않는다.

## 5. 확인 결과 기록

의존성을 바꾼 뒤의 `npm ci`·lint·두 컴파일러·build·감사 결과는 변경 기록(PR·[development](../development.md))에 실행한 것만 적는다. 업무 시험 결과는 [시험 규칙](testing.md)과 해당 실행 근거에 기록한다.
