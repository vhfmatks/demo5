# 오류 코드 · 메시지 · HTTP 계약

## 1. 선언 위치와 사용법

- 공통 category·HTTP 상태·응답 타입: `src/lib/error-codes.ts`.
- 도메인의 세부 코드·공개 메시지: `src/features/<x>/errors.ts`.
- 예외·Zod 변환: `src/server/http/errors.ts`. HTTP 직렬화: `handler.ts`.
- 클라이언트: `api-client.ts`의 `ApiError`, `use-mutation.ts`의 `failure`.

새 기능은 생성기가 `errors.ts`도 생성한다. 코드 추가 때문에 공통 파일이나 다른 도메인의 카탈로그를 수정하지 않는다.
공유 오류 정의에는 서버 의존성과 `@/` 별칭을 넣지 않는다.

```ts
// features/bookings/errors.ts — 예약 도메인을 추가할 때의 선언 예제
import { defineErrors } from "../../lib/error-codes";

export const BookingErrors = defineErrors({
  BOOKING_TIME_OVERLAP: {
    category: "CONFLICT",
    message: "선택한 시간에 이미 예약이 있습니다.",
  },
  BOOKING_CAPACITY_EXCEEDED: {
    category: "CONFLICT",
    message: "예약 가능 인원을 초과했습니다.",
  },
});
```

```ts
// service.ts — 실제 업무 조건을 검사한 뒤 발생시킨다.
throw new AppError(BookingErrors.BOOKING_TIME_OVERLAP);
// 외부 오류를 확인해 변환할 때는 원인을 내부에 보존할 수 있다.
throw new AppError(CommonErrors.UPSTREAM_TIMEOUT, { cause: upstreamError });
```

`AppError`는 선언 객체를 받는다. 임의 문자열·HTTP 상태를 매번 지정하지 않는다.
같은 code의 의미·category는 유지하고, 사용자나 agent가 서로 다르게 처리해야 하는 원인은 새 code로 추가한다.

## 2. code와 category

| 필드 | 용도 | 규칙 |
|---|---|---|
| `code` | 업무별 구체적인 원인, AC·TC·로그 연결 | `DOMAIN_REASON` 형식. `REQUEST_EDIT_NOT_PENDING`처럼 기능 접두어 사용 |
| `category` | 로그인 이동·404 처리·HTTP 상태 등 공통 동작 | 아래 공통 목록만 사용 |
| `message` | 사용자에게 표시하는 한국어 설명 | 코드 정의에 공개 가능한 기본값. 메시지 문자열로 동작을 분기하지 않음 |
| `traceId` | 한 실패 응답과 서버 기록 연결 | 서버 생성 UUID. 응답의 `X-Trace-Id`와 동일 |
| `retryable` | 다시 시도할 수 있는지 안내 | 기본 false. 쓰기 요청의 자동 재시도 권한을 의미하지 않음 |

| category | HTTP | 예 |
|---|---|---|
| VALIDATION_ERROR | 400 | 필드 검증·잘못된 JSON |
| UNAUTHENTICATED | 401 | 로그인 필요·로그인 실패 |
| FORBIDDEN | 403 | 조회 가능하지만 해당 행위 금지·출처 거부 |
| NOT_FOUND | 404 | 없음 또는 볼 수 없음 |
| CONFLICT | 409 | 중복·예약 시간 겹침·정원 충돌 |
| INVALID_STATE | 409 | 상태 전이 불가·동시 변경 |
| PAYLOAD_TOO_LARGE | 413 | 요청 크기 초과 |
| UNSUPPORTED_MEDIA_TYPE | 415 | 지원하지 않는 Content-Type |
| RATE_LIMITED | 429 | 호출 제한 |
| INTERNAL | 500 | 예상 못한 오류 |
| UPSTREAM_ERROR | 502 | 외부 서비스 응답 오류 |
| SERVICE_UNAVAILABLE | 503 | 일시적으로 서비스 사용 불가 |
| TIMEOUT | 504 | 외부 서비스 응답 시간 초과 |

현재 공통 코드는 `CommonErrors`에서 확인한다. `HTTP_INVALID_JSON`과 `HTTP_CONTENT_TYPE_UNSUPPORTED`는 다른 코드·상태다.
`HTTP_ORIGIN_REQUIRED`(출처 누락) · `HTTP_INVALID_ORIGIN`(잘못된 출처) · `HTTP_ORIGIN_REJECTED`(외부 출처)는 서로 다른 403 코드다.
`HTTP_PAYLOAD_TOO_LARGE`는 JSON 64KiB 제한에 적용된다. `HTTP_RATE_LIMITED`와 외부 서비스 오류의 선언은 호출 제한·연동 기능의 구현을 의미하지 않는다.
`retryAfterSeconds`는 429·503에서 음수가 아닌 정수로 지정하며, 응답에 `Retry-After`도 포함된다.

```ts
throw new AppError(CommonErrors.HTTP_RATE_LIMITED, { retryAfterSeconds: 30 });
```

## 3. 현재 요청·인증 코드

| code | category | 발생 조건 |
|---|---|---|
| AUTH_REQUIRED | UNAUTHENTICATED | 보호 API에서 현재 세션을 사용할 수 없음 |
| AUTH_PERMISSION_REQUIRED | FORBIDDEN | 현재 역할에 필요한 권한(`lib/permissions.ts`)이 없음 |
| AUTH_INVALID_CREDENTIALS | UNAUTHENTICATED | 계정 없음 또는 비밀번호 불일치 |
| REQUEST_NOT_FOUND | NOT_FOUND | 요청 없음 또는 조회 권한 없음 |
| REQUEST_EDIT_FORBIDDEN | FORBIDDEN | 조회 가능한 요청의 수정 권한 없음 |
| REQUEST_EDIT_NOT_PENDING | INVALID_STATE | 본인 요청이 대기 상태가 아님 |
| REQUEST_DELETE_FORBIDDEN | FORBIDDEN | 조회 가능한 요청의 삭제 권한 없음 |
| REQUEST_DELETE_NOT_PENDING | INVALID_STATE | 관리자가 아닌 소유자가 대기 상태가 아닌 요청 삭제 |
| REQUEST_TRANSITION_FORBIDDEN | FORBIDDEN | 해당 상태 전이의 행위 권한 없음 |
| REQUEST_SELF_DECISION_FORBIDDEN | FORBIDDEN | 승인자·관리자가 본인 요청 승인·반려 |
| REQUEST_TRANSITION_NOT_ALLOWED | INVALID_STATE | 해당 행위에 허용되지 않는 현재 상태 |
| REQUEST_CONCURRENT_MODIFICATION | INVALID_STATE | 조건부 상태 전이 시 다른 요청이 먼저 처리 |

요청 예제는 쓰기 시 상태 조건을 검사하고 감사로그를 같은 트랜잭션에 묶는다. 공개 메모 예제는 version 조건으로 동시 변경을 구분한다. 실제 경합·롤백 동작은 시험으로 확인해야 한다.
없는 자료와 숨겨야 하는 자료는 같은 NOT_FOUND 코드·메시지로 처리한다. 로그인 실패도 공개 원인을 구분하지 않는다.

## 4. 응답과 검증 상세

```json
{
  "error": {
    "code": "REQUEST_EDIT_NOT_PENDING",
    "category": "INVALID_STATE",
    "message": "대기 상태의 요청만 수정할 수 있습니다.",
    "traceId": "00000000-0000-4000-8000-000000000042",
    "retryable": false
  }
}
```

HTTP 상태는 409다. 성공 응답 `{data,meta?}`와 오류 봉투 `{error:{...}}`를 사용한다.
이 계약은 `api()`가 처리하는 오류에 적용된다. 미등록 API 경로·미지원 HTTP 메서드는 아직 Next 기본 응답이며, 전체 경로의 표준화는 별도 보완 항목이다.
필드 오류는 `fieldErrors`와 `issues`를 함께 제공한다.

```json
{
  "fieldErrors": { "title": ["제목은 2자 이상"] },
  "issues": [{ "path": ["title"], "code": "too_small", "message": "제목은 2자 이상" }]
}
```

위 조각은 `error` 안의 검증 상세 예시다. `fieldErrors`는 기존 폼 표시용이며 중첩 필드는 점 경로, 전체 오류는 `_`를 쓴다.
`issues[].path`는 배열 인덱스·중첩 필드 구조를 보존한다. `issues[].code`는 고정된 Zod 버전의 검증 규칙이며 업무 code와 구분한다.
원본 입력값·Zod 전체 객체·SQL·외부 응답을 직렬화하지 않는다. 검증 메시지에도 민감한 입력값을 넣지 않는다.

## 5. 클라이언트와 안전한 공개 범위

```ts
// 기존 폼: m.error와 m.fieldErrors를 그대로 사용한다.
// 업무별 분기:
const changedByAnotherUser = m.failure?.code === RequestErrors.REQUEST_CONCURRENT_MODIFICATION.code;
// 일반 오류 처리와 근거 연결:
const category = m.failure?.category;
const traceId = m.failure?.traceId;
```

- 세션 오류의 로그인 이동은 `UNAUTHENTICATED` category로 처리한다. Server Component의 `load()`도 category로 404·로그인 이동을 처리한다.
- API 소비자의 `ErrorCode`는 이후 추가될 문자열도 받을 수 있다. 발생시키는 쪽은 `defineErrors`의 선언과 타입을 사용한다.
- 알 수 없는 세부 code도 보존한다. 이전 응답에 category가 없으면 일반 code·HTTP 상태로 공통 처리를 보완한다.
- 허용 경로 밖 호출은 `CLIENT_INVALID_API_URL`, JSON 변환 실패는 `CLIENT_SERIALIZATION_ERROR`, 네트워크 실패는 `CLIENT_NETWORK_ERROR`(모두 HTTP 응답 없음, status 0), 잘못된 응답은 `CLIENT_INVALID_RESPONSE`로 구분한다.
- 5xx는 카탈로그의 승인된 기본 메시지만 응답한다. 임의 message·cause·fieldErrors·issues는 공개하지 않는다.
- 현재 서버 로그는 traceId·code·category·예외 종류만 기록한다. 내부 원인 로그가 필요하면 별도 로거에서 민감정보 제거를 설계한다.
- 예상하는 고유 제약·외부 실패만 service에서 원인을 확인해 변환한다. 미확인 DB 오류는 INTERNAL로 처리한다.

## 6. 변경·검증 기준

기존 공통 code를 세부 code로 바꿀 때 해당 AC·기존 시험 기대값·문서·직접 API 소비자를 함께 갱신한다. 봉투는 유지되지만 `code` 값의 변경은 소비자 호환성 검토가 필요하다.
HTTP status와 category, 세부 code, 거부 후 저장값 불변, 공개 정보 범위를 확인한다.
이번 계약은 지원하지 않는 Content-Type을 415로, 본인 비대기 요청 삭제를 409로 분류한다.
인증·조회 숨김처럼 공개 원인을 합쳐야 하는 항목은 세부 코드로 정보를 늘리지 않는다.

## 7. 참고한 프레임워크

도메인 코드와 안전한 메시지의 선언은 [ABP의 BusinessException·코드 기반 오류 처리](https://abp.io/docs/latest/framework/fundamentals/exception-handling)를 참고했다.
예외를 한 곳에서 HTTP 응답으로 변환하는 구조는 [Spring ErrorResponse](https://docs.spring.io/spring-framework/reference/web/webmvc/mvc-ann-rest-exceptions.html)와 [ASP.NET Core 오류 처리](https://learn.microsoft.com/en-us/aspnet/core/fundamentals/error-handling?view=aspnetcore-10.0)를 참고했다.
안정된 기계 식별자와 구조화된 검증 상세는 [RFC 9457](https://www.rfc-editor.org/rfc/rfc9457.html)의 설계와 연결된다. 현재 중첩 봉투는 RFC 9457 응답 형식이 아니므로 `application/problem+json`을 사용하지 않는다.
비교 내용과 도입 판단은 [프레임워크 조사](../research/error-contracts.md)에 기록했다.
