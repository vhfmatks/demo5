# lint — 사전 버그 차단 규칙

`npm run lint` = Biome → `lint:oxlint`(next typegen 후 oxlint) → `lint:contracts`. `verify`에 포함된다.
lint 오류 메시지가 고칠 방법을 알려준다. 규칙을 끄거나 `biome-ignore`·`oxlint-disable`로 우회하지 않는다. 오탐이면 규칙 파일을 고치는 별도 작업으로 다룬다.
근거·도구 선택 이유: [lint 조사](../research/lint-architecture.md).

| 막는 버그 | 규칙 | 도구·위치 |
|---|---|---|
| where 없는 `delete`/`update`(전체 행 삭제·수정) | `nursery/noDrizzleDeleteWithoutWhere` · `noDrizzleUpdateWithoutWhere` (`db`, `tx`) | Biome |
| await 누락(오류 유실·순서 꼬임), `onClick={async…}` 처럼 Promise 를 void 자리에 넘김 | `typescript/no-floating-promises` · `no-misused-promises` · `await-thenable` | oxlint type-aware (`oxlint-tsgolint`) |
| render 중 setState 등 React Compiler 위반 | `nursery/useReactCompiler` | Biome |
| 화면·route·lib 에서 DB 직접 접근 | `noRestrictedImports`: `drizzle-orm` `@libsql/client` `@/server/db/*` (service·`src/server` 제외) | Biome overrides |
| ui 내부 파일 직접 import | `noRestrictedImports`: `@/components/ui/*` | Biome overrides |
| feature 간 직접 import | `noRestrictedImports`: features 안에서 `@/features/**` | Biome overrides |
| 컴포넌트에서 service·서버 모듈 import, 클라이언트 중복 검증 | `noRestrictedImports`: components 에서 `../service` `@/server/**` `zod` | Biome overrides |
| 공유 파일(schema·errors·policy)이 서버 전용·별칭에 의존 | `noRestrictedImports`: `@/**` `server-only` DB | Biome overrides |
| 자기 API fetch, Client 에서 fetch 직접 사용 | `noRestrictedGlobals`: `fetch` (`src/lib/api-client.ts` `src/server` `tests` `scripts` 제외) | Biome |
| Server Action 으로 api() 계약 우회 | `"use server"` 금지 | `lint/no-server-actions.grit` |
| page·layout·*Table·*Filters 의 `"use client"` | `"use client"` 금지 | `lint/no-use-client-page.grit` |
| service 의 `throw new Error` (오류 계약 누락 → 500) | `new AppError(정의)`만 | `lint/no-plain-error.grit` |
| 오류 message 문자열로 분기 | `.message ===`·`.includes()` 등 금지 | `lint/no-message-branch.grit` |
| 트랜잭션 안 audit 이 다른 연결로 기록(원자성 깨짐) | `transaction()` 안 `audit()` 에 `tx` 필수 | `lint/audit-needs-tx.grit` |
| 간격 스케일 밖 gap(`gap-8`·`gap-5`)·`space-x/y` (화면마다 들쭉날쭉) | 부모 `gap-1·2·3·4·6·10` 만 (app·features tsx) | `lint/layout-spacing.grit` |
| 색·임의값·인라인 스타일·ui restyle·없는 클래스 | `shadcn/*` 6개 | oxlint + `@shadcn/lint` ([ui.md](ui.md)) |
| Route Handler·E2E 형식 | `api()`·runtime·params·TC 이름·중복 등 | `scripts/check-contracts.mts` ([api.md](api.md), [testing.md](testing.md)) |

이미 프레임워크가 막는 것: Client 에서 `server-only` 모듈 import, Server Component 의 hook 사용 → `next build` 오류.

lint 로 판정할 수 없는 것 → 시험으로 확인한다: 권한 판단의 정확성(policy 단위·E2E), audit 실패 시 롤백(단위: `tests/unit/requests.service.test.ts`, SQLite trigger 로 audit insert 실패 주입), 상태·version 조건의 실제 WHERE 반영(E2E 경합), 응답 봉투·Origin·세션(api() 런타임 + E2E).

규칙 추가: 경로 경계는 `biome.json` overrides(일반 → 구체 순서, 같은 규칙은 뒤 override 가 options 를 **대체**하므로 금지 목록 전체를 반복), 문법 패턴은 `lint/*.grit` + `biome.json` `plugins`(`includes` 는 `**/` 로 시작), 타입 기반은 `.oxlintrc.json`.
