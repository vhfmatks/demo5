# 권한 (RBAC)

단일 기준: [`src/lib/permissions.ts`](../../src/lib/permissions.ts). 코드는 **역할이 아니라 권한**을 검사한다.

| 원칙 | 적용 |
|---|---|
| 권한 단위 검사 | `can(user, "audit.read")`. `role === "ADMIN"` 비교 금지 → 역할 구성이 바뀌어도 검사 코드는 그대로 |
| 중앙 매핑 | `PERMISSIONS`(권한 목록) + `ROLE_DEFINITIONS`(역할 = 권한 묶음, `inherits` 상속) |
| 기본 거부 | 비로그인·알 수 없는 역할·등록되지 않은 권한은 false |
| 최소 권한 | ADMIN 만 `"ALL"`. 나머지 역할은 필요한 권한만 명시 (예: AUDITOR = 포털 접근 + 감사로그 조회) |
| 서버 강제 | 화면 숨김은 표시용. 실제 거부는 route `permission` + service `assertPermission` |
| RBAC + 자원 조건 | 권한(무엇을)과 소유자·상태·직무 분리(어떤 대상에)를 `features/<x>/policy.ts` 에서 함께 판단 |
| 자기 권한 변경 금지 | 본인 역할 변경 불가 (권한 상승·마지막 관리자 강등 방지) |
| 즉시 반영 | 역할은 요청마다 DB 에서 읽으므로 변경 즉시 적용, 감사로그 `user.role_change` 기록 |
| 시험 | `tests/unit/rbac.test.ts` 가 역할별 기대 권한 표를 고정 → 의도치 않은 권한 확대가 실패로 드러남 |

## 적용 위치

| 층 | 사용 | 실패 |
|---|---|---|
| 화면 | `const user = await requirePermission("audit.read")` | 404 (존재 숨김) |
| 메뉴 | `ADMIN_NAV` 항목의 `permission`, `(app)/layout` 의 `can()` | 미표시 |
| API | `api(fn, { permission: "audit.read" })` | 403 `AUTH_PERMISSION_REQUIRED` |
| service | `assertPermission(actor, "settings.update")` (`@/server/auth/session`) | 403 `AUTH_PERMISSION_REQUIRED` |
| policy | `can(a, "request.decide") && !isOwner(a, t)` | 도메인 오류 코드 |

API 와 service 에 같은 권한을 둔다. route 검사는 빠른 거부, service 검사는 다른 호출 경로(화면·배치)까지 막는 최종 강제다.

## 변경 방법

- **권한 추가**: `PERMISSIONS` 에 `"<자원>.<행위>[.<범위>]": "설명"` → 필요한 역할의 `grants` 에 추가 → `rbac.test.ts` 기대표 갱신.
- **역할 추가**: `lib/roles.ts` 의 `ROLES`·`ROLE_LABEL` + `ROLE_DEFINITIONS`. DB 는 text 컬럼이라 마이그레이션 불필요.
- **새 도메인**: `npm run gen` 이 `<entity>.manage.any`(전체 조회·삭제)·`<entity>.read.dept`(같은 부서 조회) 권한을 등록하고 템플릿 policy 가 사용한다. ADMIN 은 자동 포함, `read.dept` 는 MANAGER 에 준다.
- 매트릭스는 관리자 포털 `/admin/roles` 에서 확인한다(읽기 전용).

역할·권한을 운영 중 화면에서 편집해야 하면 `roles`·`role_permissions` 테이블로 옮기고, `can()` 의 조회만 바꾼다(검사 코드는 그대로).

## 부서 범위 (부서장·부서별 조회·집계)

| 항목 | 위치 |
|---|---|
| 부서 목록 | `lib/departments.ts` `DEPARTMENTS`·`DEPARTMENT_LABEL` — 프로젝트 조직에 맞게 고친다(text 열이라 마이그레이션 불필요) |
| 소속 | `users.department`(null = 미지정) → 세션 `user.department`. 관리자 포털 사용자 화면에서 지정(`user.department.update`, 감사로그 `user.department_change`) |
| 목록 범위 | gen 모듈 policy `listScope` = `all`(`<x>.manage.any`) · `dept`(`<x>.read.dept`) · `own` → service `ownerScope(actor, scope, x.ownerId)` (`@/server/scope`) |
| 상세 범위 | policy `canView` 가 소유자 부서(`ownerDepartment`, users join)와 actor 부서를 비교. 부서 미지정 actor 는 본인 것만 |
| 부서장 | 역할 `MANAGER` = 기능별 `<x>.read.dept` 만(조회만, 수정·삭제 불가). 데모 `manager@demo.local` 개발팀(user1·user3 와 같은 부서, user2 는 영업팀). 생성 시험 `TC-<X>-API-006` |
| 손으로 만든 기능 | gen 템플릿 policy·service 와 같게: Target 에 `ownerDepartment`, `deptReader` 조건, 목록은 `ownerScope` |

```ts
// 부서별 건수 — 소유자의 현재 부서 기준, 범위는 목록과 같은 조건을 그대로 건다
db.select({ department: users.department, n: count() }).from(items)
  .innerJoin(users, eq(users.id, items.ownerId))
  .where(ownerScope(actor, listScope(actor), items.ownerId))
  .groupBy(users.department).all();
```

- 기준은 소유자의 **현재** 부서다. 사람이 옮기면 지난 자료도 따라간다. 작성 시점 부서로 고정하려면 행에 `department` 열을 두고 생성 시 `actor.department` 를 저장해 그 열로 거른다.
- 본부 > 팀 같은 계층이 필요하면 `departments` 테이블(`parentId`)로 옮기고 `ownerScope` 의 부서 조건만 하위 부서 목록(`inArray`)으로 바꾼다.

## 민감 필드 · 개인정보

행 단위(누가 이 건을 보나)는 `policy.ts`, 필드 단위(이 건의 어떤 값을 보나)는 service `toDto` 에서 정한다. 화면에서 숨기는 것은 보호가 아니다.

| 상황 | 방법 |
|---|---|
| 일부 사람만 봐야 하는 필드 (상담 사유·심사 점수·정답) | `omitUnless(canSeeX(actor, row), dto, "reason")` (`@/lib/mask`) — 응답에서 필드를 지운다. DTO 타입에서 그 필드는 `reason?: string` |
| 일부만 보여 줘야 하는 값 (목록·내보내기의 이름·전화·이메일) | `maskName` `maskPhone` `maskEmail` `maskMiddle` (`@/lib/mask`) |
| 본인 + 담당자 두 사람만 열람 (상담·심사) | `gen` 에 `counselorId:ref(users)!:상담사` → policy 에 `canView = (a, t) => a.id === t.ownerId \|\| a.id === t.counselorId \|\| manager(a)`, `listScope` 도 같은 조건으로 바꾼다(`or(eq(x.ownerId, a.id), eq(x.counselorId, a.id))`) |
| 심사위원만 보는 점수 | 점수를 별도 엔티티(`ownerId` = 심사위원)로 분리하면 행 단위 정책만으로 막힌다. 집계(평균)만 공개 |
| 위치·시간처럼 조합하면 사람을 특정하는 값 | 집계는 최소 인원(예: 5명) 미만 칸을 숨기거나 "5명 미만"으로 표시 |

- 감사로그 `detail` 에 민감 원문을 넣지 않는다. 시험은 다른 사용자로 조회해 필드가 **없음**(`not.toHaveProperty`)을 확인한다.
