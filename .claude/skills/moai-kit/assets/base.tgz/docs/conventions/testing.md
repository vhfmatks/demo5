# E2E · 시험 표준

E2E는 실제 Next 서버·DB·세션을 통해 기능의 완료 조건을 검증한다. 단위 시험은 별도다.

## 1. 위치와 TC

| 층 | 위치 | 도구 · 역할 |
|---|---|---|
| 정책·서비스 | `tests/unit/*.test.ts` | Vitest, 순수 정책·메모리 DB·트랜잭션 |
| API E2E | `tests/e2e/<xs>.api.spec.ts` | Playwright `api` 프로젝트, 실제 HTTP |
| UI E2E | `tests/e2e/<xs>.ui.spec.ts` | Playwright `ui` 프로젝트, 실제 브라우저 |
| fixture | `tests/e2e/fixtures.ts` | actor별 API/브라우저 context 생성·정리 |
| 응답 assertion | `tests/e2e/helpers.ts` | status·봉투·trace·캐시·204 표준 검증 |

이름은 `TC-DOMAIN-API-001 설명` 또는 `TC-DOMAIN-UI-001 설명`이다. DOMAIN은 대문자로 시작하고 대문자·숫자를 사용하며 단어는 `_`로 구분한다.
REQ → AC → Issue → TC → 실행 근거를 연결한다. TC ID는 전체 E2E에서 중복 없이 유지한다.
보안 표기는 `(SEC-03)`처럼 `docs/security-policy.md`의 주최 측 SEC 번호다. 태그는 그 항목을 확인하는 시험이라는 표시일 뿐이며 실행 결과가 있어야 준수 근거가 된다.

## 2. 기능별 최소 시나리오

| 종류 | 필요한 확인 |
|---|---|
| CRUD 정상 | 생성 201 → 목록·상세 200 → 수정·재조회 → 삭제 204 → 재조회 404 |
| 잘못된 입력 | 400·필드 오류·세부 검증 규칙, DB 값/건수 불변 |
| 인증 필수 | 비로그인 읽기·쓰기 401, UI 로그인 이동 |
| 권한 경계 | 타인 조회·목록 노출·수정·삭제 거부, 저장값 불변 |
| 역할·상태 | 허용 역할의 전이, 금지 역할·재처리·확정 후 수정 거부 |
| 공개 CRUD | 익명 성공, 공개 범위가 policy와 일치 |
| 경합 방어 | 오래된 version 수정·삭제 409와 저장값 불변 |
| 공통 HTTP | Origin 누락·형식·scheme/port, MIME·JSON·64KiB·UUID·unknown 필드 |
| 세션 | 로그인·쿠키 속성·me·로그아웃 후 거부, 같은 로그인 실패 메시지 |
| UI | 사용자 입력 → 저장 → 역할별 처리 → reload 후 값 유지, 오류 위치·화면 유지 |

상태 재처리와 오래된 version은 제공 예제에 포함한다. 실제 동시 부하·감사 실패 롤백·세션 만료·호출 제한·5xx 장애 주입은 프로젝트에 필요한 별도 시나리오다.
HTTP 200·파일 존재·스크린샷만으로 AC를 완료하지 않는다.

## 3. 작성 계약

```ts
import { test, expect } from "./fixtures";
import { expectData, expectError, uniqueTitle } from "./helpers";
import { CommonErrors } from "../../src/lib/error-codes";

test("TC-BOOKING-API-001 비로그인 거부 (SEC-02)", async ({ apiAs }) => {
  const anon = await apiAs(null);
  await expectError(await anon.get("/api/v1/bookings"), CommonErrors.AUTH_REQUIRED);
});
```

- `test` · `expect`는 `./fixtures`에서 import한다. `apiAs("user1")` · `apiAs("approver")` · `apiAs(null)`을 사용한다.
- UI 단일 사용자는 기본 `page`, 여러 사용자는 `pageAs("user1")` · `pageAs("approver")`. fixture가 context를 정리한다.
- API의 `expectData` · `expectError` · `expectNoContent`로 상태·응답·trace·Cache-Control을 확인하고 기능의 값을 추가 assertion한다.
- 데이터는 합성 값과 `uniqueTitle()`로 만든다. 다른 TC가 만든 레코드나 실행 순서에 의존하지 않는다.
- UI는 role·label·명시적 testId로 찾고 Playwright의 재시도 assertion을 사용한다. 고정 sleep을 넣지 않는다.
- 실제 앱을 검증한다. spec 내부 HTTP mock·service/DB 직접 호출·수동 context 생성은 금지한다.
- `only` · `skip` · `fixme` · 예상 실패 지정으로 완료 판정을 우회하지 않는다. retries는 0이다.
- 공개 시험을 인증 시험으로 복사하지 않는다. 새 모듈 생성 시 인증/공개별 API·UI 템플릿이 생성된다.

`npm run lint:contracts`가 파일 구분·fixture 사용·TC ID·중복·일반적인 우회 패턴을 검사한다.

## 4. 격리 실행

```powershell
npm run test:e2e:api       # 브라우저 없이 API 전체
$env:PW_CHANNEL = "msedge"
npm run test:e2e          # API + UI 전체
npm run test:e2e:ui       # UI 전체
npm run test:e2e -- tests/e2e/requests.api.spec.ts
```

runner는 새 runId → 빈 포트 선택 → 새 DB에 migration·합성 seed → production build·기동 → 시험 → 종료로 동작한다.
`test-results/runs/<runId>/test.db`만 사용하며 개발 DB를 초기화하지 않는다. 기존 서버는 재사용하지 않는다.
같은 DB를 쓰는 실행 내에서는 workers 1이다. 팀의 병렬 실행은 별도 worktree에서 수행한다(`/moai-work`는 티켓마다 자기 worktree·브랜치에서 `PORT = 3100 + SLOT`으로 실행한다).
필요하면 `E2E_PORT=3201`로 포트를 고정한다. 사용하는 포트는 중단하며 기존 프로세스를 종료하지 않는다.
`PW_CHANNEL=msedge/chrome` 또는 `PW_CHROMIUM_PATH`로 설치된 브라우저를 선택할 수 있다.
기존 `E2E_REUSE` · 외부 `E2E_BASE_URL`과 config·workers·retries·출력 경로를 덮어쓰는 CLI 옵션은 사용하지 않는다.

## 5. 결과·근거

| 파일 | 내용 |
|---|---|
| `test-results/runs/<runId>/run.json` | 명령 범위·시각·종료코드·Git SHA/dirty·실제 파일 SHA-256·실행 전후 소스 |
| 같은 경로 `e2e.json` | Playwright TC 결과와 runId·소스 해시 metadata |
| 같은 경로 `html/` · `artifacts/` | 보고서·UI 스크린샷·실패 trace |
| `docs/evidence/<runId>.md` · `latest.md` | 검증한 실행의 PASS/FAIL/SKIP/FLAKY · 근거 링크 |

명령·실행 ID·파일 해시가 일치하는 새 결과만 사용한다. 실행 중 소스 변경·실패·skip·flaky·0개 실행은 성공으로 처리하지 않는다.
완료되지 않은 실행도 INCOMPLETE로 남긴다. Git이 없으면 SHA-256으로 실제 파일 집합을 식별한다.
소스 해시는 코드·시험·템플릿·마이그레이션·공개 정적 자산·주요 설정·잠금 파일을 포함하며 `.env`와 문서·생성 결과는 읽지 않는다.
`--project` · 파일 · grep 선택은 해당 범위만 검증한다. 선택 실행을 전체 AC 완료로 확대하지 않는다.
`--list`는 선택 목록이며 시험 근거를 갱신하지 않는다.
`npm run evidence`는 마지막 manifest/report의 연결을 재검증한다. 시험 재실행·현재 HEAD로 치환·예전 E2E와 새 단위 결과 합성은 하지 않는다.
스크린샷·보고서·DB를 보관할 때 해당 runId의 파일을 함께 보관한다. trace에는 합성 시험 세션이 포함될 수 있으므로 보관 근거에는 필요한 화면만 선택한다.

## 6. 완료 단계

관련 API·UI TC → `npm run lint` · `npm run typecheck` → 요구된 단위/빌드/보안 검사 → 전체 E2E → AC·문서·근거 갱신 순으로 진행한다.
`npm run verify`는 lint·타입·단위·build·audit이며 E2E는 별도 실행이다.
실제 실행한 결과만 [E2E 시험 문서](../e2e-test.md)에 적는다. 미검증·해당 없음·실패 사유를 구분한다.
[제출 시험 문서](../e2e-test.md) §2 계획 행(`TC | REQ | AC | 경계 | GIVEN · WHEN · THEN | 예상 결과 | 자동화 위치`)과 `test("TC-…")` 제목·파일은 1:1이어야 한다(`npm run lint:contracts`가 REQ↔AC, 경계 값, 단위 시험 파일 존재까지 대조). 현황 블록은 `npm run e2e:dashboard`가 커밋된 `docs/evidence/<runId>.md`(E2E)·`docs/evidence/unit-<시각>.md`(단위, `npm run test:unit:evidence`)에서 REQ·AC·TC·경계·시험 파일·결과(PASS/FAIL/SKIP)·소스 SHA·시각·실행 환경·근거 경로로 계산하며 직접 고치지 않는다. PC1의 `/moai-docs sync`·`final`이 다시 만든다.

fixture·프로젝트·reporter는 [Playwright 공식 fixture](https://playwright.dev/docs/test-fixtures), [프로젝트](https://playwright.dev/docs/test-projects), [JSON reporter](https://playwright.dev/docs/test-reporters#json-reporter)를 따른다.
