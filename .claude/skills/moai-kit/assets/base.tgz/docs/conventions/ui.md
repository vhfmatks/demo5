# 화면 · 컴포넌트 · 디자인 시스템

설계 방침·전체 영역 대응·실제 API·화면별 사용 절차는 [디자인 시스템 사용 가이드](../design-system/README.md)를 따른다. [공식 조사](../research/kt-ux-design.md)는 공개 사이트에서 확인한 내용과 조회하지 못한 지침을 구분하고, [제공 원문](../design-system/reference/README.md)은 제공 KDS 2.0 키트의 세부 참고 자료다.

특정 화면용 UI도 [컴포넌트 목록·사용법](../design-system/components.md)에 미리 제공한다. `/design-system`에서 실제 조합을 확인한다. 모달/시트·탭·알림·날짜/시간/범위·차트·AI·문서 화면은 기능 폴더에서 다시 만들지 않고 `@/components/ui`를 사용한다.

## Server / Client 경계
| 종류 | 위치 | 규칙 |
|---|---|---|
| page.tsx / layout.tsx | Server | 인증 화면은 `requireUser()`, 공개 화면은 선택적 `getCurrentUser()` → service 직접 호출 → 단건은 `load()`로 감싸 404 처리 |
| *Table, *Filters, 상세 표시 | Server | `"use client"` 금지. 필터는 `<form method="get">` (URL 쿼리) |
| *Form, *Actions, 토글·모달 | Client | `useMutation` + `apiClient` 만. fetch 직접 금지 |
- 권한 판단은 서버(page)에서 `policy` 로 계산해 boolean/배열 props 로 넘긴다. Client 는 그 값으로만 버튼 표시.
- Server → Client props 는 직렬화 가능한 값(DTO, 문자열, 불리언)만. 함수·Date 금지.
- 목록 갱신은 `router.refresh()`(useMutation 기본). 클라이언트 상태로 목록을 복제하지 않는다.
- 로딩·에러: `(app)/error.tsx` 공통. 폼 에러는 `<Alert>{m.error}</Alert>` + `Field error={m.fieldErrors.x}`. 삭제 확인은 `ConfirmDialog`.
- 오류 분기: `m.failure?.category`로 공통 처리, `m.failure?.code`로 도메인별 처리. `message`는 표시용이며 `traceId`는 문의·근거 연결에 사용한다. `retryable`만으로 쓰기 요청을 자동 재시도하지 않는다.

## 디자인 시스템 (src/components/ui = KDS 2.0)
원본: `KDS 20261012` → `public/kds`(tokens CSS·아이콘·Pretendard). `globals.css`가 Tailwind 레이어로 import 한다.
쓸 수 있는 것: `Button LinkButton IconButton Field Input Textarea Select toOptions SearchField FilterBar Checkbox Radio Switch Tag Alert EmptyState ConfirmDialog PageHeader Card Section Stat DescriptionList DataTable Pagination BarChart LineChart DonutChart Progress Calendar Icon Gnb cn` (특정 화면용 Modal·Tabs·DatePicker·Prompt 등은 [components.md](../design-system/components.md))
```tsx
<PageHeader title="예약" description="총 3건" actions={<LinkButton href="/bookings/new" variant="tertiary">새 예약</LinkButton>} />
<Card title="목록"><DataTable rows={items} columns={columns} rowHref={(r) => `/bookings/${r.id}`} /></Card>
<Field label="제목" name="title" required error={fe.title}><Input name="title" invalid={!!fe.title} /></Field>
<Select name="status" options={toOptions(STATUS_LABEL)} placeholder="전체" />
<Checkbox name="agree">동의합니다</Checkbox>   <Radio name="pay" value="card">카드</Radio>   <Switch name="notify">알림</Switch>
<Tag tone="critical" testId="status">반려</Tag>  // tone: default|info|progress|positive|warning|critical|complete
<Alert>{m.error}</Alert>                        // 오류 한 줄(빨간 글자+아이콘). tone="info" 는 회색 안내
<ConfirmDialog open={open} title="삭제할까요?" confirmLabel="삭제 확인" loading={d.pending} onConfirm={...} onCancel={...}><Alert>{d.error}</Alert></ConfirmDialog>
<Icon name="line-search" size={20} />           // public/kds/icons/ic-<name>.svg
<BarChart label="부서별 접수" series={["2025", "2026"]} rows={[{ label: "영업", values: [12, 18] }]} />  // 범주 비교(가로 막대)
<LineChart label="월별 매출" x={["1월", "2월"]} series={[{ name: "2026", values: [3, -1] }]} />     // 시간 추이, 음수 허용
<Progress label="요구사항 커버리지" value={42} max={60} />                                            // 비율(kds-progress)
<Calendar view={q.view} date={date} today={kstToday()} events={events} basePath="/slots/calendar" />  // 월·주 달력(아래 "달력")
<ImportForm url="/api/v1/bookings/import" headers={["제목", "분류"]} />  // @/components/app/ImportForm: 파일 선택·양식 받기·행 오류 목록
<IconButton name="line-search" label="검색" type="submit" />
<FilterBar><SearchField name="q" label="제목 검색" placeholder="제목 검색" /></FilterBar>   // 목록 위 GET 검색·필터 한 줄
<Section title="신청 정보">...</Section>       // 모바일 업무형의 평평한 섹션
```
- 버튼: `primary`(검정) = 화면의 확정 동작 1개 · `secondary`(회색) = primary 옆 짝(취소) · `tertiary`(테두리) = 단독 보조(수정·삭제·검색·새로 만들기) · `text` = 글자 버튼 · `accent`(KT 레드) = 요청받았을 때만 화면당 1개. 빨간 버튼 없음 → 삭제는 `tertiary` + `ConfirmDialog`. `confirm()` 금지.
- 크기 `size`: xsmall 32 / small 40 / medium 44(기본) / large 48. `full` = 가로 꽉. PC·모바일 모두 원본 높이를 유지한다(입력 52·검색 48·표 머리/행 44/56·페이지 번호 40).
- PC 업무 화면 기본: `Gnb`(layout) → `PageHeader` → (필터) → 표/폼. 모바일 단일 업무는 `Section`을 우선 사용하고 카드로 쌓지 않는다. 구조는 요구사항에 맞게 바꿀 수 있다.
- 면은 한 겹: 카드 안에 카드·색 박스 금지. 섹션 제목은 카드 밖(`Card title`). 태그는 예외 상태에만. 빨강은 짧은 글자 강조에만.
- 색은 토큰 유틸만(`bg-surface bg-subtle text-fg text-muted border-line bg-primary text-on-primary text-danger`) → KDS 변수에 연결돼 있다. KDS 변수 직접 사용은 `bg-(--fill-secondary-01)`.
- 글자 크기·굵기는 KDS 클래스. `PageHeader`는 모바일 22/PC 36, `Card title`은 20로 반응형 적용. 본문 `body-large-medium` · 보조 `body-small-medium` · 캡션 `caption-medium-medium`. `font-brand`는 큰 display/heading 제목에만.
- 간격은 4pt 기준(Tailwind 1 = 4px), 작은 요소 내부에만 제한적으로 2pt. 안쪽 2·4 < 요소 사이 3 < 덩어리 사이 6 < 큰 구역 10. 레이아웃 `main`은 `py-6 lg:py-8`, 페이지 덩어리 사이 `gap-6`·`mb-6`. 임의값 `[13px]` 금지.
- **레이아웃 규칙** (빽빽함·어긋남 방지. `lint/layout-spacing.grit` · TC-DENSITY-UI-004 가 검사)
  - PC 목록 기본: `PageHeader`(제목 + 오른쪽 동작) → `FilterBar`(검색·필터 한 줄, 왼쪽부터) → ResultCount → DataTable → Pagination. 모바일 업무는 Section·Divider band·CtaBar를 사용한다. 목록 화면의 GET 폼은 `FilterBar` 로만 만든다.
  - 형제 사이 간격은 부모 `gap` 으로 준다. gap 은 `1·2·3·4·6·8·10·16`(0.5 는 작은 요소 안)만, `space-x/y` 금지. 자식에 `mt-*`/`ml-*` 를 붙여 간격을 맞추지 않는다(예외: 글자 덩어리 안 보조 문장).
  - 같은 줄 요소는 세로 정렬을 맞춘다: 툴바·버튼 줄 `items-center`, 라벨 있는 폼 줄 `items-end`. 라벨은 항상 입력 위.
  - 왼쪽 시작선은 하나: 콘텐츠 폭 안에서 들여쓰기·임의 `max-w` 를 섞지 않는다. 폼은 1열 `max-w-xl`(템플릿 기본), 짧은 필드 2개를 묶을 때만 `grid gap-4 md:grid-cols-2`, 넓은 필드는 `col-span-full`. 필드에 `w-*` 를 직접 주지 않는다(FilterBar 안 필터 폭은 예외).
  - 표: 글자 왼쪽, 숫자·금액 오른쪽(`text-right tabular-nums`), 상태 `Tag`·행 동작은 끝 열.
  - 밀도 상한: primary 화면당 1개 · PageHeader 동작 최대 3개 · 표 열 PC 7개, 1280 미만은 핵심 3열(`hidden lg:table-cell`) · 폼 한 줄 최대 2필드(모바일 1) · 한 화면 Card/Section 최대 4개(넘으면 Tabs·상세 화면 분리) · Stat 한 줄 최대 4개.
  - 360·1280 에서 가로 스크롤이 생기면 안 된다. 새 목록 화면은 TC-DENSITY-UI-004 의 화면 목록에 추가한다.
- 검색 입력은 `SearchField`를 `FilterBar`(GET 폼) 안에 사용한다. 일반 `Input`으로 검색 외관을 직접 만들지 않는다. 검색 아이콘은 오른쪽이며 바깥 폼을 제출한다.
- 아이콘은 `Icon`만. `<` `>` `X` 글자·이모지 금지. 아이콘만 있는 버튼은 `aria-label`.
- 2열 상세: `grid gap-4 md:grid-cols-4` + 본문 `Card className="md:col-span-3"`.
- **디자인 lint** (`@shadcn/lint` + `.oxlintrc.json`, `npm run lint`에 포함, 전체 규칙표 [lint.md](lint.md)). 오류 메시지가 고칠 방법(쓸 variant·size·토큰)을 알려준다.
  | 규칙 | 막는 것 | 대신 |
  |---|---|---|
  | `no-restyle` | ui 컴포넌트에 색·글자·안쪽 여백·모양 클래스 | `variant`·`size`. 레이아웃(`w-*` `mt-*` `col-span-*`)만 허용 |
  | `no-raw-colors` | `bg-pink-500` 같은 Tailwind 기본 팔레트 | `bg-primary` `text-muted` 등 토큰 |
  | `no-arbitrary-values` | `p-[13px]` `grid-cols-[8rem_1fr]` | 스케일 값(`p-3`, `w-32`, `grid-cols-4`) |
  | `no-inline-styles` | `style={{ color }}` | 클래스. CSS 변수(`--icon`)만 허용 |
  | `no-unknown-classes` | CSS가 만들어지지 않는 클래스(오타 `kds-buton`) | 실제 `kds-*`·Tailwind 클래스 |
  | `require-static-classes` | 읽을 수 없는 동적 클래스 조립 | 정적 문자열·`cn()` |
- 영역별 테마는 KDS 모드(`data-mode="dark|agent|dark-agent"`)를 그 영역의 최상위 요소에 지정한다(관리자 포털 = dark). 색을 새로 정의하지 않는다.
- 1280px 이상이 PC(GNB 메뉴 표시, 높이 72px). 그보다 좁은 모바일·태블릿에서는 햄버거를 기본 표시하고 같은 메뉴를 목록으로 제공한다. `Gnb`가 자동 전환하므로 화면마다 메뉴를 추가하지 않는다. 링크 이동·Escape·PC 전환 시 목록을 닫고, 로그인/관리자 동작은 좁은 화면에서 줄바꿈한다. `sm=360`, `md=768`, `lg=1280`, `xl=1920`(Tailwind 기본값이 아니다); PC 전용 전환은 `lg:`를 쓴다. 기본 콘텐츠 최대 폭 1080은 breakpoint가 아니다.
- 새 공통 컴포넌트가 필요하면 `public/kds/tokens/kds-components.css`의 `kds-*` 클래스를 감싸 ui/ 에 추가하고 index.ts 에 export (기능 폴더에 만들지 않는다). `kds-*` 클래스를 다시 정의하지 않는다.
- KT Flow는 공개 배포본에 없다. 참가자 로컬 `kds-fonts <제공 fonts/web>` 설치는 Git 제외 경로에만 파일을 둔다. 외부 공유·공개 배포하지 않으며 미설치 시 Pretendard로 표시된다.

## 접근성·테스트 훅
- 입력은 반드시 `Field`(label 연결). 직접 자식 `Input`·`Textarea`·`Select` 하나의 id·aria-required·오류/힌트 연결을 자동 제공한다. 복합 입력은 직접 연결한다. 검증 규칙은 feature의 zod 스키마 한 곳이다. 쓰기 폼은 `noValidate`와 `useMutation(..., { schema: 입력스키마 })`로 제출 전에 같은 규칙을 검사하고 Field·Alert로 오류를 표시한다. 전체 필드를 보내는 생성·수정 공용 폼은 생성 스키마를 재사용한다. 서버는 입력과 업무 조건을 다시 검증한다. 실패 시 입력값을 유지하고 초기화는 성공 후에만 수행한다.
- 아이콘 버튼은 `IconButton label` 또는 `aria-label`. 포커스 표시를 제거하지 않는다.
- `ConfirmDialog`는 Client 컴포넌트. 취소에 초기 포커스, 내부 Tab 순환, Escape 취소·원래 트리거 포커스 복원. 처리 중 취소·닫기 차단. `Button loading`은 aria-busy와 disabled를 제공한다.
- 모드별 텍스트 대비·색 외 상태 문구를 확인한다. 동작·접근성 시험은 `tests/e2e/designSystem.ui.spec.ts`; lint만으로 전체 준수를 판단하지 않는다.
- E2E 가 잡을 요소: 역할/라벨 우선(`getByRole`, `getByLabel`), 모호하면 `data-testid`(예: status, row, stats).
- 문구는 한국어, 버튼은 동사형(등록·저장·승인·삭제).

## 차트
- 차트는 Server Component 다(JS 없음). page 에서 service 집계를 받아 props 로 넘긴다. 하나의 숫자는 차트 대신 `Stat`. 범주 비교 `BarChart` · 시간 추이 `LineChart` · 전체 중 구성비 `DonutChart`(`rows=[{ label, value }]`, 양수만).
- 계열 색은 `--ds-series-1..5`(KDS data-visual) 고정 순서. KDS 20261012 의미 토큰 teal→yellow→blue→purple→red를 따른다. 변경 후 모드별 대비·색 외 값과 범례를 실제 확인한다. 계열이 5개를 넘으면 상위 4개 + "기타"로 묶는다(6개 이상은 오류).
- 축은 하나. 단위가 다른 두 값은 차트 두 개로 나눈다. 계열 2개 이상이면 범례가 자동으로 붙고, 값은 막대 옆 글자·마우스 툴팁(title)으로 보인다.
- E2E 는 `getByTestId("chart")` 또는 `getByRole("figure", { name: label })` 과 값 글자로 확인한다.

## 달력
- `Calendar`(Server, JS 없음) + `@/lib/calendar`(날짜 계산·`CalendarQuery`·`CalendarEvent`). 이동·월/주 전환은 URL `?view=month|week&date=YYYY-MM-DD` 로만 한다. 일요일 시작, 월 보기는 하루 3건 + "+N건".
- 이벤트는 `{ id, date: "YYYY-MM-DD", time?: "HH:mm", title, href?, tone?: "primary" | "subtle" }`. 내 일정은 `primary`(검정), 남의 일정은 기본(회색).
- 조회는 보이는 날짜 범위만: `gridRange(visibleDays(view, date))` → `[from, to)`. gen `datetime` 열(텍스트)은 문자열로 비교한다.

```ts
// service — 범위 안 일정 → 이벤트. 조회 범위는 목록과 같은 ownerScope
export async function slotCalendar(actor: SessionUser, days: string[]): Promise<CalendarEvent[]> {
  const { from, to } = gridRange(days);
  const rows = await baseSelect()
    .where(and(ownerScope(actor, listScope(actor), slots.ownerId), gte(slots.startAt, from), lt(slots.startAt, to)))
    .orderBy(asc(slots.startAt)).limit(500).all();
  return rows.map(({ r }) => ({
    id: r.id, date: r.startAt.slice(0, 10), time: r.startAt.slice(11, 16), title: r.title,
    href: `/slots/${r.id}`, tone: r.ownerId === actor.id ? "primary" : "subtle",
  }));
}
// app/(app)/slots/calendar/page.tsx
const q = CalendarQuery.parse(await searchParams);
const today = kstToday();
const date = q.date ?? today;
<Calendar view={q.view} date={date} today={today} events={await slotCalendar(user, visibleDays(q.view, date))} basePath="/slots/calendar" />
```

- `dayHref={(d) => ...}` 를 주면 날짜 숫자가 링크가 된다(그날 타임라인·새로 만들기). 필터는 `params` 로 넘기면 이동해도 유지된다.
- 여러 날에 걸친 일정은 시작일에만 보인다. 기간 막대가 필요하면 날짜마다 이벤트를 펼쳐(`addDays`) 넣는다.
- 타임스탬프(`Date`) 열이면 `kstDate(from)`·`kstParts(startAt)` 로 바꿔 비교·표시한다(예제판 `bookings/service.ts` `bookingCalendar`).
- E2E 는 `getByTestId("calendar")` 안의 `[data-date="2026-10-08"]` 칸과 `getByTestId("calendar-event")` 글자로 확인한다.


## 제공 화면 기준

`public/kds/templates`·`examples`와 `/design-system/kds` React 참조 화면은 20261012 동일 외관을 제공한다. KDS 원본을 수정하거나 Tailwind Preflight로 기본 여백을 바꾸지 않는다. 날짜·범위 생성은 `DatePicker`·`DateRangePicker`, 검색은 `SearchField`, 표 건수는 `ResultCount`를 사용한다. DOM 날짜 스크립트는 HTML 미리보기 전용이다.
