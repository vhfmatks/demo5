# Kit 디자인 시스템과 사용 방법

기준일: 2026-10-13. 제공 KDS 배포: **20261012**. KT의 [Seamless Flow](https://uxdesign.kt.com/)를 기반으로 서비스 간 일관된 경험을 만들고, 반복되는 UI를 같은 토큰과 컴포넌트로 구현한다. 화면의 업무·정보 순서·배치는 요구사항에 맞춰 설계한다. KDS 외관 규칙 때문에 요청한 기능이나 흐름을 바꾸지 않는다.

기본·특정 화면용 공통 UI의 최신 목록과 코드 예제는 [컴포넌트 사용법](components.md)에 있다. 실행 가능한 조합은 `/design-system`에서 확인한다.

## 1. 기준과 적용 범위

| 기준 | 확인 위치 | 적용 방법 |
|---|---|---|
| 공식 사이트 | [조사 기록](../research/kt-ux-design.md) | 본문으로 확인한 지침과 제목만 확인한 영역을 구분 |
| 제공 KDS 2.0 키트 자료 | [원문 문서](reference/README.md), `public/kds/source-manifest.json` · `public/kds/templates` · `public/kds/examples` | 토큰·외관·모바일/PC 대응의 구현 기준 |
| 현재 React API | `src/components/ui/index.ts` | 기능 코드는 `@/components/ui`에서만 import |
| Kit 구현 계약 | [ui 규칙](../conventions/ui.md), [오류 계약](../conventions/errors.md) | Server/Client 경계·입력 검증·권한·피드백 연결 |

공식 사이트 전체 내비게이션을 조사했지만 일부 세부 본문은 공개 조회가 제한된다. 접근하지 못한 UX Principles·UX Writing 등의 세부 규칙을 공식 요구사항으로 만들어 넣지 않는다. 원문 React 패키지(`@BG002501-…`)를 설치하거나 문서의 props를 현재 컴포넌트에 그대로 넘기지 않는다. 공식 웹·제공 자료가 다를 때 버전과 근거를 기록하고, 기존 원본 토큰을 조용히 바꾸지 않는다.

## 2. 설계 방침

- 정보 위계는 회색·글자 크기·굵기·간격으로 만든다. 회색 기반과 포인트 색의 권장 비율은 8:2이며 포인트로 넓은 배경을 칠하지 않는다. [공식 Color](https://uxdesign.kt.com/054231ea3/v/62989/p/30fed2-color)
- 주요 확정 동작은 검정 `primary`, 취소는 옆의 `secondary`, 단독 보조 동작은 `tertiary`다. KT 레드 `accent`는 사용자가 요청한 경우 화면당 하나만 쓴다. 삭제는 `tertiary`로 시작하고 확인창에서 확정한다. 이 버튼 제한은 제공 KDS 키트의 지침이다.
- 면은 한 겹으로 구성한다. 카드 안에 카드·색 안내 상자를 쌓지 않는다. 섹션 제목은 카드 밖에 두고 그림자는 팝업·드롭다운 등 떠 있는 요소에 쓴다.
- 빨강은 오류·예외 상태·짧은 강조 문구에 사용한다. 일반 순위·최댓값·최저가는 굵기로 강조한다. 태그를 모든 정상 항목에 붙이지 않는다.
- 여백은 원칙적으로 4pt, 작은 복잡한 요소는 제한적으로 2pt 단위를 쓴다. [공식 Breakpoint](https://uxdesign.kt.com/054231ea3/v/56739/p/85c2cb-breakpoint)

## 3. Foundations: 토큰 사용

CSS는 `kds-tokens.css` → `kds-base.css` → `kds-components.css` 순서로 `src/app/globals.css`에서 불러온다. 원본 `public/kds`를 기능별로 덮어쓰지 않는다. 통합에 필요한 접근성·반응형 보완은 `kit-*` 클래스로 분리한다.

| 역할 | 기능 코드에서 사용 | 연결되는 KDS 토큰 |
|---|---|---|
| 배경·기본 면·보조 면 | `bg-bg`, `bg-surface`, `bg-subtle` | background-default, surface-primary-01/02 |
| 본문·보조·선 | `text-fg`, `text-muted`, `border-line` | text-primary, text-secondary-01, border-secondary-01 |
| 확정 버튼 | `Button` variant API | fill-primary, text-inverse |
| 오류 | `Alert`, `Field error`, `text-danger` | text-feedback-critical-01 |
| 결과 상태 | `Tag tone` | tag-status-fill/text-* |

본문 텍스트는 배경 대비 4.5:1 이상이 공식 Color의 기준이다. 토큰을 썼다는 이유만으로 모든 조합이 이 기준을 만족한다고 보지 않는다. 배경·모드 변경 시 실제 조합을 확인하고, 상태에는 색과 함께 읽을 수 있는 문구를 제공한다. [공식 Color](https://uxdesign.kt.com/054231ea3/v/62989/p/30fed2-color)

**타이포:** 본문·폼·버튼·표는 Pretendard, 큰 display/heading 제목에만 `font-brand`(KT Flow)를 사용한다. KT Flow는 외부 공유 금지라 공개 scaffold에는 넣지 않는다. `moai-kit kds-fonts <제공 fonts/web>`로 참가자 로컬 전용 자산을 설치하며 없으면 Pretendard로 표시된다.

| 역할 | 기본 사용 |
|---|---|
| 페이지 제목 | `PageHeader`: 모바일 22 / PC 36, 굵게 |
| 카드 섹션 제목 | `Card title`: 20, 굵게 |
| 모바일 업무 섹션 | `Section title`: 16, 굵게 |
| 본문·보조·캡션 | `body-large-medium` / `body-small-medium` / `caption-medium-medium` |
| 긴 글 | `body-reading-large-regular` 또는 `body-reading-medium-regular` |

이는 [제공 타이포](reference/foundations/typography.md)·제공 KDS 키트 구성 지침의 kit 적용값이다. 제목마다 임의 크기를 추가하지 않는다.

**간격:** Tailwind 단위 1은 4px다. KDS 8/16/20/24/40/64는 `gap-2`/`p-4`/`p-5`/`gap-6`/`mb-10`/`gap-16`으로 표현한다. 세밀한 내부 배치의 2px 간격은 `gap-0.5`로 표현한다. `p-[13px]` 같은 임의값을 쓰지 않는다.

**모서리·높이:** 버튼·입력 8, 카드·팝업 12, 시트 상단 16, 피드 카드 20 등은 원본 클래스가 소유한다. `rounded-*`·`shadow-*`로 ui 컴포넌트를 다시 꾸미지 않는다. [Radius](reference/foundations/radius.md) · [Elevation](reference/foundations/elevation.md)

**움직임:** 제공 토큰의 short/medium/long(100/200/300ms)을 사용한다. kit는 `prefers-reduced-motion: reduce`에서 이 세 전환 시간을 0으로 만든다. 새 반복 애니메이션은 별도로 정지 동작을 제공한다. [Motion](reference/foundations/motion.md)

**아이콘:** `Icon`은 기본 24, `size={20|16}`을 지원한다. 기본 상태는 `line-*`, 선택 상태는 필요에 따라 `fill-*`. 의미는 버튼의 텍스트나 `IconButton label`로 전달한다. SVG를 문자·이모지로 대체하지 않는다. 필요한 파일의 존재를 `public/kds/icons`에서 확인한다.

## 4. 반응형과 테마

| 구간 | 레이아웃·컴포넌트 |
|---|---|
| 768 미만 | 4열, 기본 좌우 20, 모바일 메뉴·업무형 섹션 |
| 768–1279 | 8열, 기본 좌우 20, 모바일 컴포넌트 |
| 1280 이상 | 12열, 기본 콘텐츠 최대 1080, PC GNB |

위 수치는 [제공 Breakpoint](reference/foundations/breakpoint.md)와 현재 `kds-base.css`의 구현 기준이다. 1080은 콘텐츠 폭이며 전환점이 아니다. Tailwind `sm=360`, `md=768`, `lg=1280`, `xl=1920`으로 맞췄다. `md:`는 태블릿 배치용, PC 전용 UI의 전환에는 `lg:`를 사용한다. 좁은 화면의 `Gnb`는 햄버거로 같은 메뉴를 열고 링크 이동·Escape로 닫는다.

`data-mode="agent|dark|dark-agent"`를 해당 영역의 최상위에 지정한다. 기본 light는 속성을 생략한다. agent는 피드/AI 표면 테마이며 로그인 역할·권한과 무관하다. 관리자 포털의 dark 선택은 kit의 운영 결정이다. CSS 변수 별칭은 모드 영역마다 다시 연결되어 `bg-*`·`text-*`가 같은 테마를 따른다.

## 5. 현재 컴포넌트 API

| 목적 | 컴포넌트·핵심 props |
|---|---|
| 동작·이동 | `Button`, `LinkButton`: variant, size, full; Button loading |
| 아이콘 동작 | `IconButton`: name, label(필수), type |
| 입력 | `Field`: label, name, required, hint, error; `Input`, `Textarea`, `Select`: 기본 HTML props, invalid |
| 검색 | `SearchField`: name, label, defaultValue, placeholder; 바깥 GET 폼을 제출 |
| 선택 | `Checkbox`, `Radio`, `Switch`: 기본 input props + children; `toOptions`는 값/라벨 Record 변환 |
| 상태·안내 | `Tag`: tone; `Alert`: error/info; `EmptyState`: title, action |
| 확인 | `ConfirmDialog`: open, title, body, confirmLabel, loading, onConfirm, onCancel, children |
| 구조 | `PageHeader`: title, description, actions; `Card`: title, actions, className; `Section`: title, className |
| 데이터 | `Stat`, `DescriptionList`, `DataTable`, `Pagination` |
| 메뉴·보조 | `Gnb`, `Icon`, `cn` |

`Button size`는 xsmall 32 / small 40 / medium 44(기본) / large 48이다. `variant="text"`는 별도 글자 버튼이므로 size/full이 적용되지 않는다. `className`은 레이아웃에만 사용한다.

코드 예제는 [화면 계약](../conventions/ui.md)(목록·폼·확인창), 추가 컴포넌트는 [컴포넌트 사용법](components.md)에 있다.

`Field`의 직접 자식이 `Input`·`Textarea`·`Select` 하나일 때 id·label·aria-required·오류/힌트의 aria-describedby를 자동 연결한다. 별도 id를 주면 같은 id로 도움말을 연결한다. 필수 표시는 aria-required로 전달하며 별표는 접근 가능한 이름에서 제외한다. 필수 표시만으로 검증을 추가하지는 않는다. 쓰기 폼은 `noValidate`와 `useMutation`의 `schema` 옵션으로 feature의 zod 스키마를 제출 전에 재사용하며 서버에서도 검사한다. 컨트롤을 별도 요소로 감싸거나 여러 컨트롤을 넣을 때는 id·label·오류 연결을 직접 설계한다. 체크·라디오 그룹은 `fieldset`/`legend`로 이름을 제공한다.

## 6. 화면 패턴과 피드백

| 상황 | 선택 기준 |
|---|---|
| PC 업무 목록 | PageHeader → GET 필터 → 결과/표 → Pagination. 숫자 컬럼은 `is-num` |
| 모바일 단일 업무 | `Section`으로 평평하게 구성. 카드 목록을 그대로 쌓지 않는다 |
| 피드·혜택 탐색 | agent 모드 + 피드 표면. `FeedSection`·`FeedCard`·`HorizontalScroll` 사용 |
| 짧은 선택 4개 이하 | Radio 등을 우선 고려. 길거나 많은 선택지는 Select |
| 삭제·되돌릴 수 없는 확정 | ConfirmDialog, 취소 왼쪽·확정 오른쪽, 같은 폭 |
| 입력 오류 | Field error + 화면 Alert. 작성 값을 유지하고 원인과 수정 방법 제시 |
| 비어 있는 데이터 | EmptyState의 짧은 설명 + 필요한 다음 행동 |
| 검색 결과 없음 | 검색 조건을 바꾸거나 초기화하는 행동 제공. 데이터 없음과 구분 |
| 저장 중 | Button loading: 중복 제출 차단·aria-busy. 실패 시 재시도 가능 여부와 문의 traceId 활용 |

확인창은 native dialog로 배경을 비활성화하고, 첫 포커스를 취소에 두며 Tab/Shift+Tab을 내부에서 순환시킨다. Escape는 취소, 처리 중에는 닫지 않는다. 닫으면 연결되어 있는 원래 트리거로 포커스를 돌린다. 현재 정책은 배경 클릭 취소를 제공하지 않는다.

공식 Tab은 같은 맥락의 섹션 전환을 위해 Fixed/Scrollable을 구분하고 레이블 최대 10자를 안내한다. 탭을 추가할 때는 키보드 이동·선택 상태·패널 연결까지 구현한다. [Tab](https://uxdesign.kt.com/054231ea3/v/56739/p/036069-tab)

공식 Bottom Sheet는 최대 화면 높이 90%와 내부 스크롤을 안내하지만 제공 CSS는 85dvh로 구현되어 있다. 원본을 보존하고 신규 `BottomSheet`의 kit 클래스에는 공식 기준인 90dvh를 적용했다. 헤더·푸터는 고정하고 본문은 내부 스크롤한다. [Bottom Sheet](https://uxdesign.kt.com/054231ea3/v/60591/p/620487-bottom-sheet)

공식 Notification에서 확인한 3초 자동 소멸은 일시적 알림에 관한 지침이다. kit의 폼 오류·복구 안내는 지속적인 `Alert`로 유지한다. 원문 Snackbar는 기본 4초인 차이도 있어, 알림 추가 시 유형별 동작을 정해야 한다. [공식 Notification](https://uxdesign.kt.com/054231ea3/p/607d4b-notification/v/56947) · [제공 원문](reference/components/notification.md)

## 7. 전체 공식 영역의 kit 적용

| 공식 영역 | kit에서 사용하는 방법·현재 범위 |
|---|---|
| Seamless Flow | 공통 토큰·UI 진입점·업무 흐름의 일관성. 상세 UX Principles 본문은 미확인 |
| Foundations | 색·타이포·모서리·높이·간격·모션·아이콘은 제공 원문과 현재 CSS로 연결. 접근성은 위 구현 계약으로 보완 |
| Components | §5의 기존 API와 [추가 컴포넌트](components.md)를 제공. Accordion·모바일 탐색/시트·Breadcrumb·Chip·Slider·Tabs·Tooltip·Loading/Skeleton·ItemTile·날짜·차트 포함. 원문의 모든 variant와 API를 동일하게 복제한 것은 아님 |
| Patterns | 빈 화면·폼·검색·상태를 §6으로 적용. 온보딩·약관은 기능 요구사항에 맞춰 추가 |
| Visual Communication | Detail Page·Infographic·Message·Hero/Contents Banner의 존재 확인. 상세 본문 미확인, 현재 전용 래퍼 없음 |
| AI Agent | PromptTextField·PromptInput/Output·ProcessIndicator·ContextPanel·Sidebar·CodeBlock·DocumentViewer를 제공. AI 호출·음성/파일/PDF 처리 API는 업무에서 연결 |
| UX Writing | 한국어·동사형 행동·명확한 오류는 kit 문구 규칙. 공식 표기/상황별 세부 원칙은 미확인 |
| Resources | 제공 자료와 확인 날짜·버전·차이를 기록하고 변경 후 lint·타입·업무 흐름 검증 |

AI 화면을 새로 만들 때 검색·즉시 결과(Monologue)와 연속 대화(Bubble)를 구분한다. 공식 Prompt Input의 접힌 질문은 각각 최대 4줄/3줄과 펼치기를 안내한다. 제공 KDS CSS는 사용자 말풍선과 평평한 AI 답변을 구분한다. AI 내비게이션은 새 대화·검색·최근 대화·프로필을 중심으로 설계하며 일반 서비스 메뉴에 그대로 강제하지 않는다. [Prompt Input](https://uxdesign.kt.com/054231ea3/v/60591/p/239b45-prompt-input) · [Navigation Bar](https://uxdesign.kt.com/054231ea3/p/10a4ef-navigation-bar/v/56739)

차트 계열 색은 `--ds-series-1..5`(teal → yellow → blue → purple → red) 고정 순서다. 넓은 카드·좌석·점유 배경을 teal로 채우지 않는다. 그래프 안의 색과 범례·값을 함께 제공하고 다크 모드에서는 실제 차트 영역의 CSS 변수를 읽는다. `BarChart`·`LineChart`·`DonutChart`는 값 글자·범례·툴팁을 함께 보여 준다. [Data Visual](reference/components/data-visual.md)

## 8. 확장·사용 절차

1. 요청한 화면의 완료할 일·정보 순서·PC/모바일 사용을 정한다. 새 CRUD는 `npm run gen -- <entity> <한글라벨>`로 시작한다.
2. 현재 UI export와 이 가이드에서 적합한 컴포넌트를 선택한다. 생성기 목록은 SearchField를 사용하는 GET 검색을 제공한다.
3. 빠진 공통 UI는 제공 원문의 변형·상태를 확인한 뒤 `src/components/ui`에 구현한다. 설치되지 않은 원문 패키지를 import하지 않는다.
4. 기존 `kds-*` 외관을 사용하고 Client 경계는 상태·이벤트가 필요한 최소 컴포넌트로 둔다. 필요한 동작과 접근성을 함께 구현하고 index.ts에 export한다.
5. 변경한 업무 흐름을 키보드·좁은 화면·PC·사용 테마에서 확인한다. 디자인 lint는 임의 색·값·restyle 등을 막지만 대비·포커스·문구·레이아웃 전체를 증명하지 않는다.

```bash
npm run lint
npm run typecheck
npm run test:e2e -- tests/e2e/designSystem.ui.spec.ts
npm run verify
```

E2E는 격리 runner로만 실행한다. 현재 디자인 시스템 시험은 모바일 메뉴·필드 오류·확인창 포커스와 탭·시트/알림·날짜/범위·AI/문서/차트 동작을 검사하며 모든 KDS 컴포넌트·화면·모드의 준수 인증을 대신하지 않는다. 결과는 [E2E 문서](../e2e-test.md)와 실행별 evidence에 기록한다.


## KDS 20261012 원본 화면 재현

`public/kds/templates` 4종과 `examples` 4종을 보존하며 `/design-system/kds/<templates|examples>/<파일명>`에서 공통 React UI로 같은 화면을 제공한다. 같은 폰트·viewport·브라우저·데이터에서 `tests/e2e/kdsParity.ui.spec.ts`가 전체 화면 픽셀 차이 0을 검사한다. 신규 업무 화면은 해당 패턴과 원본 UI 치수를 사용한다. PC용 32/36px 컨트롤 축소는 적용하지 않는다.

KDS CSS가 reset을 소유하므로 Tailwind theme·utilities만 로드한다. [Tailwind Preflight](https://tailwindcss.com/docs/preflight)의 전체 여백 초기화는 원본 HTML 외관을 바꾸므로 포함하지 않는다.
