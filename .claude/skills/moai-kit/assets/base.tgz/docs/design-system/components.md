# 미리 준비된 컴포넌트 사용법

실행 예제: `npm run dev` → `/design-system`. 모든 컴포넌트는 `@/components/ui`에서 가져온다. 공식 원문 패키지와 API가 동일한 것은 아니며 아래는 **현재 kit API**다. 외관은 KDS 토큰·클래스, 동작은 native HTML과 React로 구현했다. 추가 의존성은 없다.

## 목록과 실행 경계

| 종류 | 준비된 컴포넌트 | 실행 경계 |
|---|---|---|
| 콘텐츠 전환·보충 정보 | Tabs, Accordion, Popover, Tooltip | Client |
| 팝업·하단 시트 | Modal, BottomSheet, ConfirmDialog | Client, 제어형 open/onClose |
| 일시 알림·복구 알림 | Toast, Snackbar | Client, 제어형 open/onClose |
| 날짜·기간 | DatePicker, DateRangePicker | Client, KDS 달력. 값은 ISO 문자열 |
| 시간·카드형 선택·칩 | TimeSlotPicker, SelectButton/Group, Chip/Group | native input/button. 이벤트 사용은 Client 부모 |
| 숫자·범위 | Slider, RangeSlider | Client, 제어/비제어 모두 지원 |
| 로딩·진행·상태 | Loading, Skeleton, Progress, PageIndicator, Notice | Server에서도 표시 가능 |
| 모바일·PC 탐색 | TopNavigation, BottomNavigation, Breadcrumb, Sidebar, CtaBar, InfoBand, Footer | Server에서도 표시 가능, 현재 href를 props로 전달 |
| 피드·타일·목록 | FeedCard/Section, HorizontalScroll, ItemTile, LinkList, KeyValue, Divider, FloatingActionButton | Server에서도 표시 가능, 이벤트 사용은 Client 부모 |
| 차트 | BarChart, LineChart, DonutChart | Server, JS 없음. 계열 색 `--ds-series-1..5` |
| AI 입력·응답 | PromptTextField, PromptInput, PromptOutput, PromptConversation, PromptSuggestions | Client |
| AI 상태·출처·코드 | ProcessIndicator, ContextPanel, CodeBlock, AiMark | Client |
| 문서 페이지 보기 | DocumentViewer | Client, 사전 렌더링한 페이지 이미지 배열 |

Server에서 Client 컴포넌트로 전달하는 데이터는 직렬화 가능해야 한다. 이벤트 콜백·파일 상태는 Client 부모에서 관리한다. 표시용 `children` 슬롯은 Server가 렌더링해 전달할 수 있다. UI가 업무 권한·DB·AI 호출을 소유하지 않는다.

## 선택과 범위

```tsx
import { DateRangePicker, SelectButton, SelectButtonGroup, Slider, TimeSlotPicker } from "@/components/ui";

<DateRangePicker
  start={{ name: "start", label: "시작일", min: "2026-10-01" }}
  end={{ name: "end", label: "종료일" }}
/>
<TimeSlotPicker name="time" label="예약 시간" options={[
  { value: "09:00", label: "오전 9시" },
  { value: "10:00", label: "오전 10시", disabled: true },
]} />
<SelectButtonGroup label="이용권" columns={2}>
  <SelectButton name="plan" value="day" label="하루" defaultChecked />
  <SelectButton name="plan" value="week" label="일주일" />
</SelectButtonGroup>
<Slider label="인원" name="people" min={1} max={12} defaultValue={4} unit="명" />
```

- `DatePicker`: 필수 name/label, 기본 input props(value/defaultValue/min/max/disabled/onChange 등), hint/error. 날짜는 KDS 달력이며 화면 `YYYY.MM.DD`, FormData·value/defaultValue·onValueChange는 ISO `YYYY-MM-DD`다. 달력 min/max·윤년·월말·키보드 탐색·Escape·외부 닫기·초점 복원을 제공한다. `onChange`는 ISO 값 input 이벤트를 전달한다. 오류와 도움말은 Field에 연결한다. `bare`는 원본 HTML과 같은 라벨 없는 컨트롤로 aria-label을 제공한다.
- `DateRangePicker`: start/end에 각각 DatePickerProps를 전달한다. 날짜 순서·겹침·업무 가능 시간은 서버 스키마/서비스가 검증한다. 시작/종료를 자동 수정하지 않는다.
- `TimeSlotPicker`: name/label/options, value/defaultValue/onValueChange. native radio이므로 FormData·Tab·방향키를 지원하고 마감 옵션은 disabled로 전달한다.
- `SelectButton`: 기본 radio, 다중 선택은 type="checkbox". 표준 input props와 label/description을 지원한다. Group은 legend와 columns(1/2/3)를 제공한다.
- `Chip`: children/selected + 기본 button props. ChipGroup은 label로 그룹 이름을 제공한다. 실제 필터 값은 호출자가 URL/상태로 관리한다.
- `Slider`: label/value/defaultValue/min/max/step/unit/name/disabled/onValueChange. `RangeSlider`는 튜플 `[minValue,maxValue]`, `names`도 튜플이다. 범위는 이름 있는 두 native 핸들로 조작하며 서로 넘지 않도록 상대 값을 경계로 쓴다. 유효한 초기값과 step을 전달한다.

PC·모바일 모두 KDS 원본 입력 52·검색 48·버튼 32/40/44/48·표 44/56·페이지 번호 40을 유지한다. 화면 밀도는 배치만 바꾼다.

폼 저장은 기존 `useMutation` + `apiClient`, 검증은 feature 스키마를 따른다. DatePicker의 min/max/required는 브라우저 입력 보조이며 서버 검증을 대신하지 않는다.

## 전환·모달·알림

```tsx
<Tabs label="자료 종류" defaultValue="summary" items={[
  { value: "summary", label: "요약", content: <Summary /> },
  { value: "history", label: "내역", content: <History /> },
]} />
<BottomSheet open={open} title="정렬" onClose={() => setOpen(false)}
  footer={<Button onClick={apply}>적용</Button>}>
  <SortOptions />
</BottomSheet>
```

| 컴포넌트 | 주요 계약 |
|---|---|
| Tabs | label/items(value·label·content·disabled), value/defaultValue/onValueChange, type=fixed/scrollable. 방향키·Home·End는 비활성 탭을 건너뛰고 선택/포커스를 함께 이동 |
| Accordion | label/items(id·title·content·defaultOpen), multiple. native details/summary; 기본은 한 항목만 열기 |
| Popover | label/children. summary로 열고 외부 클릭·Escape로 닫기. 내부를 강제 menu 역할로 만들지 않으므로 폼·정보를 넣을 수 있음 |
| Tooltip | label/content(문자열). 초점·hover·탭으로 열기, Escape/초점 이탈로 닫기. 링크·버튼을 넣을 때는 Popover |
| Modal | open/title/children/onClose, description/footer/busy/showClose/size(small·medium). 초점 격리·복원과 내부 스크롤 |
| BottomSheet | ModalProps, 모바일은 화면 하단·최대 90dvh, PC는 가운데 배치. 헤더/푸터 고정, 긴 본문 내부 스크롤 |
| Toast | open/children/onClose, duration(기본 3000ms; 0이면 유지), action/closeLabel. hover/초점 동안 타이머 중단, 이탈 후 전체 duration부터 재시작 |
| Snackbar | Toast 계약, 기본 duration=0. 복구 동작을 읽고 실행할 시간을 제공 |

Toast의 `onClose`는 Client 부모에서 `useCallback` 등으로 안정적으로 전달하면 불필요한 타이머 재시작을 피할 수 있다. 폼 오류는 자동 소멸시키지 않고 기존 Alert/Field error를 사용한다. 확인·시트의 업무 저장 중에는 busy를 전달하고 동작 버튼의 loading/disabled도 지정한다. 모달 배경 클릭 닫기는 제공하지 않는다.

## 차트·피드·탐색

```tsx
<BarChart label="요일별 이용" rows={[{ label: "월", values: [24] }, { label: "화", values: [36] }]} />
<DonutChart label="이용 비율" rows={[{ label: "월", value: 24 }, { label: "화", value: 36 }]} format={(n) => `${n}건`} />
<Sidebar label="자료" currentHref="/reports" items={[
  { href: "/reports", label: "보고서", icon: "line-document" },
]} />
```

- 공통 props: `label`(figure 이름)·`format`(값 표시). Bar = `rows[].values[]`+`series`(다중 계열), Line = `x`+`series[]`(음수 허용), Donut = `rows[].value`(양수만, 0 이하 제외, 없으면 EmptyState). 사용 규칙은 [ui.md 차트](../conventions/ui.md#차트).
- 값은 막대 옆 글자·Donut 범례(값·비율)·마우스 툴팁(title)으로 보인다. 계열은 최대 5개(넘으면 "기타"로 묶는다). 색은 `--ds-series-1..5` 고정 순서로 차트 영역의 모드를 따른다.
- BottomNavigation(items/currentHref)·TopNavigation(title/backHref/actions)은 PC에서 숨긴다. Sidebar(label/items/currentHref/header/footer)는 좁은 화면에서는 전체 폭, PC에서는 280 폭이다. 접히는 모바일 사이드 메뉴가 필요하면 BottomSheet와 조합한다.
- Breadcrumb(items: label/href), LinkList(label/items/divided), KeyValue(label/children), Footer(children)로 표시 구조를 만든다.
- FeedSection(title/actions)·FeedCard·HorizontalScroll(label)는 agent 모드 영역에 둔다. ItemTile(title/description/href/image/children)의 image는 호출자가 접근 가능한 이미지 요소로 제공한다. 이동형 타일 안에 다른 버튼/링크를 중첩하지 않는다.
- Divider(band), Progress(label/value/max, Chart.tsx), PageIndicator(current/total/label), Loading(label), Skeleton(label/lines), Notice(title/children/actions)를 제공한다. Skeleton과 PageIndicator의 반복 표시는 최대 20개이며 전용 상태 문구가 있다.
- FloatingActionButton은 label/name과 기본 button props를 받는다. 고정 위치는 호출자가 레이아웃 영역에서 배치하며 컴포넌트가 페이지 위치를 강제하지 않는다.

## AI·문서 조합

```tsx
<PromptConversation>
  <PromptInput>{question}</PromptInput>
  <PromptOutput sources={sources}>{answer}</PromptOutput>
  <ProcessIndicator state="generating" text="답변을 생성하고 있습니다." />
</PromptConversation>
<PromptTextField value={draft} onValueChange={setDraft}
  onSend={send} processing={pending} onStop={stop}
  attachments={attachments} onFilesChange={attachFiles} onRemoveAttachment={removeFile} />
<ContextPanel title="출처" open={open} onClose={close}><SourceList /></ContextPanel>
```

| 컴포넌트 | 주요 계약 |
|---|---|
| PromptTextField | value/defaultValue/onValueChange, onSend(필수), label/name/placeholder, processing/disabled/onStop, attachments/onFilesChange/onRemoveAttachment, onVoice/disclaimer |
| PromptInput | 사용자 발화 children. 이름은 공식 Prompt Input 영역에 대응하며 입력 폼은 PromptTextField |
| PromptOutput | 답변 children, sources(label/href), onLike/onDislike. 일반 React 콘텐츠를 표시하며 HTML 삽입·Markdown 자동 파싱 없음 |
| PromptConversation | label/children. 대화 목록·페이지·스트리밍 데이터의 소유권은 호출자 |
| PromptSuggestions | items(문자열 배열)/onSelect. 클릭하면 호출자가 입력 초안으로 반영 |
| ProcessIndicator | state=processing/generating/complete/canceled/error, text(필수), details. 공개 처리 단계 설명을 접고 펼침 |
| ContextPanel | title/children/open/onClose. 반응형 inline aside, 모달 동작이 필요하면 BottomSheet에 내용을 넣음 |
| CodeBlock | code/language. 브라우저 Clipboard 복사와 성공/실패 안내 |
| DocumentViewer | title/pages(src·alt·width·height). 사전 렌더링된 페이지 이미지의 이전·다음 탐색 |
| AiMark | 접근 가능한 AI 표시 |

PromptTextField는 Enter로 줄바꿈, Ctrl/Command+Enter 또는 전송 버튼으로 제출한다. IME 조합 중 제출하지 않으며 처리 중 입력·첨부를 잠그고 onStop이 있으면 중지를 제공한다. 초안은 제출 후 자동 삭제하지 않는다. 파일 선택은 File[]를 콜백으로 전달할 뿐 업로드하지 않는다. 음성 버튼은 onVoice를 연결했을 때만 표시한다.

AI 호출·응답 스트림·음성 인식·파일 업로드·PDF 변환은 화면의 서비스/API에 연결한다. DocumentViewer는 PDF 파일 자체를 파싱하는 라이브러리가 아니다. `/design-system`은 합성 데이터로 UI 동작만 보여 준다.

## 검증

2026-10-09 이전 UI의 390px 모바일·시트 이력(20261012 변경 이후 근거를 대신하지 않음): [갤러리 화면](../evidence/design-system-gallery-mobile-20261009.png) · [하단 시트 화면](../evidence/design-system-sheet-mobile-20261009.png). 이미지 근거의 실행 ID는 `20261008191924425-90d0a690-494b-4dd6-87d6-f3382146ed74`다.

```bash
npm run test:e2e -- tests/e2e/designSystem.ui.spec.ts
npm run verify
```

TC-DESIGN-UI-001/002는 기존 메뉴·필드 오류·확인창을, 003–006은 신규 전환·시트/알림·폼 값/키보드 범위·AI 첨부/중지/문서/차트를 검사한다. 002와 007의 일반 사용자 메뉴는 예제판(공개 메모·요청)에서만 실행된다. 실제 실행 결과는 [E2E 근거](../e2e-test.md)를 따른다. 원문 전체 variant의 복제나 모든 브라우저·보조기술의 준수 인증을 의미하지 않는다.


## 독립 화면 틀

`TaskPage(title/backHref/actions/info/footer)`는 원본 모바일 업무 프레임 480·100dvh와 TopNavigation을 제공한다. 본문은 Section·Divider, footer는 CtaBar로 구성한다. `FeedPage(title/actions/footer)`는 agent 모드의 피드 프레임과 52px 헤더·sticky dock을 제공하며 FeedSection·FeedCard·HorizontalScroll을 사용한다. `PcPage(items/actions/footer)`는 PC Gnb·1080 컨테이너·Footer를 제공한다. 기존 `(app)`/`(public)` 레이아웃에서 이미 셸을 사용하는 페이지는 이 독립 틀을 다시 중첩하지 않는다. 원본 8종 React 화면은 `/design-system/kds`에서 확인한다.

선택 DatePicker는 값이 있을 때 `<라벨> 지우기` 버튼을 제공하고 onChange/onValueChange 및 hidden FormData에 빈 값을 전달한다. 필수·disabled·readOnly에는 지우기를 제공하지 않는다.
