# 제공 KDS 2.0 키트 원문

제공 `kds-hackathon-kit_20261012/kds-hackathon-kit`의 `docs/` Markdown 60개를 그대로 옮겼다(2026-10-13). Foundations·Components·AI Prompt 세부 문서를 로컬에서 찾아볼 수 있다. 글꼴·Figma 파일은 이 경로에 복사하지 않는다.

원문에 있는 `@BG002501-…` 패키지 경로·compound API·props는 현재 앱에 설치된 API가 아니다. 앱 코드는 [kit 사용 가이드](../README.md)와 `@/components/ui`의 실제 export를 따른다. 원문의 오타·상충 값도 그대로 보존했으므로 공식 사이트의 현행 지침과 동일하다고 단정하지 않는다. 확인한 공식 내용·버전·공개 조회 한계는 [조사 기록](../../research/kt-ux-design.md)에 있다.

| 먼저 볼 자료 | 내용 |
|---|---|
| [반응형](foundations/breakpoint.md) · [모바일–PC 대응](foundations/mobile-pc-mapping.md) | 간격·구간·디바이스별 컴포넌트 |
| [타이포](foundations/typography.md) · [색상](foundations/color-semantic-light-default.md) | 글자 위계·의미 토큰 |
| [모서리](foundations/radius.md) · [높이](foundations/elevation.md) · [움직임](foundations/motion.md) · [아이콘](foundations/iconography.md) | 기초 요소 |
| [버튼](components/button-button.md) · [입력](components/text-field.md) · [검색](components/search.md) | 입력과 주요 동작 |
| [표](components/table-data-table.md) · [팝업](components/popup.md) · [알림](components/notification.md) | 데이터·피드백 |
| [AI 개요](ai-prompt/overview.md) | Prompt·Sidebar·Context Panel |

같은 폴더의 나머지 문서는 각 컴포넌트 이름으로 찾는다. 페이지 구조는 사용자가 요청한 업무 흐름에 맞게 구성하며, 원문 예시를 필수 화면 템플릿으로 취급하지 않는다.


원문 안의 `AGENTS.md`는 제공 KDS의 사용 규칙을 뜻한다. 프로젝트의 실제 구현은 [KDS 사용 가이드](../README.md)와 [실제 UI API](../components.md)를 따른다. `tokens/`는 프로젝트 `public/kds/tokens`에 대응한다. 원문의 `lg=1024` 주의는 Tailwind 설정이 없는 해커톤 HTML 기준이며, 이 scaffold는 `lg=1280`을 설정한다. 원문에서 클래스가 없다고 한 컴포넌트 중 일부는 moai-kit의 React UI 확장으로 제공한다.
