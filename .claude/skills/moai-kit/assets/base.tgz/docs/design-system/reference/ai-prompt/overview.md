BADGE (없음 — 개요 문서, prop 테이블 없음)
Prompt: AI와 주고받는 대화 흐름에 쓰이는 컴포넌트 모음.
