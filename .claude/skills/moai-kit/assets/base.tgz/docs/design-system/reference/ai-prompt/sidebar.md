BADGE Mobile/Desktop
설명: 대화 목록·프로젝트 탐색 navigation surface. Desktop/Mobile root 각각 선택, header·contents·list·footer compound child 조합.
코드 패키지는 비공개라 설치 불가. 이 키트에서는 → 이 키트에 없음. 토큰(`tokens/kds-tokens.css`)으로 직접 그림. 아래 속성 이름은 참고용

## Root and compound children  (Root: HTMLAttributes<HTMLDivElement>)
SidebarDesktop, SidebarMobile → open, onOpenChange, theme, children
SidebarDesktopHeader/Contents/List/Footer, SidebarMobileHeader/Contents/List/Footer → children, List의 subtitle, subtitleState
SidebarItem → label, itemType(action | conversation | project | more), selected, state, onClick ⟨itemType="action"⟩
SidebarItemDesktop/Mobile → label, itemType, selected
SidebarLogo → logo, collapsedLogo, tag, collapsed
SidebarSubtitle → text, state: default | expanded | collapsed | reorder ⟨default⟩
SidebarBottom → type, userName, userInitial, memoryText ⟨프로필·메모리 footer⟩
SidebarListConversationMobile → type: conversation | skeleton | noData, children ⟨conversation⟩
SidebarPanelIconButton → icon, aria-label(필수), selected, expanded
SidebarSurfaceContext·useSidebarSurface. Mobile root는 onOpenChange 연결로 ESC·overlay 보존.

Examples: Default / Variants(Desktop surface, Mobile surface) / States(Default·Selected·Hover) / Subcomponents(Panel controls, Conversation list, list states, Item and bottom) / Interaction
Figma: (없음)
