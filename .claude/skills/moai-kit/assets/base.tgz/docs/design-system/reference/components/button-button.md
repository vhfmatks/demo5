BADGE Mobile/Desktop/디자인 동일
코드 패키지는 비공개라 설치 불가. 이 키트에서는 → `kds-button`. 아래 속성 이름은 참고용. `theme` 대신 모드는 `<html data-mode="agent">`처럼 페이지에 지정

## Button
variant → primary | secondary | tertiary | tertiary-filled | tertiary-subtle | tertiary-subtle-filled | accent-primary ⟨"primary"⟩ 버튼 시각 스타일
size → tiny | xsmall | small | medium | large | xlarge ⟨"medium"⟩ 버튼 크기 및 타이포그래피
children → ReactNode ⟨—⟩ 레이블·아이콘 콘텐츠
asChild → boolean ⟨false⟩ 기본 요소를 단일 자식 요소로 대체
theme → light | light-agent | dark | dark-agent ⟨전역 테마 상속⟩ 개별 테마 적용
disabled → boolean ⟨false⟩ 비활성화 여부
className → string ⟨—⟩ 추가 스타일 클래스 적용
(표준 HTML button 속성·이벤트 지원)

## Examples headings
Default / Variants / Sizes / With Icon / States (기본·Hover·Pressed·Disabled × 7 variants)
