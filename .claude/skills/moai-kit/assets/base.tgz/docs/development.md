# 개발 과정 · AI 활용

개발 판단 이력 문서다. AI 제안을 사람이 어떻게 검토·수정·검증했는지와 Issue·커밋 연결을 적는다. 현재 설계는 [arch](arch.md), 상세 로그는 `docs/evidence/`에 두고 링크한다.

## 진행 방식

릴리스마다 [PLAYBOOK](../PLAYBOOK.md)의 순서(요구 확정 → REQ/AC → Issue → 구현·검증 → 문서·근거)를 따른다. 규칙과 명령은 [AGENTS.md](../AGENTS.md)가 원본이다.

## AI 도구 사용 규칙

- 사용한 도구: 미정(실제 사용한 도구를 적는다).
- 규칙 파일: [AGENTS.md](../AGENTS.md), [conventions](conventions/), `.github/copilot-instructions.md`.
- 프롬프트에 비밀번호·토큰·개인정보를 넣지 않는다.

## AI 제안 → 팀 검토·수정 → 검증 사례 (AI 활용 근거)
| # | 상황 | AI 가 제안한 것 | 팀이 발견한 문제 | 수정·검증 | 커밋 / TC |
|---|---|---|---|---|---|
| 1 | | | | | |

## 일정 기록
| 시각 | 내용 |
|---|---|
