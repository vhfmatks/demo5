# KT UX Design System 공식 자료 조사

조사일: 2026-10-09. 범위는 [KT UX Design System 공식 사이트](https://uxdesign.kt.com/)의 공개 내비게이션·검색 가능한 공식 페이지 본문과, 작업 공간에 제공된 `kt-ux-design/` 자료다. **본문 확인**과 **공식 내비게이션에서 제목만 확인**을 구분한다. 이 문서는 사이트 전체 규칙을 모두 검증했다는 뜻이 아니다. 사이트는 zeroheight 기반이며 일반 웹 크롤러에서 상당수 페이지 본문이 비어 반환된다. 공개 HTML의 `window.styleguideDetails.categories`에서 문서 목록과 고유 페이지 URL을 확인했고, 아래 세부 규칙은 검색 엔진이 읽은 공식 페이지 본문에서만 확정했다. 일부 페이지에는 비밀번호가 설정되어 있으며 공개 API 본문 조회는 접근 거부(HTTP 401)였다. [사이트](https://uxdesign.kt.com/)

## 제작 방향과 정보 구조

- **Seamless Flow**는 KT의 여러 서비스를 하나의 일관된 고객 경험으로 잇는 KDS 제작 방향이며, 전사 공통 기준으로 효율과 품질을 높인다고 설명한다. [About](https://uxdesign.kt.com/054231ea3/v/56739/p/87691a-about)
- 공식 내비게이션의 주요 영역은 **Seamless Flow, Foundations, Components, Patterns, Visual Communication, AI Agent, UX Writing, Resources**다. 시작 화면은 Foundations를 시각적 일관성의 규칙, Components를 재사용 가능한 UI 요소, Patterns를 반복 업무와 문제 해결 가이드, AI Interaction을 AI 도구와 사용자 간 상호작용 가이드, UX Writing을 일관된 메시지의 언어 원칙으로 소개한다. 이 문장은 영역의 **설명과 존재 여부**만 검증한다. [사이트](https://uxdesign.kt.com/)
- Foundations의 공개 개요는 Color, Typography, Elevation, Breakpoint, Radius, Iconography, Motion, Accessibility, Design Token을 열거한다. [Foundations Overview](https://uxdesign.kt.com/054231ea3/v/56739/p/14ebc4-overview)

### 영역별 페이지 목록: 제목 확인, 본문 미확인

아래 목록은 공식 사이트 HTML 내비게이션에서 확인했다. 따라서 목록에 든 페이지의 규칙이나 수치까지 검증했다는 뜻은 아니다. 각 묶음의 링크는 해당 공식 영역의 시작 페이지다. [사이트](https://uxdesign.kt.com/)

| 영역 | 확인한 하위 페이지/그룹 | 공식 링크 |
| --- | --- | --- |
| Seamless Flow | About, UX Principles | [About](https://uxdesign.kt.com/054231ea3/p/87691a), [UX Principles](https://uxdesign.kt.com/054231ea3/p/69ce69) |
| Foundations | Color, Typography, Elevation, Breakpoint, Radius, Iconography, Motion, Accessibility, Design Token, Photography, Graphics | [Overview](https://uxdesign.kt.com/054231ea3/p/14ebc4) |
| Components | Accordion, Bottom Navigation, Bottom Sheet, Breadcrumb, Card, Divider, Dropdown, Item Tile, List, Loading, Navigation, Notification, Pagination, Popup, Search, Slider, Switch, Tab, Text Field, Tooltip, Top Navigation, Tag, Indicator, Data Visual, Button, Selection Controls(Checkbox·Radio Button·Select Button·Chip), Table·Data Table | [Overview](https://uxdesign.kt.com/054231ea3/p/16cb87) |
| Patterns | Common UI(빈 화면·유의사항·약관 동의·입력 폼), Service Pattern(시스템 상태·검색·온보딩) | [Overview](https://uxdesign.kt.com/054231ea3/p/591f50) |
| Visual Communication | Detail Page, Infographic, Message, Banner(Hero·Contents) | [Overview](https://uxdesign.kt.com/054231ea3/p/7434cb) |
| AI Agent | Principles, Components(AI Visual·Navigation Bar·Prompt Output·Process Indicator·Prompt Text Field·Context Panel·Prompt Input), Patterns(검색·파일 분석·설정·온보딩·음성입력·이미지 생성·대화형 질의응답) | [Principles](https://uxdesign.kt.com/054231ea3/p/97ae3a) |
| UX Writing | 정의, 기준과 원칙, 표기 규칙, 상황별 가이드 | [정의](https://uxdesign.kt.com/054231ea3/p/21709a) |
| Resources | Designer, Developer, Check List, Release Note | [Resources](https://uxdesign.kt.com/054231ea3/p/71ffe7) |

## 본문까지 확인한 규칙과 사용 지침

- **Color:** Gray Scale을 정보 위계의 기반으로 쓴다. Gray 400 이하 단계는 보더·배경 같은 구조 요소에 권장하고, 본문 텍스트는 최소 Gray 500 이상과 배경 대비 4.5:1 이상을 안내한다. 흰 배경의 권장 최소는 Gray 500, `#F3F4F6` 회색 배경은 Gray 550이다. 회색 배경으로 바꾸면 일부 의미 토큰을 1~2단계 올리는 예시가 있으며, Gray Scale과 Accent 비율은 **8:2 권장**이다. 이들은 권장 기준이며 실제 토큰 값과 다크 모드의 모든 조합을 검증한 것은 아니다. [Color](https://uxdesign.kt.com/054231ea3/v/62989/p/30fed2-color)
- **Breakpoint·간격:** 반응형 구조는 화면 크기와 해상도에 따라 그리드의 컬럼·마진·거터를 활용한다. 모든 여백과 간격은 원칙적으로 **4pt 그리드**로 두고, 복잡하고 작은 컴포넌트에서는 2의 배수 단위를 제한적으로 쓴다. 공개 본문은 Space-4를 라디오 버튼과 레이블 간격, Space-8을 컴포넌트 요소 간격, Space-16을 패딩, Space-20을 마진의 예로 든다. 정확한 디바이스별 경계값은 본문 텍스트에서 확인되지 않았다. [Breakpoint](https://uxdesign.kt.com/054231ea3/v/56739/p/85c2cb-breakpoint)
- **Tab:** 같은 맥락의 섹션을 탐색하는 용도다. Fixed/Scrollable 유형을 구분하고, 레이블은 **최대 10자**까지 허용하며 탭 개수와 길이에 따라 유형을 선택한다. [Tab](https://uxdesign.kt.com/054231ea3/v/56739/p/036069-tab)
- **Bottom Sheet:** 현재 화면의 맥락을 유지한 채 많은 연관 정보를 보여 주는 용도다. 컨테이너 최대 높이는 디바이스 높이의 **90%**이며 내용이 길면 내부에서 스크롤하고 헤더·푸터는 고정한다. [Bottom Sheet](https://uxdesign.kt.com/054231ea3/v/60591/p/620487-bottom-sheet)
- **Notification:** Toast와 Snackbar를 구분한다. 확인된 공개 본문은 **등장 3초 후 자동 소멸**, 주변 영역 탭으로 닫기, 텍스트 **한 줄 20자·최대 2줄**을 명시한다. 애플리케이션의 오류 복구에 이 동작을 일률 적용할지 여부는 별도 판단이 필요하다. [Notification](https://uxdesign.kt.com/054231ea3/p/607d4b-notification/v/56947)
- **빈 화면 패턴:** 데이터가 없는 상태를 알리고 다음 행동을 유도해 이탈을 줄인다. 관련 구성요소로 Search, Divider, Button, List를 제시한다. [빈 화면](https://uxdesign.kt.com/054231ea3/p/25ff7f--/v/60591)
- **AI Agent의 Prompt Input:** 질문과 응답의 맥락을 잇고, 탐색·즉시 결과에는 Monologue, 연속 대화에는 Bubble을 제시한다. 접힌 프롬프트는 Monologue 최대 4줄, Bubble 최대 3줄로 표시하고 펼치기 버튼을 제공한다. [Prompt Input](https://uxdesign.kt.com/054231ea3/v/60591/p/239b45-prompt-input)
- **AI Agent의 Navigation Bar:** 대화 기록·라이브러리·프로젝트 및 설정 접근을 위한 구조로, New Chat, Search Chat, Recent Chat, Profile을 포함하며 Library·Project는 선택 요소로 표시한다. 모바일·데스크톱 유형이 있다. 일반 서비스 GNB 전체에 그대로 적용하는 규칙으로 해석하지 않는다. [Navigation Bar](https://uxdesign.kt.com/054231ea3/p/10a4ef-navigation-bar/v/56739)

## 제공된 해커톤 자료와 사이트의 관계

`kt-ux-design/kds-hackathon-kit.zip`과 `KDS_________________.pdf`는 제공된 파일로 읽었고 수정하지 않았다. PDF는 해커톤의 목적을 **화면 구성은 팀이 정하고 버튼·입력창·표·색·글꼴의 외관은 KDS로 통일**하는 것이라 설명한다(2쪽). 코드 키트 README는 `kds-tokens.css` → `kds-base.css` → `kds-components.css` 순서, `kds-*` 클래스 및 모바일·PC 템플릿을 안내한다. 이는 **제공 파일에서 확인한 내용**이지 공개 사이트 본문에서 재확인한 정책이 아니다. 공개 사이트의 해당 자료 위치는 [Resources / Designer](https://uxdesign.kt.com/054231ea3/p/786e86)이고, 제공 파일의 직접 공개 다운로드 URL은 확인하지 못했다. 따라서 이 절은 공식 사이트 본문 규칙의 출처로 대체하지 않는다. [Designer](https://uxdesign.kt.com/054231ea3/p/786e86)

키트의 `docs/components/text-field.md`는 한 줄·여러 줄 입력, helper/error, 그룹·형식 입력을 기술하고 아이콘 버튼에 접근 가능한 이름이 필요하다고 적는다. `docs/components/button-button.md`는 버튼 변형·크기·비활성 상태를 나열한다. 이 설명은 **키트 문서로만 검증**했으며 공식 사이트의 [Text Field](https://uxdesign.kt.com/054231ea3/p/55f058)·[Button](https://uxdesign.kt.com/054231ea3/p/463124) 본문과 동일하다고 단정하지 않는다. ZIP 내부 문서는 코드 키트의 구현 참고 자료이고, 실제 웹 컴포넌트 사용 API가 현재 프로젝트에 그대로 적용되는지도 별도 확인이 필요하다. [Designer](https://uxdesign.kt.com/054231ea3/p/786e86)

## 확인 범위와 한계

- 공식 사이트 내비게이션은 HTML 자산으로 전체 영역과 제목을 확인했다. **UX Principles, Typography, Elevation, Radius, Iconography, Motion, Accessibility, Design Token, 다수 Components, UX Writing, Visual Communication, Resources**의 세부 본문은 공개 크롤러/API에서 확인하지 못했다. 해당 제목으로부터 색상 값·폰트 크기·아이콘 사용 금지사항·접근성 수치·문장 규칙을 추정하지 않았다. [공식 사이트](https://uxdesign.kt.com/)
- 공개 본문에서 `Image`로 나타나는 Figma 도면·표 이미지의 치수와 상태별 세부 조건은 텍스트 추출로 검증할 수 없었다. 위 수치와 지침은 **텍스트로 확인된 부분**만 적었다. [Color](https://uxdesign.kt.com/054231ea3/v/62989/p/30fed2-color), [Tab](https://uxdesign.kt.com/054231ea3/v/56739/p/036069-tab)
- 공식 사이트는 버전 경로(`/v/...`)가 혼재하고 시점에 따라 개정된다. 이 문서는 2026-10-09 확인 자료이며, 적용 직전에는 해당 페이지와 키트 버전의 일치 여부를 다시 확인해야 한다. [공식 사이트](https://uxdesign.kt.com/)
- 제공 PDF는 KT Flow 서체를 해커톤 참가자에게만 허용하고 외부 공유·공개 업로드를 금지한다고 적는다(5쪽). 이 조사에서는 폰트 ZIP의 내용물을 추출하거나 배포하지 않았다. 공개 사이트의 관련 자료 위치는 [Designer](https://uxdesign.kt.com/054231ea3/p/786e86)이나, 그 페이지 본문에서 이 조건을 재검증하지는 못했다.
