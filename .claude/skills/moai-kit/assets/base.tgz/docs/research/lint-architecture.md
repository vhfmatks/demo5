# 아키텍처 규칙의 lint 강제: 도구 조사

범위: [AGENTS.md](../../AGENTS.md)와 [통신](../conventions/communication.md)·[API](../conventions/api.md)·[오류](../conventions/errors.md)·[데이터](../conventions/data.md)·[UI](../conventions/ui.md) 규칙 중 디자인 외 아키텍처 규칙을 lint·타입·시험·런타임 중 무엇으로 강제할지 정리한다. 2026-10-08 기준 npm `latest`는 `@biomejs/biome` 2.5.15, `oxlint` 1.87.0, `oxlint-tsgolint` 7.0.2003이다(`npm view`로 확인). "실험"이라고 적은 항목은 저장소 밖 scratch 사본에서 실제로 실행한 결과다. 실행 조건은 아래 [검증 기록](#검증-기록)에 있다. 저장소 파일은 이 문서만 추가했다.

| 메커니즘 | 확인한 사실 | kit에 쓸 부분 | 한계 |
| --- | --- | --- | --- |
| Next 16 자체(빌드) | `server-only`를 import한 모듈을 Client Component에서 import하면 빌드 오류가 난다. Next가 `server-only`·`client-only`를 내부 처리한다. `NEXT_PUBLIC_` 없는 env는 클라이언트에서 빈 문자열이 된다. [Next: environment poisoning](https://nextjs.org/docs/app/getting-started/server-and-client-components#preventing-environment-poisoning). 실험(Next 16.4.0 Turbopack): `'server-only' cannot be imported from a Client Component module`과, Server Component의 `useState`에 대해 `You're importing a module that depends on useState into a React Server Component module` 빌드 실패를 재현했다. `next lint`는 제거됐고 `next build`도 lint를 실행하지 않는다. [Next 16 blog](https://nextjs.org/blog/next-16), [ESLint 문서 v16.4.0](https://nextjs.org/docs/app/api-reference/config/eslint) | 서버 전용 코드의 클라이언트 유입과 Server Component의 hook 사용은 `npm run build`가 이미 막는다. kit의 service·`src/server/*`에는 `import "server-only"`가 이미 있다. 같은 검사를 lint로 다시 만들지 않는다. | `server-only` 표시가 없는 모듈은 막지 못한다. lint가 아니므로 `verify`의 build 단계에서야 실패한다. |
| Biome 2.5.15 내장 규칙 | `style/noRestrictedImports`는 `paths`·gitignore식 `patterns`(부정 `!` 포함)·`importNames`를 지원하고, 동적 `import()`·`require`도 검사한다. [규칙](https://biomejs.dev/linter/rules/no-restricted-imports/) 이 규칙을 `overrides`로 파일 범위별로 지정할 수 있다. 실험: 여러 override가 같은 규칙에 매칭되면 **뒤의 override가 options를 대체한다(병합하지 않는다)**. 문서에는 "last matching override takes precedence"까지만 있다. [configuration](https://biomejs.dev/reference/configuration/) `style/noRestrictedGlobals`의 `deniedGlobals`로 `fetch`를 막을 수 있다. [규칙](https://biomejs.dev/linter/rules/no-restricted-globals/) 1.x의 `useImportRestrictions`는 2.x에 없다(`biome explain` 결과 "Unrecognized"). 대체 규칙인 `noPrivateImports`는 JSDoc `@package`/`@private`에 기반한다. [규칙](https://biomejs.dev/linter/rules/no-private-imports/) | 경로 경계 규칙에 쓴다. DB import, feature 간 import, 컴포넌트의 service·zod import, 공유 파일의 `@/` 사용, `fetch` 직접 사용을 막는다. 새 의존성이 필요 없다. | import 문자열만 보며 타입·호출 의미는 모른다. override 순서를 잘못 두면 앞의 금지 목록이 조용히 사라진다(실험으로 확인). |
| Biome drizzle·react·types 도메인 | `noDrizzleDeleteWithoutWhere`·`noDrizzleUpdateWithoutWhere`는 2.5.15에서 **nursery, 기본 severity info**다(`biome explain`). 웹 문서에는 이 규칙들이 suspicious/error로 표시된다. 웹 문서가 다음 릴리스를 반영한 것으로 보인다. [규칙](https://biomejs.dev/linter/rules/no-drizzle-delete-without-where/) `useReactCompiler`(nursery, 2.5.8+)는 React Compiler를 lint 모드로 실행한다. [규칙](https://biomejs.dev/linter/rules/use-react-compiler/) `noFloatingPromises`·`noMisusedPromises`는 types 도메인의 nursery 규칙이다. types 도메인을 켜면 프로젝트 전체를 스캔한다. [domains](https://biomejs.dev/linter/domains/) | **현재 kit 설정 `"drizzle": "recommended"`에서는 두 drizzle 규칙이 켜지지 않는다.** 실험: `biome rage --linter` 결과 kit 저장소의 활성 규칙 목록에 drizzle 규칙이 없다. 규칙을 명시적으로 켜도 `drizzleObjectName`이 없으면 보고하지 않았다. `["db","tx"]`를 지정한 뒤에야 탐지했다. `useReactCompiler`는 위반 샘플에서 `This render synchronously updates state`를 보고했고, kit 코드에서는 0건이었다. | Biome의 자체 타입 추론은 `async` 함수 호출의 floating은 잡았지만 drizzle `db.insert(...).run()`의 미대기는 **놓쳤다**(실험). nursery 규칙은 이름·동작이 바뀔 수 있다. |
| Biome GritQL plugin | `.grit` 파일로 패턴을 매칭하고 `register_diagnostic(span, message, severity, fix_kind)`로 진단을 보고한다. severity는 hint/info/warn/error이고 기본값은 error다. 대상 언어는 JS/CSS/JSON이다. `=>` rewrite와 `fix_kind`로 수정도 제안할 수 있다. `plugins` 항목의 `{path, includes}`로 대상 파일을 제한한다. [plugins](https://biomejs.dev/linter/plugins/), [configuration](https://biomejs.dev/reference/configuration/) | 문법 형태로 판정되는 규칙에 쓴다. 실험에서 다음 규칙이 kit 코드에서 오탐 0건이었다. service의 `throw new Error`, 트랜잭션 콜백 안에서 `tx` 없이 호출한 `audit()`, page·layout·Table·Filters의 `"use client"`, `"use server"`(Server Action), `.message ===` 분기. | 실험: `includes`에 `src/features/*/service.ts`를 쓰면 매칭되지 않았고 `**/features/*/service.ts`는 매칭됐다(Windows, 2.5.15). 문서에는 타입 정보·교차 파일 상태 API가 없다. rewrite는 2.5.15에서 실험하지 않았다(미검증). |
| oxlint JS plugin | 상태는 **alpha**("JS plugins are currently in alpha")다. ESLint v9 플러그인 API 대부분과 scope·fix를 지원한다. type-aware 규칙과 교차 파일 상태는 지원하지 않는다. [JS plugins](https://oxc.rs/docs/guide/usage/linter/js-plugins.html), [Writing JS plugins](https://oxc.rs/docs/guide/usage/linter/writing-js-plugins.html) | `@shadcn/lint` 실행 방식은 그대로 유지한다. | 규칙이 파일 단위로만 실행되므로 TC ID의 전체 중복 검사, "필수 export 존재" 같은 파일 집합 검사를 옮기기 어렵다. 직접 작성할 규칙의 기반으로 쓰기에는 alpha 상태다. |
| oxlint type-aware (tsgolint) | `oxlint-tsgolint` v7은 **stable**(2026-07-22 발표)이다. TypeScript 7(typescript-go)에 직접 기반하고 typescript-eslint type-aware 규칙 61개 중 59개를 구현했다. 버전은 대상 TS 버전을 따른다(7.0.2xxx ↔ TS 7.0.2). `--type-aware` 플래그나 `options.typeAware`로 켠다. "TypeScript 7.0+ is required"이며 `baseUrl` 등 일부 옛 tsconfig 옵션은 지원하지 않는다. [발표](https://oxc.rs/blog/2026-07-22-type-aware-linting-stable), [문서](https://oxc.rs/docs/guide/usage/linter/type-aware.html), [tsgolint](https://github.com/oxc-project/tsgolint) `oxlint@1.87.0`의 peerDependencies에 `oxlint-tsgolint >=7.0.2003`이 있다(`npm view`). | 실험: kit 소스 사본(70파일)에 `no-floating-promises`·`no-misused-promises`·`await-thenable`을 적용했다. 위반 0건이고 약 1.2–1.5초 걸렸으며 `@shadcn/lint`와 한 번에 실행된다. Biome이 놓친 drizzle `.run()` 미대기와 `onClick={async ...}`는 탐지했다. | 의존성 1개(플랫폼 바이너리)가 늘어난다. 실험: kit처럼 `"plugins": []`이면 `typescript/*` 규칙이 **오류 없이 무시된다**. `"plugins": ["typescript"]`가 필요하다. TS 버전을 올릴 때 tsgolint도 함께 올려야 한다. |
| oxlint 내장 `import`·`react`·`nextjs` | `import/no-cycle`, `no-restricted-imports`, react hooks 규칙, nextjs 규칙 20개가 있다. [rules](https://oxc.rs/docs/guide/usage/linter/rules.html) | 사용하지 않는다. | Biome의 next·react 도메인과 `noRestrictedImports`와 겹친다. |
| ESLint 계열 | Next 16은 ESLint flat config와 `eslint-config-next`(react, react-hooks, `@next/next`, 선택적 typescript-eslint)를 안내한다. [Next ESLint](https://nextjs.org/docs/app/api-reference/config/eslint) `eslint-plugin-react-hooks` recommended에는 React Compiler 진단이 포함되며 compiler를 쓰지 않아도 사용할 수 있다. [react.dev](https://react.dev/reference/eslint-plugin-react-hooks) `eslint-plugin-drizzle`은 `drizzleObjectName` 옵션이 있는 delete/update where 규칙을 제공한다. [Drizzle](https://orm.drizzle.team/docs/eslint-plugin) `eslint-plugin-boundaries`는 요소 유형 간 의존 규칙을 정의한다. [repo](https://github.com/javierbrea/eslint-plugin-boundaries) typescript-eslint 8.63의 peer는 `typescript <6.1.0`이며, TS 7 지원 요청은 "not planned"로 닫혔다. [issue #12518](https://github.com/typescript-eslint/typescript-eslint/issues/12518) | 사용하지 않는다. 각 기능은 위의 Biome(경계·drizzle·React Compiler)과 tsgolint(promise)로 대체된다. | kit이 ESLint를 제거한 이유인 취약 의존 경로([dependencies.md](../conventions/dependencies.md))가 다시 생기고, 타입 검사 엔진도 하나 더 생긴다. |
| dependency-cruiser | from/to 경로 규칙으로 의존 그래프 전체를 검증한다. [repo](https://github.com/sverweij/dependency-cruiser) | 사용하지 않는다. | kit의 경계는 직접 import 규칙과 Next 빌드의 `server-only` 전이 검사로 충분하다. |
| React taint API | `experimental_taintObjectReference`는 experimental 채널 전용이다. "Do not rely on just tainting for security"라는 경고가 있다. [react.dev](https://react.dev/reference/react/experimental_taintObjectReference) | 사용하지 않는다. 내부 컬럼 비노출은 `toDto()`, 반환 타입, E2E로 확인한다. | 안정판 React 19.3에서는 사용할 수 없다(문서 기준). |
| `scripts/check-contracts.mts` | TS 6 Compiler API로 Route Handler 계약을 검사한다. 대상은 `api()` 래퍼, `runtime = "nodejs"`, 동적 `params`, import 허용 목록, `try`/`if`/`switch` 금지, 직접 `Response`·`fetch` 금지다. E2E 계약도 검사한다. 대상은 파일명, `./fixtures`, `TC-…` 제목, **전체 TC 중복**, only/skip 금지, sleep·mock 금지다. | 유지한다. | 파일 집합 검사(필수 export 존재, 전체 TC 중복)는 파일 단위 lint 규칙으로 옮기기 어렵다. |

## lint로 강제할 것과 아닌 것

lint가 확인할 수 있는 것은 **문법 형태**다. import 경로, 지시어, 특정 호출 형태가 여기에 해당한다. 타입 시스템은 **값의 모양**을 보장한다. 반환 DTO, actor 타입, `api()` overload가 그 예다. 다음 항목은 lint로 판정할 수 없다.

- **권한의 정확성**: 소유자·역할·상태에 따른 404/403/409 판단은 데이터와 actor에 따라 달라진다. `canEdit`을 "호출했는지"는 lint로 볼 수 있어도 "올바르게 판단했는지"는 볼 수 없다. policy 단위 시험과 [E2E 권한 경계 시나리오](../conventions/testing.md)로 확인한다.
- **트랜잭션 원자성**: `audit(..., tx)` 형태는 lint로 확인할 수 있다. 하지만 감사 기록이 실패했을 때 업무 쓰기도 롤백되는지는 실행 의미다. 메모리 DB 단위 시험으로 확인한다. [Drizzle transactions](https://orm.drizzle.team/docs/transactions)
- **경합 조건**: 상태·version 조건이 실제 UPDATE/DELETE의 WHERE에 들어갔는지는 오래된 version으로 요청해 409와 저장값 불변을 확인하는 E2E로 검증한다. 이 시나리오는 이미 있다.
- **응답 봉투·Origin·세션**: `api()` 런타임 가드와 E2E helpers가 확인한다.

## 이 kit에 대한 권고 (Recommendation for this kit)

1. **도구 구성은 유지한다.** Biome(기본 lint), oxlint(`@shadcn/lint`), `check-contracts`, TS 7 CLI와 TS 6 API 조합을 그대로 둔다. 늘리는 것은 Biome 설정, `.grit` 파일 5개, 개발 의존성 `oxlint-tsgolint` 하나다. 근거는 위 표와 아래 실험이다.
2. **(a) `check-contracts.mts`는 유지한다.** 전체 TC 중복과 필수 export 존재는 파일 집합에 대한 검사다. oxlint JS plugin은 alpha이고 교차 파일 상태를 지원하지 않는다. GritQL도 교차 파일 API가 없다. 스크립트는 이미 설치된 TS 6 API만 사용한다. [oxlint JS plugins](https://oxc.rs/docs/guide/usage/linter/writing-js-plugins.html), [Biome plugins](https://biomejs.dev/linter/plugins/)
3. **(b) oxlint type-aware는 3개 규칙만 도입한다.** 대상은 `no-floating-promises`, `no-misused-promises`, `await-thenable`이다. libsql은 비동기이고 [data.md](../conventions/data.md)는 "모든 쿼리는 await"를 요구한다. Biome 추론은 drizzle의 미대기를 놓쳤고 tsgolint는 잡았다(실험). kit은 이미 TS 7.0.2를 쓰므로 tsgolint 7.0.2xxx와 짝이 맞는다. `.oxlintrc.json`에 `"plugins": ["typescript"]`와 `"options": {"typeAware": true}`를 추가한다. `PageProps` 전역 타입이 필요하므로 `next typegen` 뒤에 실행하는 편이 안전하다(typegen 없이 실행했을 때 탐지 차이는 미검증). Biome의 types 도메인은 켜지 않는다. 같은 일을 하는 도구를 중복하지 않기 위해서다.
4. **(c) ESLint는 추가하지 않는다.** 경계 규칙은 Biome `noRestrictedImports`, drizzle where 규칙은 Biome nursery 규칙, React Compiler 규칙은 Biome `useReactCompiler`, promise 규칙은 tsgolint로 모두 실험에서 동작했다. ESLint를 추가하면 제거했던 취약 의존 경로가 돌아오고 타입 엔진이 하나 더 생긴다. typescript-eslint는 TS 7을 지원하지 않는다. [issue #12518](https://github.com/typescript-eslint/typescript-eslint/issues/12518)
5. **즉시 고칠 불일치가 하나 있다.** [dependencies.md](../conventions/dependencies.md)에는 "Drizzle 규칙을 활성화한다"고 적혀 있다. 하지만 2.5.15의 drizzle 규칙은 nursery이고 `drizzleObjectName`이 필요하다. 그래서 현재 kit에서는 동작하지 않는다(`biome rage --linter`로 확인). 아래 설정을 적용한 뒤 문서를 고친다.

### 규칙별 강제 수단

| kit 규칙 (출처) | 강제 수단 | 상태 |
| --- | --- | --- |
| Route Handler 형식: `api()`, nodejs runtime, `params`, import 허용 목록, 분기·직접 Response 금지 (api.md) | `check-contracts` | 이미 적용 |
| E2E 계약: 파일명, fixtures, TC 이름·중복, skip 금지 (testing.md) | `check-contracts` | 이미 적용 |
| 색상 hex·임의값·restyle 금지 (ui.md) | oxlint + `@shadcn/lint` | 이미 적용 |
| Hooks 규칙 | Biome `useHookAtTopLevel`, `useExhaustiveDependencies` | 이미 적용 |
| async Client Component 금지 | Biome `noNextAsyncClientComponent` | 이미 적용 |
| 서버 모듈을 client에서 import 금지 | Next 빌드 오류(`import "server-only"`, 실험) | 이미 적용 (프레임워크) |
| Server Component에서 hook 사용 금지 | Next 빌드 오류(실험) | 이미 적용 (프레임워크) |
| Drizzle `delete`/`update`에 `where` 필수 (data.md) | Biome `nursery.noDrizzleDeleteWithoutWhere`·`noDrizzleUpdateWithoutWhere` + `drizzleObjectName: ["db","tx"]` | **추가** (현재 미적용) |
| DB 접근은 service와 `src/server`만 (AGENTS.md) | Biome `noRestrictedImports` override (`drizzle-orm`, `drizzle-orm/*`, `@libsql/client`, `@/server/db/*`) | **추가** |
| `"use client"`는 Form·Actions에만. page·layout·Table·Filters 금지 (ui.md) | GritQL `no-use-client-page` (`includes`로 범위 지정) | **추가** |
| Server Component에서 자기 API fetch 금지, Client에서 fetch 직접 사용 금지 (communication.md, ui.md) | Biome `noRestrictedGlobals` `fetch` (`src/lib/api-client.ts`, `src/server/**`는 off) | **추가** |
| 쓰기는 REST만 (Server Action 금지) | GritQL `no-server-actions` (`"use server"`) | **추가** |
| 쓰기는 `useMutation` + `apiClient` | 생성기 템플릿, 리뷰, UI E2E | lint 부적합 (위 두 규칙으로 우회 경로만 차단) |
| zod 검증은 schema.ts 한 곳, 클라이언트 중복 검증 금지 | Biome `noRestrictedImports` (components에서 `zod`·`../service`·`@/server/**` 금지) | **추가** |
| schema/errors/policy는 상대경로만, `server-only` 금지 (data.md, errors.md) | Biome `noRestrictedImports` (`@/**`, `server-only`, DB) | **추가** |
| feature 간 직접 import 금지, ui는 `@/components/ui` 진입점만 (AGENTS.md) | Biome `noRestrictedImports` (`@/features/**`, `@/components/ui/*`) | **추가** |
| service는 `new AppError(정의)`만 throw (errors.md) | GritQL `no-plain-error` (`**/features/*/service.ts`) | **추가** |
| message 문자열로 분기 금지 (errors.md) | GritQL `no-message-branch` (`.message ===`/`==`/`.includes`) | **추가** (휴리스틱) |
| 쓰기와 audit은 같은 tx: 호출 형태 (data.md) | GritQL `audit-needs-tx` (`transaction()` 콜백 안의 `audit()`에 `tx`가 없으면 오류) | **추가** |
| 쓰기와 audit은 같은 tx: 원자성·롤백 | 단위 시험(메모리 DB, audit 실패 주입) | lint 부적합 |
| 상태·version 조건이 실제 쓰기에 포함 | E2E 경합 시나리오(409, 값 불변) | lint 부적합 (시험 이미 있음) |
| policy를 service에서 강제, 404/403/409 구분 | policy 단위 시험 + E2E 권한 경계 | lint 부적합 |
| service 첫 인자는 actor | 생성기 템플릿 + `SessionUser` 타입. 인증 `login` 같은 예외가 있다. | lint 부적합 |
| DTO만 반환, 내부 컬럼 비노출 | TS 반환 타입(`Promise<XDto>`) + E2E 응답 검사. taint는 experimental. | 이미 적용 (타입/E2E) |
| 쿼리 await, floating·misused promise 금지 (data.md) | oxlint type-aware: `typescript/no-floating-promises`, `no-misused-promises`, `await-thenable` | **추가** (`oxlint-tsgolint` 7.0.2003) |
| React Compiler 호환 | Biome `nursery.useReactCompiler` | **추가** (nursery, 선택) |
| 응답 봉투, Origin, 세션 | `api()` 런타임 가드 + E2E helpers·SEC 시험 | 이미 적용 (런타임/E2E) |

설정 요지(실험에서 kit 사본 72파일 0건 통과, 위반 샘플 전부 탐지):

```jsonc
// biome.json 추가분
"plugins": [
  { "path": "./lint/no-plain-error.grit", "includes": ["**/features/*/service.ts"] },
  { "path": "./lint/no-use-client-page.grit", "includes": ["**/app/**/page.tsx", "**/app/**/layout.tsx", "**/components/*Table.tsx", "**/components/*Filters.tsx"] },
  "./lint/no-message-branch.grit", "./lint/audit-needs-tx.grit", "./lint/no-server-actions.grit"
],
"linter": { "rules": {
  "nursery": {
    "noDrizzleDeleteWithoutWhere": { "level": "error", "options": { "drizzleObjectName": ["db", "tx"] } },
    "noDrizzleUpdateWithoutWhere": { "level": "error", "options": { "drizzleObjectName": ["db", "tx"] } },
    "useReactCompiler": "error"
  },
  "style": { "noRestrictedGlobals": { "level": "error", "options": { "deniedGlobals": { "fetch": "Server는 service, Client는 useMutation+apiClient" } } } }
} },
// overrides: 같은 규칙은 뒤의 override가 options를 대체한다. 일반 → 구체 순서로 두고 각 override에 금지 목록 전체를 반복한다.
// 1) api-client.ts, server/**: noRestrictedGlobals off
// 2) src/** (service·server·ui 제외): DB + "@/components/ui/*"
// 3) src/features/** (service 제외): 2) + "@/features/**"
// 4) src/features/*/components/**: 3) + "../service", "@/server/**", "zod"
// 5) src/features/*/{schema,errors,policy}.ts: DB + "@/**", "server-only"
```

```grit
// lint/audit-needs-tx.grit: 로그인처럼 트랜잭션 밖에서 호출한 audit은 허용한다.
`audit($args)` as $call where {
  $call <: within `$db.transaction($cb)`,
  $args <: not contains `tx`,
  register_diagnostic(span=$call, message="트랜잭션 안의 audit()에는 같은 tx를 전달한다.", severity="error")
}
// no-plain-error:     `throw new Error($msg)` where { register_diagnostic(span=$msg, ...) }
// no-server-actions:  `"use server"` as $d where { register_diagnostic(span=$d, ...) }
// no-use-client-page: `"use client"` as $d where { register_diagnostic(span=$d, ...) }
// no-message-branch:  or { `$e.message === $s`, `$e.message == $s`, `$e.message.includes($s)` } as $m where { ... }
```

메시지에 `\"`를 넣으면 출력이 잘렸다(실험). 메시지 안에서는 큰따옴표를 피한다.

## 검증 기록

- 환경: Windows 11, Node 24.18.0. scratch 디렉터리에 kit과 같은 버전(`@biomejs/biome` 2.5.15, `oxlint` 1.87.0, `next` 16.4.0, `drizzle-orm` 0.45.3, `@libsql/client` 0.18.0, `@typescript/native` 7.0.2)과 `oxlint-tsgolint` 7.0.2003, `@shadcn/lint` 0.2.0을 설치했다. `src/`와 `tsconfig.json`의 사본, 합성 위반 파일로 실행했다. 저장소에서는 읽기 전용인 `npx biome rage --linter`만 실행했다.
- kit 사본에서 제안한 Biome 설정은 `--error-on-warnings` 기준 0건으로 통과했다. 주입한 위반은 모두 탐지했다. 대상은 DB import, components의 service·zod·deep ui import, 공유 파일의 `@/`·`server-only`, `fetch`, Table의 `"use client"`, `"use server"`, tx 없는 audit, `throw new Error`, message 분기, where 없는 delete/update다.
- oxlint type-aware는 kit 사본에서 0건, 주입한 floating promise는 탐지했다. kit의 `.oxlintrc.json`(shadcn)과 합쳐 한 번에 실행했다. shadcn의 `no-unknown-classes` 오류는 사본에 `public/kds` CSS가 없어서 생긴 것이며 kit 자체의 결과가 아니다.
- Next 빌드 오류 2종(`server-only` client import, Server Component의 `useState`)을 최소 앱으로 재현했다.

## 미검증

- Biome GritQL rewrite(`=>`, `fix_kind`)가 2.5.15에서 동작하는지 확인하지 않았다(문서 기준만 확인).
- drizzle 규칙의 웹 문서 표기(suspicious/error)와 2.5.15 CLI(nursery/info)의 차이가 어느 릴리스에서 해소되는지 확인하지 않았다.
- `next typegen`을 실행하지 않은 상태에서 tsgolint의 탐지 범위가 얼마나 줄어드는지 측정하지 않았다(사본에서는 `PageProps` 미해결 상태로 실행).
- TS 7 패키지 없이 `oxlint-tsgolint`만 설치해도 동작하는지 확인하지 않았다(scratch에 `@typescript/native`가 함께 설치되어 있었다).
- GritQL `includes`가 `src/...` 상대 패턴에 매칭되지 않은 현상이 Windows 전용인지 확인하지 않았다.
- `eslint-plugin-boundaries`·dependency-cruiser는 문서만 확인했고 설치·실행하지 않았다.
- (해소, 2026-10-08) audit 실패 시 롤백: `tests/unit/requests.service.test.ts`의 "audit 실패 시 롤백" 3건이 생성·수정·삭제·상태 전이를 검증한다. audit 을 트랜잭션 밖으로 옮기면 실패하는 것을 확인했다.
