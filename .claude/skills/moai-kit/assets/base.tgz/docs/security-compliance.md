# 보안 준수 결과

정책 대응·위험 문서다. SEC별 적용 여부와 사유, 구현 위치, TC·증적, 상태, 제약·예외를 적는다. 권한 규칙 본문은 [prd](prd.md), 강제 구조 설명은 [arch](arch.md)가 소유한다.

기준은 주최 측이 공지한 `docs/security-policy.md`이며 원본을 수정하지 않는다. 이 파일이 없으면 공식 준수 여부는 **미확인**이다.
아래 행은 주최 측 안내 SEC-01~12 번호로 미리 채운 kit 공통 통제다. 공식 원문의 번호·범위가 다르면 행과 TC 태그를 함께 바꾼다. 행이 있다는 것만으로 준수했다고 보지 않는다.
상태는 이 프로젝트에서 실행·확인한 결과만 쓴다. 실행 전은 `미실행`, 시험이나 확인 방법이 없으면 `미검증`이다. kit 개발 중의 시험 통과는 이 프로젝트의 증적이 아니다.

## 1. SEC별 적용 · 검증

증적은 실행 후 `docs/evidence/<runId>.md`에 연결한다. 시험 대상 코드가 바뀌면 영향받는 행을 `미검증`으로 되돌린다.
TC는 [e2e-test](e2e-test.md)의 공통 시나리오이며 프로젝트의 REQ·AC에 맞는 TC를 추가해 연결한다.

| SEC | 적용 여부 · 이유 | 구현 위치 | TC / 확인 방법 | 상태 | 제약 · 예외 |
|---|---|---|---|---|---|
| SEC-01 비밀정보 | 적용 · 세션 토큰·AI 키·비밀번호를 다룸 | `.env.example`(값 없음)·`.gitignore`(`.env*`·`data/*.key`), 세션 토큰 SHA-256 해시 저장, AI 키 AES-GCM 암호화·끝 4자리만 응답(`server/secret.ts`), 5xx 로그는 traceId·code만(`server/http/handler.ts`), 감사 detail 비밀값 금지·로그인 실패는 `emailRef` | TC-AI-API-001, TC-AUTH-API-002 · 005, `tests/unit/ai.service.test.ts` | 미실행 | 저장소 비밀 스캔은 별도 실행 필요. 데모 비밀번호는 합성 계정 전용 공개값 |
| SEC-02 사용자 인증 | 적용 · 비로그인 차단, 로그인 실패 공개 메시지 단일화·처리 시간 균일화 | `api()` 기본 required, `requireUser()`, 없는 계정도 bcrypt 비교(`features/auth/service.ts`) | TC-AUTH-API-001, TC-AUTH-UI-001, TC-ADMIN-API-001, gen 도메인 TC-<X>-API-003 | 미실행 | 응답 시간 차이는 측정 시험 없음 |
| SEC-03 접근 권한 | 적용 · 기본 거부·최소 권한·자료 소유권 | `lib/permissions.ts`, `features/*/policy.ts`, route `permission`, service `assertPermission`, 볼 권한 없음 404, gen ref 대상 열람 권한(`checkRefAccess`) | TC-ADMIN-API-004 · 006, TC-RBAC-API-001 · 002, TC-RBAC-UI-001, `tests/unit/rbac.test.ts`, gen 도메인 TC-<X>-API-004 · 006 · 007 | 미실행 | 본인·상태 같은 자원 조건은 프로젝트 policy별 TC 필요. `gen --auth=public` 도메인은 익명 누구나 수정·삭제 → 쓰면 SEC-12 예외(대기)로 기록 |
| SEC-04 입력 검증 | 적용 · 잘못된·과도한 입력과 다른 출처 쓰기 차단 | strictObject·UUID·JSON 파싱·64KiB 스트림 제한·415, 쓰기 Origin 필수·scheme/host/port 전체 일치, gen 필드 상한, Drizzle 파라미터 바인딩, CSV 수식 주입 방지(`lib/csv.ts`)·업로드 실제 바이트 제한(`upload()`, `server/import.ts`) | TC-HTTP-API-001~005, gen 도메인 TC-<X>-API-002, `tests/unit/kit-utils.test.ts`·`import.test.ts` | 미실행 | 운영 Origin은 `APP_ORIGIN` 설정 필요. SQL 공격 입력 시험 없음. 내보내기·업로드 기능이 있으면 E2E TC 추가 |
| SEC-05 비밀번호 저장 | 적용 · 자체 계정 운영 | bcrypt cost 10 해시만 저장(`features/auth/service.ts`·`scripts/db-seed.mts`), 새 비밀번호 72바이트 상한(bcrypt 절단 방지, `features/auth/schema.ts`) | `tests/unit/auth.service.test.ts`(해시 저장·원문 미저장·72바이트), TC-AUTH-API-002(응답에 해시 없음) | 미실행 | 알고리즘·비용을 주최 측 배포 기준과 대조 필요 |
| SEC-06 안전한 전송 | 적용 · 응답 헤더·외부 호출 | 보안 헤더(HSTS·nosniff·frame-ancestors·Referrer-Policy, `X-Powered-By` 제거, `next.config.ts`), 운영 쿠키 Secure, 외부 호출 https만·리다이렉트 거부·시간·크기 상한(`server/outbound.ts`, AI 주소 규칙) | TC-HTTP-API-006, TC-AI-API-003 | 미실행 | TLS 종단·인증서는 배포 환경 몫. HSTS는 https 접속에서만 적용 |
| SEC-07 정보 최소화 | 적용 · 응답·화면·오류의 불필요한 정보 제거 | DTO 필드 제한(`passwordHash` 미노출, gen 소유자 `{id,name}`), 5xx 공개 메시지·traceId만, `omitUnless`·`maskName/Phone/Email`(`lib/mask.ts`), 시드·시험은 합성 데이터만 | TC-AUTH-API-002, `tests/unit/kit-utils.test.ts`, API TC의 공통 오류 assertion | 미실행 | 과제별 마스킹 적용 위치는 해당 TC로 확인. 5xx 은닉은 장애 주입 시험 없음 |
| SEC-08 세션 관리 | 적용 · 세션 발급·만료·폐기 | 32바이트 랜덤 토큰·HttpOnly·SameSite=Lax·해시 저장, 관리자 설정 만료(`sessionTtlHours`), 로그아웃 시 DB 삭제, 비밀번호 변경 시 전체 폐기(`server/auth/session.ts`) | TC-AUTH-API-002 · 003 · 006, TC-ADMIN-API-005 | 미실행 | 운영 Secure 속성은 E2E(http)로 확인하지 못함 |
| SEC-09 반복 시도 제한 | 적용 · 로그인 반복 실패·과도한 요청 | 로그인: 같은 이메일 잠금 시간 안 실패 허용 횟수(관리자 설정 기본 5회·15분) 초과 시 맞는 비밀번호도 429·Retry-After, 성공 시 초기화(`features/auth/service.ts`). 익명 공개 쓰기 주소당 분당 60회(`api()`), AI 사용자당 분당 20회. 공용 `server/rate-limit.ts` | TC-AUTH-API-004, `tests/unit/auth.service.test.ts`(잠금·복구·동시 시도), `tests/unit/ai.service.test.ts` | 미실행 | 프로세스 메모리(재시작·다중 서버 시 초기화). 이메일 기준 잠금은 타인이 계정을 일시 잠글 수 있고, 주소 단위 로그인 제한은 없음. 익명 쓰기 주소는 `x-forwarded-for` 마지막 값 → 프록시 없이 노출하면 우회 가능 |
| SEC-10 보안 감사 기록 | 적용 · 변경 이력·보안 사건 추적 | 업무 쓰기와 `audit()`를 같은 `db.transaction`에서 실행, 로그인 성공·실패(`emailRef`·잠금 여부)·로그아웃·비밀번호·역할·부서·설정 변경 기록, 감사로그 화면(`app/admin/audit`) | TC-ADMIN-API-002 · 004, TC-AUTH-API-005, `tests/unit/auth.service.test.ts` | 미실행 | 감사 실패 시 업무 롤백은 장애 주입 시험 없음. 권한 거부(403)·현재 비밀번호 불일치는 기록하지 않음. 익명 공개 쓰기는 작업자 null |
| SEC-11 환경 분리 | 적용 · 개발·시험·운영 설정 분리 | 운영(`NODE_ENV=production`)에서 `APP_SECRET` 필수(`server/secret.ts`), 데모 계정 목록은 개발 또는 `DEMO_LOGIN=1`만(`app/login/page.tsx`), `db:seed`·`db:reset` 운영 실행 거부, `INSECURE_COOKIE`는 E2E 전용, E2E는 실행마다 새 DB | TC-AUTH-UI-001(E2E는 `DEMO_LOGIN=1`), 배포 설정 점검 | 미실행 | 배포 환경 변수 실제 값은 배포 시 확인 |
| SEC-12 예외·미검증 | 적용 · 이 문서로 관리 | 위 표의 제약·예외 칸, 아래 예외 표 | 문서 검토 | 진행 중 | 승인받지 않은 예외는 `대기` |

### 정책 외 kit 통제

| 통제 | 구현 위치 | TC / 확인 방법 | 상태 |
|---|---|---|---|
| 동시 변경 덮어쓰기 방지 | 상태 조건부 쓰기·`version` 조건 | 프로젝트 TC 필요 | 미검증 |
| 의존성 취약점·변동 관리 | 정확한 버전·lockfile, `npm run audit`([의존성 규칙](conventions/dependencies.md)) | `npm run verify` | 미실행 |

### 예외·미검증 (SEC-12)

| 항목 | 구분 | 사유·위험 | 대안·다음 조치 | 상태 |
|---|---|---|---|---|
| (프로젝트에서 채움) | 미적용 · 예외 · 미검증 | | | 대기 |

## 2. 릴리스 전 확정

- SEC 번호·항목·적용 범위·검증 방법을 주최 측 원본 정책과 대조한다. 해당 없음·예외는 이유와 검토 상태를 적는다.
- 적용 코드 위치, 실제 TC, 시험 SHA, 결과, 증적 링크를 갱신한다. 확인하지 못한 항목은 `미검증`으로 둔다.
- 로그인 실패 허용 횟수·잠금 시간(관리자 설정)·쿠키·배포 Origin·세션 만료를 정책 기준과 대조해 설정값과 시험을 맞춘다.
- 배포 환경에 `APP_SECRET`·`APP_ORIGIN`을 설정하고 `DEMO_LOGIN`·`INSECURE_COOKIE`가 의도대로인지 확인한다.
