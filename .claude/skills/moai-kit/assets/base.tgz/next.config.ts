import type { NextConfig } from "next";

// 표준: Cache Components 비활성화. 모든 페이지는 요청 시 동적 렌더링(루트 layout의 dynamic 설정).
// 이 키트는 캐시 무효화 버그보다 "항상 최신 데이터"가 낫다.
// 보안 헤더: HTTPS 고정(HSTS, http 접속에서는 브라우저가 무시)·MIME 추측 금지·다른 사이트 iframe 삽입 금지·출처 최소 전달.
const SECURITY_HEADERS = [
  { key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains" },
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Content-Security-Policy", value: "frame-ancestors 'none'" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
];

const nextConfig: NextConfig = {
  poweredByHeader: false,
  headers: async () => [{ source: "/:path*", headers: SECURITY_HEADERS }],
  serverExternalPackages: ["@libsql/client"],
  turbopack: {
    rules: {
      "*.css": { loaders: ["@tailwindcss/turbopack"], as: "*.css" },
    },
  },
};

export default nextConfig;
