import { randomBytes } from "node:crypto";
import { defineConfig, devices } from "@playwright/test";
import { runPaths, testOrigin } from "./scripts/lib/e2e.mts";

const runId = process.env.E2E_RUN_ID;
if (!runId || !process.env.E2E_SOURCE_SHA256) throw new Error("npm run test:e2e로 격리 실행하세요.");
const paths = runPaths(runId);
const { origin } = testOrigin();

export default defineConfig({
  testDir: "tests/e2e",
  fullyParallel: false,
  workers: 1,
  retries: 0,
  forbidOnly: true,
  timeout: 30_000,
  expect: { timeout: 5_000 },
  metadata: { runId, sourceSha256: process.env.E2E_SOURCE_SHA256 },
  reporter: [["list"], ["json", { outputFile: paths.report }], ["html", { outputFolder: paths.html, open: "never" }]],
  outputDir: paths.artifacts,
  use: { baseURL: origin, actionTimeout: 10_000, navigationTimeout: 30_000 },
  projects: [
    { name: "api", testMatch: "**/*.api.spec.ts" },
    { name: "ui", testMatch: "**/*.ui.spec.ts", use: {
      ...devices["Desktop Chrome"], screenshot: "on", trace: "retain-on-failure",
      channel: process.env.PW_CHANNEL,
      launchOptions: { executablePath: process.env.PW_CHROMIUM_PATH },
    } },
  ],
  webServer: {
    command: "npx --no-install tsx scripts/e2e-server.mts",
    url: `${origin}/login`,
    timeout: 180_000,
    reuseExistingServer: false,
    // 운영 빌드(next start)로 띄운다: 시험 전용 비밀 키(실행마다 새로)·데모 계정 표시·http 쿠키 허용
    env: { DATABASE_URL: paths.database, APP_ORIGIN: origin, INSECURE_COOKIE: "1", DEMO_LOGIN: "1", APP_SECRET: randomBytes(32).toString("hex") },
  },
});
