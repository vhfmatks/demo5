#!/usr/bin/env python3
"""icons/ 폴더의 SVG마다 아이콘 클래스를 만들어 tokens/kds-base.css 맨 아래에 넣는다.
아이콘을 추가·삭제한 뒤 실행:  python3 scripts/build-icon-classes.py"""
import pathlib, re
root = pathlib.Path(__file__).resolve().parent.parent
names = sorted(p.stem for p in (root / "icons").glob("*.svg"))
css = root / "tokens/kds-base.css"
s = re.sub(r"\n*/\* ICON-CLASSES:START.*?ICON-CLASSES:END \*/\n", "\n", css.read_text(encoding="utf-8"), flags=re.S)
block = ["/* ICON-CLASSES:START — 아이콘 이름 = 클래스 이름. 경로는 이 CSS 파일 기준이라 페이지 위치와 상관없이 맞는다 (scripts/build-icon-classes.py로 생성) */"]
block += [f".{n} {{ --icon: url(../icons/{n}.svg); }}" for n in names]
block.append(".ic-line-mobile { --icon: url(../icons/ic-line-moblie.svg); } /* 파일명 오타(moblie) 별칭 */")
block.append("/* ICON-CLASSES:END */")
css.write_text(s.rstrip("\n") + "\n\n" + "\n".join(block) + "\n", encoding="utf-8", newline="\n")
print(f"아이콘 클래스 {len(names)}개 생성")
