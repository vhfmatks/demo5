#!/bin/bash
# AGENTS.md(원본) 내용을 Copilot·Cursor 규칙 파일에 그대로 복사한다.
# AGENTS.md를 고친 뒤 실행:  ./scripts/sync-instructions.sh
set -e
# Reference-only copy: moai-kit owns project workflow and connector rules.
printf "%s\n" "moai-kit: update project AGENTS.md through the skill; never overwrite it with KDS-only rules."
exit 1
cd "$(dirname "$0")/.."
NOTE="<!-- 자동 생성: AGENTS.md 복사본. 직접 고치지 말고 AGENTS.md를 고친 뒤 scripts/sync-instructions.sh 실행 -->"
{ echo "$NOTE"; echo; cat AGENTS.md; } > .github/copilot-instructions.md
{ printf -- "---\ndescription: KDS 2.0 디자인 시스템 규칙 — 모든 UI 작업에 적용\nalwaysApply: true\n---\n\n"; echo "$NOTE"; echo; cat AGENTS.md; } > .cursor/rules/kds.mdc
echo "동기화 완료: .github/copilot-instructions.md, .cursor/rules/kds.mdc"
