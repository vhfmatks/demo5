// AST를 사용한 작업 규칙 검사. 보안·업무 검증은 실제 API/E2E 시험에서 수행한다.
import fs from "node:fs";
import path from "node:path";
import ts from "typescript";

const issues: string[] = [];
const caseIds = new Set<string>();
function files(directory: string): string[] {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const name = path.join(directory, entry.name);
    return entry.isDirectory() ? files(name) : entry.isFile() ? [name] : [];
  });
}
function scan(file: string, visit: (node: ts.Node, fail: (message: string) => void) => void) {
  const source = ts.createSourceFile(file, fs.readFileSync(file, "utf8"), ts.ScriptTarget.Latest, true);
  const walk = (node: ts.Node) => {
    const fail = (message: string) => {
      const { line } = source.getLineAndCharacterOfPosition(node.getStart(source));
      issues.push(`${file}:${line + 1} ${message}`);
    };
    visit(node, fail);
    ts.forEachChild(node, walk);
  };
  walk(source);
}
const methods = new Set(["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"]);
const routes = files("src/app/api").filter((file) => path.basename(file) === "route.ts");
for (const file of routes) {
  let wrapped = 0;
  let runtime = false;
  let standardImport = false;
  scan(file, (node, fail) => {
    if (ts.isImportDeclaration(node) && ts.isStringLiteral(node.moduleSpecifier)) {
      const name = node.moduleSpecifier.text;
      const allowed = name === "@/server/http/handler" || /^@\/features\/[^/]+\/(schema|service)$/.test(name) ||
        (file.replaceAll("\\", "/").includes("/auth/") && name === "@/server/auth/session");
      if (!allowed) fail("API route는 HTTP 래퍼·기능 schema/service만 import한다. DB·ORM·직접 응답 금지.");
      const bindings = node.importClause?.namedBindings;
      if (name === "@/server/http/handler" && bindings && ts.isNamedImports(bindings)) {
        standardImport ||= bindings.elements.some((element) => element.name.text === "api" && !element.propertyName);
      }
    }
    if (ts.isVariableStatement(node) && node.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.ExportKeyword)) {
      for (const declaration of node.declarationList.declarations) {
        if (!ts.isIdentifier(declaration.name)) continue;
        const name = declaration.name.text;
        const init = declaration.initializer;
        if (name === "runtime") {
          runtime = !!init && ts.isStringLiteral(init) && init.text === "nodejs";
          if (!runtime) fail("SQLite API의 runtime은 nodejs로 선언한다.");
        } else if (methods.has(name)) {
          if (!init || !ts.isCallExpression(init) || !ts.isIdentifier(init.expression) || init.expression.text !== "api") {
            fail("HTTP 메서드는 export const METHOD = api(...) 형식만 사용한다.");
            continue;
          }
          wrapped++;
          if (file.includes("[")) {
            const options = init.arguments[1];
            if (!options || !ts.isObjectLiteralExpression(options) || !options.properties.some((property) =>
              ts.isPropertyAssignment(property) && property.name.getText() === "params" &&
              ts.isIdentifier(property.initializer) && property.initializer.text !== "undefined")) fail("동적 경로에 공유 params 스키마를 선언한다.");
          }
        } else fail("route에는 HTTP 메서드와 runtime만 export한다.");
      }
    }
    if (ts.isFunctionDeclaration(node) && node.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.ExportKeyword)) {
      fail("export 함수 대신 api()를 사용한다.");
    }
    if (ts.isTryStatement(node) || ts.isIfStatement(node) || ts.isSwitchStatement(node)) fail("route의 업무·권한·예외 분기는 service 또는 공통 래퍼로 이동한다.");
    if (ts.isNewExpression(node) && ["Response", "NextResponse"].includes(node.expression.getText())) fail("직접 Response 생성 대신 응답 헬퍼를 사용한다.");
    if (ts.isCallExpression(node) && (node.expression.getText() === "fetch" || /\.json$/.test(node.expression.getText()))) fail("직접 fetch·JSON 파싱 대신 service·body·응답 헬퍼를 사용한다.");
  });
  if (!runtime || !standardImport || wrapped === 0) issues.push(`${file}: nodejs runtime·표준 api import·HTTP 핸들러가 필요하다.`);
}

const specs = files("tests/e2e").filter((file) => file.endsWith(".spec.ts"));
for (const file of specs) {
  if (!/\.(api|ui)\.spec\.ts$/.test(file)) issues.push(`${file}: *.api.spec.ts 또는 *.ui.spec.ts로 구분한다.`);
  let fixtureImport = false;
  let cases = 0;
  scan(file, (node, fail) => {
    if (ts.isImportDeclaration(node) && ts.isStringLiteral(node.moduleSpecifier)) {
      const name = node.moduleSpecifier.text;
      const bindings = node.importClause?.namedBindings;
      if (name === "./fixtures" && bindings && ts.isNamedImports(bindings)) {
        fixtureImport ||= ["test", "expect"].every((required) => bindings.elements.some((element) =>
          element.name.text === required && !element.propertyName));
      }
      if ((name === "@playwright/test" && !node.importClause?.isTypeOnly) || name.includes("/server/") || name.endsWith("/service")) {
        fail("E2E는 ./fixtures의 test·expect와 실제 HTTP/UI를 사용한다.");
      }
    }
    if (!ts.isCallExpression(node)) return;
    const name = node.expression.getText();
    if (name === "test") {
      cases++;
      const title = node.arguments[0];
      const id = title && ts.isStringLiteral(title) ? title.text.split(" ")[0] : "";
      if (!/^TC-[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)*-(API|UI)-\d{3}$/.test(id)) fail("TC-DOMAIN-API/UI-001 설명 형식의 고정 제목이 필요하다.");
      else if (caseIds.has(id)) fail(`중복 TC: ${id}`);
      else caseIds.add(id);
    }
    if (/^test(?:\.describe)?\.(only|skip|fixme|fail)$/.test(name)) fail("only·skip·fixme·예상 실패로 완료 판정을 우회하지 않는다.");
    if (/(?:\.waitForTimeout|\.newContext|\.route)$/.test(name) || name === "fetch") fail("고정 sleep·수동 context·E2E 내부 mock 대신 fixture와 HTTP/UI assertion을 사용한다.");
  });
  if (!fixtureImport || cases === 0) issues.push(`${file}: ./fixtures의 test·expect와 최소 1개 TC가 필요하다.`);
}
if (issues.length) {
  console.error(issues.join("\n"));
  process.exitCode = 1;
} else console.log(`계약 검사 통과: API ${routes.length}개 · E2E ${specs.length}개 · TC ${caseIds.size}개`);
