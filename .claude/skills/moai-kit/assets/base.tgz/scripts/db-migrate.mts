import { migrateDb, openDb } from "../src/server/db/open.ts";

const file = process.env.DATABASE_URL ?? "data/dev.db";
await migrateDb(openDb(file));
console.log(`migrated: ${file}`);
