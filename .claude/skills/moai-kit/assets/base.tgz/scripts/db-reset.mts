// DB 파일 삭제 → 마이그레이션 → 시드 (E2E 전·데모 전 실행)
import fs from "node:fs";
import { migrateDb, openDb } from "../src/server/db/open.ts";
import { assertNotProduction, seed } from "./db-seed.mts";

assertNotProduction();
const file = process.env.DATABASE_URL ?? "data/dev.db";
for (const f of [file, `${file}-wal`, `${file}-shm`]) fs.rmSync(f, { force: true });
const db = openDb(file);
await migrateDb(db);
await seed(db);
console.log(`reset: ${file}`);
