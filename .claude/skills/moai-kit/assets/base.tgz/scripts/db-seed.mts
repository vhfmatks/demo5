// 합성 데이터 시드. 실제 개인정보·사내 데이터 금지 (security-policy).
import bcrypt from "bcryptjs";
import { openDb, type Db } from "../src/server/db/open.ts";
import type { Role } from "../src/lib/roles.ts";
import type { Department } from "../src/lib/departments.ts";
import { users } from "../src/server/db/schema.ts";

export const DEMO_PASSWORD = "Credit!23";

/** 합성 계정·공개 비밀번호를 운영 DB에 넣지 않는다. 명령 진입점(db:seed·db:reset)에서 호출한다. */
export function assertNotProduction() {
  if (process.env.NODE_ENV === "production") throw new Error("NODE_ENV=production 에서는 시드·초기화를 실행하지 않습니다.");
}

export async function seed(db: Db) {
  const hash = bcrypt.hashSync(DEMO_PASSWORD, 10);
  const mk = (email: string, name: string, role: Role, department: Department | null = null) =>
    db.insert(users).values({ email, name, role, department, passwordHash: hash }).returning().get();

  // 부서: user1·user3·manager = 개발팀, user2 = 영업팀 (부서 범위 시험이 이 배치를 쓴다)
  await mk("user1@demo.local", "김민수", "USER", "DEV");
  await mk("user2@demo.local", "이서연", "USER", "SALES");
  await mk("approver@demo.local", "박승인", "APPROVER", "PLAN");
  await mk("admin@demo.local", "최관리", "ADMIN");
  await mk("user3@demo.local", "정하늘", "USER", "DEV");
  await mk("auditor@demo.local", "한감사", "AUDITOR");
  await mk("manager@demo.local", "윤부장", "MANAGER", "DEV");

  console.log("seeded");
}

if (process.argv[1]?.endsWith("db-seed.mts")) {
  assertNotProduction();
  await seed(openDb(process.env.DATABASE_URL ?? "data/dev.db"));
}
