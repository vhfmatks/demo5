// docs/e2e-test.md 현황 블록을 §2 계획·tests/e2e·docs/evidence 실행 근거로 다시 만든다. 시험을 실행하지 않는다.
// --check: 계획↔시험 파일, PRD AC 상태↔계획·실행 근거를 대조만 한다(파일을 쓰지 않음). lint:contracts 에서 실행한다.
import fs from "node:fs";
import { execFileSync } from "node:child_process";

const DOC = "docs/e2e-test.md";
const START = "<!-- e2e-dashboard:start -->";
const END = "<!-- e2e-dashboard:end -->";
const ID = /TC-[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)*-(?:API|UI)-\d{3}/;
const BOUNDS = ["정상", "오류", "권한", "재조회"] as const;
const doc = fs.readFileSync(DOC, "utf8");
const cells = (line: string) => line.split(/(?<!\\)\|/).slice(1, -1).map((cell) => cell.trim());
const issues: string[] = [];

// 계획: §2 표의 `| TC | REQ | AC | 경계 | GIVEN · WHEN · THEN | 예상 결과 | 자동화 위치 |` 행.
// REQ = AC 번호의 REQ(AC-01-1 → REQ-01), 경계 = 정상·오류·권한·재조회 중 확인하는 것, 자동화 위치 = E2E spec 1개 + 같은 AC의 단위 시험 파일(·로 구분).
type Plan = { req: string; ac: string; bounds: string[]; file: string; units: string[] };
const plan = new Map<string, Plan>();
const from = doc.indexOf("\n## 2.");
const to = doc.indexOf("\n## 3.");
if (from < 0 || to < from) throw new Error(`${DOC}에 '## 2.' 계획 절과 '## 3.' 결과 절이 필요하다.`);
for (const line of doc.slice(from, to).split("\n")) {
  if (!line.startsWith("| TC-")) continue;
  const row = cells(line);
  const id = row[0].match(ID)?.[0];
  if (!id || row.length !== 7) { issues.push(`${DOC}: 계획 행 형식 오류(TC·REQ·AC·경계·GWT·예상 결과·자동화 위치 7칸): ${row[0]}`); continue; }
  const [, req, ac, bound, , , where] = row;
  const reqs = [...new Set([...ac.matchAll(/AC-(\d+)-\d+/g)].map((m) => `REQ-${m[1]}`))].join(", ");
  if (req !== (reqs || ac)) issues.push(`${DOC}: ${id} REQ '${req}' ≠ AC에서 나온 '${reqs || ac}'`);
  const bounds = bound.split("·").map((b) => b.trim());
  if (!bounds.length || bounds.some((b) => !(BOUNDS as readonly string[]).includes(b))) issues.push(`${DOC}: ${id} 경계 '${bound}'는 ${BOUNDS.join("·")} 중 하나 이상이어야 한다.`);
  const paths = where.split("·").map((p) => p.trim());
  const e2e = paths.filter((p) => p.startsWith("tests/e2e/"));
  const units = paths.filter((p) => p.startsWith("tests/unit/"));
  if (e2e.length !== 1 || e2e.length + units.length !== paths.length) issues.push(`${DOC}: ${id} 자동화 위치는 tests/e2e spec 1개와 tests/unit 파일(선택)만 ·로 적는다: ${where}`);
  for (const unit of units) if (!fs.existsSync(unit)) issues.push(`${DOC}: ${id} 단위 시험 ${unit}이 없다.`);
  if (plan.has(id)) issues.push(`${DOC}: 계획 TC 중복 ${id}`);
  plan.set(id, { req, ac, bounds, file: e2e[0] ?? "", units });
}

// 시험: tests/e2e 의 test("TC-…") 제목
const tests = new Map<string, string>();
for (const name of fs.readdirSync("tests/e2e").filter((file) => file.endsWith(".spec.ts")).sort()) {
  const file = `tests/e2e/${name}`;
  for (const match of fs.readFileSync(file, "utf8").matchAll(new RegExp(`\\btest\\(\\s*["'\`](${ID.source})`, "g"))) tests.set(match[1], file);
}
for (const [id, file] of tests) {
  const planned = plan.get(id);
  if (!planned) issues.push(`${file}: ${id}가 ${DOC} §2 계획에 없다. 계획 행을 추가하거나 계획된 ID를 사용한다.`);
  else if (planned.file !== file) issues.push(`${DOC}: ${id} 자동화 위치 ${planned.file} ≠ 실제 ${file}`);
}

// 이력: docs/evidence/<runId>.md 의 머리 정보와 `| 프로젝트 | 결과 | TC 제목 |` 행. runId 는 시각으로 시작해 이름순 = 시간순
type Run = { runId: string; sha: string; dirty: boolean; source: string; at: string; env: string; status: string };
const field = (text: string, name: string) => text.match(new RegExp(`^- ${name}: (.+)$`, "m"))?.[1].trim() ?? "";
const utc = (iso: string) => iso.replace(/^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}).*/, "$1 $2");
const history = new Map<string, Run[]>();
const evidence = (fs.existsSync("docs/evidence") ? fs.readdirSync("docs/evidence") : []).filter((file) => /^\d{17}-.+\.md$/.test(file)).sort();
for (const name of evidence) {
  const text = fs.readFileSync(`docs/evidence/${name}`, "utf8");
  const run = {
    runId: name.slice(0, -3), sha: field(text, "Git SHA"), dirty: field(text, "미커밋 변경") === "true",
    source: field(text, "시험 소스 SHA-256"), at: utc(field(text, "시작\\(UTC\\)")),
    env: [field(text, "Node") && `Node ${field(text, "Node")}`, field(text, "UI 브라우저")].filter(Boolean).join(" · "),
  };
  for (const match of text.matchAll(new RegExp(`^\\| (?:api|ui) \\| (PASS|FAIL|SKIP|FLAKY) \\| (${ID.source})`, "gm"))) {
    history.set(match[2], [...(history.get(match[2]) ?? []), { ...run, status: match[1] }]);
  }
}

// PRD: REQ 행에 적힌 AC마다 `| AC | 인수조건 | FLOW | Issue/PR | TC | 상태 | 판정 근거 |` 행 1개.
// 상태 형식, TC = §2에서 그 AC를 덮는 계획 TC 전부, FLOW = experience 흐름 표의 ID, 검증(<sha7>) = 그 SHA의 미커밋 아닌 PASS.
const PRD = "docs/prd.md";
const STATUS = /^(미실행|구현\(PR #\d+(?:, #\d+)*\)|검증\([0-9a-f]{7}\)|실패|미검증|미구현)$/;
if (fs.existsSync(PRD)) {
  const experience = fs.existsSync("docs/experience.md") ? fs.readFileSync("docs/experience.md", "utf8") : "";
  const acRows = new Map<string, string[]>();
  const mentioned = new Set<string>();
  for (const line of fs.readFileSync(PRD, "utf8").split("\n")) {
    const row = cells(line);
    if (line.startsWith("| REQ-")) {
      const num = row[0].match(/^REQ-(\d+)$/)?.[1];
      for (const match of line.matchAll(new RegExp(`AC-${num}-\\d+`, "g"))) mentioned.add(match[0]);
      if (!STATUS.test(row.at(-1) ?? "")) issues.push(`${PRD}: ${row[0]} 상태 '${row.at(-1)}'는 미실행·구현(PR #n)·검증(<sha7>)·실패·미검증·미구현 중 하나여야 한다.`);
    } else if (line.startsWith("| AC-")) {
      if (!/^AC-\d+-\d+$/.test(row[0]) || row.length !== 7) { issues.push(`${PRD}: AC 행 형식 오류(AC·인수조건·FLOW·Issue/PR·TC·상태·판정 근거 7칸): ${row[0]}`); continue; }
      if (acRows.has(row[0])) issues.push(`${PRD}: AC 행 중복 ${row[0]}`);
      acRows.set(row[0], row);
    }
  }
  for (const ac of mentioned) if (!acRows.has(ac)) issues.push(`${PRD}: ${ac}의 AC별 연결·판정 행이 없다.`);
  for (const [ac, [, , flow, , tc, status]] of acRows) {
    if (!STATUS.test(status)) issues.push(`${PRD}: ${ac} 상태 '${status}'는 미실행·구현(PR #n)·검증(<sha7>)·실패·미검증·미구현 중 하나여야 한다.`);
    if (!/^(FLOW-\d+(, FLOW-\d+)*|미정|—|)$/.test(flow)) issues.push(`${PRD}: ${ac} FLOW '${flow}'는 FLOW-NN 목록·미정·— 중 하나여야 한다.`);
    for (const id of flow.match(/FLOW-\d+/g) ?? []) if (!experience.includes(`| ${id} |`)) issues.push(`${PRD}: ${ac} ${id}가 docs/experience.md 흐름 표에 없다.`);
    const planned = [...plan].filter(([, p]) => p.ac.match(/AC-\d+-\d+/g)?.includes(ac)).map(([id]) => id).sort();
    const listed = [...new Set(tc.match(new RegExp(ID.source, "g")) ?? [])].sort();
    if (planned.join() !== listed.join()) issues.push(`${PRD}: ${ac} TC '${listed.join(", ") || tc}' ≠ ${DOC} §2 계획 '${planned.join(", ") || "없음"}'`);
    const sha = status.match(/^검증\(([0-9a-f]{7})\)$/)?.[1];
    if (sha && !planned.length) issues.push(`${PRD}: ${ac} 계획 TC 없이 검증(${sha})이다.`);
    if (sha) for (const id of planned) if (!history.get(id)?.some((run) => run.status === "PASS" && !run.dirty && run.sha.startsWith(sha))) issues.push(`${PRD}: ${ac} 검증(${sha})인데 ${id}에 ${sha}의 미커밋 아닌 PASS 근거가 없다.`);
    if (status === "미실행" && planned.some((id) => history.get(id)?.some((run) => run.status !== "SKIP"))) issues.push(`${PRD}: ${ac} 실행 근거가 있는데 미실행이다(검증·실패·미검증으로 판정한다).`);
  }
}

if (issues.length) {
  console.error(issues.join("\n"));
  process.exit(1);
}
if (process.argv.includes("--check")) {
  console.log(`E2E 계획·PRD 대조 통과: 계획 ${plan.size} · 자동화 ${tests.size}`);
  process.exit(0);
}

// 단위 시험: docs/evidence/unit-<시각>.md 중 최신 1건 (npm run test:unit:evidence)
const unitFile = (fs.existsSync("docs/evidence") ? fs.readdirSync("docs/evidence") : []).filter((file) => /^unit-\d{17}\.md$/.test(file)).sort().at(-1);
const unitLine = (() => {
  if (!unitFile) return "단위 시험(Vitest 전체): 미실행 — `npm run test:unit:evidence`로 기록한다.";
  const text = fs.readFileSync(`docs/evidence/${unitFile}`, "utf8");
  const sha = `${field(text, "Git SHA").slice(0, 7) || "Git 없음"}${field(text, "미커밋 변경") === "true" ? "*" : ""}`;
  return `단위 시험(Vitest 전체): ${field(text, "시험")} · 파일 ${field(text, "파일")} · 소스 ${sha} · ${utc(field(text, "시작\\(UTC\\)"))} UTC · Node ${field(text, "Node")} · [근거](evidence/${unitFile})`;
})();

// 시험 파일이 마지막 실행 SHA 이후 커밋으로 바뀌었으면 그 결과는 현재 시험을 증명하지 않는다.
const git = (...args: string[]) => { try { return execFileSync("git", args, { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim(); } catch { return null; } };
const lastChange = new Map<string, string>();
const covered = (file: string, sha: string) => {
  if (!lastChange.has(file)) lastChange.set(file, git("log", "-1", "--format=%H", "--", file) ?? "");
  const change = lastChange.get(file);
  return !change || !sha || git("merge-base", "--is-ancestor", change, sha) !== null;
};

const link = (file: string, root: string, ext: string) => `[${file.slice(root.length, -ext.length)}](../${file})`;
const count: Record<string, number> = { 검증: 0, 실패: 0, 미검증: 0, 미실행: 0, 미구현: 0 };
const byReq = new Map<string, { tc: number; done: number; bounds: Record<string, [number, number]> }>();
const rows = [...plan].map(([id, { req, ac, bounds, units }]) => {
  const file = tests.get(id);
  const runs = history.get(id) ?? [];
  const last = runs.at(-1);
  const status = !file ? "미구현" : !last || last.status === "SKIP" ? "미실행" : last.status !== "PASS" ? "실패"
    : covered(file, last.sha) ? "검증" : "미검증";
  count[status]++;
  const r = byReq.get(req) ?? { tc: 0, done: 0, bounds: Object.fromEntries(BOUNDS.map((b) => [b, [0, 0]])) };
  r.tc++;
  if (status === "검증") r.done++;
  for (const b of bounds) { r.bounds[b][1]++; if (status === "검증") r.bounds[b][0]++; }
  byReq.set(req, r);
  const result = !file ? "미구현" : !last ? "미실행" : status === "미검증" ? `${last.status} (시험 변경 후 미실행)` : last.status;
  const sha = last ? `${last.sha.slice(0, 7) || "Git 없음"}${last.dirty ? "*" : ""}${last.source ? ` · ${last.source.slice(0, 8)}` : ""}` : "—";
  const when = last ? `[${last.at || last.runId}](evidence/${last.runId}.md)` : "—";
  const tally = runs.length ? ["PASS", "FAIL", "FLAKY", "SKIP"].map((s) => [s, runs.filter((run) => run.status === s).length] as const)
    .filter(([, n]) => n).map(([s, n]) => `${s} ${n}`).join(" · ") : "—";
  const files = [file ? link(file, "tests/e2e/", ".spec.ts") : "—", ...units.map((unit) => link(unit, "tests/unit/", ".test.ts"))].join(" · ");
  return `| ${req} | ${ac} | ${id} | ${bounds.join("·")} | ${files} | ${result} | ${sha} | ${when} | ${last?.env || "—"} | ${tally} |`;
});
const reqOrder = (req: string) => Number(req.match(/REQ-(\d+)/)?.[1] ?? Infinity);
const reqRows = [...byReq].sort(([a], [b]) => reqOrder(a) - reqOrder(b) || a.localeCompare(b)).map(([req, { tc, done, bounds }]) =>
  `| ${req} | ${done}/${tc} | ${BOUNDS.map((b) => bounds[b][1] ? `${bounds[b][0]}/${bounds[b][1]}` : "없음").join(" | ")} |`);

const block = [
  START,
  `> 자동 생성 — \`npm run e2e:dashboard\`로 다시 만들며 직접 고치지 않는다. 근거: §2 계획 · \`tests/e2e\` · \`docs/evidence/<runId>.md\` ${evidence.length}건 · \`docs/evidence/unit-*.md\`. 결과는 TC별 마지막 실행이고 시각은 UTC, 소스 SHA는 Git SHA(\`*\` = 미커밋 변경 상태의 실행) · 시험 소스 SHA-256 앞 8자다.`,
  "",
  "| 계획 TC | 자동화 | 검증 | 실패 | 미검증 | 미실행 | 미구현 |",
  "|---|---|---|---|---|---|---|",
  `| ${plan.size} | ${tests.size} | ${count.검증} | ${count.실패} | ${count.미검증} | ${count.미실행} | ${count.미구현} |`,
  "",
  unitLine,
  "",
  "REQ별 경계 확인(검증 TC/계획 TC, `없음` = 계획된 TC가 없는 경계):",
  "",
  `| REQ | TC | ${BOUNDS.join(" | ")} |`,
  "|---|---|---|---|---|---|",
  ...reqRows,
  "",
  "| REQ | AC | TC | 경계 | 시험 파일(E2E · 단위) | 결과 | 소스 SHA | 실행 시각(UTC) · 근거 | 실행 환경 | 이력 |",
  "|---|---|---|---|---|---|---|---|---|---|",
  ...rows,
  END,
].join("\n");
const start = doc.indexOf(START);
const next = start >= 0 ? doc.slice(0, start) + block + doc.slice(doc.indexOf(END) + END.length)
  : doc.replace("\n## 1.", `\n## 현황\n\n${block}\n\n## 1.`);
if (next !== doc) fs.writeFileSync(DOC, next);
console.log(`E2E 현황: 계획 ${plan.size} · 검증 ${count.검증} · 실패 ${count.실패} · 미검증 ${count.미검증} · 미실행 ${count.미실행} · 미구현 ${count.미구현}`);
