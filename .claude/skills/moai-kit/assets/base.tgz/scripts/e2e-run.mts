// 새 DB·결과 경로로 실행한다. 개발 DB 삭제·기존 서버 재사용 금지.
import fs from "node:fs";
import { randomUUID } from "node:crypto";
import { createRequire } from "node:module";
import { createServer } from "node:net";
import { spawn } from "node:child_process";
import { readReport, runPaths, sourceSnapshot, testOrigin, writeEvidence, type RunManifest } from "./lib/e2e.mts";

const args = process.argv.slice(2);
const controlled = ["--config", "-c", "--workers", "-j", "--retries", "--repeat-each", "--shard", "--output", "--reporter"];
if (args.some((arg) => controlled.some((flag) => arg === flag || arg.startsWith(`${flag}=`)) || /^-(?:c|j).+/.test(arg))) {
  throw new Error("config·workers·retries·출력 경로는 표준 runner가 관리합니다.");
}
if (process.env.E2E_REUSE || process.env.E2E_BASE_URL) throw new Error("기존 서버 재사용·외부 baseURL 금지. E2E_PORT로 포트를 분리하세요.");
// Next와 같은 전체 인터페이스에서 빈 포트를 확인한다. 지정 포트가 사용 중이면 중단한다.
const requestedPort = process.env.E2E_PORT ? testOrigin().port : 0;
const port = await new Promise<number>((resolve, reject) => {
  const probe = createServer();
  probe.once("error", reject);
  probe.listen(requestedPort, () => {
    const address = probe.address();
    if (!address || typeof address === "string") { probe.close(); reject(new Error("시험 포트를 확인하지 못했습니다.")); return; }
    probe.close((error) => error ? reject(error) : resolve(address.port));
  });
});
process.env.E2E_PORT = String(port);
const runId = `${new Date().toISOString().replaceAll(/[^0-9]/g, "")}-${randomUUID()}`;
const paths = runPaths(runId);
if (fs.existsSync(paths.directory)) throw new Error("이미 존재하는 실행 경로입니다.");
fs.mkdirSync(paths.directory, { recursive: true });
const source = sourceSnapshot();
const { origin } = testOrigin();
const startedAt = new Date().toISOString();
const cli = createRequire(import.meta.url).resolve("@playwright/test/cli");
const child = spawn(process.execPath, [cli, "test", ...args], {
  stdio: "inherit", windowsHide: true,
  env: { ...process.env, E2E_RUN_ID: runId, E2E_SOURCE_SHA256: source.sha256 },
});
process.on("SIGINT", () => child.kill("SIGINT"));
process.on("SIGTERM", () => child.kill("SIGTERM"));
let exitCode = await new Promise<number>((resolve) => {
  child.once("error", () => resolve(1));
  child.once("exit", (code) => resolve(code ?? 1));
});
if (args.some((arg) => ["--list", "--help", "--version"].includes(arg))) {
  console.log("목록·도움말 실행은 시험 결과로 기록하지 않습니다.");
  process.exitCode = exitCode;
} else {
  const sourceAfter = sourceSnapshot();
  const sourceChanged = source.sha256 !== sourceAfter.sha256;
  let status: RunManifest["status"] = "incomplete";
  let counts: RunManifest["counts"] = { passed: 0, failed: 0, skipped: 0, flaky: 0 };
  try {
    const report = readReport(runId, source.sha256, startedAt);
    counts = { passed: report.stats.expected, failed: report.stats.unexpected, skipped: report.stats.skipped, flaky: report.stats.flaky };
    const valid = !sourceChanged && counts.passed > 0 && counts.failed === 0 && counts.skipped === 0 && counts.flaky === 0;
    status = exitCode === 0 && valid ? "passed" : "failed";
    if (status !== "passed" && exitCode === 0) exitCode = 1;
  } catch { exitCode = 1; }
  const manifest: RunManifest = {
    version: 1, runId, startedAt, finishedAt: new Date().toISOString(), node: process.version,
    browserChannel: process.env.PW_CHANNEL ?? (process.env.PW_CHROMIUM_PATH ? "executablePath" : "chromium"),
    args, origin, source, sourceAfter, sourceChanged, exitCode, status, counts,
  };
  fs.writeFileSync(paths.manifest, JSON.stringify(manifest, null, 2));
  fs.writeFileSync("test-results/e2e-latest.json", JSON.stringify({ runId }, null, 2));
  writeEvidence(manifest);
  console.log(`E2E ${status}: ${runId} · 소스 ${source.sha256} · manifest ${paths.manifest}`);
  process.exitCode = exitCode;
}
