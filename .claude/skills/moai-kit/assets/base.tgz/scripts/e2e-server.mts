import fs from "node:fs";
import path from "node:path";
import { createHash, randomBytes } from "node:crypto";
import { createRequire } from "node:module";
import { spawn } from "node:child_process";
import { eq } from "drizzle-orm";
import { migrateDb, openDb } from "../src/server/db/open.ts";
import { sessions, users } from "../src/server/db/schema.ts";
import { seed } from "./db-seed.mts";
import { runPaths, testOrigin } from "./lib/e2e.mts";
import { startKdsFontServer } from "./kds-font-server.mts";

const paths = runPaths(process.env.E2E_RUN_ID ?? "");
const { port, origin } = testOrigin();
if (process.env.DATABASE_URL !== paths.database || process.env.APP_ORIGIN !== origin || fs.existsSync(paths.database)) {
  throw new Error("E2E는 해당 runId의 새 DB와 로컬 Origin만 사용합니다.");
}
const db = openDb(paths.database);
await migrateDb(db);
await seed(db);
// 만료 세션 거부 시험(TC-AUTH-API-006)용: 이 실행의 새 DB에만 이미 만료된 user1 합성 세션 1개. 원문 토큰은 이 실행 디렉터리에만 둔다.
const expiredToken = randomBytes(32).toString("base64url");
const [user1] = await db.select({ id: users.id }).from(users).where(eq(users.email, "user1@demo.local"));
await db.insert(sessions).values({ id: createHash("sha256").update(expiredToken).digest("hex"), userId: user1.id, expiresAt: new Date(Date.now() - 60_000) });
fs.writeFileSync(path.join(paths.directory, "expired-session.token"), expiredToken);
const fonts = await startKdsFontServer();
process.env.KDS_LOCAL_FONT_CSS = fonts?.css ?? "";
const next = createRequire(import.meta.url).resolve("next/dist/bin/next");
let active: ReturnType<typeof spawn> | undefined;
process.on("SIGINT", () => { active?.kill("SIGINT"); void fonts?.close(); });
process.on("SIGTERM", () => { active?.kill("SIGTERM"); void fonts?.close(); });
async function run(args: string[]) {
  active = spawn(process.execPath, [next, ...args], { stdio: "inherit", windowsHide: true, env: process.env });
  return await new Promise<number>((resolve) => {
    active?.once("error", () => resolve(1));
    active?.once("exit", (code) => resolve(code ?? 1));
  });
}
const built = await run(["build"]);
process.exitCode = built === 0 ? await run(["start", "--port", String(port)]) : built;
await fonts?.close();
