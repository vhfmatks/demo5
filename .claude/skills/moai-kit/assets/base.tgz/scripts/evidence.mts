// 현재 실행 manifest를 검증해 문서화한다. 시험 재실행·현재 HEAD로 교체 금지.
import fs from "node:fs";
import { readReport, runPaths, writeEvidence, type RunManifest } from "./lib/e2e.mts";

const pointer = JSON.parse(fs.readFileSync("test-results/e2e-latest.json", "utf8")) as { runId: string };
const manifest = JSON.parse(fs.readFileSync(runPaths(pointer.runId).manifest, "utf8")) as RunManifest;
if (manifest.version !== 1 || manifest.runId !== pointer.runId) {
  throw new Error("완료된 실행 manifest가 없습니다. npm run test:e2e를 실행하세요.");
}
if (manifest.status !== "incomplete") readReport(manifest.runId, manifest.source.sha256, manifest.startedAt);
writeEvidence(manifest);
console.log(`기록한 실행: ${manifest.runId} · ${manifest.status} · 소스 ${manifest.source.sha256}`);
process.exitCode = manifest.status === "passed" ? 0 : 1;
