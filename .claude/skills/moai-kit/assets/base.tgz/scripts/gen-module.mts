// 새 도메인 모듈 생성기 — CRUD 전체(테이블·서비스·API·화면·E2E)를 1분 안에 만든다.
//   npm run gen -- <entity> <한글라벨> [--plural=<entities>] [--auth=required|public] [--fields=<명세>] [--skip-tests]
//   예) npm run gen -- booking 예약          → /bookings
//       npm run gen -- category 분류 --plural=categories
//       npm run gen -- task 업무 "--fields=amount:int!:금액,dueDate:date:마감일,done:bool:완료,status:enum(OPEN=진행|DONE=종료)!:상태"
//   --fields 형식: name:type[!]:라벨 (! = 필수). type = text|long|int|num|bool|date|datetime|enum(VALUE=라벨|...)|ref(<대상 복수형>).
//     입력 상한(SEC-04): text 200자·long 2000자·int 0~10억·num ±10억. 업무 범위가 더 좁으면 생성 후 schema.ts 에서 줄인다.
//     title·memo 는 항상 생성된다. ref 는 다른 엔티티(gen 으로 만든 것) 또는 users 를 가리키는 FK 이고 이름은 ...Id 로 끝난다.
//     테이블·zod·DTO·toDto·폼·목록·상세·API/UI 시험에 필드를 함께 넣는다.
// 이후: npm run db:generate -- --name add_<table> → npm run db:migrate (필드를 더 바꾸면 features/<entities>/schema.ts + db/schema.ts)
import fs from "node:fs";
import path from "node:path";

const args = process.argv.slice(2).filter((a) => !a.startsWith("--"));
const flags: Record<string, string | undefined> = Object.fromEntries(
  process.argv.slice(2).filter((a) => a.startsWith("--")).map((a) => {
    const i = a.indexOf("=");
    return i < 0 ? [a.slice(2), undefined] : [a.slice(2, i), a.slice(i + 1)];
  }),
);
for (const key of Object.keys(flags)) {
  if (!["plural", "auth", "fields", "skip-tests"].includes(key)) throw new Error(`지원하지 않는 옵션: --${key}`);
  if (key !== "skip-tests" && !flags[key]) throw new Error(`--${key}=값 형식으로 지정하세요.`);
}
const [rawEntity, label] = args;
if (args.length !== 2 || !rawEntity || !label || !/^[a-z][a-zA-Z0-9]*$/.test(rawEntity)) {
  console.error("사용법: npm run gen -- <entity(camelCase, 단수)> <한글라벨> [--plural=<복수형>] [--auth=required|public] [--fields=<명세>]");
  process.exit(1);
}

const entity = rawEntity;
const entities = flags.plural ?? `${entity}s`;
const auth = flags.auth ?? "required";
if (!/^[a-z][a-zA-Z0-9]*$/.test(entities) || !["required", "public"].includes(auth)) {
  throw new Error("plural은 camelCase 식별자, auth는 required 또는 public이어야 합니다.");
}
if (/[\r\n"'`\\<>{}]/.test(label)) throw new Error("라벨에는 따옴표·줄바꿈·코드 문자를 넣지 않습니다.");
const skipTests = Object.hasOwn(flags, "skip-tests");
const pascal = (s: string) => s[0].toUpperCase() + s.slice(1);
const snake = (s: string) => s.replace(/[A-Z]/g, (c) => `_${c.toLowerCase()}`);

const TOKENS: [string, string][] = [
  ["__Entities__", pascal(entities)],
  ["__entities__", entities],
  ["__Entity__", pascal(entity)],
  ["__entity__", entity],
  ["__ENTITY__", snake(entity).toUpperCase()],
  ["__table__", snake(entities)],
  ["__label__", label],
];
const fill = (s: string) => TOKENS.reduce((acc, [k, v]) => acc.replaceAll(k, v), s);

// ── --fields: 템플릿의 "@f:<이름>" 마커 줄을 필드별 코드로 바꾼다 ──────────────
type Kind = "text" | "long" | "int" | "num" | "bool" | "date" | "datetime" | "enum" | "ref";
type Spec = { name: string; kind: Kind; required: boolean; label: string; options: [string, string][]; target: string };
const RESERVED = new Set(["id", "title", "memo", "owner", "ownerId", "version", "createdAt", "updatedAt"]);
const badText = (s: string) => /[\r\n"'`\\<>{}|=:,]/.test(s);
const fields: Spec[] = (flags.fields ?? "").split(",").filter((raw) => raw.trim()).map((raw) => {
  const m = /^([a-z][a-zA-Z0-9]*):(text|long|int|num|bool|datetime|date|enum\(([^)]+)\)|ref\(([a-z][a-zA-Z0-9]*)\))(!?):(.+)$/.exec(raw.trim());
  if (!m) throw new Error(`필드 형식 오류: ${raw} → name:type[!]:라벨, type=text|long|int|num|bool|date|datetime|enum(A=라벨|B=라벨)|ref(대상복수형)`);
  const [, name, type, enumBody, target = "", bang, fieldLabel] = m;
  if (RESERVED.has(name)) throw new Error(`예약된 필드명: ${name}`);
  if (badText(fieldLabel)) throw new Error(`라벨에 특수문자 금지: ${fieldLabel}`);
  const options = (enumBody ?? "").split("|").filter(Boolean).map((o): [string, string] => {
    const [value, optionLabel] = o.split("=");
    if (!/^[A-Z][A-Z0-9_]*$/.test(value) || !optionLabel || badText(optionLabel)) throw new Error(`enum 값 형식 오류: ${o} (VALUE=라벨)`);
    return [value, optionLabel];
  });
  const kind = (enumBody ? "enum" : target ? "ref" : type) as Kind;
  if (kind === "ref") {
    if (!name.endsWith("Id")) throw new Error(`ref 필드 이름은 Id 로 끝난다: ${name} (예: roomId:ref(rooms))`);
    if (auth === "public") throw new Error("ref 필드는 --auth=public 에서 지원하지 않습니다.");
    if (target === entities && bang === "!") throw new Error(`자기 참조 ${name} 은(는) 필수(!)일 수 없습니다(첫 행을 만들 수 없음).`);
  }
  return { name, kind, required: bang === "!" && type !== "bool", label: fieldLabel, options, target };
});
if (new Set(fields.map((x) => x.name)).size !== fields.length) throw new Error("필드명이 중복됩니다.");

const ENT = snake(entity).toUpperCase();
const v = auth === "public" ? "row" : "r"; // 템플릿 변형별 행 변수명
const VALUES = (x: Spec) => `${ENT}_${snake(x.name).toUpperCase()}_VALUES`;
const LABELS = (x: Spec) => `${ENT}_${snake(x.name).toUpperCase()}_LABEL`;
const enums = fields.filter((x) => x.kind === "enum");
const refs = fields.filter((x) => x.kind === "ref");
// ref 대상: users 는 이름(name), gen 엔티티는 제목(title)을 표시값으로 쓴다. 대상 테이블·목록 service 가 이미 있어야 한다.
const schemaSource = fs.readFileSync(path.join(process.cwd(), "src/server/db/schema.ts"), "utf8");
for (const x of refs) {
  if (x.target === "users" || x.target === entities) continue;
  if (!schemaSource.includes(`export const ${x.target} = sqliteTable(`)) throw new Error(`ref 대상 테이블 없음: ${x.target} (먼저 gen 으로 만든다)`);
  const svc = path.join(process.cwd(), "src/features", x.target, "service.ts");
  if (!fs.existsSync(svc) || !fs.readFileSync(svc, "utf8").includes(`export async function list${pascal(x.target)}(actor`)) {
    throw new Error(`ref 대상 ${x.target} 에 list${pascal(x.target)}(actor, query) 가 없습니다. gen 으로 만든 엔티티나 users 만 가리킬 수 있습니다.`);
  }
}
const stem = (x: Spec) => x.name.slice(0, -2); // roomId → room
const refAlias = (x: Spec) => `${x.name}Ref`;
const refLabelCol = (x: Spec) => `${refAlias(x)}.${x.target === "users" ? "name" : "title"}`;
const optionsType = `${pascal(entity)}Options`;
const str = (s: string) => JSON.stringify(s);

const zodOf = (x: Spec) => {
  const len = x.kind === "long" ? 2000 : 200;
  switch (x.kind) {
    case "text":
    case "long":
      return x.required
        ? `z.string().trim().min(1, "${x.label}을(를) 입력해 주세요.").max(${len}, "${len}자 이하")`
        : `z.string().trim().max(${len}, "${len}자 이하")`;
    case "int":
      return `z.preprocess((value) => (value === "" ? ${x.required ? "undefined" : "0"} : value), z.coerce.number({ error: "${x.label}을(를) 숫자로 입력해 주세요." }).int("정수로 입력해 주세요.").min(0, "0 이상").max(1_000_000_000, "10억 이하"))`;
    case "num":
      return `z.preprocess((value) => (value === "" ? ${x.required ? "undefined" : "0"} : value), z.coerce.number({ error: "${x.label}을(를) 숫자로 입력해 주세요." }).min(-1_000_000_000, "-10억 이상").max(1_000_000_000, "10억 이하"))`;
    case "datetime":
      return x.required
        ? `z.iso.datetime({ local: true, precision: -1, error: "${x.label}을(를) 선택해 주세요." })`
        : `z.union([z.literal(""), z.iso.datetime({ local: true, precision: -1, error: "올바른 일시가 아닙니다." })])`;
    case "ref":
      return x.required
        ? `z.uuid({ error: "${x.label}을(를) 선택해 주세요." })`
        : `z.union([z.literal(""), z.uuid({ error: "${x.label}을(를) 다시 선택해 주세요." })]).transform((value) => value || null)`;
    case "bool":
      return "z.union([z.boolean(), z.stringbool()])";
    case "date":
      return x.required
        ? `z.iso.date({ error: "${x.label}을(를) 선택해 주세요." })`
        : `z.union([z.literal(""), z.iso.date({ error: "올바른 날짜가 아닙니다." })])`;
    case "enum":
      return `z.enum(${VALUES(x)}, { error: "${x.label}을(를) 선택해 주세요." })`;
  }
};
const defaultOf = (x: Spec) =>
  ({ text: '""', long: '""', date: '""', datetime: '""', int: "0", num: "0", bool: "false", enum: str(x.options[0]?.[0] ?? ""), ref: "null" })[x.kind];
const tsOf = (x: Spec) =>
  ({
    text: "string", long: "string", date: "string", datetime: "string", int: "number", num: "number", bool: "boolean",
    enum: `(typeof ${VALUES(x)})[number]`, ref: x.required ? "string" : "string | null",
  })[x.kind];
const colOf = (x: Spec) => {
  const c = str(snake(x.name));
  // ref: 필수는 대상 삭제 시 함께 삭제(cascade), 선택은 비운다(set null). 대상 삭제가 FK 오류(500)로 막히지 않게 한다.
  if (x.kind === "ref") {
    const to = `references((): AnySQLiteColumn => ${x.target}.id, { onDelete: "${x.required ? "cascade" : "set null"}" })`;
    return x.required ? `text(${c}).notNull().${to}` : `text(${c}).${to}`;
  }
  const base =
    x.kind === "int" ? `integer(${c}).notNull()`
    : x.kind === "num" ? `real(${c}).notNull()`
    : x.kind === "bool" ? `integer(${c}, { mode: "boolean" }).notNull()`
    : x.kind === "enum" ? `text(${c}, { enum: ${VALUES(x)} }).notNull()`
    : `text(${c}).notNull()`;
  return x.required ? base : `${base}.default(${defaultOf(x)})`;
};
const showOf = (x: Spec) => {
  const val = `${v}.${x.name}`;
  return ({
    text: `${val} || "-"`, long: `${val} || "-"`, date: `${val}.replaceAll("-", ".") || "-"`, datetime: `${val}.replace("T", " ") || "-"`,
    int: `${val}.toLocaleString("ko-KR")`, num: `${val}.toLocaleString("ko-KR")`,
    bool: `${val} ? "예" : "아니오"`, enum: `${LABELS(x)}[${val}]`, ref: `${v}.${stem(x)}Label ?? "-"`,
  })[x.kind];
};
const sampleOf = (x: Spec) =>
  ({
    text: str(`합성 ${x.label}`), long: str(`합성 ${x.label}`), int: "1", num: "-1.5", bool: "true", date: '"2026-01-01"',
    datetime: '"2026-01-01T09:30"', enum: str(x.options.at(-1)?.[0] ?? ""), ref: "",
  })[x.kind];
const plain = fields.filter((x) => x.kind !== "ref"); // SAMPLE 에 고정값으로 넣는 필드 (ref 는 시험 중에 대상 행을 만든다)
const formOf = (x: Spec): string[] => {
  const n = x.name;
  const ctl = (tag: string, props: string) => `  <${tag} name="${n}"${props} invalid={!!m.fieldErrors.${n}} />`;
  const field = (inner: string) => [`<Field label="${x.label}" name="${n}"${x.required ? " required" : ""} error={m.fieldErrors.${n}}>`, inner, "</Field>"];
  switch (x.kind) {
    case "text": return field(ctl("Input", ` defaultValue={initial?.${n}}`));
    case "long": return field(ctl("Textarea", ` defaultValue={initial?.${n}}`));
    case "int": return field(ctl("Input", ` type="number" inputMode="numeric" min={0} defaultValue={initial?.${n}}`));
    case "num": return field(ctl("Input", ` type="number" inputMode="decimal" step="any" defaultValue={initial?.${n}}`));
    case "date": return [`  <DatePicker name="${n}" label="${x.label}"${x.required ? " required" : ""} defaultValue={initial?.${n}} error={m.fieldErrors.${n}} />`];
    case "datetime": return field(ctl("Input", ` type="datetime-local" defaultValue={initial?.${n}}`));
    case "ref":
      return field(ctl("Select", ` options={options.${n}} placeholder="${x.required ? "선택하세요" : "없음"}" defaultValue={initial?.${n} ?? ""}`));
    case "enum":
      return field(ctl("Select", ` options={toOptions(${LABELS(x)})}${x.required ? ' placeholder="선택하세요"' : ""} defaultValue={initial?.${n}${x.required ? ' ?? ""' : ""}}`));
    case "bool": // 체크 해제도 PATCH 로 보내도록 hidden 값을 먼저 둔다(formValues 는 마지막 값을 쓴다).
      return [`<input type="hidden" name="${n}" value="false" />`, `<Checkbox name="${n}" value="true" defaultChecked={initial?.${n}}>${x.label}</Checkbox>`];
  }
};
const fillOf = (x: Spec): string[] =>
  x.kind === "enum" ? [`await page.getByLabel(${str(x.label)}).selectOption(${sampleOf(x)});`]
  : x.kind === "ref" ? [`await page.getByLabel(${str(x.label)}).selectOption(${x.name});`]
  : x.kind === "date" ? [`await selectKdsDate(page, ${str(x.label)}, ${sampleOf(x)});`]
  : [`await page.getByLabel(${str(x.label)}).fill(${x.kind === "int" ? '"1"' : x.kind === "num" ? '"-1.5"' : sampleOf(x)});`];
const listFn = (target: string) => `list${pascal(target)}`;
// ref 대상 단건 조회(열람 권한 포함): 자기 참조는 이 파일의 get, 다른 gen 엔티티는 대상 service 의 get<X>(actor, id).
const getFn = (target: string) => {
  if (target === entities) return `get${pascal(entity)}`;
  const src = fs.readFileSync(path.join(process.cwd(), "src/features", target, "service.ts"), "utf8");
  const m = /export async function (get\w+)\(actor: SessionUser, id: string\)/.exec(src);
  if (!m) throw new Error(`ref 대상 ${target} service 에 get<X>(actor: SessionUser, id: string) 가 없습니다.`);
  return m[1];
};
const accessRefs = refs.filter((x) => x.target !== "users"); // users 는 이름만 쓰는 선택지라 존재만 확인
const optionOf = (x: Spec) =>
  x.target === "users"
    ? `${x.name}: await userOptions(),`
    : `${x.name}: (await ${listFn(x.target)}(actor, { page: 1, pageSize: 100 })).items.map((t) => ({ value: t.id, label: t.title })),`;

const MARKERS: Record<string, (file: string) => string[]> = {
  "// @f:enums": () => enums.flatMap((x) => [
    `export const ${VALUES(x)} = [${x.options.map(([o]) => str(o)).join(", ")}] as const;`,
    `export const ${LABELS(x)}: Record<(typeof ${VALUES(x)})[number], string> = { ${x.options.map(([o, l]) => `${o}: ${str(l)}`).join(", ")} };`,
  ]),
  "// @f:zod": () => fields.map((x) => `${x.name}: ${zodOf(x)},`),
  "// @f:defaults": () => fields.filter((x) => !x.required).map((x) => `${x.name}: ${pascal(entity)}Fields.${x.name}.default(${defaultOf(x)}),`),
  "// @f:upd": () => fields.map((x) => `${x.name}: ${pascal(entity)}Fields.${x.name}.optional(),`),
  "// @f:dto": () => fields.flatMap((x) => [`${x.name}: ${tsOf(x)};`, ...(x.kind === "ref" ? [`${stem(x)}Label: ${tsOf(x)};`] : [])]),
  "// @f:map": () => fields.flatMap((x) => [`${x.name}: ${v}.${x.name},`, ...(x.kind === "ref" ? [`${stem(x)}Label: refs.${stem(x)}Label,`] : [])]),
  "// @f:idx": () => refs.map((x) => `index("${snake(entities)}_${snake(x.name)}_idx").on(t.${x.name}),`),
  "// @f:options": () => (refs.length
    ? [`/** 폼 선택지 (ref 필드). service 의 get${pascal(entity)}Options 가 만든다. */`,
      `export type ${optionsType} = { ${refs.map((x) => `${x.name}: { value: string; label: string }[]`).join("; ")} };`]
    : []),
  "// @f:svcimports": () => {
    // 대상 테이블·Options 타입은 applyRefs 가 기존 import 줄에 더한다.
    const out = refs.length ? ['import { alias } from "drizzle-orm/sqlite-core";'] : [];
    for (const t of new Set(refs.filter((x) => x.target !== entities).map((x) => x.target))) {
      out.push(t === "users" ? 'import { userOptions } from "@/features/users/service";' : `import { ${getFn(t)}, ${listFn(t)} } from "@/features/${t}/service";`);
    }
    return out;
  },
  "// @f:aliases": () => refs.map((x) => `const ${refAlias(x)} = alias(${x.target}, "${snake(x.name)}_ref");`),
  "// @f:select": () => refs.map((x) => `${stem(x)}Label: ${refLabelCol(x)},`),
  "// @f:joins": () => refs.map((x) => `.${x.required ? "innerJoin" : "leftJoin"}(${refAlias(x)}, eq(${refAlias(x)}.id, ${entities}.${x.name}))`),
  "// @f:row": () => refs.map((x) => `${stem(x)}Label: ${tsOf(x)};`),
  "// @f:checkrefs": () => (refs.length
    ? [
      "",
      "/** ref 대상이 실제로 있는지 확인한다. 없으면 400 (FK 위반 500 대신). */",
      `async function checkRefs(tx: DbExecutor, input: { ${refs.map((x) => `${x.name}?: string | null`).join("; ")} }) {`,
      ...refs.flatMap((x) => [
        `  if (input.${x.name} && !(await tx.select({ id: ${x.target}.id }).from(${x.target}).where(eq(${x.target}.id, input.${x.name})).get())) {`,
        `    throw Errors.validation({ ${x.name}: ["선택한 ${x.label}을(를) 찾을 수 없습니다."] });`,
        "  }",
      ]),
      "}",
      ...(accessRefs.length
        ? [
          "",
          "/** ref 대상 열람 권한: 볼 수 없는 행은 연결하지 않는다(없음과 같은 400). 대상 service 의 get 권한을 따른다. tx 밖에서 호출한다. */",
          `async function checkRefAccess(actor: SessionUser, input: { ${accessRefs.map((x) => `${x.name}?: string | null`).join("; ")} }) {`,
          "  const hidden = (fieldErrors: Record<string, string[]>) => (e: unknown) => {",
          "    throw e instanceof AppError && e.status === 404 ? Errors.validation(fieldErrors) : e;",
          "  };",
          ...accessRefs.map((x) => `  if (input.${x.name}) await ${getFn(x.target)}(actor, input.${x.name}).catch(hidden({ ${x.name}: ["선택한 ${x.label}을(를) 찾을 수 없습니다."] }));`),
          "}",
        ]
        : []),
    ]
    : []),
  "// @f:checkcall": () => (refs.length ? ["await checkRefs(tx, input);"] : []),
  "// @f:accesscall": () => (accessRefs.length ? ["await checkRefAccess(actor, input);"] : []),
  "// @f:optionsfn": () => (refs.length
    ? [
      "",
      "/** 폼 선택지 (ref 필드). gen 엔티티는 대상 service 의 목록 권한을 따르고 최대 100건이다. */",
      // users 만 가리키면 actor 를 쓰지 않는다 → _actor (호출부 시그니처는 같게 유지)
      `export async function get${pascal(entity)}Options(${refs.some((x) => x.target !== "users") ? "actor" : "_actor"}: SessionUser): Promise<${optionsType}> {`,
      "  return {",
      ...refs.map((x) => `    ${optionOf(x)}`),
      "  };",
      "}",
    ]
    : []),
  "// @f:refsfn": () => (refs.length
    ? [`const refs = async (api: APIRequestContext) => ({ ${refs.map((x) => `${x.name}: await createRef(api, "${x.target}")`).join(", ")} });`]
    : []),
  "// @f:reftests": () => (refs.length
    ? [
      "",
      `test("TC-${ENT}-API-005 존재하지 않는 참조 거부·저장값 불변", async ({ apiAs }) => {`,
      '  const owner = await apiAs("user1");',
      "  const ref = await refs(owner);",
      `  const before = (await expectData<${pascal(entity)}Dto[]>(await owner.get(URL))).meta?.total;`,
      `  const data = { ...SAMPLE, ...ref, title: uniqueTitle("TC-${ENT}-API-005"), ${refs[0].name}: "00000000-0000-4000-8000-000000000000" };`,
      "  const error = await expectError(await owner.post(URL, { data }), CommonErrors.VALIDATION_ERROR);",
      `  expect(error.fieldErrors?.${refs[0].name}).toBeTruthy();`,
      `  expect((await expectData<${pascal(entity)}Dto[]>(await owner.get(URL))).meta?.total).toBe(before);`,
      "});",
      ...(accessRefs.length
        ? [
          "",
          `test("TC-${ENT}-API-007 볼 수 없는 참조 대상 연결 거부·저장값 불변 (SEC-03)", async ({ apiAs }) => {`,
          '  const [owner, other] = await Promise.all([apiAs("user1"), apiAs("user2")]);',
          "  const ref = await refs(owner);",
          `  const hidden = await createRef(other, "${accessRefs[0].target}");`,
          `  const before = (await expectData<${pascal(entity)}Dto[]>(await owner.get(URL))).meta?.total;`,
          `  const data = { ...SAMPLE, ...ref, title: uniqueTitle("TC-${ENT}-API-007"), ${accessRefs[0].name}: hidden };`,
          "  const error = await expectError(await owner.post(URL, { data }), CommonErrors.VALIDATION_ERROR);",
          `  expect(error.fieldErrors?.${accessRefs[0].name}).toBeTruthy();`,
          `  expect((await expectData<${pascal(entity)}Dto[]>(await owner.get(URL))).meta?.total).toBe(before);`,
          "});",
        ]
        : []),
    ]
    : []),
  "// @f:prefill": () => refs.filter((x) => x.required).map((x) => `const ${x.name} = await createRef(await apiAs("user1"), "${x.target}");`),
  "// @f:cols": () => fields.map((x) => `${x.name}: ${colOf(x)},`),
  "{/* @f:form */}": () => fields.flatMap(formOf),
  "// @f:col": () => fields.filter((x) => x.kind !== "long").map((x) => `{ key: "${x.name}", header: "${x.label}", render: (${v}) => ${showOf(x)} },`),
  "// @f:desc": () => fields.map((x) => `{ label: "${x.label}", value: ${showOf(x)} },`),
  "// @f:imports": (file) => {
    const from = path.relative(process.cwd(), file).startsWith(path.join("src", "app")) ? `@/features/${entities}/schema` : "../schema";
    return enums.length ? [`import { ${enums.map(LABELS).join(", ")} } from "${from}";`] : [];
  },
  "// @f:sample": () => plain.map((x) => `${x.name}: ${sampleOf(x)},`),
  "// @f:fill": () => fields.filter((x) => x.required).flatMap(fillOf),
};
const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\/]/g, "\\$&");
function applyFields(file: string, content: string) {
  let out = content;
  if (file.endsWith(".ui.spec.ts") && fields.some((x) => x.kind === "date" && x.required)) out = out.replace(/import \{([^}]+)\} from "\.\/helpers";/, 'import {$1, selectKdsDate } from "./helpers";');
  for (const [marker, make] of Object.entries(MARKERS)) {
    out = out.replace(new RegExp(`^([ \\t]*)${escapeRe(marker)}\\r?\\n`, "gm"), (_, indent: string) =>
      make(file).map((line) => `${indent}${line}\n`).join(""));
  }
  if (file.endsWith("Form.tsx")) {
    const need = fields.flatMap((x) => (x.kind === "bool" ? ["Checkbox"] : x.kind === "enum" ? ["Select", "toOptions"] : x.kind === "ref" ? ["Select"] : x.kind === "date" ? ["DatePicker"] : []));
    out = out.replace(/import \{ ([^}]*) \} from "@\/components\/ui";/, (_, names: string) =>
      `import { ${[...new Set([...names.split(", "), ...need])].join(", ")} } from "@/components/ui";`);
  }
  if (refs.length) out = applyRefs(file, out);
  if (out.includes("@f:")) throw new Error(`처리되지 않은 필드 마커: ${file}`);
  return out.replace(/ = \{\r?\n\};/g, " = {};");
}
// ref 가 있을 때만 바뀌는 고정 코드 (폼 선택지 props·시험의 대상 행 생성)
function applyRefs(file: string, content: string) {
  const swap = (s: string, from: string, to: string) => {
    if (!s.includes(from)) throw new Error(`${path.relative(process.cwd(), file)} 에 "${from}" 이 없어 ref 를 적용할 수 없습니다.`);
    return s.replace(from, to);
  };
  const name = path.basename(file);
  const P = pascal(entity);
  const getOptions = `get${P}Options`;
  const Form = `${P}Form`;
  let out = content;
  if (name === "service.ts") {
    out = swap(out, "({ r, ownerName }: Row)", "({ r, ownerName, ...refs }: Row)");
    out = swap(out, 'import { AppError } from "@/server/http/errors";', 'import { AppError, Errors } from "@/server/http/errors";');
    const tables = [...new Set(refs.map((x) => x.target))].filter((t) => t !== "users" && t !== entities);
    out = swap(out, `import { ${entities}, users } from "@/server/db/schema";`, `import { ${[entities, ...tables, "users"].join(", ")} } from "@/server/db/schema";`);
    out = swap(out, ` Update${P}Input } from "./schema";`, ` Update${P}Input, ${optionsType} } from "./schema";`);
  }
  if (name === `${Form}.tsx`) {
    out = swap(out, `({ initial }: { initial?: ${P}Dto })`, `({ initial, options }: { initial?: ${P}Dto; options: ${optionsType} })`);
    out = swap(out, `type ${P}Dto } from "../schema";`, `type ${P}Dto, type ${optionsType} } from "../schema";`);
  }
  if (name === "page.tsx" && out.includes(`<${Form} `)) {
    if (!out.includes("const user = await requireUser();")) out = swap(out, "await requireUser();", "const user = await requireUser();");
    out = out.replace(`<${Form} />`, `<${Form} options={await ${getOptions}(user)} />`)
      .replace(`<${Form} initial={r} />`, `<${Form} initial={r} options={await ${getOptions}(user)} />`);
    out = swap(out, `import { ${Form} }`, `import { ${getOptions} } from "@/features/${entities}/service";\nimport { ${Form} }`);
  }
  if (name.endsWith(".api.spec.ts")) {
    // 시험마다 대상 행을 한 번 만들고(ref) 생성·비교에 같은 값을 쓴다.
    out = out.split("\ntest(").map((block) => {
      if (!block.includes("{ ...SAMPLE, title") || block.includes("const ref =")) return block;
      // 다른 사용자는 자기 대상 행을 쓴다(남의 대상 행은 열람 권한 검사로 400).
      return swap(block.replaceAll("{ ...SAMPLE, title", "{ ...SAMPLE, ...ref, title")
        .replaceAll("other.post(URL, { data: { ...SAMPLE, ...ref, title", "other.post(URL, { data: { ...SAMPLE, ...(await refs(other)), title"),
        'const owner = await apiAs("user1");\n', 'const owner = await apiAs("user1");\n  const ref = await refs(owner);\n');
    }).join("\ntest(");
    out = swap(out, 'import { test, expect } from "./fixtures";',
      'import type { APIRequestContext } from "@playwright/test";\nimport { test, expect } from "./fixtures";\nimport { createRef } from "./samples";');
  }
  if (name.endsWith(".ui.spec.ts") && refs.some((x) => x.required)) {
    out = swap(out, "async ({ page })", "async ({ page, apiAs })");
    out = swap(out, 'import { loginUI, uniqueTitle } from "./helpers";', 'import { loginUI, uniqueTitle } from "./helpers";\nimport { createRef } from "./samples";');
  }
  return out;
}
const render = (file: string, s: string) => applyFields(file, fill(s));

const ROOT = process.cwd();
const TPL = path.join(ROOT, "templates/module");
const created: string[] = [];
const outputs = new Map<string, string>();

function copyDir(src: string, dest: string) {
  for (const name of fs.readdirSync(src)) {
    const from = path.join(src, name);
    const to = path.join(dest, fill(name));
    if (fs.statSync(from).isDirectory()) copyDir(from, to);
    else {
      outputs.set(to, render(to, fs.readFileSync(from, "utf8")));
    }
  }
}

function insertBefore(file: string, marker: string, text: string) {
  const p = path.join(ROOT, file);
  const s = outputs.get(p) ?? fs.readFileSync(p, "utf8");
  if (!s.includes(marker)) throw new Error(`${file} 에 마커 ${marker} 가 없습니다.`);
  outputs.set(p, s.replace(marker, `${text}${marker}`));
}

copyDir(path.join(TPL, "features/__entities__"), path.join(ROOT, "src/features", entities));
copyDir(path.join(TPL, "api"), path.join(ROOT, "src/app/api/v1", entities));
const pageGroup = auth === "public" ? "(public)" : "(app)";
copyDir(path.join(TPL, "pages"), path.join(ROOT, `src/app/${pageGroup}`, entities));
if (!skipTests) copyDir(path.join(TPL, "tests"), path.join(ROOT, "tests/e2e"));
const variant = path.join(ROOT, "templates/module-public");
if (auth === "public") {
  copyDir(path.join(variant, "features/__entities__"), path.join(ROOT, "src/features", entities));
  copyDir(path.join(variant, "api"), path.join(ROOT, "src/app/api/v1", entities));
  copyDir(path.join(variant, "pages"), path.join(ROOT, `src/app/${pageGroup}`, entities));
  if (!skipTests) copyDir(path.join(variant, "tests"), path.join(ROOT, "tests/e2e"));
}
const sharedFiles = new Set(["src/server/db/schema.ts", "src/app/(app)/nav.ts", "src/lib/permissions.ts", "tests/e2e/samples.ts"].map((f) => path.join(ROOT, f)));
// 모든 생성 목적지를 먼저 확인한다. 템플릿 변형은 메모리에서 덮어쓰고 기존 소스는 덮어쓰지 않는다.
for (const file of outputs.keys()) {
  if (fs.existsSync(file)) throw new Error(`이미 존재: ${path.relative(ROOT, file)}`);
}
const tableTemplate = auth === "public" ? path.join(variant, "table.ts.txt") : path.join(TPL, "table.ts.txt");
insertBefore("src/server/db/schema.ts", "// @gen:tables", render("table.ts", fs.readFileSync(tableTemplate, "utf8")));
if (enums.length) {
  insertBefore("src/server/db/schema.ts", "// @gen:imports", `import { ${enums.map(VALUES).join(", ")} } from "../../features/${entities}/schema";\n`);
}
{
  // 필요한 sqlite-core 이름(real·AnySQLiteColumn)을 schema.ts 의 기존 import 에 더한다.
  const need = [...(fields.some((x) => x.kind === "num") ? ["real"] : []), ...(refs.length ? ["type AnySQLiteColumn"] : [])];
  const file = path.join(ROOT, "src/server/db/schema.ts");
  const cur = outputs.get(file) ?? fs.readFileSync(file, "utf8");
  const key = (n: string) => n.replace("type ", "");
  outputs.set(file, cur.replace(/import \{ ([^}]*) \} from "drizzle-orm\/sqlite-core";/, (_, names: string) =>
    `import { ${[...new Set([...names.split(", "), ...need])].sort((a, b) => key(a).localeCompare(key(b))).join(", ")} } from "drizzle-orm/sqlite-core";`));
}
// 시험용 합성 입력 등록 (다른 엔티티의 ref 시험이 이 엔티티 행을 만들 때 사용)
// refs 는 필수 ref 만 (선택 ref 까지 만들면 자기 참조가 끝없이 돈다).
const obj = (pairs: string[]) => (pairs.length ? `{ ${pairs.join(", ")} }` : "{}");
insertBefore("tests/e2e/samples.ts", "  // @gen:samples",
  `  ${entities}: { body: ${obj(plain.map((x) => `${x.name}: ${sampleOf(x)}`))}, refs: ${obj(refs.filter((x) => x.required).map((x) => `${x.name}: "${x.target}"`))} },\n`);
insertBefore("src/app/(app)/nav.ts", "  // @gen:nav", `  { href: "/${entities}", label: "${label}" },\n`);
// 인증 모듈은 "<entity>.manage.any"·"<entity>.read.dept" 권한을 등록하고 read.dept 는 MANAGER 에 준다(ADMIN 자동 포함).
if (auth !== "public") {
  insertBefore("src/lib/permissions.ts", "  // @gen:permissions", `  "${entity}.manage.any": "${label} 전체 조회·삭제",\n  "${entity}.read.dept": "${label} 같은 부서 조회",\n`);
  insertBefore("src/lib/permissions.ts", "      // @gen:dept-grants", `      "${entity}.read.dept",\n`);
}
const originals = new Map<string, string>();
const written: string[] = [];
try {
  for (const [file, content] of outputs) {
    if (sharedFiles.has(file)) originals.set(file, fs.readFileSync(file, "utf8"));
    fs.mkdirSync(path.dirname(file), { recursive: true });
    written.push(file);
    fs.writeFileSync(file, content);
    created.push(`${path.relative(ROOT, file)}${sharedFiles.has(file) ? " (수정)" : ""}`);
  }
} catch (error) {
  for (const file of written.reverse()) {
    const original = originals.get(file);
    if (original !== undefined) fs.writeFileSync(file, original);
    else fs.rmSync(file, { force: true });
  }
  throw error;
}

console.log(`\n✔ ${label}(${entities}) 모듈 생성${fields.length ? ` · 필드 ${fields.map((x) => x.name).join(", ")}` : ""}\n${created.map((f) => `  - ${f}`).join("\n")}`);
console.log(`
다음 단계:
  1. ${fields.length ? "필드는 반영됨. 추가 변경 시" : "필드 수정:"} src/features/${entities}/schema.ts  +  src/server/db/schema.ts (${entities} 테이블)
  2. npm run db:generate -- --name add_${snake(entities)} && npm run db:migrate
  3. ${auth === "public" ? "공개 CRUD 범위" : "권한 규칙"} 확인: src/features/${entities}/policy.ts
  ${skipTests ? "시험 파일은 생성하지 않았습니다. 실제 AC에 맞는 시험은 별도로 준비하세요." : `${auth === "public" ? "공개" : "인증"} CRUD 기본 API·UI 시험을 생성했습니다. TC·AC를 문서에 연결하세요.`}
  4. npm run verify && npm run test:e2e
`);
