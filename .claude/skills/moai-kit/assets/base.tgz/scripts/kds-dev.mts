import { spawn } from "node:child_process";
import { createRequire } from "node:module";
import { startKdsFontServer } from "./kds-font-server.mts";

const fonts = await startKdsFontServer();
const next = createRequire(import.meta.url).resolve("next/dist/bin/next");
const child = spawn(process.execPath, [next, "dev", ...process.argv.slice(2)], { stdio: "inherit", windowsHide: true, env: { ...process.env, KDS_LOCAL_FONT_CSS: fonts?.css ?? "" } });
const stop = () => { child.kill("SIGTERM"); void fonts?.close(); };
process.once("SIGINT", stop);
process.once("SIGTERM", stop);
process.exitCode = await new Promise<number>((resolve) => { child.once("error", () => resolve(1)); child.once("exit", (code) => resolve(code ?? 0)); });
await fonts?.close();
