import fs from "node:fs";
import path from "node:path";
import { randomBytes } from "node:crypto";
import { createServer } from "node:http";

/** Private participant bytes never pass through the public Next server. */
export async function startKdsFontServer(root = process.cwd()) {
  const folder = path.join(root, ".kds-private", "fonts");
  const names = { "500": "KTFLOW-MEDIUM.woff2", "700": "KTFLOW-BOLD.woff2" } as const;
  if (!Object.values(names).every((name) => fs.existsSync(path.join(folder, name)))) return null;
  const key = randomBytes(24).toString("hex");
  let port = 0;
  const server = createServer((req, res) => {
    let origin: URL;
    try { origin = new URL(req.headers.origin ?? ""); } catch { res.writeHead(403).end(); return; }
    if (!["localhost", "127.0.0.1", "[::1]"].includes(origin.hostname) || origin.protocol !== "http:" || req.headers.host !== `127.0.0.1:${port}`) {
      res.writeHead(403).end(); return;
    }
    const match = new RegExp(`^/${key}/(500|700)\\.woff2$`).exec(req.url ?? "");
    if (req.method !== "GET" || !match) { res.writeHead(404).end(); return; }
    const name = names[match[1] as keyof typeof names];
    res.writeHead(200, { "Content-Type": "font/woff2", "Access-Control-Allow-Origin": origin.origin, Vary: "Origin", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
    fs.createReadStream(path.join(folder, name)).pipe(res);
  });
  await new Promise<void>((resolve, reject) => { server.once("error", reject); server.listen(0, "127.0.0.1", resolve); });
  const address = server.address();
  if (!address || typeof address === "string") { server.close(); throw new Error("Local font listener unavailable"); }
  port = address.port;
  const css = [500, 700].map((weight) => `@font-face { font-family: "KT Flow"; font-weight: ${weight}; font-display: swap; src: url("http://127.0.0.1:${port}/${key}/${weight}.woff2") format("woff2"); }`).join("\n");
  return { address: address.address, port, css, fontUrl: `http://127.0.0.1:${port}/${key}/700.woff2`, close: () => new Promise<void>((resolve) => server.close(() => resolve())) };
}
