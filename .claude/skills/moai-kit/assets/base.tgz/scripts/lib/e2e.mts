import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";

export function runPaths(runId: string) {
  if (!/^[a-z0-9-]{8,80}$/.test(runId)) throw new Error("올바른 E2E runId가 필요합니다.");
  const root = path.resolve("test-results/runs");
  const directory = path.resolve(root, runId);
  if (path.dirname(directory) !== root) throw new Error("E2E 경로가 실행 디렉터리 밖입니다.");
  return {
    directory, database: path.join(directory, "test.db"),
    report: path.join(directory, "e2e.json"), manifest: path.join(directory, "run.json"),
    artifacts: path.join(directory, "artifacts"), html: path.join(directory, "html"),
  };
}

export function testOrigin() {
  const port = Number(process.env.E2E_PORT ?? 3100);
  if (!Number.isInteger(port) || port < 1024 || port > 65535) throw new Error("E2E_PORT는 1024~65535 정수입니다.");
  return { port, origin: `http://localhost:${port}` };
}

export function sourceSnapshot() {
  const files: string[] = [];
  const walk = (directory: string) => {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const name = path.join(directory, entry.name);
      if (entry.isDirectory()) walk(name);
      else if (entry.isFile()) files.push(name);
      else throw new Error("시험 소스에 심볼릭 링크를 사용하지 않습니다.");
    }
  };
  for (const dir of ["src", "scripts", "tests", "templates", "drizzle", "public"]) walk(dir);
  files.push("package.json", "package-lock.json", "next.config.ts", "playwright.config.ts", "tsconfig.json", "biome.json", "drizzle.config.ts");
  const hash = createHash("sha256");
  for (const file of files.sort()) {
    hash.update(file.replaceAll("\\", "/")).update("\0").update(fs.readFileSync(file)).update("\0");
  }
  let gitSha: string | null = null;
  let gitDirty: boolean | null = null;
  try {
    gitSha = execFileSync("git", ["rev-parse", "HEAD"], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim();
    gitDirty = !!execFileSync("git", ["status", "--porcelain"], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim();
  } catch { /* Git이 없는 kit는 실제 파일 해시로 식별한다. */ }
  return { sha256: hash.digest("hex"), fileCount: files.length, gitSha, gitDirty };
}

export type RunManifest = {
  version: 1; runId: string; startedAt: string; finishedAt: string; node: string;
  browserChannel: string; args: string[]; origin: string;
  source: ReturnType<typeof sourceSnapshot>; sourceAfter: ReturnType<typeof sourceSnapshot>;
  sourceChanged: boolean; exitCode: number; status: "passed" | "failed" | "incomplete";
  counts: { passed: number; failed: number; skipped: number; flaky: number };
};
type ReportTest = { projectName: string; status: string; results: { status: string }[] };
type ReportSuite = { title: string; specs?: { title: string; tests: ReportTest[] }[]; suites?: ReportSuite[] };
type Report = {
  config: { metadata: { runId: string; sourceSha256: string } };
  stats: { startTime: string; duration: number; expected: number; unexpected: number; skipped: number; flaky: number };
  suites: ReportSuite[];
};

export function readReport(runId: string, sourceSha256: string, startedAt: string): Report {
  const report = JSON.parse(fs.readFileSync(runPaths(runId).report, "utf8")) as Report;
  const metadata = report.config?.metadata;
  if (metadata?.runId !== runId || metadata.sourceSha256 !== sourceSha256 || !Array.isArray(report.suites)) {
    throw new Error("시험 결과의 runId·소스 해시가 일치하지 않습니다.");
  }
  const stats = report.stats;
  if (!stats || ![stats.expected, stats.unexpected, stats.skipped, stats.flaky].every((n) => Number.isSafeInteger(n) && n >= 0) ||
    !Number.isFinite(Date.parse(stats.startTime)) || Date.parse(stats.startTime) < Date.parse(startedAt)) {
    throw new Error("시험 결과가 실행 시작 이전이거나 통계가 올바르지 않습니다.");
  }
  return report;
}

export function writeEvidence(manifest: RunManifest) {
  const report = manifest.status === "incomplete" ? null : readReport(manifest.runId, manifest.source.sha256, manifest.startedAt);
  const rows: string[] = [];
  const walk = (suite: ReportSuite) => {
    for (const spec of suite.specs ?? []) for (const test of spec.tests) {
      const last = test.results.at(-1);
      const status = test.status === "expected" && last?.status === "passed" ? "PASS"
        : test.status === "skipped" ? "SKIP" : test.status === "flaky" ? "FLAKY" : "FAIL";
      rows.push(`| ${test.projectName} | ${status} | ${spec.title.replaceAll("|", "\\|")} |`);
    }
    for (const child of suite.suites ?? []) walk(child);
  };
  for (const suite of report?.suites ?? []) walk(suite);
  const link = path.relative("docs/evidence", runPaths(manifest.runId).directory).replaceAll("\\", "/");
  const text = [
    "# E2E 실행 근거", "",
    `- 실행 ID: ${manifest.runId}`, `- 시작(UTC): ${manifest.startedAt}`, `- 종료(UTC): ${manifest.finishedAt}`,
    `- Git SHA: ${manifest.source.gitSha ?? "Git 없음"}`, `- 미커밋 변경: ${manifest.source.gitDirty ?? "Git 없음"}`,
    `- 시험 소스 SHA-256: ${manifest.source.sha256}`, `- 실행 중 소스 변경: ${manifest.sourceChanged}`,
    `- Node: ${manifest.node}`, `- UI 브라우저: ${manifest.browserChannel}`,
    `- 명령: npm run test:e2e -- ${manifest.args.join(" ")}`, `- 결과: ${manifest.status.toUpperCase()} · 종료코드 ${manifest.exitCode}`,
    report ? `- PASS ${manifest.counts.passed} / FAIL ${manifest.counts.failed} / SKIP ${manifest.counts.skipped} / FLAKY ${manifest.counts.flaky}` : "- 결과 통계: 확인할 수 없음. 실행·보고서 오류를 해결한 뒤 새 실행이 필요하다.",
    report ? `- [실행 manifest](${link}/run.json) · [JSON 결과](${link}/e2e.json) · [HTML 보고서](${link}/html/index.html) · [스크린샷·trace](${link}/artifacts/)` : `- [실행 manifest](${link}/run.json)`, "",
    "부분 선택 실행은 명시된 범위만 검증한다. 실행 당시 Git SHA·파일 해시를 사용하며 현재 HEAD로 바꾸지 않는다. 단위 시험 결과는 포함하지 않는다.", "",
    "| 프로젝트 | 결과 | TC |", "|---|---|---|", ...rows, "",
  ].join("\n");
  fs.mkdirSync("docs/evidence", { recursive: true });
  fs.writeFileSync(`docs/evidence/${manifest.runId}.md`, text);
  fs.writeFileSync("docs/evidence/latest.md", text);
}
