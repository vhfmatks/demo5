# Clean up implementer worktrees (.claude/worktrees/agent-*) so finished or dead runs don't leak disk, branches or dev servers.
# Usage: pwsh scripts/moai-worktree-clean.ps1             sweep: agent worktrees whose claude process is gone, or whose issue is closed
#        pwsh scripts/moai-worktree-clean.ps1 <path> ...  these worktrees, even while this run still holds their lock (moai-work §9)
# Uncommitted work on issue-<n> is committed as `wip: resume (#<n>)` first; the local branch stays for a resume or a human.
# Kept (with a warning): a failed wip commit, changes on any other branch, or a folder Windows won't delete.
param([string[]]$Path)
$root = git rev-parse --show-toplevel
$base = [IO.Path]::GetFullPath((Join-Path $root .claude/worktrees))
function Rows {
  foreach ($b in ((git -C $root worktree list --porcelain) -join "`n") -split "`n`n") {
    if ($b -notmatch '(?m)^worktree (.+)$') { continue }
    [pscustomobject]@{
      path   = [IO.Path]::GetFullPath($Matches[1])
      branch = if ($b -match '(?m)^branch refs/heads/(.+)$') { $Matches[1] }
      owner  = if ($b -match '(?m)^locked .*\(pid (\d+)\)') { [int]$Matches[1] }   # Agent isolation locks it to the claude pid
    }
  }
}
$rows = Rows
$targets = if ($Path) {
  $want = $Path | ForEach-Object { [IO.Path]::GetFullPath($_) }
  $rows | Where-Object { $_.path -in $want }
} else {
  # Dead = locked by a claude pid that's gone. Unlocked = the agent finished, but its orchestrator may still need the
  # worktree (review, rebase), so only a closed issue's worktree goes.
  $rows | Where-Object {
    $_.path.StartsWith($base, 'OrdinalIgnoreCase') -and (Split-Path $_.path -Leaf) -like 'agent-*' -and $(
      if ($_.owner) { -not (Get-Process -Id $_.owner -ErrorAction Ignore) }
      elseif ($_.branch -match '^issue-(\d+)$') { (gh issue view $Matches[1] --json state -q .state 2>$null) -eq 'CLOSED' }
    )
  }
}

foreach ($w in $targets) {
  $p = $w.path
  # Orphaned next/playwright servers from a dead run hold .next and data/*.db open, and Windows then refuses the delete.
  # ponytail: matched by command line under <worktree>/node_modules; a server started another way survives (rmdir warns below).
  if ($IsWindows) {
    Get-CimInstance Win32_Process | Where-Object { "$($_.CommandLine)".Replace('/', '\').Contains("$p\node_modules", 'OrdinalIgnoreCase') } |
      ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction Ignore }
  }
  if (git -C $p status --porcelain) {
    if ($w.branch -notmatch '^issue-(\d+)$') { Write-Warning "kept $p — uncommitted changes on '$($w.branch)'"; continue }
    $n = $Matches[1]
    git -C $p add -A -- . ':!docs/evidence/*.md'   # generated run reports stay uncommitted (moai-implement step 6)
    git -C $p diff --cached --quiet
    if ($LASTEXITCODE -ne 0) {
      git -C $p commit -q -m "wip: resume (#$n)"
      if ($LASTEXITCODE -ne 0) { Write-Warning "kept $p — wip commit failed"; continue }
    }
  }
  git -C $root worktree remove -f -f $p 2>$null   # -f twice: also drops the agent lock
  if (Test-Path $p) {   # long node_modules paths make git give up halfway; rmdir /s doesn't follow junctions
    if ($IsWindows) { cmd /c rmdir /s /q "$p" 2>$null } else { Remove-Item -Recurse -Force $p -ErrorAction Ignore }
  }
  if (Test-Path $p) { Write-Warning "kept $p — files still in use" } else { "removed $p$(if ($w.branch) { " [$($w.branch)]" })" }
}

git -C $root worktree prune
# The isolation branch each agent started on (worktree-agent-*) is abandoned once it switches to issue-<n>.
# -d (not -D) only deletes it when it holds no commits of its own.
$used = @(Rows | ForEach-Object branch)
git -C $root for-each-ref --format='%(refname:short)' 'refs/heads/worktree-agent-*' |
  Where-Object { $_ -notin $used } | ForEach-Object { git -C $root branch -q -d $_ 2>$null }
