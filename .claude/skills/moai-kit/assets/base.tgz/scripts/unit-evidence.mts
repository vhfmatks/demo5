// 단위 시험(Vitest 전체)을 실행하고 결과를 docs/evidence/unit-<시각>.md 로 남긴다. e2e:dashboard 가 최신 1건을 현황에 표시한다.
import fs from "node:fs";
import { execFileSync, spawnSync } from "node:child_process";

type Result = { numPassedTests: number; numFailedTests: number; numPendingTests: number; numTodoTests: number;
  testResults: { name: string; assertionResults: { fullName: string; status: string }[] }[] };
const git = (...args: string[]) => { try { return execFileSync("git", args, { encoding: "utf8" }).trim(); } catch { return ""; } };
const started = new Date();
const id = started.toISOString().replace(/\D/g, "").slice(0, 17);
const json = `test-results/unit/${id}.json`;
fs.mkdirSync("test-results/unit", { recursive: true });
const sha = git("rev-parse", "HEAD");
const dirty = git("status", "--porcelain").length > 0;
const run = spawnSync(process.execPath, ["node_modules/vitest/vitest.mjs", "run", "--reporter=default", "--reporter=json", `--outputFile=${json}`], { stdio: "inherit" });
const result = fs.existsSync(json) ? (JSON.parse(fs.readFileSync(json, "utf8")) as Result) : null;
const failed = result?.testResults.flatMap((file) => file.assertionResults.filter((t) => t.status === "failed").map((t) => t.fullName)) ?? [];

fs.mkdirSync("docs/evidence", { recursive: true });
fs.writeFileSync(`docs/evidence/unit-${id}.md`, [
  "# 단위 시험 실행 근거",
  "",
  `- 실행 ID: unit-${id}`,
  `- 시작(UTC): ${started.toISOString()}`,
  `- Git SHA: ${sha}`,
  `- 미커밋 변경: ${dirty}`,
  `- Node: ${process.version}`,
  "- 명령: npm run test:unit:evidence",
  `- 결과: ${run.status === 0 ? "PASSED" : "FAILED"} · 종료코드 ${run.status}`,
  `- 파일: ${result?.testResults.length ?? "결과 없음"}`,
  `- 시험: ${result ? `PASS ${result.numPassedTests} / FAIL ${result.numFailedTests} / SKIP ${result.numPendingTests + result.numTodoTests}` : "결과 없음(실행 실패)"}`,
  `- [JSON 결과](../../${json})`,
  "",
  "AC와의 연결은 docs/e2e-test.md §2 자동화 위치의 tests/unit 파일이다. E2E 결과는 포함하지 않는다.",
  ...(failed.length ? ["", "실패한 시험:", "", ...failed.map((name) => `- ${name}`)] : []),
  "",
].join("\n"));
console.log(`기록한 단위 시험 실행: unit-${id} · 종료코드 ${run.status}`);
process.exitCode = run.status ?? 1;
