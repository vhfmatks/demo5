"use client";
// 예상 못한 서버 에러 화면. 상세 메시지는 노출하지 않는다(digest 만 표시 → 서버 로그와 대조).
import { Alert, Button } from "@/components/ui";

export default function AppErrorBoundary({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="flex flex-col items-start gap-3">
      <Alert>일시적인 오류가 발생했습니다. {error.digest && `(코드: ${error.digest})`}</Alert>
      <Button variant="tertiary" onClick={reset}>다시 시도</Button>
    </div>
  );
}
