// 내 정보 [Server]
import { Card, DescriptionList, LinkButton, PageHeader } from "@/components/ui";
import { requireUser } from "@/server/auth/session";
import { can } from "@/lib/permissions";
import { ROLE_LABEL } from "@/lib/roles";
import { DEPARTMENT_LABEL } from "@/lib/departments";
import { PasswordForm } from "@/features/auth/components/PasswordForm";

export default async function MePage() {
  const user = await requireUser();
  return (
    <>
      <PageHeader title="내 정보" />
      <div className="flex flex-col gap-6">
        <Card title="계정">
          <DescriptionList items={[
            { label: "이름", value: user.name },
            { label: "이메일", value: user.email },
            { label: "역할", value: ROLE_LABEL[user.role] },
            { label: "부서", value: user.department ? DEPARTMENT_LABEL[user.department] : "미지정" },
          ]} />
        </Card>
        {can(user, "admin.access") && (
          <Card title="관리">
            <div className="flex items-center justify-between gap-3">
              <p className="body-medium-medium text-muted">사용자·권한·감사로그·설정을 관리합니다.</p>
              <LinkButton href="/admin" variant="tertiary" size="small">관리자 포털</LinkButton>
            </div>
          </Card>
        )}
        <Card title="비밀번호 변경">
          <PasswordForm />
        </Card>
      </div>
    </>
  );
}
