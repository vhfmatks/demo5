// 상단 메뉴. `npm run gen` 이 마커 위에 항목을 추가한다.
export const NAV: { href: string; label: string }[] = [
  { href: "/", label: "대시보드" },
  // @gen:nav
];
