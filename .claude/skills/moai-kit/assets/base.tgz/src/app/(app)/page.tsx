// 대시보드 [Server] — 기능을 추가하면 요약(Stat·최근 목록)을 여기에 둔다. 예: moai-kit examples 의 src/app/(app)/page.tsx
import { Card, EmptyState, LinkButton, PageHeader } from "@/components/ui";
import { requireUser } from "@/server/auth/session";
import { NAV } from "./nav";

export default async function DashboardPage() {
  const user = await requireUser();
  const menus = NAV.filter((n) => n.href !== "/");
  return (
    <>
      <PageHeader title="대시보드" description={`${user.name}님, 안녕하세요.`} />
      <Card title="바로 가기">
        {menus.length ? (
          <div className="flex flex-wrap gap-2">
            {menus.map((n) => <LinkButton key={n.href} href={n.href} variant="tertiary">{n.label}</LinkButton>)}
          </div>
        ) : (
          <EmptyState title="아직 등록된 기능이 없습니다." />
        )}
      </Card>
    </>
  );
}
