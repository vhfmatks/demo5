"use client";
// 공개 화면도 같은 안전한 오류 UI를 사용한다.
export { default } from "../(app)/error";
