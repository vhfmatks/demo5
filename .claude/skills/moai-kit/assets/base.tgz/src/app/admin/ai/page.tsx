// AI 공급자·모델 [Server] — 공급자 연결 시험·등록 → 모델 시험·등록 → 기능에서 aiComplete/aiJson 으로 사용
import { Card, PageHeader } from "@/components/ui";
import { requirePermission } from "@/server/auth/session";
import { listAiModels, listAiProviders } from "@/features/ai/service";
import { ProviderForm } from "@/features/ai/components/ProviderForm";
import { ModelForm } from "@/features/ai/components/ModelForm";
import { AiProviderTable } from "@/features/ai/components/AiProviderTable";
import { AiModelTable } from "@/features/ai/components/AiModelTable";

export default async function AdminAiPage() {
  const user = await requirePermission("ai.manage");
  const [providers, models] = await Promise.all([listAiProviders(user), listAiModels(user)]);
  return (
    <>
      <PageHeader title="AI" description="공급자 연결을 시험해 등록하고, 모델을 시험해 등록합니다. 기능은 기본 모델(또는 호출 이름)로 AI 를 씁니다. 호출 내역은 감사로그(ai.call)에 남습니다." />
      <div className="flex flex-col gap-6">
        <Card title="1. 공급자">
          <AiProviderTable rows={providers} />
        </Card>
        <Card title="공급자 등록">
          <ProviderForm />
        </Card>
        <Card title="2. 모델">
          <AiModelTable rows={models} />
        </Card>
        <Card title="모델 등록">
          <ModelForm providers={providers} />
        </Card>
      </div>
    </>
  );
}
