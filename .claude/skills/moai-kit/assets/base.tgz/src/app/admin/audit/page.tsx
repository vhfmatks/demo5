// 감사로그 [Server]
import { Card, PageHeader, Pagination } from "@/components/ui";
import { requirePermission } from "@/server/auth/session";
import { listAuditLogs } from "@/features/auditLogs/service";
import { ListAuditQuery } from "@/features/auditLogs/schema";
import { AuditFilters } from "@/features/auditLogs/components/AuditFilters";
import { AuditTable } from "@/features/auditLogs/components/AuditTable";

export default async function AdminAuditPage({ searchParams }: PageProps<"/admin/audit">) {
  const user = await requirePermission("audit.read");
  const q = ListAuditQuery.parse(await searchParams);
  const { items, meta } = await listAuditLogs(user, q);
  return (
    <>
      <PageHeader title="감사로그" description={`총 ${meta.total}건`} />
      <AuditFilters q={q} />
      <Card>
        <AuditTable rows={items} />
        <Pagination meta={meta} basePath="/admin/audit" params={{ action: q.action, entity: q.entity, entityId: q.entityId, actor: q.actor, from: q.from, to: q.to }} />
      </Card>
    </>
  );
}
