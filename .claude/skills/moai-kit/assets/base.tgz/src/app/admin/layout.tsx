import { Gnb, LinkButton, Tag } from "@/components/ui";
import { requirePermission } from "@/server/auth/session";
import { LogoutButton } from "@/components/app/LogoutButton";
import { can } from "@/lib/permissions";
import { ADMIN_NAV } from "./nav";

// /admin = 관리자 포털. 사용자 화면((app))과 레이아웃·메뉴·색상을 분리한다. admin.access 권한이 없으면 404, 메뉴는 권한별로 표시.
// 색상: KDS 공식 dark 모드를 이 영역에만 적용(사용자 화면은 라이트 그대로). 토큰만 바뀌므로 hex·별도 색 정의 없음.
export default async function AdminLayout({ children }: LayoutProps<"/admin">) {
  const user = await requirePermission("admin.access");
  return (
    <div data-mode="dark" data-testid="admin-portal" className="min-h-screen bg-bg text-fg kit-app-frame">
      <Gnb
        items={ADMIN_NAV.filter((n) => can(user, n.permission))}
        actions={<>
          <Tag tone="critical">관리자 포털</Tag>
          <span data-testid="current-user" className="body-small-medium text-muted">{user.name}</span>
          <LinkButton href="/" variant="tertiary" size="small">사용자 화면</LinkButton>
          <LogoutButton />
        </>}
      />
      <main className="kds-container kit-page-main">{children}</main>
    </div>
  );
}
