// 관리자 개요 [Server] — 가진 권한에 해당하는 요약만 보여준다.
import { Card, LinkButton, PageHeader, Stat } from "@/components/ui";
import { requirePermission } from "@/server/auth/session";
import { can } from "@/lib/permissions";
import { ROLE_LABEL, ROLES } from "@/lib/roles";
import { userRoleStats } from "@/features/users/service";
import { listAuditLogs } from "@/features/auditLogs/service";
import { getSettings } from "@/features/settings/service";
import { AuditTable } from "@/features/auditLogs/components/AuditTable";

export default async function AdminHomePage() {
  const user = await requirePermission("admin.access");
  const [roles, recent, settings] = await Promise.all([
    can(user, "user.read") ? userRoleStats(user) : null,
    can(user, "audit.read") ? listAuditLogs(user, { page: 1, pageSize: 10 }) : null,
    can(user, "settings.read") ? getSettings() : null,
  ]);
  return (
    <>
      <PageHeader title="관리자 포털" description="권한이 있는 관리 기능만 표시됩니다." />
      {(roles || settings) && (
        <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-5" data-testid="stats">
          {roles && ROLES.map((r) => <Stat key={r} label={`${ROLE_LABEL[r]} 사용자`} value={roles[r]} />)}
          {settings && <Stat label="점검 모드" value={settings.maintenanceMode ? "켜짐" : "꺼짐"} tone={settings.maintenanceMode ? "danger" : undefined} />}
        </div>
      )}
      {recent && (
        <Card title="최근 감사로그" actions={<LinkButton href="/admin/audit" variant="text">전체 보기</LinkButton>}>
          <AuditTable rows={recent.items} />
        </Card>
      )}
    </>
  );
}
