// 역할·권한 매트릭스 [Server] — lib/permissions.ts 를 그대로 보여준다(읽기 전용, 코드가 단일 기준).
import { Card, PageHeader } from "@/components/ui";
import { requirePermission } from "@/server/auth/session";
import { PERMISSION_KEYS, PERMISSIONS, ROLE_DEFINITIONS, ROLE_PERMISSIONS } from "@/lib/permissions";
import { ROLE_LABEL, ROLES } from "@/lib/roles";

export default async function AdminRolesPage() {
  await requirePermission("admin.access");
  return (
    <>
      <PageHeader title="역할·권한" description="역할은 권한의 묶음입니다. 변경은 src/lib/permissions.ts 에서 하고 시험으로 검증합니다." />
      <div className="flex flex-col gap-6">
        <Card title="역할">
          <dl className="body-medium-medium flex flex-col gap-3">
            {ROLES.map((r) => (
              <div key={r} className="flex gap-4">
                <dt className="w-32 shrink-0 font-semibold">{ROLE_LABEL[r]}</dt>
                <dd className="text-muted">
                  {ROLE_DEFINITIONS[r].description}
                  {ROLE_DEFINITIONS[r].inherits && ` (${ROLE_LABEL[ROLE_DEFINITIONS[r].inherits]} 권한 포함)`}
                </dd>
              </div>
            ))}
          </dl>
        </Card>
        <Card title="권한 매트릭스">
          <div className="kds-table-wrap">
            <table className="kds-table" data-testid="permission-matrix">
              <thead>
                <tr>
                  <th scope="col">권한</th>
                  <th scope="col">설명</th>
                  {ROLES.map((r) => <th key={r} scope="col" className="text-center">{ROLE_LABEL[r]}</th>)}
                </tr>
              </thead>
              <tbody>
                {PERMISSION_KEYS.map((p) => (
                  <tr key={p}>
                    <th scope="row"><code>{p}</code></th>
                    <td>{PERMISSIONS[p]}</td>
                    {ROLES.map((r) => (
                      <td key={r} className="text-center" aria-label={`${ROLE_LABEL[r]} ${p} ${ROLE_PERMISSIONS[r].has(p) ? "허용" : "거부"}`}>
                        {ROLE_PERMISSIONS[r].has(p) ? "O" : "-"}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </>
  );
}
