// 운영 설정 [Server]
import { Card, PageHeader } from "@/components/ui";
import { requirePermission } from "@/server/auth/session";
import { can } from "@/lib/permissions";
import { fmtDateTime } from "@/lib/format";
import { getSettingsForAdmin } from "@/features/settings/service";
import { SettingsForm } from "@/features/settings/components/SettingsForm";

export default async function AdminSettingsPage() {
  const user = await requirePermission("settings.read");
  const s = await getSettingsForAdmin(user);
  return (
    <>
      <PageHeader title="설정" description={s.updatedAt ? `마지막 변경 ${fmtDateTime(s.updatedAt)} · 변경 내역은 감사로그에 남습니다.` : "기본값으로 동작 중입니다."} />
      <Card>
        <SettingsForm values={s.values} readOnly={!can(user, "settings.update")} />
      </Card>
    </>
  );
}
