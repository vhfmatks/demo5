// 사용자 관리 [Server]
import { Card, FilterBar, SearchField, PageHeader, Pagination, Select, toOptions } from "@/components/ui";
import { requirePermission } from "@/server/auth/session";
import { ROLE_LABEL } from "@/lib/roles";
import { listUsers } from "@/features/users/service";
import { ListUserQuery } from "@/features/users/schema";
import { UserTable } from "@/features/users/components/UserTable";

export default async function AdminUsersPage({ searchParams }: PageProps<"/admin/users">) {
  const user = await requirePermission("user.read");
  const q = ListUserQuery.parse(await searchParams);
  const { items, meta } = await listUsers(user, q);
  return (
    <>
      <PageHeader title="사용자" description={`총 ${meta.total}명 · 역할 변경은 즉시 적용됩니다.`} />
      <FilterBar>
        <Select name="role" aria-label="역할" defaultValue={q.role ?? ""} options={toOptions(ROLE_LABEL)} placeholder="전체 역할" className="w-36" />
        <SearchField name="q" label="이름·이메일 검색" defaultValue={q.q ?? ""} placeholder="이름·이메일 검색" className="w-56" />
      </FilterBar>
      <Card>
        <UserTable rows={items} actor={user} />
        <Pagination meta={meta} basePath="/admin/users" params={{ role: q.role, q: q.q }} />
      </Card>
    </>
  );
}
