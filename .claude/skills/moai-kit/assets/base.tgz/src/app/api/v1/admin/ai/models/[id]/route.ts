// 관리자 전용: 기본 모델 지정 PATCH { isDefault: true } / 삭제 DELETE
import { api, body, IdParams, noContent, ok } from "@/server/http/handler";
import { UpdateModelInput } from "@/features/ai/schema";
import { deleteAiModel, updateAiModel } from "@/features/ai/service";

export const PATCH = api<{ id: string }>(async ({ req, params, user }) =>
  ok(await updateAiModel(user, params.id, await body(req, UpdateModelInput))), { params: IdParams, permission: "ai.manage" });
export const DELETE = api<{ id: string }>(async ({ params, user }) => {
  await deleteAiModel(user, params.id);
  return noContent();
}, { params: IdParams, permission: "ai.manage" });

export const runtime = "nodejs";
