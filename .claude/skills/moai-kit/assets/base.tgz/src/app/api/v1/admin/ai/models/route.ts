// 관리자 전용: AI 모델 목록 GET / 등록 POST (서버가 모델 시험 후 저장)
import { api, body, created, ok } from "@/server/http/handler";
import { CreateModelInput } from "@/features/ai/schema";
import { createAiModel, listAiModels } from "@/features/ai/service";

export const GET = api(async ({ user }) => ok(await listAiModels(user)), { permission: "ai.manage" });
export const POST = api(async ({ req, user }) => created(await createAiModel(user, await body(req, CreateModelInput))), { permission: "ai.manage" });

export const runtime = "nodejs";
