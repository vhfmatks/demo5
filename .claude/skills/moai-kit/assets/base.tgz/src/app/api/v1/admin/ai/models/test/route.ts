// 관리자 전용: 모델 시험 POST (저장 안 함) → { ok, ms, reply }
import { api, body, ok } from "@/server/http/handler";
import { TestModelInput } from "@/features/ai/schema";
import { testAiModel } from "@/features/ai/service";

export const POST = api(async ({ req, user }) => ok(await testAiModel(user, await body(req, TestModelInput))), { permission: "ai.manage" });

export const runtime = "nodejs";
