// 관리자 전용: 공급자가 제공하는 모델 ID 목록 GET (모델 등록 화면 제안)
import { api, IdParams, ok } from "@/server/http/handler";
import { listAiProviderModels } from "@/features/ai/service";

export const GET = api<{ id: string }>(async ({ params, user }) => ok(await listAiProviderModels(user, params.id)), { params: IdParams, permission: "ai.manage" });

export const runtime = "nodejs";
