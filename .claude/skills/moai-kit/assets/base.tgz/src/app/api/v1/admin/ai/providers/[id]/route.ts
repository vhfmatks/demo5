// 관리자 전용: 공급자 삭제 DELETE (모델도 함께)
import { api, IdParams, noContent } from "@/server/http/handler";
import { deleteAiProvider } from "@/features/ai/service";

export const DELETE = api<{ id: string }>(async ({ params, user }) => {
  await deleteAiProvider(user, params.id);
  return noContent();
}, { params: IdParams, permission: "ai.manage" });

export const runtime = "nodejs";
