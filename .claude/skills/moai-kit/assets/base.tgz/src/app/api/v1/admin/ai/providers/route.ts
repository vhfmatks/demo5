// 관리자 전용: AI 공급자 목록 GET / 등록 POST (서버가 연결 시험 후 저장)
import { api, body, created, ok } from "@/server/http/handler";
import { CreateProviderInput } from "@/features/ai/schema";
import { createAiProvider, listAiProviders } from "@/features/ai/service";

export const GET = api(async ({ user }) => ok(await listAiProviders(user)), { permission: "ai.manage" });
export const POST = api(async ({ req, user }) => created(await createAiProvider(user, await body(req, CreateProviderInput))), { permission: "ai.manage" });

export const runtime = "nodejs";
