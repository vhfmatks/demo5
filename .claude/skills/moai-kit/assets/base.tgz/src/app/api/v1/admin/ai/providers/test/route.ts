// 관리자 전용: 공급자 연결 시험 POST (저장 안 함) → { ok, ms, models }
import { api, body, ok } from "@/server/http/handler";
import { TestProviderInput } from "@/features/ai/schema";
import { testAiProvider } from "@/features/ai/service";

export const POST = api(async ({ req, user }) => ok(await testAiProvider(user, await body(req, TestProviderInput))), { permission: "ai.manage" });

export const runtime = "nodejs";
