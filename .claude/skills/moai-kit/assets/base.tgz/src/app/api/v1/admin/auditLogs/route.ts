// 관리자 전용: 감사로그 조회 GET /api/v1/admin/auditLogs?action=&entity=&actor=&from=&to=
import { api, ok, query } from "@/server/http/handler";
import { ListAuditQuery } from "@/features/auditLogs/schema";
import { listAuditLogs } from "@/features/auditLogs/service";

export const GET = api(async ({ req, user }) => {
  const { items, meta } = await listAuditLogs(user, query(req, ListAuditQuery));
  return ok(items, meta);
}, { permission: "audit.read" });

export const runtime = "nodejs";
