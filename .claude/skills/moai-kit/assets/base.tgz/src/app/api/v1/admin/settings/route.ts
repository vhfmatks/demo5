// 관리자 전용: 운영 설정 GET(조회) / PATCH(일부 변경)
import { api, body, ok } from "@/server/http/handler";
import { UpdateSettingsInput } from "@/features/settings/schema";
import { getSettingsForAdmin, updateSettings } from "@/features/settings/service";

export const GET = api(async ({ user }) => ok(await getSettingsForAdmin(user)), { permission: "settings.read" });

export const PATCH = api(async ({ req, user }) =>
  ok(await updateSettings(user, await body(req, UpdateSettingsInput))),
  { permission: "settings.update" },
);

export const runtime = "nodejs";
