// 부서 지정 PATCH /api/v1/admin/users/{id}/department { department: "DEV" | null }
import { api, body, IdParams, ok } from "@/server/http/handler";
import { UpdateUserDepartmentInput } from "@/features/users/schema";
import { updateUserDepartment } from "@/features/users/service";

export const PATCH = api<{ id: string }>(async ({ req, params, user }) =>
  ok(await updateUserDepartment(user, params.id, await body(req, UpdateUserDepartmentInput))),
  { params: IdParams, permission: "user.department.update" },
);

export const runtime = "nodejs";
