// 관리자 전용: 역할 변경 PATCH /api/v1/admin/users/{id} { role }
import { api, body, IdParams, ok } from "@/server/http/handler";
import { UpdateUserRoleInput } from "@/features/users/schema";
import { updateUserRole } from "@/features/users/service";

export const PATCH = api<{ id: string }>(async ({ req, params, user }) =>
  ok(await updateUserRole(user, params.id, await body(req, UpdateUserRoleInput))),
  { params: IdParams, permission: "user.role.update" },
);

export const runtime = "nodejs";
