// 관리자 전용: 사용자 목록 GET /api/v1/admin/users?role=&q=
import { api, ok, query } from "@/server/http/handler";
import { ListUserQuery } from "@/features/users/schema";
import { listUsers } from "@/features/users/service";

export const GET = api(async ({ req, user }) => {
  const { items, meta } = await listUsers(user, query(req, ListUserQuery));
  return ok(items, meta);
}, { permission: "user.read" });

export const runtime = "nodejs";
