import { api, body, ok } from "@/server/http/handler";
import { LoginInput } from "@/features/auth/schema";
import { login } from "@/features/auth/service";

export const POST = api(async ({ req }) => ok(await login(await body(req, LoginInput))), { auth: "public" });

export const runtime = "nodejs";
