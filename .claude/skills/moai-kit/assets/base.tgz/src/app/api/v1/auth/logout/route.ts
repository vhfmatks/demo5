import { api, noContent } from "@/server/http/handler";
import { destroySession } from "@/server/auth/session";

export const POST = api(
  async () => {
    await destroySession();
    return noContent();
  },
  { auth: "public" },
);

export const runtime = "nodejs";
