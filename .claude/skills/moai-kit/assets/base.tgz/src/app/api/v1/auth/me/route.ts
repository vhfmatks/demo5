import { api, ok } from "@/server/http/handler";

export const GET = api(async ({ user }) => ok(user));

export const runtime = "nodejs";
