// 비밀번호 변경 POST /api/v1/auth/password { currentPassword, newPassword, confirmPassword }
import { api, body, noContent } from "@/server/http/handler";
import { ChangePasswordInput } from "@/features/auth/schema";
import { changePassword } from "@/features/auth/service";

export const POST = api(async ({ req, user }) => {
  await changePassword(user, await body(req, ChangePasswordInput));
  return noContent();
});

export const runtime = "nodejs";
