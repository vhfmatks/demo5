import { api, download } from "@/server/http/handler";
import { getLocalFontStyle } from "@/features/kdsFonts/service";

export const runtime = "nodejs";
export const GET = api(async ({ user }) => download("kt-flow.css", await getLocalFontStyle(user), "text/css; charset=utf-8"), { auth: "public" });
