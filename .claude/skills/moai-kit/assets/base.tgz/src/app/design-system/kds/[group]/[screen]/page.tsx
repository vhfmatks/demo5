import { notFound } from "next/navigation";
import { KDS_SCREENS } from "@/components/design-system/KdsScreens";

/** Organizer reference screens rendered by local React UI components, without an iframe. */
export default async function KdsScreenPage({ params }: PageProps<"/design-system/kds/[group]/[screen]">) {
  const { group, screen } = await params;
  const key = `${group}/${screen}`;
  if (!(key in KDS_SCREENS)) notFound();
  const entry = KDS_SCREENS[key as keyof typeof KDS_SCREENS];
  const Screen = entry.component;
  return <div data-kds-screen={key} data-mode={entry.mode} data-platform={entry.platform} className="kit-kds-reference">
    {group === "examples" && <link rel="stylesheet" href="/kds/examples/examples.css" />}
    <link rel="stylesheet" href={entry.stylesheet} />
    <Screen />
  </div>;
}
