import { ComponentExamples } from "@/components/design-system/ComponentExamples";
import { DateContractExample } from "@/components/design-system/DateContractExample";
import { AiMark, BarChart, BottomNavigation, Breadcrumb, Card, CtaBar, Divider, DonutChart, FeedCard, FeedSection, FloatingActionButton,
  Footer, Gnb, HorizontalScroll, InfoBand, ItemTile, KeyValue, LineChart, LinkButton, LinkList, Loading, Notice, PageHeader, PageIndicator, Progress,
  Section, Sidebar, Skeleton, TopNavigation } from "@/components/ui";

const data = [{ label: "월", value: 24 }, { label: "화", value: 36 }, { label: "수", value: 18 }, { label: "목", value: 42 }];
const bars = data.map((d) => ({ label: d.label, values: [d.value] }));
const unit = (n: number) => `${n.toLocaleString("ko-KR")}건`;
export default function DesignSystemPage() {
  return <>
    <Gnb items={[{ href: "/design-system", label: "디자인 시스템" }, { href: "/login", label: "로그인" }]} />
    <main className="kds-container py-6 lg:py-8">
      <Breadcrumb items={[{ href: "/", label: "홈" }, { label: "디자인 시스템" }]} />
      <PageHeader title="디자인 시스템" description="공통 UI를 조합하고 키보드·모바일 동작을 확인하는 예제입니다." />
      <Section title="KDS 20261012 원본 화면">
        <div className="flex flex-wrap gap-2">
          {["templates/mobile-task", "templates/mobile-feed", "templates/pc-page", "templates/pc-admin", "examples/mobile", "examples/mobile-pay-method", "examples/mobile-benefit", "examples/pc"].map((screen) =>
            <LinkButton key={screen} href={`/design-system/kds/${screen}`} variant="tertiary">{screen}</LinkButton>)}
        </div>
      </Section>
      <ComponentExamples />
      <DateContractExample />
      <div className="mt-6 grid grid-cols-1 gap-6">
        <Card title="차트"><div className="grid gap-6 lg:grid-cols-2"><BarChart label="요일별 이용" rows={bars} format={unit} />
          <DonutChart label="이용 비율" rows={data} format={unit} /></div><LineChart label="이용 추이" x={data.map((d) => d.label)} series={[{ name: "이용", values: data.map((d) => d.value) }]} format={unit} /></Card>
        <Section title="로딩·진행·안내"><Loading /><Skeleton lines={3} /><Progress label="자료 처리" value={65} />
          <PageIndicator current={2} total={4} /><Notice title="이용 안내">예제 데이터는 모두 합성 데이터입니다.</Notice><Divider />
          <KeyValue label="처리 건수">65건</KeyValue><LinkList label="도움말" items={[{ href: "/login", label: "로그인" }]} divided /></Section>
        <section aria-label="피드 예제" data-mode="agent" className="bg-bg text-fg">
          <FeedSection title="추천 정보" actions={<AiMark />}><HorizontalScroll label="추천 카드">
            <FeedCard className="w-56"><h3 className="title-small-bold">예약 안내</h3><p>날짜·시간을 선택하세요.</p></FeedCard>
            <FeedCard className="w-56"><h3 className="title-small-bold">일정 관리</h3><p>이용 내역을 확인하세요.</p></FeedCard>
          </HorizontalScroll></FeedSection>
        </section>
        <Section title="모바일 업무·탐색"><TopNavigation title="예약 안내" backHref="/design-system" /><InfoBand>현재 선택한 이용권: 하루</InfoBand>
          <Section title="예약 정보"><KeyValue label="이용 인원">4명</KeyValue></Section><Divider band />
          <ItemTile title="이용 내역" description="목록 화면으로 이동합니다." href="/login" />
          <Sidebar label="예제 탐색" currentHref="/design-system" items={[{ href: "/design-system", label: "컴포넌트", icon: "line-home" }, { href: "/login", label: "로그인", icon: "line-document" }]} />
          <CtaBar><LinkButton href="/login" full>예제 이용</LinkButton></CtaBar>
          <BottomNavigation currentHref="/design-system" items={[{ href: "/design-system", label: "컴포넌트", icon: "line-home" }, { href: "/login", label: "로그인", icon: "line-document" }]} />
          <FloatingActionButton name="line-add" label="예제 추가 버튼" disabled />
        </Section>
        <section data-mode="dark" aria-label="다크 모드 예제" className="bg-bg text-fg"><Card title="다크 모드"><BarChart label="요일별 이용 (다크)" rows={bars} format={unit} />
          </Card><Notice title="모드 안내">같은 컴포넌트가 영역의 토큰을 따릅니다.</Notice></section>
      </div>
    </main><Footer>Moai Kit · KDS 2.0 컴포넌트 예제</Footer>
  </>;
}
