import type { Metadata } from "next";
import "./globals.css";
import { allowsLocalKdsFonts } from "@/features/kdsFonts/policy";

// 표준: 전 페이지 요청 시 렌더링 (캐시 없음 → 저장 후 즉시 반영)
export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Moai Kit", description: "Next.js 풀스택 스타터" };

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="ko">
      <body>
        {allowsLocalKdsFonts() && <link rel="stylesheet" href="/api/v1/local-font-style" />}
        {children}
      </body>
    </html>
  );
}
