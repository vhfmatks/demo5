import { redirect } from "next/navigation";
import { getCurrentUser } from "@/server/auth/session";
import { Card } from "@/components/ui";
import { LoginForm } from "@/features/auth/components/LoginForm";

// 시드(scripts/db-seed.mts)의 합성 계정. 개발 서버에서만 보이고, 운영(next start)은 DEMO_LOGIN=1 일 때만 보인다(시연 배포용).
const showDemo = () => process.env.NODE_ENV !== "production" || process.env.DEMO_LOGIN === "1";
const DEMO = [
  { email: "user1@demo.local", label: "일반 김민수" },
  { email: "user2@demo.local", label: "일반 이서연" },
  { email: "manager@demo.local", label: "개발팀 부서장" },
  { email: "approver@demo.local", label: "승인자" },
  { email: "auditor@demo.local", label: "감사 담당" },
  { email: "admin@demo.local", label: "관리자" },
];

export default async function LoginPage() {
  if (await getCurrentUser()) redirect("/");
  return (
    <div className="mx-auto mt-24 max-w-sm px-4">
      <Card title="로그인">
        <LoginForm demo={showDemo() ? DEMO : []} />
      </Card>
      {showDemo() && <p className="mt-3 text-center text-xs text-muted">데모 계정 비밀번호: Credit!23 (합성 데이터)</p>}
    </div>
  );
}
