import { EmptyState, LinkButton } from "@/components/ui";

export default function NotFound() {
  return <EmptyState title="페이지를 찾을 수 없습니다." action={<LinkButton href="/" variant="tertiary">홈으로</LinkButton>} />;
}
