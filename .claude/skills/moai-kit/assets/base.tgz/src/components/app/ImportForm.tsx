"use client";
// [Client] 표 가져오기(.csv/.xlsx) 폼. 서버는 handler.ts upload() → server/import.ts readTable·parseRows.
//   <ImportForm url="/api/v1/items/import" headers={["제목", "분류"]} />   응답 data = { created: number }
// 행 오류는 fieldErrors("3행 분류")로 오므로 목록으로 보여 준다. 저장은 전부 아니면 전무.
import { useState } from "react";
import { Alert, Button, Field, Input, LinkButton } from "@/components/ui";
import { apiClient } from "@/lib/api-client";
import { csvCell } from "@/lib/csv";
import { useMutation } from "@/lib/use-mutation";

export function ImportForm({ url, headers, filename = "양식.csv" }: { url: string; headers: string[]; filename?: string }) {
  const [created, setCreated] = useState<number | null>(null);
  const m = useMutation((form: FormData) => apiClient.upload<{ created: number }>(url, form), { onSuccess: (r) => setCreated(r.created) });
  const rowErrors = Object.entries(m.fieldErrors).filter(([key]) => key !== "file");
  const template = `data:text/csv;charset=utf-8,${encodeURIComponent(`\uFEFF${headers.map(csvCell).join(",")}\r\n`)}`;
  return (
    <form
      className="flex max-w-xl flex-col gap-4"
      onSubmit={(e) => {
        e.preventDefault();
        setCreated(null);
        m.run(new FormData(e.currentTarget));
      }}
    >
      <Field label="파일" name="file" required error={m.fieldErrors.file} hint={`첫 행 열 이름: ${headers.join(", ")} · .csv/.xlsx · 5MB, 1,000행까지`}>
        <Input name="file" type="file" accept=".csv,.xlsx" required invalid={!!m.fieldErrors.file} />
      </Field>
      <Alert>{m.error}</Alert>
      {rowErrors.length > 0 && (
        <ul aria-label="행 오류" className="body-small-medium flex flex-col gap-1 text-danger">
          {rowErrors.map(([key, messages]) => <li key={key}>{key}: {messages.join(" ")}</li>)}
        </ul>
      )}
      <Alert tone="info">{created !== null && `${created}건을 가져왔습니다.`}</Alert>
      <div className="flex gap-2">
        <Button type="submit" loading={m.pending}>가져오기</Button>
        <LinkButton href={template} download={filename} prefetch={false} variant="tertiary">양식 받기</LinkButton>
      </div>
    </form>
  );
}
