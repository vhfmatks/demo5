"use client";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui";
import { apiClient } from "@/lib/api-client";
import { useMutation } from "@/lib/use-mutation";

export function LogoutButton() {
  const router = useRouter();
  const m = useMutation(() => apiClient.post("/api/v1/auth/logout"), { onSuccess: () => router.push("/login"), refresh: false });
  return <Button variant="text" loading={m.pending} onClick={() => m.run(undefined)}>로그아웃</Button>;
}
