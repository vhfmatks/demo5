"use client";

import { useCallback, useState } from "react";
import { Accordion, Alert, BottomSheet, Button, Section, Chip, ChipGroup, CodeBlock, ContextPanel, DateRangePicker, DocumentViewer, Modal,
  Popover, ProcessIndicator, PromptConversation, PromptInput, PromptOutput, PromptSuggestions, PromptTextField, RangeSlider,
  SelectButton, SelectButtonGroup, Slider, Snackbar, Tabs, TimeSlotPicker, Toast, Tooltip, type PromptAttachment } from "@/components/ui";

export function ComponentExamples() {
  const [sheet, setSheet] = useState(false); const [modal, setModal] = useState(false);
  const [toast, setToast] = useState(false); const [snackbar, setSnackbar] = useState(false);
  const closeToast = useCallback(() => setToast(false), []); const closeSnackbar = useCallback(() => setSnackbar(false), []);
  const [chip, setChip] = useState(false); const [formResult, setFormResult] = useState("");
  const [prompt, setPrompt] = useState(""); const [answer, setAnswer] = useState(""); const [processing, setProcessing] = useState(false);
  const [attachments, setAttachments] = useState<PromptAttachment[]>([]); const [panel, setPanel] = useState(true);
  return <div className="grid grid-cols-1 gap-6">
    <Section title="탭·아코디언·보충 정보">
      <Tabs label="예제 화면" items={[
        { value: "overview", label: "개요", content: <p>같은 맥락의 콘텐츠를 전환합니다.</p> },
        { value: "disabled", label: "준비 중", disabled: true, content: <p>선택할 수 없는 탭입니다.</p> },
        { value: "details", label: "상세", content: <p>방향키와 Home·End로 이동할 수 있습니다.</p> },
      ]} />
      <Accordion label="자주 묻는 질문" items={[{ id: "usage", title: "어디에서 가져오나요?", content: <p>@/components/ui에서 가져옵니다.</p> },
        { id: "theme", title: "다크 모드도 되나요?", content: <p>영역에 data-mode를 지정합니다.</p> }]} />
      <div className="flex flex-wrap items-center justify-end gap-4"><Popover label="표시 옵션"><label className="kds-checkbox"><input type="checkbox" />완료 항목 포함</label></Popover>
        <Tooltip label="컴포넌트 도움말" content="상세 설정에는 Popover를 사용합니다." /></div>
    </Section>
    <Section title="팝업·시트·알림">
      <div className="flex flex-wrap gap-2"><Button variant="tertiary" onClick={() => setModal(true)}>팝업 열기</Button>
        <Button variant="tertiary" onClick={() => setSheet(true)}>시트 열기</Button>
        <Button variant="tertiary" onClick={() => setToast(true)}>토스트 표시</Button>
        <Button variant="tertiary" onClick={() => setSnackbar(true)}>스낵바 표시</Button></div>
      <Modal open={modal} title="상세 안내" description="본문과 하단 동작을 조합하는 팝업입니다." onClose={() => setModal(false)}
        footer={<Button onClick={() => setModal(false)}>확인</Button>}><p>Escape로 닫으면 원래 버튼으로 포커스가 돌아갑니다.</p></Modal>
      <BottomSheet open={sheet} title="정렬 방식" onClose={() => setSheet(false)} footer={<Button onClick={() => setSheet(false)}>적용</Button>}>
        <SelectButtonGroup label="정렬"><SelectButton label="최신순" type="radio" name="sort" value="recent" defaultChecked />
          <SelectButton label="이름순" type="radio" name="sort" value="name" /></SelectButtonGroup>
      </BottomSheet>
      <Toast open={toast} onClose={closeToast}>설정을 저장했습니다.</Toast>
      <Snackbar open={snackbar} onClose={closeSnackbar} action={<button type="button" className="kit-toast-action" onClick={closeSnackbar}>되돌리기</button>}>항목을 보관했습니다.</Snackbar>
    </Section>
    <Section title="날짜·시간·범위·선택">
      <form className="grid gap-6" onSubmit={(event) => {
        event.preventDefault(); const values = new FormData(event.currentTarget);
        setFormResult(`시작 ${String(values.get("start") ?? "")} · 종료 ${String(values.get("end") ?? "")} · 시간 ${String(values.get("time") ?? "")} · 이용권 ${String(values.get("plan") ?? "")}`);
      }}>
        <DateRangePicker start={{ name: "start", label: "시작일", defaultValue: "2026-10-09" }} end={{ name: "end", label: "종료일", defaultValue: "2026-10-10" }} />
        <TimeSlotPicker name="time" label="예약 시간" options={[{ value: "09:00", label: "오전 9시" }, { value: "10:00", label: "오전 10시", disabled: true }, { value: "11:00", label: "오전 11시" }]} />
        <SelectButtonGroup label="이용권"><SelectButton name="plan" value="day" label="하루" description="하루 이용권" defaultChecked />
          <SelectButton name="plan" value="week" label="일주일" description="7일 이용권" /></SelectButtonGroup>
        <ChipGroup label="추가 필터"><Chip selected={chip} onClick={() => setChip((current) => !current)}>사용 가능</Chip></ChipGroup>
        <Slider label="인원" name="people" defaultValue={4} min={1} max={12} unit="명" />
        <RangeSlider label="금액 범위" names={["minPrice", "maxPrice"]} defaultValue={[20, 80]} unit="천원" />
        <Button type="submit">선택 확인</Button><output aria-live="polite" data-testid="selection-result">{formResult}</output>
      </form>
    </Section>
    <Section title="AI 대화·출처·문서">
      <PromptConversation><PromptInput>회의실 예약 방법을 알려 주세요.</PromptInput><PromptOutput sources={[{ label: "컴포넌트 사용 예제", href: "/design-system" }]}>
        <p>날짜와 시간을 선택한 뒤 예약을 확정합니다.</p>{answer && <p>{answer}</p>}
      </PromptOutput><ProcessIndicator state={processing ? "generating" : "complete"} text={processing ? "예제 응답을 생성하고 있습니다." : "예제 응답이 준비되었습니다."}
        details={<p>요청 내용과 제공된 자료를 확인합니다.</p>} /></PromptConversation>
      <PromptSuggestions items={["예약 취소 방법은?", "다음 주 일정 보기"]} onSelect={setPrompt} />
      <PromptTextField value={prompt} onValueChange={setPrompt} processing={processing} attachments={attachments}
        onFilesChange={(files) => setAttachments((current) => [...current, ...files.map((file) => ({ id: crypto.randomUUID(), name: file.name }))])}
        onRemoveAttachment={(id) => setAttachments((current) => current.filter((attachment) => attachment.id !== id))}
        onSend={(text) => { setAnswer(`입력한 예제 질문: ${text}`); setProcessing(true); }} onStop={() => setProcessing(false)}
        disclaimer="입력 동작을 보여 주는 예제입니다. 실제 AI 호출은 연결하지 않았습니다." />
      {processing && <Button variant="tertiary" onClick={() => setProcessing(false)}>예제 응답 완료</Button>}
      {!panel && <Button variant="tertiary" onClick={() => setPanel(true)}>출처 패널 열기</Button>}
      <ContextPanel title="참고 자료" open={panel} onClose={() => setPanel(false)}><p>출처·문서·편집 화면을 슬롯으로 넣을 수 있습니다.</p>
        <DocumentViewer title="예제 문서" pages={[{ src: "/design-system/sample-page-1.svg", alt: "예제 문서 1쪽: 예약 안내", width: 400, height: 500 },
          { src: "/design-system/sample-page-2.svg", alt: "예제 문서 2쪽: 취소 안내", width: 400, height: 500 }]} /></ContextPanel>
      <CodeBlock language="tsx" code={'import { BottomSheet, DatePicker } from "@/components/ui";'} />
      <Alert tone="info">음성 인식·AI 호출·파일 업로드·PDF 렌더링은 업무 기능에서 연결합니다.</Alert>
    </Section>
  </div>;
}
