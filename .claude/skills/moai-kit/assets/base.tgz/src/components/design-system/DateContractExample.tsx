"use client";

import { useState } from "react";
import { Button, DatePicker, Section } from "@/components/ui";

/** Executable public input contracts, including controlled parent updates and ISO FormData. */
export function DateContractExample() {
  const [value, setValue] = useState("2024-02-28");
  const [change, setChange] = useState({ count: 0, name: "", value: "" });
  const [submitted, setSubmitted] = useState("");
  return <Section title="달력 입력 계약">
    <form noValidate className="flex flex-col gap-4" onSubmit={(event) => {
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      setSubmitted(`${String(data.get("controlled") ?? "")} · ${data.getAll("controlled").length}`);
    }}>
      <DatePicker name="controlled" label="제어 날짜" value={value} min="2024-02-01" max="2024-02-29"
        onChange={(event) => { const next = event.currentTarget.value; const name = event.currentTarget.name; setValue(next); setChange((previous) => ({ count: previous.count + 1, name, value: next })); }} />
      <DatePicker name="disabled-date" label="비활성 날짜" defaultValue="2024-02-28" disabled />
      <DatePicker name="readonly-date" label="읽기 전용 날짜" defaultValue="2024-02-28" readOnly />
      <DatePicker name="invalid-date" label="오류 날짜" hint="날짜 입력 안내" error={["허용된 날짜를 선택하세요."]} />
      <div className="flex flex-wrap gap-2">
        <Button variant="tertiary" onClick={() => setValue("")}>날짜 지우기</Button>
        <Button variant="tertiary" onClick={() => setValue("2024-02-02")}>부모 날짜 변경</Button>
        <Button type="submit">날짜 값 확인</Button>
      </div>
    </form>
    <output data-testid="date-change">{change.count} · {change.name} · {change.value}</output>
    <output data-testid="date-form">{submitted}</output>
  </Section>;
}
