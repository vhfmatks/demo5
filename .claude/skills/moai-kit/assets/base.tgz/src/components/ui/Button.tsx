import Link from "next/link";
import type { ComponentProps } from "react";
import { cn } from "./cn";
import { Icon } from "./Icon";

/**
 * KDS 버튼. primary=검정(화면의 확정 동작) · secondary=회색(primary 와 짝으로만) · tertiary=테두리(단독 보조 동작)
 * accent=KT 레드(요청받았을 때 화면당 1개) · text=글자 버튼. 빨간(위험) 버튼은 KDS 에 없다 → 삭제는 tertiary + ConfirmDialog.
 */
type Style = {
  variant?: "primary" | "secondary" | "tertiary" | "accent" | "text";
  size?: "xsmall" | "small" | "medium" | "large";
  full?: boolean;
};
const cls = ({ variant = "primary", size, full }: Style, extra?: string) =>
  variant === "text"
    ? cn("kds-text-button", extra)
    : cn("kds-button", `kds-button--${variant}`, size && `kds-button--${size}`, full && "kds-button--full", extra);

export function Button({
  variant,
  size,
  full,
  loading,
  className,
  children,
  type = "button",
  ...rest
}: ComponentProps<"button"> & Style & { loading?: boolean }) {
  return (
    <button type={type} className={cls({ variant, size, full }, className)} {...rest} aria-busy={loading || undefined} disabled={loading || rest.disabled}>
      {loading ? "처리 중…" : children}
    </button>
  );
}

/** 아이콘 단독 동작에는 접근 가능한 이름을 필수로 지정한다. */
export function IconButton({ name, label, className, type = "button", ...rest }: Omit<ComponentProps<"button">, "children" | "aria-label"> & { name: ComponentProps<typeof Icon>["name"]; label: string }) {
  return <button type={type} className={cn("kds-icon-button", className)} aria-label={label} {...rest}><Icon name={name} /></button>;
}

export function LinkButton({ variant, size, full, className, ...rest }: ComponentProps<typeof Link> & Style) {
  return <Link className={cls({ variant, size, full }, className)} {...rest} />;
}
