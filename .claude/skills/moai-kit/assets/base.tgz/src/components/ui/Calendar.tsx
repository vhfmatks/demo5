// 월·주 달력 (Server, JS 불필요). 이동·보기 전환은 URL(?view=&date=)로만. 날짜 계산·이벤트 타입은 lib/calendar.ts.
//   const q = CalendarQuery.parse(await searchParams); const date = q.date ?? kstToday();
//   <Calendar view={q.view} date={date} today={kstToday()} events={await svc.calendar(user, visibleDays(q.view, date))} basePath="/x/calendar" />
// 이벤트는 날짜·시각 순. 월 보기는 하루 3건까지 보이고 나머지는 "+N건"(dayHref 또는 그 주 보기로 이동).
import Link from "next/link";
import {
  addDays, addMonths, monthGrid, WEEKDAY_LABEL, weekDays, type CalendarEvent, type CalendarView,
} from "@/lib/calendar";
import { LinkButton } from "./Button";
import { cn } from "./cn";

const MAX_PER_DAY = 3;
const label = (e: CalendarEvent) => (e.time ? `${e.time} ${e.title}` : e.title);
const md = (date: string) => `${Number(date.slice(5, 7))}. ${Number(date.slice(8))}.`;

/** wrap = 주 보기(칸이 세로로 길어 제목을 줄바꿈), 월 보기는 한 줄 + 툴팁 */
function EventChip({ e, wrap = false }: { e: CalendarEvent; wrap?: boolean }) {
  const cls = cn(
    "caption-medium-medium block rounded-sm px-1.5 py-0.5 no-underline",
    !wrap && "truncate",
    e.tone === "primary" ? "bg-primary text-on-primary" : "bg-subtle text-fg",
  );
  return e.href
    ? <Link href={e.href} title={label(e)} data-testid="calendar-event" className={cls}>{label(e)}</Link>
    : <span title={label(e)} data-testid="calendar-event" className={cls}>{label(e)}</span>;
}

export function Calendar({
  view,
  date,
  today,
  events,
  basePath,
  params = {},
  dayHref,
}: {
  view: CalendarView;
  /** 보여 줄 달·주에 속한 아무 날짜 (YYYY-MM-DD) */
  date: string;
  /** 오늘 (KST, kstToday()). 강조·"오늘" 이동에 쓴다 */
  today: string;
  events: CalendarEvent[];
  basePath: string;
  /** 이동해도 유지할 다른 query (필터 등) */
  params?: Record<string, string | undefined>;
  /** 날짜 숫자를 누르면 갈 곳 (예: 그날 상세·새로 만들기). 없으면 숫자는 글자만 */
  dayHref?: (date: string) => string;
}) {
  const href = (v: CalendarView, d: string) => {
    const sp = new URLSearchParams(Object.entries(params).filter((e): e is [string, string] => !!e[1]));
    sp.set("view", v);
    sp.set("date", d);
    return `${basePath}?${sp}`;
  };
  const byDay = new Map<string, CalendarEvent[]>();
  for (const e of [...events].sort((a, b) => `${a.date}${a.time ?? ""}`.localeCompare(`${b.date}${b.time ?? ""}`))) {
    byDay.set(e.date, [...(byDay.get(e.date) ?? []), e]);
  }
  const month = date.slice(0, 7);
  const week = weekDays(date);
  const title = view === "month"
    ? `${month.slice(0, 4)}년 ${Number(month.slice(5))}월`
    : `${week[0].slice(0, 4)}. ${md(week[0])} – ${md(week[6])}`;
  const prev = view === "month" ? `${addMonths(month, -1)}-01` : addDays(date, -7);
  const next = view === "month" ? `${addMonths(month, 1)}-01` : addDays(date, 7);
  const dayNumber = (d: string) => {
    const text = view === "month" ? Number(d.slice(8)) : `${WEEKDAY_LABEL[week.indexOf(d)]} ${md(d)}`;
    const cls = cn("body-small-bold inline-flex self-start rounded-sm px-1", d === today ? "bg-primary text-on-primary" : "text-inherit");
    return dayHref
      ? <Link href={dayHref(d)} aria-label={`${d}${d === today ? " 오늘" : ""}`} className={cn(cls, "no-underline")}>{text}</Link>
      : <span className={cls}>{text}</span>;
  };

  return (
    <div data-testid="calendar" data-view={view}>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <h2 className="title-large-bold mr-2" data-testid="calendar-title">{title}</h2>
        <LinkButton href={href(view, prev)} variant="tertiary" size="small">{view === "month" ? "이전 달" : "이전 주"}</LinkButton>
        <LinkButton href={href(view, today)} variant="tertiary" size="small">오늘</LinkButton>
        <LinkButton href={href(view, next)} variant="tertiary" size="small">{view === "month" ? "다음 달" : "다음 주"}</LinkButton>
        <nav aria-label="보기" className="ml-auto flex gap-1">
          <LinkButton href={href("month", date)} variant={view === "month" ? "secondary" : "text"} size="small" aria-current={view === "month" ? "page" : undefined}>월</LinkButton>
          <LinkButton href={href("week", date)} variant={view === "week" ? "secondary" : "text"} size="small" aria-current={view === "week" ? "page" : undefined}>주</LinkButton>
        </nav>
      </div>

      {view === "month" ? (
        <div className="overflow-x-auto">
          <table className="w-full min-w-2xl table-fixed border-collapse">
            <caption className="sr-only">{title} 일정</caption>
            <thead>
              <tr>
                {WEEKDAY_LABEL.map((w) => <th key={w} scope="col" className="caption-medium-medium p-2 text-left text-muted">{w}</th>)}
              </tr>
            </thead>
            <tbody>
              {monthGrid(month).map((days) => (
                <tr key={days[0]}>
                  {days.map((d) => {
                    const list = byDay.get(d) ?? [];
                    return (
                      <td key={d} data-date={d} className={cn("h-28 border border-line p-1 align-top", !d.startsWith(month) && "bg-subtle text-muted")}>
                        {dayNumber(d)}
                        <div className="mt-1 flex flex-col gap-0.5">
                          {list.slice(0, MAX_PER_DAY).map((e) => <EventChip key={e.id} e={e} />)}
                          {list.length > MAX_PER_DAY && (
                            <Link href={dayHref?.(d) ?? href("week", d)} className="caption-medium-medium px-1.5 text-muted">
                              +{list.length - MAX_PER_DAY}건
                            </Link>
                          )}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <ol className="grid gap-2 md:grid-cols-7">
          {week.map((d) => {
            const list = byDay.get(d) ?? [];
            return (
              <li key={d} data-date={d} className="flex flex-col gap-1 rounded-md border border-line p-2 md:min-h-40">
                {dayNumber(d)}
                {list.map((e) => <EventChip key={e.id} e={e} wrap />)}
                {!list.length && <p className="caption-medium-medium text-muted">일정 없음</p>}
              </li>
            );
          })}
        </ol>
      )}
    </div>
  );
}
