import type { CSSProperties } from "react";
import { cn } from "./cn";
import { EmptyState } from "./Feedback";

// 차트 (Server Component, JS 없음). 계열 색은 globals.css 의 --ds-series-1..5 (KDS data-visual, 순서 고정).
// 값 표시·범례는 글자색 토큰을 쓰고, 색은 막대·선에만 쓴다. 마우스를 올리면 브라우저 기본 툴팁(title)이 값을 보여준다.
// ponytail: 툴팁은 네이티브 title. 십자선·고정 툴팁이 필요하면 Client 컴포넌트로 감싼다.
const BG = ["bg-series-1", "bg-series-2", "bg-series-3", "bg-series-4", "bg-series-5"] as const;
const STROKE = ["stroke-series-1", "stroke-series-2", "stroke-series-3", "stroke-series-4", "stroke-series-5"] as const;
const FILL = ["fill-series-1", "fill-series-2", "fill-series-3", "fill-series-4", "fill-series-5"] as const;
export const MAX_SERIES = BG.length;

type Format = (n: number) => string;
const num: Format = (n) => n.toLocaleString("ko-KR");

function assertSeries(count: number) {
  if (count > MAX_SERIES) throw new Error(`차트 계열은 최대 ${MAX_SERIES}개입니다. 나머지는 "기타"로 묶으세요.`);
}

/** 0 을 포함하는 보기 좋은 눈금(1·2·5 배수). 마지막 값 ≥ 최댓값, 첫 값 ≤ 최솟값. */
export function niceTicks(min: number, max: number, count = 4): number[] {
  const lo = Math.min(0, min);
  const hi = Math.max(0, max);
  if (lo === hi) return [0, 1];
  const raw = (hi - lo) / count;
  const pow = 10 ** Math.floor(Math.log10(raw));
  const step = ([1, 2, 5, 10].find((m) => m * pow >= raw) ?? 10) * pow;
  const ticks: number[] = [];
  for (let t = Math.floor(lo / step) * step; ; t += step) {
    ticks.push(Number(t.toPrecision(12)));
    if (t >= hi - step * 1e-9) return ticks;
  }
}

function Legend({ series }: { series: string[] }) {
  if (series.length < 2) return null; // 계열 1개는 제목이 이름 역할
  return (
    <ul className="caption-medium-medium flex flex-wrap gap-4 text-muted">
      {series.map((s, i) => (
        <li key={s} className="flex items-center gap-1">
          <span aria-hidden="true" className={cn("size-2 rounded-full", BG[i])} />
          {s}
        </li>
      ))}
    </ul>
  );
}

/**
 * 가로 막대: 범주별 크기 비교. rows[].values[i] 는 series[i] 의 값(0 이상).
 * 예) <BarChart label="부서별 접수" series={["2025", "2026"]} rows={[{ label: "영업", values: [12, 18] }]} />
 */
export function BarChart({ label, rows, series = [label], format = num }: {
  label: string;
  rows: { label: string; values: number[] }[];
  series?: string[];
  format?: Format;
}) {
  assertSeries(series.length);
  const max = Math.max(1, ...rows.flatMap((r) => r.values));
  return (
    <figure aria-label={label} className="flex flex-col gap-4" data-testid="chart">
      <Legend series={series} />
      <dl className="flex flex-col gap-3">
        {rows.map((r) => (
          <div key={r.label} className="grid grid-cols-4 items-center gap-3">
            <dt className="body-small-medium truncate text-muted" title={r.label}>{r.label}</dt>
            <dd className="col-span-3 flex flex-col gap-1">
              {series.map((s, i) => {
                const v = r.values[i] ?? 0;
                return (
                  <div key={s} className="flex items-center gap-2" title={`${r.label} · ${s}: ${format(v)}`}>
                    <span
                      className={cn("h-2 w-(--bar) min-w-1 rounded-r-sm", BG[i])}
                      style={{ "--bar": `${(Math.max(0, v) / max) * 85}%` } as CSSProperties}
                    />
                    <span className="caption-medium-medium text-fg">{format(v)}</span>
                  </div>
                );
              })}
            </dd>
          </div>
        ))}
      </dl>
    </figure>
  );
}

/**
 * 선: 시간에 따른 변화. x = 축 라벨(기간), series[].values[j] = x[j] 시점 값. 음수 허용, 축은 하나.
 * 예) <LineChart label="월별 매출" x={["1월", "2월"]} series={[{ name: "2025", values: [3, 5] }, { name: "2026", values: [4, 6] }]} />
 */
export function LineChart({ label, x, series, format = num }: {
  label: string;
  x: string[];
  series: { name: string; values: number[] }[];
  format?: Format;
}) {
  assertSeries(series.length);
  const W = 600;
  const H = 220;
  const L = 56; // 왼쪽 눈금 글자 자리
  const B = 24; // 아래 x 라벨 자리
  const T = 12; // 위 여백 (최댓값 점이 잘리지 않게)
  const X0 = L + 20; // 첫 점 (눈금 글자와 띄움)
  const X1 = W - 24; // 끝 점 (마지막 x 라벨이 잘리지 않게)
  const ticks = niceTicks(Math.min(...series.flatMap((s) => s.values)), Math.max(...series.flatMap((s) => s.values)));
  const lo = ticks[0];
  const hi = ticks.at(-1) ?? 1;
  const px = (j: number) => (x.length < 2 ? (X0 + X1) / 2 : X0 + (j * (X1 - X0)) / (x.length - 1));
  const py = (v: number) => T + ((hi - v) * (H - B - T)) / (hi - lo);
  return (
    <figure aria-label={label} className="flex flex-col gap-4" data-testid="chart">
      <Legend series={series.map((s) => s.name)} />
      <svg viewBox={`0 0 ${W} ${H}`} className="caption-medium-medium h-auto w-full" role="img" aria-label={label}>
        {ticks.map((t) => (
          <g key={t}>
            <line x1={L} x2={W} y1={py(t)} y2={py(t)} className={cn("stroke-line", t === 0 ? "stroke-2" : "stroke-1")} />
            <text x={L - 8} y={py(t)} textAnchor="end" dominantBaseline="middle" className="fill-muted">{format(t)}</text>
          </g>
        ))}
        {x.map((label, j) => (
          <text key={label} x={px(j)} y={H - 4} textAnchor="middle" className="fill-muted">{label}</text>
        ))}
        {series.map((s, i) => (
          <g key={s.name}>
            <polyline
              points={s.values.map((v, j) => `${px(j)},${py(v)}`).join(" ")}
              fill="none"
              className={cn("stroke-2", STROKE[i])}
              strokeLinejoin="round"
              strokeLinecap="round"
            />
            {s.values.map((v, j) => (
              <circle key={x[j]} cx={px(j)} cy={py(v)} r={4} className={cn("stroke-2 stroke-surface", FILL[i])}>
                <title>{`${x[j]} · ${s.name}: ${format(v)}`}</title>
              </circle>
            ))}
          </g>
        ))}
      </svg>
    </figure>
  );
}

/**
 * 도넛: 전체 중 구성 비율(합계가 의미 있을 때만). 항목은 최대 5개, 나머지는 "기타"로 묶는다. 0 이하 값은 뺀다.
 * 예) <DonutChart label="분류별 비율" rows={[{ label: "장비", value: 12 }, { label: "교육", value: 5 }]} />
 */
export function DonutChart({ label, rows, format = num }: {
  label: string;
  rows: { label: string; value: number }[];
  format?: Format;
}) {
  const valid = rows.filter((r) => Number.isFinite(r.value) && r.value > 0);
  assertSeries(valid.length);
  const total = valid.reduce((sum, r) => sum + r.value, 0);
  if (!total) return <EmptyState title="표시할 데이터가 없습니다." />;
  const pct = (n: number) => (n / total) * 100;
  const start = (i: number) => pct(valid.slice(0, i).reduce((sum, r) => sum + r.value, 0));
  return (
    <figure aria-label={label} className="flex flex-wrap items-center gap-6" data-testid="chart">
      <svg viewBox="0 0 120 120" className="w-40 shrink-0" role="img" aria-label={`${label}. 합계 ${format(total)}`}>
        <circle cx={60} cy={60} r={44} fill="none" className="stroke-line" strokeWidth={16} />
        {valid.map((r, i) => (
          <circle key={r.label} cx={60} cy={60} r={44} pathLength={100} fill="none" strokeWidth={16}
            strokeDasharray={`${pct(r.value)} ${100 - pct(r.value)}`} strokeDashoffset={-start(i)} transform="rotate(-90 60 60)" className={STROKE[i]}>
            <title>{`${r.label}: ${format(r.value)}`}</title>
          </circle>
        ))}
        <text x={60} y={64} textAnchor="middle" className="caption-medium-medium fill-fg">{format(total)}</text>
      </svg>
      <ul className="body-small-medium flex flex-col gap-2">
        {valid.map((r, i) => (
          <li key={r.label} className="flex items-center gap-2">
            <span aria-hidden="true" className={cn("size-2 rounded-full", BG[i])} />
            {r.label} {format(r.value)} ({Math.round(pct(r.value))}%)
          </li>
        ))}
      </ul>
    </figure>
  );
}

/** 비율 막대 (커버리지·좌석 점유율 등). KDS kds-progress. */
export function Progress({ label, value, max = 100 }: { label: string; value: number; max?: number }) {
  const pct = max > 0 ? Math.round((Math.min(Math.max(value, 0), max) / max) * 100) : 0;
  return (
    <div className="flex flex-col gap-1">
      <div className="body-small-medium flex justify-between gap-2">
        <span className="text-muted">{label}</span>
        <span>{pct}%</span>
      </div>
      <div
        className="kds-progress"
        role="progressbar"
        aria-label={label}
        aria-valuenow={pct}
        aria-valuemin={0}
        aria-valuemax={100}
        style={{ "--value": `${pct}%` } as CSSProperties}
      />
    </div>
  );
}
