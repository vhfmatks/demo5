"use client";

import type { ReactNode } from "react";
import { Modal } from "./Modal";
import { Button } from "./Button";

/** KDS 가운데 팝업 + 브라우저 모달의 포커스 격리·복원. */
export function ConfirmDialog({ open, title, body, confirmLabel, loading, onConfirm, onCancel, children }: {
  open: boolean; title: string; body?: ReactNode; confirmLabel: string; loading?: boolean;
  onConfirm: () => void; onCancel: () => void; children?: ReactNode;
}) {
  return <Modal open={open} title={title} description={body} onClose={onCancel} busy={loading} showClose={false} size="small"
    footer={<><Button variant="secondary" autoFocus disabled={loading} onClick={onCancel}>취소</Button>
      <Button loading={loading} onClick={onConfirm}>{confirmLabel}</Button></>}>
    {children}
  </Modal>;
}
