// Server Component 에서 쓰는 표(kds-table). 컬럼 정의만 넘기면 된다 (render 함수는 서버에서 실행). 숫자 칸은 className="is-num".
import type { ReactNode } from "react";
import Link from "next/link";
import { EmptyState } from "./Feedback";

export type Column<T> = { key: string; header: string; render: (row: T) => ReactNode; className?: string };

export function DataTable<T extends { id: string }>({
  rows,
  columns,
  empty = "데이터가 없습니다.",
  rowHref,
}: {
  rows: T[];
  columns: Column<T>[];
  empty?: string;
  rowHref?: (row: T) => string;
}) {
  if (!rows.length) return <EmptyState title={empty} />;
  return (
    <div className="kds-table-wrap">
      <table className="kds-table">
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c.key} scope="col" className={c.className}>
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id} data-testid="row">
              {columns.map((c, i) => (
                <td key={c.key} className={c.className}>
                  {i === 0 && rowHref ? (
                    <Link href={rowHref(row)} className="font-semibold text-fg no-underline hover:underline">
                      {c.render(row)}
                    </Link>
                  ) : (
                    c.render(row)
                  )}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
