"use client";

import { useEffect, useId, useMemo, useRef, useState, type ComponentPropsWithoutRef, type KeyboardEvent } from "react";
import { Field } from "./Form";
import { Icon } from "./Icon";
import { cn } from "./cn";
import { WEEKDAYS, addDays, addMonths, calendarDays, firstDayOfMonth, formatDate, isDateInRange, monthLabel, parseDate, partsOf, todayValue } from "./date-values";

type InputProps = ComponentPropsWithoutRef<"input">;

export type DatePickerProps = Omit<InputProps, "type" | "name" | "value" | "defaultValue" | "min" | "max"> & {
  name: string;
  label: string;
  hint?: string;
  error?: string[];
  value?: string;
  defaultValue?: string;
  min?: string;
  max?: string;
  onValueChange?: (value: string) => void;
  /** Renders the raw KDS control without the kit Field wrapper. Labels/errors remain the caller's responsibility. */
  bare?: boolean;
};

/** KDS 2.0 date picker. The visible value is YYYY.MM.DD; FormData receives ISO YYYY-MM-DD from the hidden input. */
export function DatePicker({
  label,
  name,
  hint,
  error,
  value,
  defaultValue,
  min,
  max,
  onChange,
  onValueChange,
  required,
  disabled,
  readOnly,
  bare = false,
  className,
  ...rest
}: DatePickerProps) {
  const id = rest.id ?? name;
  const displayFormId = `kds-datepicker-display-${useId()}`;
  const rootRef = useRef<HTMLSpanElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const hiddenRef = useRef<HTMLInputElement>(null);
  const dayRefs = useRef(new Map<string, HTMLButtonElement>());
  const invalid = !!error?.length || rest["aria-invalid"] === true || rest["aria-invalid"] === "true";
  const description = error?.length ? `${id}-error` : hint ? `${id}-hint` : undefined;
  const describedBy = [rest["aria-describedby"], description].filter(Boolean).join(" ") || undefined;
  const controlled = value !== undefined;
  const parsedValue = parseDate(value);
  const [uncontrolledValue, setUncontrolledValue] = useState(() => parseDate(defaultValue) ?? "");
  const selectedValue = parsedValue ?? (controlled ? "" : uncontrolledValue);
  const [open, setOpen] = useState(false);
  const [viewValue, setViewValue] = useState(() => firstDayOfMonth(selectedValue || parseDate(min) || todayValue()));
  const [focusedValue, setFocusedValue] = useState<string | null>(null);
  const view = useMemo(() => partsOf(viewValue), [viewValue]);
  const leadingWeekdays = useMemo(() => WEEKDAYS.slice(0, new Date(view.year, view.month, 1).getDay()), [view.year, view.month]);
  const today = useMemo(() => todayValue(), []);
  const days = useMemo(
    () => calendarDays({ year: view.year, month: view.month, min, max, today }),
    [view.year, view.month, min, max, today],
  );

  useEffect(() => {
    if (controlled || open || !parsedValue) return;
    setViewValue(firstDayOfMonth(parsedValue));
  }, [controlled, open, parsedValue]);

  useEffect(() => {
    if (!open || focusedValue === null) return;
    dayRefs.current.get(focusedValue)?.focus();
  }, [open, focusedValue]);

  useEffect(() => {
    if (!open || focusedValue !== null) return;
    const firstEnabled = days.find((day) => day && !day.disabled);
    if (firstEnabled) setFocusedValue(firstEnabled.value);
  }, [days, open, focusedValue]);

  useEffect(() => {
    if (!open) return;
    const closeFromOutside = (event: PointerEvent) => {
      if (rootRef.current?.contains(event.target as Node)) return;
      setOpen(false);
    };
    document.addEventListener("pointerdown", closeFromOutside);
    return () => document.removeEventListener("pointerdown", closeFromOutside);
  }, [open]);

  const openCalendar = () => {
    if (disabled || readOnly) return;
    const start = selectedValue || parseDate(min) || todayValue();
    setOpen(true);
    setViewValue(firstDayOfMonth(start));
    setFocusedValue(selectedValue && isDateInRange(selectedValue, min, max) ? selectedValue : null);
  };

  const closeCalendar = (returnFocus = true) => {
    setOpen(false);
    if (returnFocus) inputRef.current?.focus();
  };

  const changeMonth = (amount: number) => {
    const next = addMonths(viewValue, amount);
    if (!next) return;
    setViewValue(firstDayOfMonth(next));
    setFocusedValue(isDateInRange(next, min, max) ? next : null);
  };

  const moveFocusedDate = (amount: number) => {
    const current = focusedValue || selectedValue || todayValue();
    const next = addDays(current, amount);
    if (!next || !isDateInRange(next, min, max)) return;
    setViewValue(firstDayOfMonth(next));
    setFocusedValue(next);
  };

  const selectDate = (nextValue: string) => {
    if (nextValue ? !isDateInRange(nextValue, min, max) : required) return;
    if (readOnly) return;
    setUncontrolledValue(nextValue);
    onValueChange?.(nextValue);
    const display = inputRef.current;
    if (display) {
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set?.call(display, nextValue);
      display.dispatchEvent(new Event("input", { bubbles: true }));
    }
    closeCalendar();
  };

  const handleInputKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    rest.onKeyDown?.(event);
    if (event.defaultPrevented || disabled) return;
    if (event.key === "Enter" || event.key === " " || event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      if (open) closeCalendar();
      else openCalendar();
    }
    if (event.key === "Escape" && open) {
      event.stopPropagation();
      closeCalendar();
    }
  };

  const handleCalendarKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === "Escape") {
      event.stopPropagation();
      closeCalendar();
      return;
    }
    if (event.key === "PageUp" || event.key === "PageDown") {
      event.preventDefault();
      changeMonth(event.key === "PageUp" ? -1 : 1);
      return;
    }
    const moves: Record<string, number> = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 };
    if (event.key in moves) {
      event.preventDefault();
      moveFocusedDate(moves[event.key] ?? 0);
      return;
    }
    if (event.key !== "Tab") return;
    const focusable = rootRef.current?.querySelectorAll<HTMLButtonElement>("button:not(:disabled)");
    if (!focusable?.length) return;
    event.preventDefault();
    const items = Array.from(focusable);
    const index = Math.max(0, items.indexOf(document.activeElement as HTMLButtonElement));
    const nextIndex = event.shiftKey ? (index - 1 + items.length) % items.length : (index + 1) % items.length;
    const target = items[nextIndex];
    target?.focus();
  };

  const calendar = open && (
    <div
      id={`${id}-calendar`}
      className="kds-calendar"
      role="dialog"
      aria-label={`${label} 날짜 선택`}
      onKeyDown={handleCalendarKeyDown}
    >
      <div className="kds-calendar__head">
        <button type="button" className="kds-icon-button" aria-label="이전 달" onClick={() => changeMonth(-1)}>
          <Icon name="line-chevron_left" />
        </button>
        <span className="kds-calendar__title">{monthLabel(view)}</span>
        <button type="button" className="kds-icon-button" aria-label="다음 달" onClick={() => changeMonth(1)}>
          <Icon name="line-chevron_right" />
        </button>
      </div>
      <div className="kds-calendar__grid">
        {WEEKDAYS.map((weekday) => (
          <span key={weekday} className="kds-calendar__dow">{weekday}</span>
        ))}
        {leadingWeekdays.map((weekday) => (
          <span key={`calendar-blank-${weekday}`} />
        ))}
        {days.filter((day) => day !== null).map((day) => day && (
          <button
            key={day.value}
            type="button"
            className={`kds-calendar__day${day.sunday ? " is-sunday" : ""}${day.today ? " is-today" : ""}`}
            data-day={day.day}
            data-value={day.value}
            aria-pressed={selectedValue === day.value}
            aria-current={day.today ? "date" : undefined}
            aria-label={`${view.year}년 ${view.month + 1}월 ${day.day}일`}
            disabled={day.disabled}
            ref={(element) => {
              if (element) dayRefs.current.set(day.value, element);
              else dayRefs.current.delete(day.value);
            }}
            onClick={() => selectDate(day.value)}
          >
            <span>{day.day}</span>
          </button>
        ))}
      </div>
    </div>
  );

  const control = (
    <span ref={rootRef} className={cn("kds-datepicker", selectedValue && !required && !readOnly && !disabled && "kit-datepicker-clearable")}>
      <input
        {...rest}
        id={id}
        name={name}
        form={displayFormId}
        ref={inputRef}
        type="text"
        role="combobox"
        aria-autocomplete="none"
        className={cn("kds-field__input", className)}
        value={formatDate(selectedValue)}
        placeholder={rest.placeholder ?? "날짜 선택"}
        readOnly
        disabled={disabled}
        aria-label={bare ? label : undefined}
        aria-required={required || undefined}
        aria-invalid={invalid || undefined}
        aria-describedby={describedBy}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-controls={open ? `${id}-calendar` : undefined}
        onClick={(event) => {
          rest.onClick?.(event);
          if (event.defaultPrevented || disabled) return;
          if (open) closeCalendar(false);
          else openCalendar();
        }}
        onKeyDown={handleInputKeyDown}
        onChange={onChange}
      />
      {selectedValue && !required && !readOnly && !disabled && <button type="button" className="kds-icon-button kit-date-clear" aria-label={`${label} 지우기`} onClick={() => selectDate("")}><Icon name="line-close" size={16} /></button>}
      {calendar}
      <input
        ref={hiddenRef}
        type="hidden"
        name={name}
        value={selectedValue}
        disabled={disabled}
        readOnly
        min={min}
        max={max}
        required={required}
      />
    </span>
  );

  return bare ? control : (
    <Field label={label} name={id} hint={hint} error={error} required={required}>{control}</Field>
  );
}

/** KDS date range layout. Date order and business boundaries remain the responsibility of the server schema/service. */
export function DateRangePicker({ start, end }: { start: DatePickerProps; end: DatePickerProps }) {
  return (
    <div className="kds-date-range flex-col gap-4 md:flex-row md:items-end">
      <DatePicker {...start} />
      <span aria-hidden="true" className="self-center">~</span>
      <DatePicker {...end} />
    </div>
  );
}
