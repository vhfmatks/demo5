"use client";

import { type ReactNode, useEffect, useId, useRef, useState } from "react";
import { Icon } from "./Icon";
import { cn } from "./cn";

export function Accordion({ items, multiple = false, label }: {
  items: { id: string; title: string; content: ReactNode; defaultOpen?: boolean }[]; multiple?: boolean; label: string;
}) {
  const id = useId();
  return <section aria-label={label} className="kit-accordion">
    {items.map((item) => <details key={item.id} name={multiple ? undefined : id} open={item.defaultOpen || undefined}>
      <summary>{item.title}<Icon name="line-chevron_down" size={20} /></summary>
      <div className="body-medium-medium py-4">{item.content}</div>
    </details>)}
  </section>;
}

/** 상세/폼 등 임의 콘텐츠용 disclosure. 메뉴 역할은 콘텐츠가 직접 정의한다. */
export function Popover({ label, children }: { label: string; children: ReactNode }) {
  const ref = useRef<HTMLDetailsElement>(null);
  useEffect(() => {
    const dismiss = (event: PointerEvent) => {
      if (event.target instanceof Node && ref.current && !ref.current.contains(event.target)) ref.current.open = false;
    };
    document.addEventListener("pointerdown", dismiss);
    return () => document.removeEventListener("pointerdown", dismiss);
  }, []);
  return <details ref={ref} className="kit-popover" onKeyDown={(event) => {
    if (event.key === "Escape" && ref.current) { ref.current.open = false; ref.current.querySelector("summary")?.focus(); }
  }}>
    <summary className="kds-button kds-button--tertiary">{label}<Icon name="line-chevron_down" size={16} /></summary>
    <div className="kit-popover-content">{children}</div>
  </details>;
}

/** 텍스트 보충 설명. 인터랙티브 콘텐츠는 Popover를 쓴다. */
export function Tooltip({ label, content }: { label: string; content: string }) {
  const id = useId(); const [open, setOpen] = useState(false); const root = useRef<HTMLSpanElement>(null);
  const leave = (target: EventTarget | null) => { if (!(target instanceof Node) || !root.current?.contains(target)) setOpen(false); };
  return <span ref={root} className="kit-tooltip">
    <button type="button" className="kds-icon-button" aria-label={label} aria-describedby={open ? id : undefined}
      onFocus={() => setOpen(true)} onBlur={() => setOpen(false)} onClick={() => setOpen(true)}
      onMouseEnter={() => setOpen(true)} onMouseLeave={(event) => leave(event.relatedTarget)}
      onKeyDown={(event) => { if (event.key === "Escape") { event.stopPropagation(); setOpen(false); } }}>
      <Icon name="line-info" size={20} />
    </button>
    <span id={id} role="tooltip" hidden={!open} onMouseLeave={(event) => leave(event.relatedTarget)} className={cn("kit-tooltip-content", "body-small-medium")}>{content}</span>
  </span>;
}
