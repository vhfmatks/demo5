"use client";

import Image from "next/image";
import { useState } from "react";
import { Button } from "./Button";

/** 사전 렌더링된 문서 페이지를 탐색한다. PDF 파싱·외부 다운로드는 호출자가 담당한다. */
export function DocumentViewer({ title, pages }: { title: string; pages: { src: string; alt: string; width: number; height: number }[] }) {
  const [selected, setSelected] = useState(0); const index = Math.min(selected, Math.max(0, pages.length - 1)); const page = pages[index];
  return <section aria-label={title} className="kit-document-viewer"><h2 className="title-large-bold">{title}</h2>
    {page ? <><div className="kit-document-page"><Image src={page.src} alt={page.alt} width={page.width} height={page.height} unoptimized /></div>
      <nav aria-label="문서 페이지" className="flex items-center justify-between gap-2"><Button variant="tertiary" disabled={index === 0} onClick={() => setSelected(index - 1)}>이전 페이지</Button>
        <span role="status">{index + 1} / {pages.length}</span><Button variant="tertiary" disabled={index === pages.length - 1} onClick={() => setSelected(index + 1)}>다음 페이지</Button></nav></>
      : <p className="body-small-medium text-muted">표시할 문서 페이지가 없습니다.</p>}
  </section>;
}
