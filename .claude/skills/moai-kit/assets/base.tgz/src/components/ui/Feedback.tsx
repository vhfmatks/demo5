import type { ReactNode } from "react";
import { cn } from "./cn";
import { Icon } from "./Icon";

/** 상태 태그. 예외 상태에만 붙이고 정상·기본 상태엔 생략한다 (KDS). */
export type Tone = "default" | "info" | "progress" | "positive" | "warning" | "critical" | "complete";
export function Tag({ tone = "default", children, testId }: { tone?: Tone; children: ReactNode; testId?: string }) {
  return <span data-testid={testId} className={cn("kds-tag", tone !== "default" && `kds-tag--${tone}`)}>{children}</span>;
}

/** 오류·안내 한 줄 (kds-info-line). 색 박스를 쓰지 않는다. children 이 비면 렌더하지 않는다. */
export function Alert({ tone = "error", children }: { tone?: "error" | "info"; children: ReactNode }) {
  if (!children) return null;
  const error = tone === "error";
  return (
    <p role={error ? "alert" : "status"} className={cn("kds-info-line", error && "kds-info-line--error")}>
      <Icon name={error ? "line-warning" : "line-info"} size={16} />
      {children}
    </p>
  );
}

export function EmptyState({ title, action }: { title: string; action?: ReactNode }) {
  return (
    <div className="kds-empty">
      <Icon name="line-inbox" purpose="empty" />
      <p className="kds-empty__text">{title}</p>
      {action}
    </div>
  );
}

