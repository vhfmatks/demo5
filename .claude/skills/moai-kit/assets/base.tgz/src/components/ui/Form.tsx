import { cloneElement, isValidElement, type ComponentProps, type ReactNode } from "react";
import { cn } from "./cn";

/** 라벨 + 컨트롤 + 에러(kds-field). 에러 문구는 useMutation().fieldErrors[name] 을 그대로 넘긴다. */
export function Field({
  label,
  name,
  error,
  hint,
  required,
  children,
}: {
  label: string;
  name: string;
  error?: string[];
  hint?: string;
  required?: boolean;
  children: ReactNode;
}) {
  const control = isValidElement<ComponentProps<"input"> & Ctl>(children)
    && (children.type === Input || children.type === Textarea || children.type === Select) ? children : null;
  const id = control?.props.id ?? name;
  const invalid = !!error?.length;
  const description = invalid ? `${id}-error` : hint ? `${id}-hint` : undefined;
  return (
    <div className={cn("kds-field", invalid && "kds-field--error")}>
      <label htmlFor={id} className="kds-field__label">
        {label}
        {required && <span aria-hidden="true" className="ml-0.5 text-danger">*</span>}
      </label>
      {control ? cloneElement(control, {
        id,
        "aria-required": required || control.props["aria-required"],
        invalid: invalid || control.props.invalid,
        "aria-describedby": [control.props["aria-describedby"], description].filter(Boolean).join(" ") || undefined,
      }) : children}
      {error?.length ? (
        <p id={`${id}-error`} role="alert" className="kds-field__helper">
          {error[0]}
        </p>
      ) : hint ? (
        <p id={`${id}-hint`} className="kds-field__helper">{hint}</p>
      ) : null}
    </div>
  );
}

type Ctl = { invalid?: boolean };
export function Input({ invalid, className, ...rest }: ComponentProps<"input"> & Ctl) {
  return (
    <input
      id={rest.name}
      aria-invalid={invalid || undefined}
      aria-describedby={invalid ? `${rest.id ?? rest.name}-error` : undefined}
      className={cn("kds-field__input", className)}
      {...rest}
    />
  );
}
export function Textarea({ invalid, className, ...rest }: ComponentProps<"textarea"> & Ctl) {
  return <textarea id={rest.name} aria-invalid={invalid || undefined} aria-describedby={invalid ? `${rest.id ?? rest.name}-error` : undefined} className={cn("kds-field__input", className)} {...rest} />;
}
export function Select({
  invalid,
  options,
  placeholder,
  className,
  ...rest
}: ComponentProps<"select"> & Ctl & { options: { value: string; label: string }[]; placeholder?: string }) {
  return (
    <select id={rest.name} aria-invalid={invalid || undefined} aria-describedby={invalid ? `${rest.id ?? rest.name}-error` : undefined} className={cn("kds-field__input kds-select", className)} {...rest}>
      {placeholder !== undefined && <option value="">{placeholder}</option>}
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}

/** Record<값, 라벨> → Select options */
export const toOptions = <K extends string>(labels: Record<K, string>) =>
  (Object.entries(labels) as [K, string][]).map(([value, label]) => ({ value, label }));

/** 체크·라디오·스위치: label 안에 input (KDS 마크업). 선택지 4개 이하면 Select 대신 Radio. */
type Choice = Omit<ComponentProps<"input">, "type"> & { children: ReactNode };
export const Checkbox = ({ children, className, ...rest }: Choice) => (
  <label className={cn("kds-checkbox", className)}><input type="checkbox" {...rest} />{children}</label>
);
export const Radio = ({ children, className, ...rest }: Choice) => (
  <label className={cn("kds-radio", className)}><input type="radio" {...rest} />{children}</label>
);
export const Switch = ({ children, className, ...rest }: Choice) => (
  <label className={cn("kds-switch", className)}>{children}<input type="checkbox" {...rest} /></label>
);
