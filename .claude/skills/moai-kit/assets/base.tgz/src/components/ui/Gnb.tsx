"use client";
// KDS PC 메뉴 + 좁은 화면용 목록 메뉴. 현재 위치는 가장 길게 일치한 경로 하나.
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { type ReactNode, useEffect, useRef } from "react";
import { Icon } from "./Icon";

export function Gnb({ items, actions }: { items: { href: string; label: string }[]; actions?: ReactNode }) {
  const path = usePathname();
  const menu = useRef<HTMLDetailsElement>(null);
  useEffect(() => { if (path && menu.current) menu.current.open = false; }, [path]);
  useEffect(() => {
    const desktop = window.matchMedia("(min-width: 1280px)");
    const close = () => { if (desktop.matches && menu.current) menu.current.open = false; };
    close();
    desktop.addEventListener("change", close);
    return () => desktop.removeEventListener("change", close);
  }, []);
  // 가장 길게 일치하는 메뉴 하나만 현재 메뉴 (/admin 과 /admin/audit 공존)
  const current = items.map((n) => n.href)
    .filter((href) => path === href || (href !== "/" && path.startsWith(`${href}/`)))
    .sort((a, b) => b.length - a.length)[0];
  const active = (href: string) => href === current;
  return (
    <header className="kds-gnb kit-gnb">
      <div className="kds-container kds-gnb__inner kit-gnb-inner">
        {items.length > 0 && <details ref={menu} className="kit-mobile-menu" onKeyDown={(event) => {
          if (event.key === "Escape" && menu.current) {
            menu.current.open = false;
            menu.current.querySelector("summary")?.focus();
          }
        }}>
          <summary className="kds-icon-button" aria-label="주 메뉴 열기"><Icon name="line-menu" /></summary>
          <nav aria-label="모바일 주 메뉴">
            <ul className="kds-list kds-list--divided">
              {items.map((n) => <li key={n.href}><Link href={n.href} aria-current={active(n.href) ? "page" : undefined}
                onClick={() => { if (menu.current) menu.current.open = false; }}>{n.label}</Link></li>)}
            </ul>
          </nav>
        </details>}
        <Link href="/">
          <Image className="kds-gnb__logo" src="/kds/images/logo_kt.svg" alt="KT" width={23} height={19} priority />
        </Link>
        <nav className="kit-desktop-menu" aria-label="주 메뉴">
          <ul className="kds-gnb__menu title-medium-semibold">
            {items.map((n) => (
              <li key={n.href}>
                <Link href={n.href} aria-current={active(n.href) ? "page" : undefined}>
                  {n.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        {actions && <div className="kds-gnb__actions kit-gnb-actions">{actions}</div>}
      </div>
    </header>
  );
}
