import Image from "next/image";
import { cn } from "./cn";

/** KDS 20261012 icon classes. Multicolor artwork uses the original SVG image. */
type Name = `${"line" | "fill"}-${string}`;

export function Icon({ name, size, purpose, className }: { name: Name; size?: 16 | 20; purpose?: "empty"; className?: string }) {
  if (name === "line-alarm_unread" || name === "fill-k_logo_red" || name === "line-loading") {
    return <Image aria-hidden="true" alt="" src={`/kds/icons/ic-${name}.svg`} width={size ?? 24} height={size ?? 24} unoptimized
      className={cn("kit-color-icon", size && `kit-color-icon--${size}`, className)} />;
  }
  return (
    <span
      aria-hidden="true"
      className={cn("kds-icon", `ic-${name}`, size && `kds-icon--${size}`, purpose === "empty" && "kds-empty__icon", className)}
    />
  );
}
