import type { ReactNode } from "react";
import { cn } from "./cn";

/** 모바일 업무형 화면은 카드 대신 평평한 섹션으로 구성한다. */
export function Section({ title, children, className }: { title?: string; children: ReactNode; className?: string }) {
  return <section className={cn("kds-section min-w-0", className)}>
    {title && <h2 className="kds-section__title">{title}</h2>}
    {children}
  </section>;
}

/** 페이지 제목(KT Flow) + 설명 + 보조 동작. 페이지 위 보조 동작은 tertiary 버튼 (검정은 확정 동작 하나). */
export function PageHeader({ title, description, actions }: { title: string; description?: string; actions?: ReactNode }) {
  return (
    <div className="kit-page-head">
      <div>
        <h1 className="heading-small-bold kit-page-title">{title}</h1>
        {description && <p className="body-medium-medium mt-1 text-muted">{description}</p>}
      </div>
      {actions && <div className="flex gap-2">{actions}</div>}
    </div>
  );
}

/** 목록 위 GET 검색·필터 한 줄. 항목은 왼쪽부터, 같은 높이·가운데 정렬. 새로 만들기 등 동작은 PageHeader actions 에 둔다. */
export function FilterBar({ children }: { children: ReactNode }) {
  return <search><form method="get" className="kit-filters">{children}</form></search>;
}

/** 섹션 제목은 카드 밖, 면은 한 겹 (KDS). 카드 안에 카드를 넣지 않는다. */
export function Card({ title, actions, children, className }: { title?: string; actions?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={cn("kit-content-card", className)}>
      {(title || actions) && (
        <div className="mb-2 flex items-center justify-between gap-2">
          {title && <h2 className="title-large-bold">{title}</h2>}
          {actions}
        </div>
      )}
      <div className="kds-card">{children}</div>
    </section>
  );
}

export function ResultCount({ total, label = "조회결과" }: { total: number; label?: string }) {
  return <p className="kds-result-count">{label} <b>{total.toLocaleString("ko-KR")}</b>개</p>;
}

/** 요약 숫자. 한 덩어리에 대표 값 하나만 크게. */
export function Stat({ label, value, tone }: { label: string; value: ReactNode; tone?: "danger" | "success" }) {
  return (
    <div className="kds-card gap-1">
      <p className="body-small-medium text-muted">{label}</p>
      <p className={cn("title-large-bold",tone === "danger" && "text-danger", tone === "success" && "text-success")}>{value}</p>
    </div>
  );
}

/** 라벨-값 목록 (상세 화면용) */
export function DescriptionList({ items }: { items: { label: string; value: ReactNode }[] }) {
  return (
    <dl className="body-medium-medium flex flex-col gap-3">
      {items.map((it) => (
        <div key={it.label} className="flex gap-4">
          <dt className="w-32 shrink-0 text-muted">{it.label}</dt>
          <dd className="min-w-0 whitespace-pre-wrap">{it.value}</dd>
        </div>
      ))}
    </dl>
  );
}
