"use client";

import { type ReactNode, useEffect, useId, useRef } from "react";
import { IconButton } from "./Button";
import { cn } from "./cn";

export type ModalProps = {
  open: boolean; title: string; description?: ReactNode; children: ReactNode; footer?: ReactNode;
  onClose: () => void; busy?: boolean; showClose?: boolean; size?: "small" | "medium";
};

/** 공유 모달 동작: 배경 비활성·포커스 순환/복원·Escape. */
export function Modal({ open, title, description, children, footer, onClose, busy, showClose = true, size = "medium", presentation = "popup" }: ModalProps & { presentation?: "popup" | "sheet" }) {
  const id = useId();
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const dialog = ref.current;
    if (!open || !dialog) return;
    const previous = document.activeElement;
    dialog.showModal();
    return () => { dialog.close(); if (previous instanceof HTMLElement && previous.isConnected) previous.focus(); };
  }, [open]);
  const sheet = presentation === "sheet";
  return <dialog ref={ref} className={cn("kit-dialog", sheet && "kit-sheet-dialog")} aria-labelledby={id}
    aria-describedby={description ? `${id}-description` : undefined} aria-busy={busy || undefined}
    onCancel={(event) => { event.preventDefault(); if (!busy) onClose(); }}
    onKeyDown={(event) => {
      if (event.key !== "Tab") return;
      const controls = Array.from(event.currentTarget.querySelectorAll<HTMLElement>(
        'button:not(:disabled), a[href], input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex="0"]',
      )).filter((element) => element.tabIndex >= 0 && element.getClientRects().length > 0);
      const first = controls[0]; const last = controls.at(-1);
      if (!first || !last) { event.preventDefault(); return; }
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }}>
    <div className={cn(sheet ? "kds-sheet kit-sheet" : "kds-popup kit-modal", !sheet && size === "small" && "kds-popup--small")}>
      <div className={sheet ? "kds-sheet__header" : "flex items-center justify-between gap-2"}>
        <h2 id={id} className={sheet ? undefined : "kds-popup__title"}>{title}</h2>
        {showClose && <IconButton name="line-close" label="닫기" disabled={busy} onClick={onClose} />}
      </div>
      <div className={sheet ? "kds-sheet__body" : "kit-modal-body"}>
        {description && <div id={`${id}-description`} className="kds-popup__body">{description}</div>}
        {children}
      </div>
      {footer && <div className={sheet ? "kds-sheet__footer" : "kds-popup__actions"}>{footer}</div>}
    </div>
  </dialog>;
}

/** 모바일에서는 하단 시트, PC에서는 가운데 팝업으로 적응한다. */
export function BottomSheet(props: ModalProps) { return <Modal {...props} presentation="sheet" />; }
