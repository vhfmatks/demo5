import Link from "next/link";
import type { ComponentProps, ReactNode } from "react";
import { Icon } from "./Icon";

type NavigationItem = { href: string; label: string; icon?: ComponentProps<typeof Icon>["name"] };
export function Breadcrumb({ items }: { items: { label: string; href?: string }[] }) {
  return <nav aria-label="현재 경로"><ol className="kds-breadcrumb">{items.map((item, index) => <li key={item.href ?? item.label} className="flex items-center gap-1">
    {index > 0 && <Icon name="line-chevron_right" size={16} />}
    {item.href && index !== items.length - 1 ? <Link href={item.href}>{item.label}</Link> : <span aria-current={index === items.length - 1 ? "page" : undefined}>{item.label}</span>}
  </li>)}</ol></nav>;
}
export function BottomNavigation({ items, currentHref }: { items: NavigationItem[]; currentHref: string }) {
  return <nav aria-label="하단 메뉴" className="kds-bottomnav kit-mobile-only">{items.map((item) =>
    <Link key={item.href} href={item.href} aria-current={item.href === currentHref ? "page" : undefined}>{item.icon && <Icon name={item.icon} />}{item.label}</Link>)}</nav>;
}
export function TopNavigation({ title, backHref, actions, platform = "auto" }: { title: string; backHref?: string; actions?: ReactNode; platform?: "auto" | "mobile" }) {
  return <header className={platform === "auto" ? "kds-topnav kit-mobile-only" : "kds-topnav"}>{backHref && <Link href={backHref} className="kds-icon-button" aria-label="뒤로"><Icon name="line-chevron_left" /></Link>}
    <h2 className="kds-topnav__title">{title}</h2>{actions && <div className="kds-topnav__actions">{actions}</div>}</header>;
}
export function Sidebar({ label, items, currentHref, header, footer }: { label: string; items: NavigationItem[]; currentHref?: string; header?: ReactNode; footer?: ReactNode }) {
  return <nav aria-label={label} className="kds-lnb kit-sidebar">{header}{items.map((item) =>
    <Link key={item.href} href={item.href} aria-current={item.href === currentHref ? "page" : undefined}>{item.icon && <Icon name={item.icon} size={20} />}{item.label}</Link>)}{footer}</nav>;
}
export function CtaBar({ children }: { children: ReactNode }) { return <div className="kds-cta-bar">{children}</div>; }
export function InfoBand({ children }: { children: ReactNode }) { return <div className="kds-info-band">{children}</div>; }
export function Footer({ children }: { children: ReactNode }) { return <footer className="kds-footer"><div className="kds-container">{children}</div></footer>; }
