"use client";

import { type ReactNode, useEffect, useState } from "react";
import { IconButton } from "./Button";
import { cn } from "./cn";

function OpenToast({ open, children, onClose, duration = 3000, action, closeLabel = "알림 닫기" }: {
  open: boolean; children: ReactNode; onClose: () => void; duration?: number; action?: ReactNode; closeLabel?: string;
}) {
  const [paused, setPaused] = useState(false);
  useEffect(() => {
    if (!open || paused || duration <= 0) return;
    const timer = window.setTimeout(onClose, duration);
    return () => window.clearTimeout(timer);
  }, [open, duration, paused, onClose]);
  if (!open) return null;
  return <aside aria-label="알림" className={cn("kds-toast is-open", "kit-toast")} onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}
    onFocus={() => setPaused(true)} onBlur={(event) => { if (!event.currentTarget.contains(event.relatedTarget)) setPaused(false); }}>
    <span role="status">{children}</span>{action}<IconButton name="line-close" label={closeLabel} onClick={onClose} />
  </aside>;
}

export function Toast(props: Parameters<typeof OpenToast>[0]) { return props.open ? <OpenToast {...props} /> : null; }

/** 복구 동작이 있는 알림은 명시적으로 닫도록 기본 duration=0. */
export function Snackbar(props: Parameters<typeof Toast>[0]) { return <Toast {...props} duration={props.duration ?? 0} />; }
