import type { ReactNode } from "react";
import { Gnb } from "./Gnb";
import { Footer, TopNavigation } from "./Navigation";

/** Standalone mobile task frame: use Section/Divider inside and CtaBar in footer. */
export function TaskPage({ title, backHref, actions, info, children, footer }: {
  title: string; backHref?: string; actions?: ReactNode; info?: ReactNode; children: ReactNode; footer?: ReactNode;
}) {
  return <div className="kit-task-page"><TopNavigation platform="mobile" title={title} backHref={backHref} actions={actions} />{info}<main>{children}</main>{footer}</div>;
}

/** Agent-mode mobile feed frame, matching the organizer mobile-feed template. */
export function FeedPage({ title, actions, children, footer }: {
  title: string; actions?: ReactNode; children: ReactNode; footer?: ReactNode;
}) {
  return <div data-mode="agent" className="kit-feed-canvas"><div className="kit-feed-page">
    <header className="kit-feed-head"><h1 className="title-medium-bold">{title}</h1>{actions && <div className="kds-topnav__actions">{actions}</div>}</header>
    <main>{children}</main>{footer && <div className="kit-page-dock">{footer}</div>}
  </div></div>;
}

/** Standalone PC frame: GNB 72, centered content 1080, and organizer footer. */
export function PcPage({ items, actions, children, footer }: {
  items: { href: string; label: string }[]; actions?: ReactNode; children: ReactNode; footer?: ReactNode;
}) {
  return <div className="kit-pc-page"><Gnb items={items} actions={actions} /><main className="kds-container">{children}</main>{footer && <Footer>{footer}</Footer>}</div>;
}
