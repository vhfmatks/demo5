// URL 기반 페이지네이션 (JS 불필요). 현재 searchParams 를 유지한 채 page 만 바꾼다.
import Link from "next/link";
import type { PageMeta } from "@/lib/error-codes";

/** 처음·끝·현재±1 만 보인다(360 폭에서 한 줄). null = 생략(…) */
export function pageWindow(page: number, last: number): (number | null)[] {
  const keep = [...new Set([1, page - 1, page, page + 1, last])].filter((p) => p >= 1 && p <= last).sort((a, b) => a - b);
  return keep.flatMap((p, i) => (i > 0 && p - keep[i - 1] > 1 ? [null, p] : [p]));
}

export function Pagination({
  meta,
  basePath,
  params,
}: {
  meta: PageMeta;
  basePath: string;
  params: Record<string, string | undefined>;
}) {
  const last = Math.max(1, Math.ceil(meta.total / meta.pageSize));
  if (last === 1) return null;
  const href = (page: number) => {
    const sp = new URLSearchParams(Object.entries(params).filter((e): e is [string, string] => !!e[1]));
    sp.set("page", String(page));
    return `${basePath}?${sp}`;
  };
  return (
    <nav aria-label="페이지" className="kds-pagination kit-pagination">
      {pageWindow(meta.page, last).map((p, i) => p === null ? (
        // biome-ignore lint/suspicious/noArrayIndexKey: 생략 표시는 위치가 곧 식별자
        <span key={`gap-${i}`} aria-hidden="true" className="self-center text-muted">…</span>
      ) : (
        <Link
          key={p}
          href={href(p)}
          aria-current={p === meta.page ? "page" : undefined}
        >
          {p}
        </Link>
      ))}
    </nav>
  );
}
