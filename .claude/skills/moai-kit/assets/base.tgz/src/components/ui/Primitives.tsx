import Link from "next/link";
import type { ComponentProps, ReactNode } from "react";
import { cn } from "./cn";
import { Icon } from "./Icon";

export function Divider({ band = false }: { band?: boolean }) { return <hr className={band ? "kds-divider-band" : "kds-divider"} />; }
export function Loading({ label = "처리 중입니다. 잠시만 기다려 주세요." }: { label?: string }) {
  return <div role="status" className="body-medium-medium flex items-center gap-2 text-muted"><Icon name="line-loading" />{label}</div>;
}
export function Skeleton({ label = "불러오는 중", lines = 3 }: { label?: string; lines?: number }) {
  return <div role="status" aria-label={label} aria-busy="true" className="kit-skeleton">
    <span className="sr-only">{label}</span>{Array.from({ length: Math.max(1, Math.min(20, lines)) }, (_, index) => index + 1).map((line) => <span key={line} aria-hidden="true" />)}
  </div>;
}
export function PageIndicator({ current, total, label = "현재 위치" }: { current: number; total: number; label?: string }) {
  return <div className="kds-dots" role="img" aria-label={`${label}: ${current} / ${total}`}>
    {Array.from({ length: Math.max(0, Math.min(20, total)) }, (_, index) => index + 1).map((position) => <span key={position} aria-hidden="true" aria-current={position === current ? "step" : undefined} />)}
  </div>;
}
export function Notice({ title, children, actions }: { title: string; children?: ReactNode; actions?: ReactNode }) {
  return <aside className="kds-notice"><div><strong className="kds-notice__title">{title}</strong>
    {children && <div className="kds-notice__body">{children}</div>}</div>{actions}</aside>;
}
export function KeyValue({ label, children }: { label: string; children: ReactNode }) {
  return <div className="kds-kv"><span className="kds-kv__label">{label}</span><span className="kds-kv__value">{children}</span></div>;
}
export function LinkList({ items, divided = false, label }: { items: { href: string; label: string }[]; divided?: boolean; label: string }) {
  return <nav aria-label={label}><ul className={cn("kds-list", divided && "kds-list--divided")}>
    {items.map((item) => <li key={item.href}><Link href={item.href}>{item.label}<Icon name="line-chevron_right" size={20} /></Link></li>)}
  </ul></nav>;
}
export function FeedCard({ children, className }: { children: ReactNode; className?: string }) {
  return <article className={cn("kds-feed-card", className)}>{children}</article>;
}
export function FeedSection({ title, actions, children }: { title: string; actions?: ReactNode; children: ReactNode }) {
  return <section className="kds-feed-section"><h2 className="kds-feed-section__title">{title}{actions}</h2>{children}</section>;
}
export function HorizontalScroll({ label, children }: { label: string; children: ReactNode }) {
  return <section className="kds-hscroll" aria-label={label}>{children}</section>;
}
export function ItemTile({ title, description, href, image, children }: { title: string; description?: string; href?: string; image?: ReactNode; children?: ReactNode }) {
  const content = <>{image}<strong className="title-small-bold">{title}</strong>{description && <p className="body-small-medium text-muted">{description}</p>}{children}</>;
  return href ? <Link href={href} className="kds-card kds-card--link">{content}</Link> : <article className="kds-card">{content}</article>;
}
export function FloatingActionButton({ label, name, ...rest }: Omit<ComponentProps<"button">, "children"> & { label: string; name: ComponentProps<typeof Icon>["name"] }) {
  return <button type="button" className="kit-fab" aria-label={label} {...rest}><Icon name={name} /></button>;
}
