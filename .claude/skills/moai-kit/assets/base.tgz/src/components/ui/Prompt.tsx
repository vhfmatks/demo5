"use client";

import Link from "next/link";
import { type ReactNode, useId, useRef, useState } from "react";
import { Button, IconButton } from "./Button";
import { Icon } from "./Icon";
import { cn } from "./cn";

export type PromptAttachment = { id: string; name: string };
export function PromptTextField({ label = "AI에게 질문", name = "prompt", value, defaultValue = "", onValueChange, onSend, onStop, onFilesChange, onVoice,
  processing = false, disabled = false, attachments = [], onRemoveAttachment, placeholder = "원하는 업무를 입력하세요", disclaimer }: {
  label?: string; name?: string; value?: string; defaultValue?: string; onValueChange?: (value: string) => void;
  onSend: (value: string) => void; onStop?: () => void; onFilesChange?: (files: File[]) => void; onVoice?: () => void;
  processing?: boolean; disabled?: boolean; attachments?: PromptAttachment[]; onRemoveAttachment?: (id: string) => void;
  placeholder?: string; disclaimer?: string;
}) {
  const id = useId(); const file = useRef<HTMLInputElement>(null); const [local, setLocal] = useState(defaultValue);
  const current = value ?? local;
  return <form className="kds-prompt-dock kds-prompt-dock--inline kit-prompt-composer" aria-busy={processing || undefined} onSubmit={(event) => {
    event.preventDefault(); if (!disabled && !processing && current.trim()) onSend(current.trim());
  }}>
    <label htmlFor={id} className="sr-only">{label}</label>
    {attachments.length > 0 && <ul className="kit-attachments">{attachments.map((attachment) => <li key={attachment.id}>{attachment.name}
      {onRemoveAttachment && <IconButton name="line-close" label={`${attachment.name} 첨부 제거`} disabled={disabled || processing} onClick={() => onRemoveAttachment(attachment.id)} />}
    </li>)}</ul>}
    <textarea id={id} name={name} value={current} rows={1} placeholder={placeholder} disabled={disabled || processing}
      aria-describedby={disclaimer ? `${id}-disclaimer` : undefined} className="kit-prompt-input"
      onChange={(event) => { if (value === undefined) setLocal(event.currentTarget.value); onValueChange?.(event.currentTarget.value); }}
      onKeyDown={(event) => { if (event.key === "Enter" && !event.nativeEvent.isComposing && (event.ctrlKey || event.metaKey)) { event.preventDefault(); event.currentTarget.form?.requestSubmit(); } }} />
    <div className="flex flex-wrap items-center justify-between gap-2"><div className="flex gap-2">
      {onFilesChange && <><input ref={file} type="file" multiple aria-label="파일 첨부" className="sr-only" disabled={disabled || processing}
        onChange={(event) => { onFilesChange(Array.from(event.currentTarget.files ?? [])); event.currentTarget.value = ""; }} />
        <IconButton name="line-attach" label="파일 선택" disabled={disabled || processing} onClick={() => file.current?.click()} /></>}
      {onVoice && <IconButton name="line-mic" label="음성 입력" disabled={disabled || processing} onClick={onVoice} />}
    </div>{processing && onStop ? <Button key="stop" type="button" variant="tertiary" onClick={(event) => { event.preventDefault(); onStop(); }}>생성 중지</Button>
      : <Button key="send" type="submit" disabled={disabled || !current.trim()} loading={processing}>전송</Button>}</div>
    {disclaimer && <p id={`${id}-disclaimer`} className="caption-medium-medium text-muted">{disclaimer}</p>}
  </form>;
}
export function PromptInput({ children }: { children: ReactNode }) { return <div className="kds-chat__user">{children}</div>; }
export type PromptSource = { label: string; href: string };
export function PromptOutput({ children, sources, onLike, onDislike }: { children: ReactNode; sources?: PromptSource[]; onLike?: () => void; onDislike?: () => void }) {
  return <article className="kds-chat__answer">{children}
    {sources?.length ? <nav aria-label="응답 출처" className="mt-4"><ol className="body-small-medium">{sources.map((source) => <li key={`${source.href}-${source.label}`}><Link href={source.href}>{source.label}</Link></li>)}</ol></nav> : null}
    {(onLike || onDislike) && <div className="mt-2 flex gap-2">{onLike && <IconButton name="line-like" label="도움이 됐어요" onClick={onLike} />}
      {onDislike && <IconButton name="line-dislike" label="도움이 안 됐어요" onClick={onDislike} />}</div>}
  </article>;
}
export function PromptConversation({ label = "AI 대화", children }: { label?: string; children: ReactNode }) {
  return <section aria-label={label} className="kds-chat kds-chat--on-white">{children}</section>;
}
export function PromptSuggestions({ items, onSelect }: { items: string[]; onSelect: (prompt: string) => void }) {
  return <fieldset aria-label="추천 질문" className="flex flex-wrap gap-2 border-0 p-0">{items.map((item) => <Button key={item} variant="tertiary" onClick={() => onSelect(item)}>{item}</Button>)}</fieldset>;
}
export function ProcessIndicator({ state = "processing", text, details }: { state?: "processing" | "generating" | "complete" | "canceled" | "error"; text: string; details?: ReactNode }) {
  const busy = state === "processing" || state === "generating";
  return <div className="body-small-medium"><p role="status" className={cn("flex items-center gap-2", state === "error" ? "text-danger" : "text-muted")}>
    <Icon name={state === "error" ? "line-warning" : busy ? "line-loading" : "line-check"} size={16} />{text}</p>
    {details && <details className="kds-chat__thinking"><summary>처리 과정 보기</summary>{details}</details>}
  </div>;
}
export function ContextPanel({ title, children, open = true, onClose }: { title: string; children: ReactNode; open?: boolean; onClose?: () => void }) {
  const id = useId();
  if (!open) return null;
  return <aside aria-labelledby={id} className="kit-context-panel"><div className="flex items-center justify-between gap-2">
    <h2 id={id} className="title-large-bold">{title}</h2>{onClose && <IconButton name="line-close" label={`${title} 닫기`} onClick={onClose} />}
  </div>{children}</aside>;
}
export function CodeBlock({ code, language }: { code: string; language?: string }) {
  const [message, setMessage] = useState("");
  const copy = async () => { try { await navigator.clipboard.writeText(code); setMessage("복사했습니다."); } catch { setMessage("복사하지 못했습니다. 코드를 직접 선택해 주세요."); } };
  return <div className="kit-code-block"><div className="flex items-center justify-between gap-2"><span>{language ?? "코드"}</span>
    <Button variant="text" onClick={() => { void copy(); }}>코드 복사</Button></div><pre><code>{code}</code></pre><span role="status">{message}</span></div>;
}
export function AiMark() { return <span className="kds-ai-mark" role="img" aria-label="AI" />; }
