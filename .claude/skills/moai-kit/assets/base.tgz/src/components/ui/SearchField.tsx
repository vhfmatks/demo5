import type { ComponentProps } from "react";
import { IconButton } from "./Button";
import { cn } from "./cn";

/** GET 필터 폼 안의 KDS 검색 입력. 오른쪽 버튼이 바깥 폼을 제출한다. */
export function SearchField({ label = "검색", className, ...rest }: Omit<ComponentProps<"input">, "type" | "aria-label"> & { label?: string }) {
  return <div className={cn("kds-search", className)}>
    <input type="search" aria-label={label} {...rest} />
    <IconButton type="submit" name="line-search" label="검색" />
  </div>;
}
