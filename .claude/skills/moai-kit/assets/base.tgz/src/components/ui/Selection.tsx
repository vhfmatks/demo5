import type { ComponentProps, ReactNode } from "react";
import { cn } from "./cn";

export function Chip({ selected, children, className, ...rest }: ComponentProps<"button"> & { selected?: boolean }) {
  return <button type="button" className={cn("kds-chip", className)} aria-pressed={selected ?? false} {...rest}>{children}</button>;
}
export function ChipGroup({ label, children }: { label: string; children: ReactNode }) {
  return <fieldset aria-label={label} className="kds-chips border-0 p-0">{children}</fieldset>;
}
export function SelectButton({ label, description, type = "radio", className, ...rest }:
  Omit<ComponentProps<"input">, "type"> & { label: string; description?: string; type?: "radio" | "checkbox" }) {
  return <label className={cn("kds-select-button kit-select-button", className)}>
    <input type={type} {...rest} /><span className="kds-select-button__title">{label}</span>
    {description && <span className="kds-select-button__sub">{description}</span>}
  </label>;
}
export function SelectButtonGroup({ label, columns = 2, children }: { label: string; columns?: 1 | 2 | 3; children: ReactNode }) {
  return <fieldset className="min-w-0 border-0 p-0"><legend className="kds-field__label">{label}</legend>
    <div className={cn("kds-select-buttons", columns === 1 && "kds-select-buttons--list", columns === 3 && "kds-select-buttons--3col")}>{children}</div>
  </fieldset>;
}
