"use client";

import { useId, useState } from "react";

export function Slider({ label, name, value, defaultValue = 0, min = 0, max = 100, step = 1, disabled, unit = "", onValueChange }: {
  label: string; name?: string; value?: number; defaultValue?: number; min?: number; max?: number; step?: number;
  disabled?: boolean; unit?: string; onValueChange?: (value: number) => void;
}) {
  const id = useId(); const [local, setLocal] = useState(defaultValue);
  const current = value ?? local;
  return <div className="kit-slider">
    <div className="flex items-center justify-between gap-2"><label htmlFor={id} className="kds-field__label">{label}</label>
      <output htmlFor={id}>{current}{unit}</output></div>
    <input id={id} type="range" name={name} value={current} min={min} max={max} step={step} disabled={disabled}
      aria-valuetext={`${current}${unit}`} onChange={(event) => {
        const next = event.currentTarget.valueAsNumber; if (value === undefined) setLocal(next); onValueChange?.(next);
      }} />
    <div className="body-small-medium flex justify-between text-muted"><span>{min}{unit}</span><span>{max}{unit}</span></div>
  </div>;
}

/** 겹친 핸들 대신 이름 있는 두 슬라이더로 키보드 접근을 제공한다. */
export function RangeSlider({ label, value, defaultValue = [0, 100], min = 0, max = 100, step = 1, disabled, unit, names, onValueChange }: {
  label: string; value?: [number, number]; defaultValue?: [number, number]; min?: number; max?: number; step?: number;
  disabled?: boolean; unit?: string; names?: [string, string]; onValueChange?: (value: [number, number]) => void;
}) {
  const [local, setLocal] = useState(defaultValue); const current = value ?? local;
  const change = (next: [number, number]) => { if (value === undefined) setLocal(next); onValueChange?.(next); };
  return <fieldset className="min-w-0 border-0 p-0"><legend className="kds-field__label">{label}</legend>
    <div className="grid gap-4 md:grid-cols-2">
      <Slider label="최솟값" name={names?.[0]} value={current[0]} min={min} max={current[1]} step={step} disabled={disabled} unit={unit}
        onValueChange={(next) => change([next, current[1]])} />
      <Slider label="최댓값" name={names?.[1]} value={current[1]} min={current[0]} max={max} step={step} disabled={disabled} unit={unit}
        onValueChange={(next) => change([current[0], next])} />
    </div>
  </fieldset>;
}
