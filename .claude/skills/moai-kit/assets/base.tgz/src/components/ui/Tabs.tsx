"use client";

import { type ReactNode, useId, useRef, useState } from "react";
import { cn } from "./cn";

export type TabItem = { value: string; label: string; content: ReactNode; disabled?: boolean };
export function Tabs({ items, label, value, defaultValue, onValueChange, type = "fixed" }: {
  items: TabItem[]; label: string; value?: string; defaultValue?: string;
  onValueChange?: (value: string) => void; type?: "fixed" | "scrollable";
}) {
  const id = useId(); const root = useRef<HTMLDivElement>(null);
  const enabled = items.filter((item) => !item.disabled);
  const [local, setLocal] = useState(defaultValue ?? enabled[0]?.value);
  const chosen = value ?? local;
  const selected = enabled.some((item) => item.value === chosen) ? chosen : enabled[0]?.value;
  const choose = (next: string) => { if (value === undefined) setLocal(next); onValueChange?.(next); };
  return <div ref={root}>
    <div role="tablist" aria-label={label} className={cn("kds-tabs", type === "scrollable" && "kds-tabs--scroll")}>
      {items.map((item, index) => <button key={item.value} type="button" role="tab" id={`${id}-tab-${index}`}
        aria-selected={selected === item.value} aria-controls={`${id}-panel-${index}`} disabled={item.disabled}
        tabIndex={selected === item.value ? 0 : -1} onClick={() => choose(item.value)}
        onKeyDown={(event) => {
          if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
          event.preventDefault();
          const at = enabled.findIndex((entry) => entry.value === item.value);
          const next = event.key === "Home" ? enabled[0] : event.key === "End" ? enabled.at(-1)
            : enabled[(at + (event.key === "ArrowRight" ? 1 : -1) + enabled.length) % enabled.length];
          if (!next) return;
          choose(next.value);
          root.current?.querySelector<HTMLButtonElement>(`[id="${id}-tab-${items.indexOf(next)}"]`)?.focus();
        }}>{item.label}</button>)}
    </div>
    {items.map((item, index) => <div key={item.value} role="tabpanel" id={`${id}-panel-${index}`}
      aria-labelledby={`${id}-tab-${index}`} hidden={item.value !== selected} className="py-4">{item.content}</div>)}
  </div>;
}
