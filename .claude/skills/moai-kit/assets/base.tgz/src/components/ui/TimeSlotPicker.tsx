import { cn } from "./cn";

/** native radio로 선택·방향키·FormData를 제공한다. */
export function TimeSlotPicker({ label, name, options, value, defaultValue, onValueChange }: {
  label: string; name: string; options: { value: string; label: string; disabled?: boolean }[];
  value?: string; defaultValue?: string; onValueChange?: (value: string) => void;
}) {
  return <fieldset className="min-w-0 border-0 p-0"><legend className="kds-field__label">{label}</legend>
    <div className="kds-time-buttons">{options.map((option) => <label key={option.value} className={cn("kds-time-button", "kit-time-slot")}>
      <input type="radio" name={name} value={option.value} disabled={option.disabled}
        checked={value === undefined ? undefined : value === option.value} defaultChecked={value === undefined ? defaultValue === option.value : undefined}
        onChange={onValueChange ? () => onValueChange(option.value) : undefined} /><span>{option.label}</span>
    </label>)}</div>
  </fieldset>;
}
