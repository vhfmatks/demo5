export const WEEKDAYS = ["일", "월", "화", "수", "목", "금", "토"] as const;

export type DateMonth = { year: number; month: number };
export type CalendarDay = {
  value: string;
  day: number;
  disabled: boolean;
  sunday: boolean;
  today: boolean;
};

const ISO_DATE = /^(\d{4})-(\d{2})-(\d{2})$/;
const pad = (value: number) => String(value).padStart(2, "0");

export const isLeapYear = (year: number) => (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;

export const daysInMonth = (year: number, month: number) => {
  if (month < 0 || month > 11) throw new Error("month must be between 0 and 11");
  return [31, isLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month];
};

/** Strict ISO YYYY-MM-DD parser. Invalid calendar dates, including Feb 29 in non-leap years, return null. */
export const parseDate = (value: string | number | null | undefined): string | null => {
  if (value === null || value === undefined || value === "") return null;
  const match = ISO_DATE.exec(String(value));
  if (!match) return null;
  const [year, month, day] = [Number(match[1]), Number(match[2]), Number(match[3])];
  if (month < 1 || month > 12 || day < 1 || day > daysInMonth(year, month - 1)) return null;
  return `${pad(year)}-${pad(month)}-${pad(day)}`;
};

export const formatDate = (value: string | number | null | undefined) => {
  const date = parseDate(value);
  return date ? date.replaceAll("-", ".") : "";
};

export const todayValue = () => {
  const now = new Date();
  return `${pad(now.getFullYear())}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
};

export const partsOf = (value: string) => {
  const date = parseDate(value);
  if (!date) throw new Error(`invalid date: ${value}`);
  return { year: Number(date.slice(0, 4)), month: Number(date.slice(5, 7)) - 1, day: Number(date.slice(8, 10)) };
};

export const firstDayOfMonth = (value: string) => {
  const { year, month } = partsOf(value);
  return `${pad(year)}-${pad(month + 1)}-01`;
};

/** Month arithmetic keeps the day when possible and clamps month-end dates (Jan 31 -> Feb 28/29). */
export const addMonths = (value: string, amount: number) => {
  const { year, month, day } = partsOf(value);
  const absolute = year * 12 + month + amount;
  const nextYear = Math.floor(absolute / 12);
  const nextMonth = absolute % 12;
  if (nextYear < 0 || nextYear > 9999) return null;
  return `${pad(nextYear)}-${pad(nextMonth + 1)}-${pad(Math.min(day, daysInMonth(nextYear, nextMonth)))}`;
};

export const addDays = (value: string, amount: number) => {
  const { year, month, day } = partsOf(value);
  const date = new Date(year, month, day + amount);
  if (Number.isNaN(date.getTime()) || date.getFullYear() < 0 || date.getFullYear() > 9999) return null;
  return `${pad(date.getFullYear())}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
};

export const isDateInRange = (value: string, min?: string | null, max?: string | null) => {
  const date = parseDate(value);
  const minimum = parseDate(min);
  const maximum = parseDate(max);
  return !!date && (!minimum || date >= minimum) && (!maximum || date <= maximum);
};

export const monthLabel = ({ year, month }: DateMonth) => `${year}년 ${month + 1}월`;

/** One KDS calendar month: leading blanks for the Sunday-start week, then every calendar day. */
export const calendarDays = ({ year, month, min, max, today }: DateMonth & { min?: string | null; max?: string | null; today?: string | null }) => {
  if (month < 0 || month > 11) throw new Error("month must be between 0 and 11");
  const weekdayOfFirst = new Date(year, month, 1).getDay();
  return [
    ...Array.from({ length: weekdayOfFirst }, () => null),
    ...Array.from({ length: daysInMonth(year, month) }, (_, index) => {
      const day = index + 1;
      const value = `${pad(year)}-${pad(month + 1)}-${pad(day)}`;
      return { value, day, disabled: !isDateInRange(value, min, max), sunday: weekdayOfFirst === 0 ? index % 7 === 0 : (weekdayOfFirst + index) % 7 === 0, today: value === today };
    }),
  ];
};
