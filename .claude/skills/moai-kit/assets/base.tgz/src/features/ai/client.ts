// [서버] AI 공급자 어댑터: 모델 목록·대화. 종류별 API 차이는 여기만 안다.
// 실제 HTTP 는 server/outbound.ts(리다이렉트 거부·시간 제한·크기 상한). 주소 규칙은 isAllowedAiUrl. 키는 오류·로그에 넣지 않는다.
import "server-only";
import { OutboundError, outboundFetch } from "@/server/outbound";
import { isAllowedAiUrl, type AiKind } from "./schema";

export type AiTarget = { kind: AiKind; baseUrl: string; apiKey: string };
export type ChatInput = { model: string; system?: string; prompt: string; maxTokens: number; timeoutMs?: number };
export type ChatOutput = { text: string; inputTokens: number | null; outputTokens: number | null };

/** 원인별 실패. service 가 관리자 시험(원인 공개 400)·기능 호출(502/504)로 바꾼다. */
export class AiCallError extends Error {
  constructor(
    public readonly reason: "url" | "network" | "timeout" | "too_large" | "http" | "format",
    public readonly status?: number,
    /** 공급자가 돌려준 오류 설명(앞 160자) */
    public readonly detail?: string,
  ) {
    super(reason);
    this.name = "AiCallError";
  }
}

async function call(t: AiTarget, path: string, json: unknown | undefined, timeoutMs: number): Promise<Record<string, unknown>> {
  if (!isAllowedAiUrl(t.baseUrl)) throw new AiCallError("url");
  const headers: Record<string, string> = t.kind === "anthropic"
    ? { "x-api-key": t.apiKey, "anthropic-version": "2023-06-01" }
    : t.apiKey ? { authorization: `Bearer ${t.apiKey}` } : {};
  let res: Awaited<ReturnType<typeof outboundFetch>>;
  try {
    res = await outboundFetch(`${t.baseUrl}${path}`, { headers, json, timeoutMs });
  } catch (error) {
    throw error instanceof OutboundError ? new AiCallError(error.reason) : error;
  }
  let body: unknown = null;
  try {
    body = JSON.parse(res.text);
  } catch {
    body = null;
  }
  if (!res.ok) {
    const message = (body as { error?: { message?: unknown } } | null)?.error?.message;
    throw new AiCallError("http", res.status, typeof message === "string" ? message.slice(0, 160) : undefined);
  }
  if (!body || typeof body !== "object") throw new AiCallError("format");
  return body as Record<string, unknown>;
}

/** 공급자가 제공하는 모델 ID 목록 (연결 시험 겸용) */
export async function listModels(t: AiTarget): Promise<string[]> {
  const json = await call(t, t.kind === "anthropic" ? "/v1/models" : "/models", undefined, 15_000);
  if (!Array.isArray(json.data)) throw new AiCallError("format");
  return json.data.map((m) => (m as { id?: unknown }).id).filter((id): id is string => typeof id === "string").sort();
}

export async function chat(t: AiTarget, input: ChatInput): Promise<ChatOutput> {
  const timeout = input.timeoutMs ?? 60_000;
  if (t.kind === "anthropic") {
    const json = await call(t, "/v1/messages", {
      model: input.model, max_tokens: input.maxTokens, system: input.system, messages: [{ role: "user", content: input.prompt }],
    }, timeout);
    if (!Array.isArray(json.content)) throw new AiCallError("format");
    const usage = json.usage as { input_tokens?: number; output_tokens?: number } | undefined;
    return {
      text: json.content.map((c: { type?: string; text?: unknown }) => (c.type === "text" ? String(c.text ?? "") : "")).join(""),
      inputTokens: usage?.input_tokens ?? null,
      outputTokens: usage?.output_tokens ?? null,
    };
  }
  // OpenAI 본가의 최신 모델은 max_tokens 대신 max_completion_tokens 만 받는다. 호환 서버(Ollama·vLLM 등)는 max_tokens.
  const official = new URL(t.baseUrl).hostname === "api.openai.com";
  const json = await call(t, "/chat/completions", {
    model: input.model,
    messages: [...(input.system ? [{ role: "system", content: input.system }] : []), { role: "user", content: input.prompt }],
    [official ? "max_completion_tokens" : "max_tokens"]: input.maxTokens,
  }, timeout);
  const choice = Array.isArray(json.choices) ? (json.choices[0] as { message?: { content?: unknown } } | undefined) : undefined;
  if (!choice) throw new AiCallError("format");
  const usage = json.usage as { prompt_tokens?: number; completion_tokens?: number } | undefined;
  return {
    text: typeof choice.message?.content === "string" ? choice.message.content : "",
    inputTokens: usage?.prompt_tokens ?? null,
    outputTokens: usage?.completion_tokens ?? null,
  };
}

/** 관리자에게 보여 줄 원인 (키는 포함하지 않는다) */
export function describeAiError(e: AiCallError): string {
  const detail = e.detail ? ` (${e.detail})` : "";
  switch (e.reason) {
    case "url": return "허용되지 않은 주소입니다.";
    case "timeout": return "응답 시간이 초과되었습니다.";
    case "network": return "연결할 수 없습니다. 주소·네트워크를 확인해 주세요.";
    case "too_large": return "응답이 너무 큽니다.";
    case "format": return "응답 형식을 해석할 수 없습니다. 종류·주소를 확인해 주세요.";
    default: {
      const hint = e.status === 401 || e.status === 403 ? "키가 올바르지 않거나 권한이 없습니다."
        : e.status === 404 ? "주소 또는 모델 ID 를 확인해 주세요."
        : e.status === 429 ? "공급자 요청 한도를 넘었습니다." : "공급자가 요청을 거부했습니다.";
      return `HTTP ${e.status}: ${hint}${detail}`;
    }
  }
}
