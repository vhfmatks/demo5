"use client";
// [Client] 공급자·모델 행 동작: 모델 시험·기본 지정·삭제(확인 대화상자)
import { useState } from "react";
import { Alert, Button, ConfirmDialog } from "@/components/ui";
import { apiClient } from "@/lib/api-client";
import { useMutation } from "@/lib/use-mutation";
import type { AiModelDto, ModelTestResult } from "../schema";

export function AiDeleteButton({ url, name, body }: { url: string; name: string; body?: string }) {
  const [open, setOpen] = useState(false);
  const m = useMutation(() => apiClient.del(url), { onSuccess: () => setOpen(false) });
  return (
    <>
      <Button variant="text" size="small" aria-label={`${name} 삭제`} onClick={() => setOpen(true)}>삭제</Button>
      <ConfirmDialog open={open} title={`${name} 을(를) 삭제할까요?`} body={body} confirmLabel="삭제 확인" loading={m.pending}
        onConfirm={() => m.run(undefined)} onCancel={() => setOpen(false)}>
        <Alert>{m.error}</Alert>
      </ConfirmDialog>
    </>
  );
}

export function AiModelActions({ row }: { row: AiModelDto }) {
  const [result, setResult] = useState<ModelTestResult | null>(null);
  const test = useMutation(() => apiClient.post<ModelTestResult>("/api/v1/admin/ai/models/test", { providerId: row.provider.id, model: row.model }),
    { onSuccess: setResult, refresh: false });
  const makeDefault = useMutation(() => apiClient.patch(`/api/v1/admin/ai/models/${row.id}`, { isDefault: true }));
  return (
    <div className="flex flex-col gap-1">
      <div className="flex flex-wrap gap-1">
        <Button variant="text" size="small" aria-label={`${row.label} 시험`} loading={test.pending} onClick={() => test.run(undefined)}>시험</Button>
        {!row.isDefault && (
          <Button variant="text" size="small" aria-label={`${row.label} 기본으로`} loading={makeDefault.pending} onClick={() => makeDefault.run(undefined)}>기본으로</Button>
        )}
        <AiDeleteButton url={`/api/v1/admin/ai/models/${row.id}`} name={row.label} />
      </div>
      <Alert>{test.error ?? makeDefault.error}</Alert>
      <Alert tone="info">{result && `응답: ${result.reply || "(빈 응답)"} · ${result.ms}ms`}</Alert>
    </div>
  );
}
