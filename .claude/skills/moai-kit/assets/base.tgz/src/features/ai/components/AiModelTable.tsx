// [Server] 등록된 AI 모델 표. 행 동작(시험·기본·삭제)만 Client(AiModelActions).
import { DataTable, Tag, type Column } from "@/components/ui";
import type { AiModelDto } from "../schema";
import { AiModelActions } from "./AiActions";

export const AiModelTable = ({ rows }: { rows: AiModelDto[] }) => {
  const columns: Column<AiModelDto>[] = [
    { key: "label", header: "호출 이름", render: (m) => <span className="flex items-center gap-2">{m.label}{m.isDefault && <Tag tone="info" testId="default-model">기본</Tag>}</span> },
    { key: "model", header: "모델 ID", render: (m) => m.model },
    { key: "provider", header: "공급자", render: (m) => m.provider.name },
    { key: "actions", header: "", render: (m) => <AiModelActions row={m} /> },
  ];
  return <DataTable rows={rows} columns={columns} empty="등록된 모델이 없습니다." />;
};
