// [Server] 등록된 AI 공급자 표. 키는 끝 4자리만.
import { DataTable, type Column } from "@/components/ui";
import { AI_KIND_LABEL, type AiProviderDto } from "../schema";
import { AiDeleteButton } from "./AiActions";

export const AiProviderTable = ({ rows }: { rows: AiProviderDto[] }) => {
  const columns: Column<AiProviderDto>[] = [
    { key: "name", header: "이름", render: (p) => p.name },
    { key: "kind", header: "종류", render: (p) => AI_KIND_LABEL[p.kind] },
    { key: "baseUrl", header: "API 주소", render: (p) => p.baseUrl },
    { key: "key", header: "키", render: (p) => p.apiKeyHint ?? "없음" },
    { key: "actions", header: "", render: (p) => <AiDeleteButton url={`/api/v1/admin/ai/providers/${p.id}`} name={p.name} body="이 공급자의 모델도 함께 삭제됩니다." /> },
  ];
  return <DataTable rows={rows} columns={columns} empty="등록된 공급자가 없습니다." />;
};
