"use client";
// [Client] 모델 등록: 공급자 선택 → 모델 ID 제안(공급자 목록) → [모델 시험](저장 안 함) → [등록](서버가 다시 시험 후 저장).
import { useRef, useState } from "react";
import { Alert, Button, Checkbox, Field, Input, Select } from "@/components/ui";
import { apiClient } from "@/lib/api-client";
import { useMutation } from "@/lib/use-mutation";
import type { AiModelDto, AiProviderDto, ModelTestResult } from "../schema";

const read = (form: HTMLFormElement) => {
  const v = new FormData(form);
  const s = (k: string) => String(v.get(k) ?? "");
  return { providerId: s("providerId"), model: s("model"), label: s("label"), isDefault: v.get("isDefault") === "on" };
};

export function ModelForm({ providers }: { providers: AiProviderDto[] }) {
  const ref = useRef<HTMLFormElement>(null);
  const [result, setResult] = useState<ModelTestResult | null>(null);
  const [suggest, setSuggest] = useState<string[]>([]);
  const list = useMutation((id: string) => apiClient.get<string[]>(`/api/v1/admin/ai/providers/${id}/models`), { onSuccess: setSuggest, refresh: false });
  const test = useMutation((v: ReturnType<typeof read>) => apiClient.post<ModelTestResult>("/api/v1/admin/ai/models/test", { providerId: v.providerId, model: v.model }),
    { onSuccess: setResult, refresh: false });
  const save = useMutation((v: ReturnType<typeof read>) => apiClient.post<AiModelDto>("/api/v1/admin/ai/models", v), {
    onSuccess: () => {
      ref.current?.reset();
      setResult(null);
      setSuggest([]);
    },
  });
  if (!providers.length) return <Alert tone="info">먼저 공급자를 등록해 주세요.</Alert>;
  const fe = { ...test.fieldErrors, ...save.fieldErrors };
  return (
    <form ref={ref} className="flex max-w-xl flex-col gap-6" onSubmit={(e) => { e.preventDefault(); save.run(read(e.currentTarget)); }}>
      <Field label="공급자" name="providerId" required error={fe.providerId}>
        <Select name="providerId" placeholder="선택" options={providers.map((p) => ({ value: p.id, label: p.name }))} invalid={!!fe.providerId}
          onChange={(e) => { setResult(null); setSuggest([]); if (e.target.value) list.run(e.target.value); }} />
      </Field>
      <Field label="모델 ID" name="model" required error={fe.model} hint={suggest.length ? `공급자 제공 모델 ${suggest.length}개 중에서 고르거나 직접 입력` : "공급자의 모델 ID (예: gpt-4o-mini, claude-sonnet-5-5)"}>
        <Input name="model" list="ai-model-suggest" autoComplete="off" invalid={!!fe.model} onChange={() => setResult(null)} />
      </Field>
      <datalist id="ai-model-suggest">{suggest.map((m) => <option key={m} value={m} />)}</datalist>
      <Field label="호출 이름" name="label" error={fe.label} hint="기능 코드가 부르는 이름(aiComplete 의 model). 비우면 모델 ID">
        <Input name="label" invalid={!!fe.label} />
      </Field>
      <Checkbox name="isDefault">기본 모델로 지정 (첫 모델은 자동으로 기본)</Checkbox>
      <Alert>{list.error ?? test.error ?? save.error}</Alert>
      <Alert tone="info">{result && `응답: ${result.reply || "(빈 응답)"} · ${result.ms}ms`}</Alert>
      <div className="flex gap-2">
        <Button variant="tertiary" loading={test.pending} onClick={() => ref.current && test.run(read(ref.current))}>모델 시험</Button>
        <Button type="submit" loading={save.pending}>등록</Button>
      </div>
    </form>
  );
}
