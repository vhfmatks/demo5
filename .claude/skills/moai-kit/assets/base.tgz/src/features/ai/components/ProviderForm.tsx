"use client";
// [Client] 공급자 등록: [연결 테스트](저장 안 함) → [등록](서버가 다시 시험 후 저장). 종류를 바꾸면 기본 주소를 채운다.
import { useRef, useState } from "react";
import { Alert, Button, Field, Input, Select, toOptions } from "@/components/ui";
import { apiClient } from "@/lib/api-client";
import { useMutation } from "@/lib/use-mutation";
import { AI_DEFAULT_URL, AI_KIND_LABEL, type AiKind, type AiProviderDto, type ProviderTestResult } from "../schema";

const read = (form: HTMLFormElement) => {
  const v = Object.fromEntries(new FormData(form)) as Record<string, string>;
  return { kind: v.kind, name: v.name, baseUrl: v.baseUrl, apiKey: v.apiKey };
};

export function ProviderForm() {
  const ref = useRef<HTMLFormElement>(null);
  const [result, setResult] = useState<ProviderTestResult | null>(null);
  const [baseUrl, setBaseUrl] = useState(AI_DEFAULT_URL.openai);
  const test = useMutation((v: ReturnType<typeof read>) => apiClient.post<ProviderTestResult>("/api/v1/admin/ai/providers/test", { kind: v.kind, baseUrl: v.baseUrl, apiKey: v.apiKey }),
    { onSuccess: setResult, refresh: false });
  const save = useMutation((v: ReturnType<typeof read>) => apiClient.post<AiProviderDto>("/api/v1/admin/ai/providers", v), {
    onSuccess: () => {
      ref.current?.reset();
      setBaseUrl(AI_DEFAULT_URL.openai);
      setResult(null);
    },
  });
  const fe = { ...test.fieldErrors, ...save.fieldErrors };
  return (
    <form ref={ref} className="flex max-w-xl flex-col gap-6" onSubmit={(e) => { e.preventDefault(); save.run(read(e.currentTarget)); }}>
      <Field label="종류" name="kind" required error={fe.kind}>
        <Select name="kind" options={toOptions(AI_KIND_LABEL)} defaultValue="openai" invalid={!!fe.kind}
          onChange={(e) => { setBaseUrl(AI_DEFAULT_URL[e.target.value as AiKind]); setResult(null); }} />
      </Field>
      <Field label="이름" name="name" required error={fe.name} hint="관리용 이름 (예: OpenAI 운영, 로컬 Ollama)">
        <Input name="name" invalid={!!fe.name} />
      </Field>
      <Field label="API 주소" name="baseUrl" required error={fe.baseUrl} hint="https 주소. 로컬 모델은 http://localhost:11434/v1 처럼 이 서버 안 주소만">
        <Input name="baseUrl" value={baseUrl} onChange={(e) => setBaseUrl(e.target.value)} invalid={!!fe.baseUrl} />
      </Field>
      <Field label="API 키" name="apiKey" error={fe.apiKey} hint="암호화해 저장하고 화면에는 끝 4자리만 보입니다. 로컬 모델은 비워 둡니다.">
        <Input name="apiKey" type="password" autoComplete="off" invalid={!!fe.apiKey} />
      </Field>
      <Alert>{test.error ?? save.error}</Alert>
      <Alert tone="info">{result && `연결됨 · 모델 ${result.models.length}개 · ${result.ms}ms`}</Alert>
      <div className="flex gap-2">
        <Button variant="tertiary" loading={test.pending} onClick={() => ref.current && test.run(read(ref.current))}>연결 테스트</Button>
        <Button type="submit" loading={save.pending}>등록</Button>
      </div>
    </form>
  );
}
