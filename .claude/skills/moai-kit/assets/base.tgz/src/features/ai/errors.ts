// [공유] AI 오류 계약. 관리자 시험 실패는 원인을 보여 주고(400), 기능 호출 실패는 공통 502·504·503 으로 숨긴다.
import { defineErrors } from "../../lib/error-codes";

export const AiErrors = defineErrors({
  AI_NOT_CONFIGURED: {
    category: "SERVICE_UNAVAILABLE",
    message: "AI 모델이 등록되지 않았습니다. 관리자 포털 > AI 에서 공급자와 모델을 등록해 주세요.",
  },
  AI_TEST_FAILED: { category: "VALIDATION_ERROR", message: "AI 연결 시험에 실패했습니다." },
  AI_SECRET_UNREADABLE: { category: "INVALID_STATE", message: "저장된 키를 읽을 수 없습니다. 공급자를 삭제하고 다시 등록해 주세요." },
  AI_PROVIDER_NOT_FOUND: { category: "NOT_FOUND", message: "AI 공급자를 찾을 수 없습니다." },
  AI_MODEL_NOT_FOUND: { category: "NOT_FOUND", message: "AI 모델을 찾을 수 없습니다." },
  AI_NAME_TAKEN: { category: "CONFLICT", message: "이미 같은 이름이 있습니다." },
  AI_RATE_LIMITED: { category: "RATE_LIMITED", message: "AI 요청이 많습니다. 잠시 후 다시 시도해 주세요.", retryable: true },
});
