// [공유] AI 공급자·모델: 종류·기본 주소·입력 스키마·DTO
// 주의: drizzle-kit 이 import 하므로 "@/" 별칭 금지(상대경로만), server-only 금지
import { z } from "zod";

/** openai = OpenAI 호환 API(OpenAI·Ollama·vLLM·LM Studio·OpenRouter 등), anthropic = Anthropic Messages API */
export const AI_KINDS = ["openai", "anthropic"] as const;
export type AiKind = (typeof AI_KINDS)[number];
export const AI_KIND_LABEL: Record<AiKind, string> = { openai: "OpenAI 호환", anthropic: "Anthropic" };
export const AI_DEFAULT_URL: Record<AiKind, string> = { openai: "https://api.openai.com/v1", anthropic: "https://api.anthropic.com" };

/** https 는 어디든, http 는 이 서버 자신(localhost·127.0.0.1·[::1], 로컬 모델)만. 경로 끝 / 는 뗀다. */
export const isAllowedAiUrl = (value: string) => {
  try {
    const url = new URL(value);
    if (url.username || url.password || url.search || url.hash) return false;
    return url.protocol === "https:" || (url.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname));
  } catch {
    return false;
  }
};
const baseUrl = z.string().trim().max(300)
  .refine(isAllowedAiUrl, "https 주소(로컬 모델은 http://localhost)만 쓸 수 있습니다. 계정·query 는 넣지 않습니다.")
  .transform((v) => v.replace(/\/+$/, ""));
const apiKey = z.string().trim().max(500, "500자 이하");

export const TestProviderInput = z.strictObject({
  kind: z.enum(AI_KINDS, { error: "종류를 선택해 주세요." }),
  baseUrl,
  apiKey: apiKey.default(""), // 로컬 모델은 비워 둔다
});
export type TestProviderInput = z.infer<typeof TestProviderInput>;
export const CreateProviderInput = TestProviderInput.extend({
  name: z.string().trim().min(1, "이름을 입력해 주세요.").max(50, "50자 이하"),
});
export type CreateProviderInput = z.infer<typeof CreateProviderInput>;

const modelId = z.string().trim().min(1, "모델 ID 를 입력해 주세요.").max(100, "100자 이하");
export const TestModelInput = z.strictObject({ providerId: z.uuid({ error: "공급자를 선택해 주세요." }), model: modelId });
export type TestModelInput = z.infer<typeof TestModelInput>;
export const CreateModelInput = TestModelInput.extend({
  /** 기능 코드가 부르는 이름(aiComplete({ model: "요약" })). 비우면 모델 ID */
  label: z.string().trim().max(50, "50자 이하").default(""),
  isDefault: z.boolean().default(false),
});
export type CreateModelInput = z.infer<typeof CreateModelInput>;
export const UpdateModelInput = z.strictObject({ isDefault: z.literal(true) });
export type UpdateModelInput = z.infer<typeof UpdateModelInput>;

/** 기능 코드의 aiComplete·aiJson 호출 제한(키트 기본값, 모델 컨텍스트 토큰 계산 아님). 외부 호출 전에 검사한다. */
export const AI_CALL_LIMITS = { timeoutMs: [1000, 60_000], maxTokens: [1, 4096], promptChars: 16_000 } as const;
export const AiCallLimits = z.object({
  timeoutMs: z.number().int("정수").min(AI_CALL_LIMITS.timeoutMs[0], "1000ms 이상").max(AI_CALL_LIMITS.timeoutMs[1], "60000ms 이하").default(60_000),
  maxTokens: z.number().int("정수").min(AI_CALL_LIMITS.maxTokens[0], "1 이상").max(AI_CALL_LIMITS.maxTokens[1], "4096 이하").default(1024),
  prompt: z.string(),
  system: z.string().default(""),
}).refine((v) => v.prompt.length + v.system.length <= AI_CALL_LIMITS.promptChars, {
  path: ["prompt"], message: `prompt 와 system 합계 ${AI_CALL_LIMITS.promptChars}자 이하`,
});

export type AiProviderDto = {
  id: string;
  name: string;
  kind: AiKind;
  baseUrl: string;
  /** 끝 4자리만 (예: "••••abcd"). 키가 없으면 null */
  apiKeyHint: string | null;
  createdAt: string;
};
export type AiModelDto = {
  id: string;
  provider: { id: string; name: string; kind: AiKind };
  model: string;
  label: string;
  isDefault: boolean;
  createdAt: string;
};
export type ProviderTestResult = { ok: true; ms: number; models: string[] };
export type ModelTestResult = { ok: true; ms: number; reply: string };
