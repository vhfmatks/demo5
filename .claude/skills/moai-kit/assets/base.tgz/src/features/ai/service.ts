// [서버] AI: 관리자 등록·시험(ai.manage) + 기능 코드용 aiComplete·aiJson.
// 흐름: 공급자 연결 시험 → 등록(서버가 다시 시험) → 모델 시험 → 등록(다시 시험) → 기능에서 사용.
//   const { text } = await aiComplete(actor, { feature: "request.summary", prompt });            // 기본 모델
//   const out = await aiJson(actor, { feature: "request.suggest", prompt, schema: Suggestion });  // zod 로 검증된 객체
// AI 출력은 "제안"이다. 권한·상태 판단에 쓰지 않고, 저장 전에 사람이 확인하거나 스키마로 다시 검사한다.
import "server-only";
import { randomUUID } from "node:crypto";
import { asc, eq, ne } from "drizzle-orm";
import type { ZodType } from "zod";
import { db, type DbExecutor } from "@/server/db/client";
import { aiModels, aiProviders } from "@/server/db/schema";
import { AppError, fromZod } from "@/server/http/errors";
import { audit } from "@/server/audit";
import { recordHit, retryAfterSeconds } from "@/server/rate-limit";
import { assertPermission, type SessionUser } from "@/server/auth/session";
import { decryptSecret, encryptSecret, secretHint } from "@/server/secret";
import { CommonErrors } from "@/lib/error-codes";
import { AiCallError, chat, describeAiError, listModels, type AiTarget } from "./client";
import { AiErrors } from "./errors";
import { AiCallLimits } from "./schema";
import type {
  AiModelDto, AiProviderDto, CreateModelInput, CreateProviderInput, ModelTestResult, ProviderTestResult,
  TestModelInput, TestProviderInput, UpdateModelInput,
} from "./schema";

const ENTITY = "ai";
const TEST_PROMPT = "Reply with the single word: OK";

const failed = (e: unknown) =>
  e instanceof AiCallError ? new AppError(AiErrors.AI_TEST_FAILED, { message: `AI 연결 시험 실패 — ${describeAiError(e)}`, cause: e }) : e;

async function timed<T>(fn: () => Promise<T>): Promise<{ value: T; ms: number }> {
  const started = performance.now();
  const value = await fn();
  return { value, ms: Math.round(performance.now() - started) };
}

async function loadProvider(id: string, executor: DbExecutor = db) {
  const p = await executor.select().from(aiProviders).where(eq(aiProviders.id, id)).get();
  if (!p) throw new AppError(AiErrors.AI_PROVIDER_NOT_FOUND);
  return p;
}

function target(p: typeof aiProviders.$inferSelect): AiTarget {
  let apiKey = "";
  try {
    if (p.apiKeyEnc) apiKey = decryptSecret(p.apiKeyEnc);
  } catch (cause) {
    throw new AppError(AiErrors.AI_SECRET_UNREADABLE, { cause });
  }
  return { kind: p.kind, baseUrl: p.baseUrl, apiKey };
}

const providerDto = (p: typeof aiProviders.$inferSelect): AiProviderDto => ({
  id: p.id, name: p.name, kind: p.kind, baseUrl: p.baseUrl, apiKeyHint: p.apiKeyHint, createdAt: p.createdAt.toISOString(),
});

const modelSelect = (executor: DbExecutor = db) =>
  executor.select({ m: aiModels, p: aiProviders }).from(aiModels).innerJoin(aiProviders, eq(aiProviders.id, aiModels.providerId));
const modelDto = ({ m, p }: { m: typeof aiModels.$inferSelect; p: typeof aiProviders.$inferSelect }): AiModelDto => ({
  id: m.id, provider: { id: p.id, name: p.name, kind: p.kind }, model: m.model, label: m.label, isDefault: m.isDefault,
  createdAt: m.createdAt.toISOString(),
});

async function loadModel(id: string, executor: DbExecutor = db) {
  const row = await modelSelect(executor).where(eq(aiModels.id, id)).get();
  if (!row) throw new AppError(AiErrors.AI_MODEL_NOT_FOUND);
  return row;
}

const isUnique = (e: unknown) => String((e as { cause?: unknown })?.cause ?? e).includes("UNIQUE");

// ── 관리자: 공급자 ─────────────────────────────────────────
export async function listAiProviders(actor: SessionUser): Promise<AiProviderDto[]> {
  assertPermission(actor, "ai.manage");
  return (await db.select().from(aiProviders).orderBy(asc(aiProviders.name)).all()).map(providerDto);
}

/** 저장 없이 연결 시험: 모델 목록을 받아 온다 */
export async function testAiProvider(actor: SessionUser, input: TestProviderInput): Promise<ProviderTestResult> {
  assertPermission(actor, "ai.manage");
  try {
    const { value: models, ms } = await timed(() => listModels(input));
    return { ok: true, ms, models };
  } catch (e) {
    throw failed(e);
  }
}

/** 등록 = 서버가 다시 연결 시험 → 통과하면 키를 암호화해 저장 */
export async function createAiProvider(actor: SessionUser, input: CreateProviderInput): Promise<AiProviderDto> {
  await testAiProvider(actor, input);
  try {
    return await db.transaction(async (tx) => {
      const p = await tx.insert(aiProviders).values({
        name: input.name, kind: input.kind, baseUrl: input.baseUrl,
        apiKeyEnc: input.apiKey ? encryptSecret(input.apiKey) : null, apiKeyHint: secretHint(input.apiKey),
      }).returning().get();
      await audit(actor.id, `${ENTITY}.provider_create`, ENTITY, p.id, { name: p.name, kind: p.kind, baseUrl: p.baseUrl }, tx);
      return providerDto(p);
    });
  } catch (e) {
    if (isUnique(e)) throw new AppError(AiErrors.AI_NAME_TAKEN, { fieldErrors: { name: [AiErrors.AI_NAME_TAKEN.message] } });
    throw e;
  }
}

/** 공급자 삭제 = 그 공급자의 모델도 함께 삭제(cascade) */
export async function deleteAiProvider(actor: SessionUser, id: string): Promise<void> {
  assertPermission(actor, "ai.manage");
  await db.transaction(async (tx) => {
    const p = await loadProvider(id, tx);
    await tx.delete(aiProviders).where(eq(aiProviders.id, id)).run();
    await audit(actor.id, `${ENTITY}.provider_delete`, ENTITY, id, { name: p.name }, tx);
  });
}

/** 모델 등록 화면의 제안 목록 */
export async function listAiProviderModels(actor: SessionUser, id: string): Promise<string[]> {
  assertPermission(actor, "ai.manage");
  try {
    return await listModels(target(await loadProvider(id)));
  } catch (e) {
    throw failed(e);
  }
}

// ── 관리자: 모델 ───────────────────────────────────────────
export async function listAiModels(actor: SessionUser): Promise<AiModelDto[]> {
  assertPermission(actor, "ai.manage");
  return (await modelSelect().orderBy(asc(aiModels.label)).all()).map(modelDto);
}

/** 저장 없이 짧은 질문을 보내 응답·시간을 본다 */
export async function testAiModel(actor: SessionUser, input: TestModelInput): Promise<ModelTestResult> {
  assertPermission(actor, "ai.manage");
  const t = target(await loadProvider(input.providerId));
  try {
    const { value, ms } = await timed(() => chat(t, { model: input.model, prompt: TEST_PROMPT, maxTokens: 256, timeoutMs: 30_000 }));
    return { ok: true, ms, reply: value.text.trim().slice(0, 200) };
  } catch (e) {
    throw failed(e);
  }
}

/** 등록 = 서버가 다시 시험. 첫 모델이거나 isDefault 면 기본 모델이 된다(기본은 하나). */
export async function createAiModel(actor: SessionUser, input: CreateModelInput): Promise<AiModelDto> {
  await testAiModel(actor, input);
  const label = input.label || input.model;
  try {
    return await db.transaction(async (tx) => {
      const first = !(await tx.select({ id: aiModels.id }).from(aiModels).limit(1).get());
      const m = await tx.insert(aiModels).values({ providerId: input.providerId, model: input.model, label, isDefault: first || input.isDefault })
        .returning().get();
      if (m.isDefault) await tx.update(aiModels).set({ isDefault: false }).where(ne(aiModels.id, m.id)).run();
      await audit(actor.id, `${ENTITY}.model_create`, ENTITY, m.id, { label, model: m.model, isDefault: m.isDefault }, tx);
      return modelDto(await loadModel(m.id, tx));
    });
  } catch (e) {
    if (isUnique(e)) throw new AppError(AiErrors.AI_NAME_TAKEN, { fieldErrors: { label: [AiErrors.AI_NAME_TAKEN.message] } });
    throw e;
  }
}

export async function updateAiModel(actor: SessionUser, id: string, _input: UpdateModelInput): Promise<AiModelDto> {
  assertPermission(actor, "ai.manage");
  return db.transaction(async (tx) => {
    const row = await loadModel(id, tx);
    await tx.update(aiModels).set({ isDefault: false }).where(ne(aiModels.id, id)).run();
    await tx.update(aiModels).set({ isDefault: true }).where(eq(aiModels.id, id)).run();
    await audit(actor.id, `${ENTITY}.model_default`, ENTITY, id, { label: row.m.label }, tx);
    return modelDto(await loadModel(id, tx));
  });
}

export async function deleteAiModel(actor: SessionUser, id: string): Promise<void> {
  assertPermission(actor, "ai.manage");
  await db.transaction(async (tx) => {
    const row = await loadModel(id, tx);
    await tx.delete(aiModels).where(eq(aiModels.id, id)).run();
    await audit(actor.id, `${ENTITY}.model_delete`, ENTITY, id, { label: row.m.label }, tx);
  });
}

// ── 기능 코드용 ─────────────────────────────────────────────
export type AiCompleteOptions = {
  /** 감사로그·사용량 구분용 이름 (예: "request.suggest") */
  feature: string;
  prompt: string;
  system?: string;
  /** 등록한 모델 label. 생략 = 기본 모델 */
  model?: string;
  /** 출력 토큰 상한 1~4096, 기본 1024 */
  maxTokens?: number;
  /** 공급자 응답 대기 ms, 정수 1000~60000, 기본 60000 */
  timeoutMs?: number;
};

/** 호출 추적 정보. 사용량은 공급자가 제공하지 않으면 null (0·추정치 아님) */
export type AiCallMeta = { callId: string; providerId: string; modelId: string; inputTokens: number | null; outputTokens: number | null };

// 사용자당 분당 20회 (server/rate-limit.ts, 프로세스 메모리)
const RATE = { limit: 20, windowMs: 60_000 };
function rateLimit(key: string) {
  const wait = retryAfterSeconds(`ai:${key}`, RATE);
  if (wait) throw new AppError(AiErrors.AI_RATE_LIMITED, { retryAfterSeconds: wait });
  recordHit(`ai:${key}`, RATE.windowMs);
}

/**
 * 호출 한 번의 공통 경로: 옵션 검사(외부 호출 전) → 제한 → 호출 → parse(후처리·검증) → 최종 감사 1건.
 * parse 가 AiCallError("format") 을 던지면 실패로 기록한다. 감사에는 프롬프트·응답·공급자 오류 원문을 넣지 않는다.
 */
async function runCall<T>(actor: SessionUser | null, opts: AiCompleteOptions, parse: (text: string) => T) {
  const limits = AiCallLimits.safeParse({ timeoutMs: opts.timeoutMs, maxTokens: opts.maxTokens, prompt: opts.prompt, system: opts.system });
  if (!limits.success) throw fromZod(limits.error);
  rateLimit(actor?.id ?? "anonymous");
  const row = await modelSelect()
    .where(opts.model ? eq(aiModels.label, opts.model) : eq(aiModels.isDefault, true)).get();
  if (!row) throw new AppError(AiErrors.AI_NOT_CONFIGURED);
  // 감사 범위: 공급자 호출·응답 처리 실패(AiCallError)만 ai.call 로 남는다. 호출 전 실패(옵션·제한·AI_NOT_CONFIGURED·키 복호화 AI_SECRET_UNREADABLE)는 AppError 로만 전달된다.
  const callId = randomUUID();
  const detail = { callId, feature: opts.feature, providerId: row.p.id, model: row.m.label, modelId: row.m.model };
  const started = performance.now();
  const ms = () => Math.round(performance.now() - started);
  let out: Awaited<ReturnType<typeof chat>>;
  let value: T;
  try {
    out = await chat(target(row.p), {
      model: row.m.model, system: opts.system, prompt: opts.prompt, maxTokens: limits.data.maxTokens, timeoutMs: limits.data.timeoutMs,
    });
    value = parse(out.text);
  } catch (e) {
    if (!(e instanceof AiCallError)) throw e;
    await audit(actor?.id ?? null, `${ENTITY}.call`, ENTITY, row.m.id, {
      ...detail, ok: false, ms: ms(), reason: e.reason, status: e.status ?? null, inputTokens: null, outputTokens: null,
    });
    throw new AppError(e.reason === "timeout" ? CommonErrors.UPSTREAM_TIMEOUT : CommonErrors.UPSTREAM_ERROR, { cause: e });
  }
  const elapsed = ms();
  await audit(actor?.id ?? null, `${ENTITY}.call`, ENTITY, row.m.id, {
    ...detail, ok: true, ms: elapsed, inputTokens: out.inputTokens, outputTokens: out.outputTokens,
  });
  const meta: AiCallMeta = { callId, providerId: row.p.id, modelId: row.m.model, inputTokens: out.inputTokens, outputTokens: out.outputTokens };
  return { text: out.text, value, model: row.m.label, ms: elapsed, meta };
}

/** 등록된 모델로 한 번 묻는다. 실패는 502(UPSTREAM_ERROR)·504(UPSTREAM_TIMEOUT)·503(AI_NOT_CONFIGURED), 옵션 위반은 400. 호출마다 감사로그(본문 제외). */
export async function aiComplete(actor: SessionUser | null, opts: AiCompleteOptions): Promise<{ text: string; model: string; ms: number; meta: AiCallMeta }> {
  const { text, model, ms, meta } = await runCall(actor, opts, (t) => t);
  return { text, model, ms, meta };
}

/** JSON 하나를 받아 zod 로 검증한다. 형식이 틀리면 502(감사에는 format 실패 1건). 예: 분류·추출·점수 제안 */
export async function aiJson<T>(actor: SessionUser | null, opts: AiCompleteOptions & { schema: ZodType<T> }): Promise<T> {
  const { value } = await runCall(
    actor,
    { ...opts, system: `${opts.system ? `${opts.system}\n` : ""}JSON 객체 하나만 출력한다. 설명·코드 블록 표시는 쓰지 않는다.` },
    (text) => {
      const parsed = opts.schema.safeParse(extractJson(text));
      if (!parsed.success) throw new AiCallError("format");
      return parsed.data;
    },
  );
  return value;
}

/** 응답에서 첫 { 부터 마지막 } 까지를 JSON 으로 읽는다(코드 블록·앞뒤 설명 허용). 실패하면 undefined */
export function extractJson(text: string): unknown {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start < 0 || end < start) return undefined;
  try {
    return JSON.parse(text.slice(start, end + 1));
  } catch {
    return undefined;
  }
}

/** 화면에서 AI 버튼을 보일지 (기본 모델 존재) */
export async function aiAvailable(): Promise<boolean> {
  return !!(await db.select({ id: aiModels.id }).from(aiModels).where(eq(aiModels.isDefault, true)).limit(1).get());
}
