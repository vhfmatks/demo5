// [Server] GET 폼 필터 (?action=&entity=&actor=&from=&to=)
import { Button, Input, FilterBar } from "@/components/ui";
import type { ListAuditQuery } from "../schema";

export const AuditFilters = ({ q }: { q: ListAuditQuery }) => (
  <FilterBar>
    <Input name="action" aria-label="행위" defaultValue={q.action ?? ""} placeholder="행위 (예: request.)" className="w-48" />
    <Input name="entity" aria-label="대상 종류" defaultValue={q.entity ?? ""} placeholder="대상 종류 (예: request)" className="w-48" />
    <Input name="actor" aria-label="수행자" defaultValue={q.actor ?? ""} placeholder="수행자 이름·이메일" className="w-48" />
    <Input name="from" type="date" aria-label="시작일" defaultValue={q.from ?? ""} className="w-40" />
    <Input name="to" type="date" aria-label="종료일" defaultValue={q.to ?? ""} className="w-40" />
    <Button type="submit" variant="tertiary">검색</Button>
  </FilterBar>
);
