// [Server] 감사로그 표
import { DataTable, type Column } from "@/components/ui";
import { fmtDateTime } from "@/lib/format";
import type { AuditLogDto } from "../schema";

const columns: Column<AuditLogDto>[] = [
  { key: "createdAt", header: "일시", render: (r) => fmtDateTime(r.createdAt), className: "whitespace-nowrap" },
  { key: "actor", header: "수행자", render: (r) => (r.actor ? `${r.actor.name} (${r.actor.email})` : "익명·시스템") },
  { key: "action", header: "행위", render: (r) => <code>{r.action}</code> },
  { key: "target", header: "대상", render: (r) => <code>{r.entityId ? `${r.entity}/${r.entityId.slice(0, 8)}` : r.entity}</code> },
  { key: "detail", header: "상세", render: (r) => (r.detail ? <code className="break-all">{JSON.stringify(r.detail)}</code> : "") },
];

export const AuditTable = ({ rows }: { rows: AuditLogDto[] }) => (
  <DataTable rows={rows} columns={columns} empty="감사로그가 없습니다." />
);
