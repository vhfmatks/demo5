// [공유] 감사로그 조회 조건·DTO. 기록은 server/audit.ts 의 audit() 가 담당한다.
import { z } from "zod";

const ymd = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional().catch(undefined);
export const ListAuditQuery = z.object({
  action: z.string().trim().max(50).optional().catch(undefined), // 접두어 일치 (예: request. / settings.update)
  entity: z.string().trim().max(50).optional().catch(undefined),
  entityId: z.string().trim().max(50).optional().catch(undefined),
  actor: z.string().trim().max(50).optional().catch(undefined), // 이름·이메일 부분 일치
  from: ymd, // YYYY-MM-DD (Asia/Seoul)
  to: ymd,
  page: z.coerce.number().int().min(1).default(1).catch(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20).catch(20),
});
export type ListAuditQuery = z.infer<typeof ListAuditQuery>;

export type AuditLogDto = {
  id: string;
  action: string;
  entity: string;
  entityId: string | null;
  actor: { id: string; name: string; email: string } | null;
  detail: Record<string, unknown> | null;
  createdAt: string;
};
