// [서버] 감사로그 조회 (관리자 전용, 읽기만). 기록은 각 서비스가 audit() 로 한다.
import "server-only";
import { and, count, desc, eq, gte, like, lt, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/server/db/client";
import { auditLogs, users } from "@/server/db/schema";
import { assertPermission, type SessionUser } from "@/server/auth/session";
import type { PageMeta } from "@/lib/error-codes";
import type { AuditLogDto, ListAuditQuery } from "./schema";

const kstDay = (ymd: string, addDays = 0) => new Date(Date.parse(`${ymd}T00:00:00+09:00`) + addDays * 86_400_000);

export async function listAuditLogs(
  actor: SessionUser,
  q: ListAuditQuery,
): Promise<{ items: AuditLogDto[]; meta: PageMeta }> {
  assertPermission(actor, "audit.read");
  const where: SQL[] = [];
  if (q.action) where.push(like(auditLogs.action, `${q.action}%`));
  if (q.entity) where.push(eq(auditLogs.entity, q.entity));
  if (q.entityId) where.push(eq(auditLogs.entityId, q.entityId));
  if (q.actor) {
    const p = `%${q.actor}%`;
    where.push(or(like(users.name, p), like(users.email, p)) as SQL);
  }
  if (q.from) where.push(gte(auditLogs.createdAt, kstDay(q.from)));
  if (q.to) where.push(lt(auditLogs.createdAt, kstDay(q.to, 1)));
  const cond = where.length ? and(...where) : undefined;

  const rows = await db
    .select({ a: auditLogs, name: users.name, email: users.email })
    .from(auditLogs)
    .leftJoin(users, eq(users.id, auditLogs.actorId))
    .where(cond)
    .orderBy(desc(auditLogs.createdAt), desc(sql`audit_logs.rowid`)) // 같은 ms 는 기록 역순
    .limit(q.pageSize)
    .offset((q.page - 1) * q.pageSize)
    .all();
  const total = (await db.select({ n: count() }).from(auditLogs).leftJoin(users, eq(users.id, auditLogs.actorId)).where(cond).get())?.n ?? 0;
  const items = rows.map(({ a, name, email }): AuditLogDto => ({
    id: a.id,
    action: a.action,
    entity: a.entity,
    entityId: a.entityId,
    actor: a.actorId ? { id: a.actorId, name: name ?? "", email: email ?? "" } : null,
    detail: a.detail ?? null,
    createdAt: a.createdAt.toISOString(),
  }));
  return { items, meta: { page: q.page, pageSize: q.pageSize, total } };
}
