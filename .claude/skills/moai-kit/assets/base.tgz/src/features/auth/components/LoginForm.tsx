"use client";
import { useRouter } from "next/navigation";
import { Alert, Button, Field, Input } from "@/components/ui";
import { apiClient } from "@/lib/api-client";
import { formValues, useMutation } from "@/lib/use-mutation";
import { LoginInput } from "../schema";

/** demo: 개발·시연용 합성 계정 목록. 누르면 이메일을 채운다(비밀번호는 직접 입력). */
export function LoginForm({ demo = [] }: { demo?: { email: string; label: string }[] }) {
  const router = useRouter();
  const m = useMutation((v: Record<string, string>) => apiClient.post("/api/v1/auth/login", v), {
    schema: LoginInput,
    onSuccess: () => router.push("/"),
  });
  return (
    <form
      noValidate
      className="flex flex-col gap-4"
      onSubmit={(e) => {
        e.preventDefault();
        m.run(formValues(e.currentTarget));
      }}
    >
      <Field label="이메일" name="email" required error={m.fieldErrors.email}>
        <Input name="email" type="email" autoComplete="username" invalid={!!m.fieldErrors.email} />
      </Field>
      <Field label="비밀번호" name="password" required error={m.fieldErrors.password}>
        <Input name="password" type="password" autoComplete="current-password" invalid={!!m.fieldErrors.password} />
      </Field>
      <Alert>{m.error}</Alert>
      <Button type="submit" loading={m.pending}>로그인</Button>
      {demo.length > 0 && (
        <fieldset className="flex flex-wrap gap-2">
          <legend className="body-small-medium mb-2 text-muted">데모 계정 선택</legend>
          {demo.map((d) => (
            <Button key={d.email} variant="tertiary" size="xsmall" onClick={(e) => {
              const input = e.currentTarget.form?.elements.namedItem("email");
              if (input instanceof HTMLInputElement) input.value = d.email;
              (e.currentTarget.form?.elements.namedItem("password") as HTMLInputElement | null)?.focus();
            }}>{d.label}</Button>
          ))}
        </fieldset>
      )}
    </form>
  );
}
