"use client";
// [Client] 비밀번호 변경 폼. 성공하면 다른 기기 세션은 모두 종료된다.
import { useRef, useState } from "react";
import { Alert, Button, Field, Input } from "@/components/ui";
import { apiClient } from "@/lib/api-client";
import { formValues, useMutation } from "@/lib/use-mutation";
import { ChangePasswordInput } from "../schema";

export function PasswordForm() {
  const [done, setDone] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);
  const m = useMutation((v: Record<string, string>) => apiClient.post("/api/v1/auth/password", v), {
    schema: ChangePasswordInput,
    onSuccess: () => { setDone(true); formRef.current?.reset(); },
  });
  const fe = m.fieldErrors;
  return (
    <form
      noValidate
      ref={formRef}
      className="flex max-w-md flex-col gap-4"
      onSubmit={(e) => {
        e.preventDefault();
        setDone(false);
        const form = e.currentTarget;
        m.run(formValues(form));
      }}
    >
      <Field label="현재 비밀번호" name="currentPassword" required error={fe.currentPassword}>
        <Input name="currentPassword" type="password" autoComplete="current-password" invalid={!!fe.currentPassword} />
      </Field>
      <Field label="새 비밀번호" name="newPassword" required hint="8자 이상, 영문·숫자 포함" error={fe.newPassword}>
        <Input name="newPassword" type="password" autoComplete="new-password" invalid={!!fe.newPassword} />
      </Field>
      <Field label="새 비밀번호 확인" name="confirmPassword" required error={fe.confirmPassword}>
        <Input name="confirmPassword" type="password" autoComplete="new-password" invalid={!!fe.confirmPassword} />
      </Field>
      <Alert>{m.error}</Alert>
      <Alert tone="info">{done && "비밀번호를 변경했습니다. 다른 기기에서는 다시 로그인해야 합니다."}</Alert>
      <div><Button type="submit" loading={m.pending}>변경</Button></div>
    </form>
  );
}
