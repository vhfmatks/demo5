// 공개 로그인 실패는 계정 없음·비밀번호 불일치를 구분하지 않는다.
import { defineErrors } from "../../lib/error-codes";

export const AuthErrors = defineErrors({
  AUTH_INVALID_CREDENTIALS: {
    category: "UNAUTHENTICATED",
    message: "이메일 또는 비밀번호가 올바르지 않습니다.",
  },
  AUTH_TOO_MANY_ATTEMPTS: {
    category: "RATE_LIMITED",
    message: "로그인 시도가 너무 많습니다. 잠시 후 다시 시도해 주세요.",
    retryable: true,
  },
  AUTH_CURRENT_PASSWORD_MISMATCH: { category: "VALIDATION_ERROR", message: "현재 비밀번호가 올바르지 않습니다." },
});
