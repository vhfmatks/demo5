import { z } from "zod";

export const LoginInput = z.strictObject({
  email: z.email("이메일 형식이 아닙니다.").trim().toLowerCase(),
  password: z.string().min(1, "비밀번호를 입력해 주세요.").max(200),
});
export type LoginInput = z.infer<typeof LoginInput>;

export const ChangePasswordInput = z
  .strictObject({
    currentPassword: z.string().min(1, "현재 비밀번호를 입력해 주세요.").max(200),
    // bcrypt 는 72바이트 뒤를 무시한다 → 그보다 긴 비밀번호는 앞부분만 같아도 통과하므로 받지 않는다.
    newPassword: z.string().min(8, "8자 이상 입력해 주세요.")
      .refine((v) => new TextEncoder().encode(v).length <= 72, "72바이트(영문·숫자 72자, 한글 24자) 이하로 입력해 주세요.")
      .regex(/[A-Za-z]/, "영문을 포함해 주세요.").regex(/\d/, "숫자를 포함해 주세요."),
    confirmPassword: z.string(),
  })
  .refine((v) => v.newPassword === v.confirmPassword, { path: ["confirmPassword"], message: "새 비밀번호와 일치하지 않습니다." })
  .refine((v) => v.newPassword !== v.currentPassword, { path: ["newPassword"], message: "현재 비밀번호와 다르게 입력해 주세요." });
export type ChangePasswordInput = z.infer<typeof ChangePasswordInput>;
