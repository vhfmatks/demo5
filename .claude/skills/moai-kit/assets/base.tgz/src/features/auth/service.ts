import "server-only";
import { createHash } from "node:crypto";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { db } from "@/server/db/client";
import { users } from "@/server/db/schema";
import { AppError } from "@/server/http/errors";
import { createSession, revokeAllSessions, type SessionUser } from "@/server/auth/session";
import { audit } from "@/server/audit";
import { clearHits, recordHit, retryAfterSeconds } from "@/server/rate-limit";
import { getSettings } from "@/features/settings/service";
import type { ChangePasswordInput, LoginInput } from "./schema";
import { AuthErrors } from "./errors";

// 없는 계정도 같은 비용으로 비교해 응답 시간으로 계정 존재를 드러내지 않는다.
const DUMMY_HASH = bcrypt.hashSync("timing-equalizer", 10);
/** 감사용 이메일 식별자: 원문 대신 해시 앞 16자리(같은 이메일 반복 시도 추적용). */
const emailRef = (email: string) => createHash("sha256").update(email).digest("hex").slice(0, 16);

/**
 * 같은 이메일로 잠금 시간 안에 실패 허용 횟수에 이르면 맞는 비밀번호도 429로 거부한다. 성공하면 기록을 지운다.
 * 시도는 비교 전에 기록한다(확인·기록 사이에 await 없음) → 동시 요청으로 횟수를 넘길 수 없다.
 */
export async function login(input: LoginInput): Promise<SessionUser> {
  const { loginMaxFailures, loginLockMinutes } = await getSettings();
  const key = `login:${input.email}`;
  const rule = { limit: loginMaxFailures, windowMs: loginLockMinutes * 60_000 };
  const wait = retryAfterSeconds(key, rule);
  if (!wait) recordHit(key, rule.windowMs);
  const user = await db.select().from(users).where(eq(users.email, input.email)).get();
  if (wait) {
    await audit(null, "auth.login_failed", "user", user?.id ?? null, { emailRef: emailRef(input.email), locked: true });
    throw new AppError(AuthErrors.AUTH_TOO_MANY_ATTEMPTS, { retryAfterSeconds: wait });
  }
  if (!(await bcrypt.compare(input.password, user?.passwordHash ?? DUMMY_HASH)) || !user) {
    await audit(null, "auth.login_failed", "user", user?.id ?? null, { emailRef: emailRef(input.email) });
    throw new AppError(AuthErrors.AUTH_INVALID_CREDENTIALS);
  }
  clearHits(key);
  await createSession(user.id);
  await audit(user.id, "auth.login", "user", user.id);
  return { id: user.id, email: user.email, name: user.name, role: user.role, department: user.department };
}

/** 비밀번호 변경: 현재 비밀번호 확인 → 저장 → 모든 세션 폐기(다른 기기 로그아웃) → 현재 기기만 새 세션. */
export async function changePassword(actor: SessionUser, input: ChangePasswordInput): Promise<void> {
  const user = await db.select().from(users).where(eq(users.id, actor.id)).get();
  if (!user || !(await bcrypt.compare(input.currentPassword, user.passwordHash))) {
    throw new AppError(AuthErrors.AUTH_CURRENT_PASSWORD_MISMATCH, {
      fieldErrors: { currentPassword: [AuthErrors.AUTH_CURRENT_PASSWORD_MISMATCH.message] },
    });
  }
  const passwordHash = await bcrypt.hash(input.newPassword, 10);
  await db.transaction(async (tx) => {
    await tx.update(users).set({ passwordHash }).where(eq(users.id, actor.id)).run();
    await revokeAllSessions(actor.id, tx);
    await audit(actor.id, "auth.password_change", "user", actor.id, undefined, tx);
  });
  await createSession(actor.id);
}
