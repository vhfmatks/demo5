type FontEnvironment = { NODE_ENV?: string; E2E_RUN_ID?: string; E2E_SOURCE_SHA256?: string; APP_ORIGIN?: string };
/** Participant fonts are served only during development or isolated loopback E2E. */
export function allowsLocalKdsFonts(env: FontEnvironment = process.env) {
  if (env.NODE_ENV === "development") return true;
  if (!env.E2E_RUN_ID || !/^[a-f0-9]{64}$/.test(env.E2E_SOURCE_SHA256 ?? "")) return false;
  try { return ["localhost", "127.0.0.1", "[::1]"].includes(new URL(env.APP_ORIGIN ?? "").hostname); }
  catch { return false; }
}
