import "server-only";
import type { SessionUser } from "@/server/auth/session";
import { Errors } from "@/server/http/errors";
import { allowsLocalKdsFonts } from "./policy";

/** Only CSS metadata crosses the Next server; participant bytes remain on loopback. */
export async function getLocalFontStyle(_actor: SessionUser | null) {
  if (!allowsLocalKdsFonts()) throw Errors.notFound();
  return process.env.KDS_LOCAL_FONT_CSS || "/* Optional participant fonts are not installed. */";
}
