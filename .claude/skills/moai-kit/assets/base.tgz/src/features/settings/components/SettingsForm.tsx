"use client";
// [Client] 운영 설정 폼. SETTING_FIELDS 를 순회해 default 타입별 입력을 그린다 → 새 설정은 schema.ts 만 수정.
import { Alert, Button, Field, Input, Switch } from "@/components/ui";
import { apiClient } from "@/lib/api-client";
import { useMutation } from "@/lib/use-mutation";
import { SETTING_FIELDS, SETTING_KEYS, UpdateSettingsInput, type AppSettings, type SettingsDto } from "../schema";

export function SettingsForm({ values, readOnly = false }: { values: AppSettings; readOnly?: boolean }) {
  const m = useMutation((v: Partial<AppSettings>) => apiClient.patch<SettingsDto>("/api/v1/admin/settings", v), { schema: UpdateSettingsInput });
  const fe = m.fieldErrors;
  return (
    <form
      noValidate
      className="flex max-w-xl flex-col gap-6"
      onSubmit={(e) => {
        e.preventDefault();
        const els = e.currentTarget.elements;
        // 입력 형식만 JSON 타입으로 바꾼다. 검증은 공유 zod 스키마를 재사용한다.
        const read = (k: keyof AppSettings) => {
          const el = els.namedItem(k) as HTMLInputElement;
          const d = SETTING_FIELDS[k].default;
          return typeof d === "boolean" ? el.checked : typeof d === "number" ? (el.value === "" ? null : Number(el.value)) : el.value;
        };
        m.run(Object.fromEntries(SETTING_KEYS.map((k) => [k, read(k)])));
      }}
    >
      <fieldset disabled={readOnly} className="flex flex-col gap-6">
      {SETTING_KEYS.map((k) => {
        const f = SETTING_FIELDS[k];
        const v = values[k];
        return typeof v === "boolean" ? (
          <div key={k} className="flex flex-col gap-1">
            <Switch name={k} defaultChecked={v}>{f.label}</Switch>
            <p className="body-small-medium text-muted">{f.hint}</p>
            <Alert>{fe[k]?.[0]}</Alert>
          </div>
        ) : (
          <Field key={k} label={f.label} name={k} hint={f.hint} error={fe[k]}>
            <Input name={k} type={typeof v === "number" ? "number" : "text"} defaultValue={v} invalid={!!fe[k]} />
          </Field>
        );
      })}
      </fieldset>
      <Alert>{m.error}</Alert>
      <Alert tone="info">{readOnly && "조회 권한만 있어 변경할 수 없습니다."}</Alert>
      {!readOnly && <div><Button type="submit" loading={m.pending}>저장</Button></div>}
    </form>
  );
}
