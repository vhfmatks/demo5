// [Server] 사용자 화면 상단 공지·점검 안내. layout 에서 <SettingsNotice settings={await getSettings()} />
import { Alert } from "@/components/ui";
import type { AppSettings } from "../schema";

export function SettingsNotice({ settings: s }: { settings: AppSettings }) {
  if (!s.noticeBanner && !s.maintenanceMode) return null;
  return (
    <div data-testid="notice" className="mb-6 flex flex-col gap-2">
      {s.maintenanceMode && <Alert>서비스 점검 중입니다. 조회만 가능합니다.</Alert>}
      <Alert tone="info">{s.noticeBanner}</Alert>
    </div>
  );
}
