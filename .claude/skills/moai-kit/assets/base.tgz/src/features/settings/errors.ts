// [공유] 운영 설정 오류 계약
import { defineErrors } from "../../lib/error-codes";

export const SettingsErrors = defineErrors({
  SETTINGS_MAINTENANCE_MODE: {
    category: "SERVICE_UNAVAILABLE",
    message: "서비스 점검 중입니다. 잠시 후 다시 시도해 주세요.",
    retryable: true,
  },
});
