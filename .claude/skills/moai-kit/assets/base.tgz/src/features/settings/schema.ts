// [공유] 운영 설정 레지스트리. 새 설정 = SETTING_FIELDS 에 한 줄 추가 (마이그레이션·폼 수정 불필요).
// 폼 입력 종류는 default 의 타입(string·boolean·number)으로 정해진다. 비밀값은 설정에 넣지 않는다(.env 사용).
import { z } from "zod";

export const SETTING_FIELDS = {
  noticeBanner: {
    label: "공지 배너",
    hint: "비우면 표시하지 않습니다. 모든 사용자 화면 상단에 보입니다.",
    schema: z.string().trim().max(200, "200자 이하로 입력해 주세요."),
    default: "",
  },
  maintenanceMode: {
    label: "점검 모드",
    hint: "켜면 관리자 외 사용자의 쓰기 요청이 503으로 거부됩니다(로그인·로그아웃 제외).",
    schema: z.boolean({ error: "켜기/끄기 값이어야 합니다." }),
    default: false,
  },
  sessionTtlHours: {
    label: "세션 유지 시간(시간)",
    hint: "1~72. 새 로그인부터 적용됩니다.",
    schema: z.number({ error: "숫자를 입력해 주세요." }).int("정수로 입력해 주세요.").min(1, "1 이상").max(72, "72 이하"),
    default: 8,
  },
  loginMaxFailures: {
    label: "로그인 실패 허용 횟수",
    hint: "3~20. 같은 이메일로 잠금 시간 안에 이만큼 실패하면 잠금 시간 동안 로그인을 거부합니다(429).",
    schema: z.number({ error: "숫자를 입력해 주세요." }).int("정수로 입력해 주세요.").min(3, "3 이상").max(20, "20 이하"),
    default: 5,
  },
  loginLockMinutes: {
    label: "로그인 잠금 시간(분)",
    hint: "1~60. 실패 횟수를 세는 기간이자 잠금 유지 시간입니다.",
    schema: z.number({ error: "숫자를 입력해 주세요." }).int("정수로 입력해 주세요.").min(1, "1 이상").max(60, "60 이하"),
    default: 15,
  },
} as const;

export type SettingKey = keyof typeof SETTING_FIELDS;
export const SETTING_KEYS = Object.keys(SETTING_FIELDS) as SettingKey[];
export type AppSettings = { [K in SettingKey]: z.infer<(typeof SETTING_FIELDS)[K]["schema"]> };

const shape = Object.fromEntries(SETTING_KEYS.map((k) => [k, SETTING_FIELDS[k].schema])) as {
  [K in SettingKey]: (typeof SETTING_FIELDS)[K]["schema"];
};
export const UpdateSettingsInput = z.strictObject(shape).partial().refine(
  (input) => Object.keys(input).length > 0,
  { message: "변경할 설정을 하나 이상 입력해 주세요." },
);
export type UpdateSettingsInput = z.infer<typeof UpdateSettingsInput>;

/** 설정 화면용 DTO */
export type SettingsDto = { values: AppSettings; updatedAt: string | null };
