// [서버] 운영 설정. getSettings() 는 누구나(내부 인프라 포함) 읽고, 관리 조회·변경은 settings.read/update 권한.
import "server-only";
import { cache } from "react";
import { desc } from "drizzle-orm";
import { db, type DbExecutor } from "@/server/db/client";
import { appSettings } from "@/server/db/schema";
import { audit } from "@/server/audit";
import { assertPermission, type SessionUser } from "@/server/auth/session";
import { SETTING_FIELDS, SETTING_KEYS, type AppSettings, type SettingsDto, type UpdateSettingsInput } from "./schema";

const ENTITY = "settings";

async function read(executor: DbExecutor = db): Promise<SettingsDto> {
  const rows = await executor.select().from(appSettings).orderBy(desc(appSettings.updatedAt)).all();
  const stored = new Map(rows.map((r) => [r.key, r.value]));
  // 저장값이 현재 스키마와 맞지 않으면(삭제·규칙 변경) 기본값으로 동작한다.
  const values = Object.fromEntries(SETTING_KEYS.map((k) => {
    const parsed = SETTING_FIELDS[k].schema.safeParse(stored.get(k));
    return [k, parsed.success ? parsed.data : SETTING_FIELDS[k].default];
  })) as AppSettings;
  return { values, updatedAt: rows[0]?.updatedAt.toISOString() ?? null };
}

/** 현재 적용 중인 설정값. 한 요청 안에서는 1회만 조회된다. */
export const getSettings = cache(async (): Promise<AppSettings> => (await read()).values);

export async function getSettingsForAdmin(actor: SessionUser): Promise<SettingsDto> {
  assertPermission(actor, "settings.read");
  return read();
}

export async function updateSettings(actor: SessionUser, input: UpdateSettingsInput): Promise<SettingsDto> {
  assertPermission(actor, "settings.update");
  return db.transaction(async (tx) => {
    const before = (await read(tx)).values;
    const changes: Record<string, { from: unknown; to: unknown }> = {};
    for (const [key, value] of Object.entries(input) as [keyof AppSettings, unknown][]) {
      if (value === undefined || before[key] === value) continue;
      changes[key] = { from: before[key], to: value };
      await tx.insert(appSettings).values({ key, value, updatedBy: actor.id })
        .onConflictDoUpdate({ target: appSettings.key, set: { value, updatedBy: actor.id, updatedAt: new Date() } }).run();
    }
    if (Object.keys(changes).length) await audit(actor.id, `${ENTITY}.update`, ENTITY, null, { changes }, tx);
    return read(tx);
  });
}
