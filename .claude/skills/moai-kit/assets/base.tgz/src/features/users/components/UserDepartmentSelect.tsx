"use client";
// [Client] 행 단위 부서 지정. 선택 즉시 저장(빈 값 = 미지정), 실패하면 서버 값을 다시 표시한다.
import { useState } from "react";
import { Alert, Select, toOptions } from "@/components/ui";
import { apiClient } from "@/lib/api-client";
import { DEPARTMENT_LABEL, type Department } from "@/lib/departments";
import { useMutation } from "@/lib/use-mutation";
import type { UserDto } from "../schema";

export function UserDepartmentSelect({ user, disabled }: { user: UserDto; disabled: boolean }) {
  const [department, setDepartment] = useState(user.department ?? "");
  const m = useMutation((next: Department | null) => apiClient.patch<UserDto>(`/api/v1/admin/users/${user.id}/department`, { department: next }));
  return (
    <div className="flex flex-col gap-1">
      <Select name={`department-${user.id}`} aria-label={`${user.name} 부서`} value={m.failure ? (user.department ?? "") : department}
        options={toOptions(DEPARTMENT_LABEL)} placeholder="미지정" disabled={disabled || m.pending} className="w-32"
        onChange={(e) => { setDepartment(e.target.value); m.run((e.target.value || null) as Department | null); }} />
      <Alert>{m.error}</Alert>
    </div>
  );
}
