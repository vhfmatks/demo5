"use client";
// [Client] 행 단위 역할 변경. 선택 즉시 저장, 실패하면 서버 값을 다시 표시한다.
import { useState } from "react";
import { Alert, Select, toOptions } from "@/components/ui";
import { apiClient } from "@/lib/api-client";
import { ROLE_LABEL, type Role } from "@/lib/roles";
import { useMutation } from "@/lib/use-mutation";
import type { UserDto } from "../schema";

export function UserRoleSelect({ user, disabled }: { user: UserDto; disabled: boolean }) {
  const [role, setRole] = useState(user.role);
  const m = useMutation((next: Role) => apiClient.patch<UserDto>(`/api/v1/admin/users/${user.id}`, { role: next }));
  return (
    <div className="flex flex-col gap-1">
      <Select name={`role-${user.id}`} aria-label={`${user.name} 역할`} value={m.failure ? user.role : role} options={toOptions(ROLE_LABEL)}
        disabled={disabled || m.pending} onChange={(e) => { setRole(e.target.value as Role); m.run(e.target.value as Role); }} className="w-32" />
      <Alert>{m.error}</Alert>
    </div>
  );
}
