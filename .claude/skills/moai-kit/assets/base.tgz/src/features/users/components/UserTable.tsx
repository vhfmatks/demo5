// [Server] 사용자 표. 역할 칸만 Client(UserRoleSelect).
import { DataTable, type Column } from "@/components/ui";
import { fmtDateTime } from "@/lib/format";
import { can } from "@/lib/permissions";
import type { Role } from "@/lib/roles";
import type { UserDto } from "../schema";
import { canChangeRole } from "../policy";
import { UserRoleSelect } from "./UserRoleSelect";
import { UserDepartmentSelect } from "./UserDepartmentSelect";

export const UserTable = ({ rows, actor }: { rows: UserDto[]; actor: { id: string; role: Role } }) => {
  const columns: Column<UserDto>[] = [
    { key: "name", header: "이름", render: (u) => u.name },
    { key: "email", header: "이메일", render: (u) => u.email },
    { key: "role", header: "역할", render: (u) => <UserRoleSelect user={u} disabled={!canChangeRole(actor, u)} /> },
    { key: "department", header: "부서", render: (u) => <UserDepartmentSelect user={u} disabled={!can(actor, "user.department.update")} /> },
    { key: "createdAt", header: "가입일", render: (u) => fmtDateTime(u.createdAt), className: "whitespace-nowrap" },
  ];
  return <DataTable rows={rows} columns={columns} empty="사용자가 없습니다." />;
};
