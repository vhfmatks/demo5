// [공유] 사용자 관리 오류 계약
import { defineErrors } from "../../lib/error-codes";

export const UserErrors = defineErrors({
  USER_NOT_FOUND: { category: "NOT_FOUND", message: "사용자를 찾을 수 없습니다." },
  USER_SELF_ROLE_CHANGE_FORBIDDEN: { category: "FORBIDDEN", message: "본인 역할은 변경할 수 없습니다." },
  USER_CONCURRENT_MODIFICATION: { category: "INVALID_STATE", message: "다른 관리자가 먼저 변경했습니다. 새로고침해 주세요." },
});
