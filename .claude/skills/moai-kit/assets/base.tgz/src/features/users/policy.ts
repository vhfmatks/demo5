// [공유] 사용자 관리 권한. 본인 역할은 바꿀 수 없다 → 마지막 관리자가 스스로 권한을 잃거나 스스로 권한을 올리는 일을 막는다.
import { can } from "../../lib/permissions";
import type { Role } from "../../lib/roles";

type Actor = { id: string; role: Role };
export const canChangeRole = (a: Actor, target: { id: string }) => can(a, "user.role.update") && a.id !== target.id;
