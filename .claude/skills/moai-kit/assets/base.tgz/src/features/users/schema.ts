// [공유] 관리자용 사용자 목록·역할 변경
import { z } from "zod";
import { ROLES, type Role } from "../../lib/roles";
import { DEPARTMENTS, type Department } from "../../lib/departments";

export const ListUserQuery = z.object({
  role: z.enum(ROLES).optional().catch(undefined),
  q: z.string().trim().max(50).optional().catch(undefined), // 이름·이메일 부분 일치
  page: z.coerce.number().int().min(1).default(1).catch(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20).catch(20),
});
export type ListUserQuery = z.infer<typeof ListUserQuery>;

export const UpdateUserRoleInput = z.strictObject({ role: z.enum(ROLES, { error: "역할을 선택해 주세요." }) });
export type UpdateUserRoleInput = z.infer<typeof UpdateUserRoleInput>;

export const UpdateUserDepartmentInput = z.strictObject({ department: z.enum(DEPARTMENTS, { error: "부서를 선택해 주세요." }).nullable() });
export type UpdateUserDepartmentInput = z.infer<typeof UpdateUserDepartmentInput>;

export type UserDto = { id: string; email: string; name: string; role: Role; department: Department | null; createdAt: string };
