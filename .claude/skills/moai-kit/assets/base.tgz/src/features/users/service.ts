// [서버] 관리자용 사용자 관리. passwordHash 는 DTO 로 내보내지 않는다.
import "server-only";
import { and, asc, count, desc, eq, inArray, like, or, type SQL } from "drizzle-orm";
import { db, type DbExecutor } from "@/server/db/client";
import { users } from "@/server/db/schema";
import { AppError } from "@/server/http/errors";
import { audit } from "@/server/audit";
import { assertPermission, type SessionUser } from "@/server/auth/session";
import type { PageMeta } from "@/lib/error-codes";
import { ROLES, type Role } from "@/lib/roles";
import { canChangeRole } from "./policy";
import { UserErrors } from "./errors";
import type { ListUserQuery, UpdateUserDepartmentInput, UpdateUserRoleInput, UserDto } from "./schema";

const ENTITY = "user";
const cols = { id: users.id, email: users.email, name: users.name, role: users.role, department: users.department, createdAt: users.createdAt };
const toDto = (u: Omit<UserDto, "createdAt"> & { createdAt: Date }): UserDto => ({
  ...u,
  createdAt: u.createdAt.toISOString(),
});
const load = async (id: string, executor: DbExecutor = db) => {
  const u = await executor.select(cols).from(users).where(eq(users.id, id)).get();
  if (!u) throw new AppError(UserErrors.USER_NOT_FOUND);
  return u;
};

export async function listUsers(actor: SessionUser, q: ListUserQuery): Promise<{ items: UserDto[]; meta: PageMeta }> {
  assertPermission(actor, "user.read");
  const where: SQL[] = [];
  if (q.role) where.push(eq(users.role, q.role));
  if (q.q) where.push(or(like(users.name, `%${q.q}%`), like(users.email, `%${q.q}%`)) as SQL);
  const cond = where.length ? and(...where) : undefined;
  const items = (await db.select(cols).from(users).where(cond)
    .orderBy(desc(users.createdAt), desc(users.id)).limit(q.pageSize).offset((q.page - 1) * q.pageSize).all()).map(toDto);
  const total = (await db.select({ n: count() }).from(users).where(cond).get())?.n ?? 0;
  return { items, meta: { page: q.page, pageSize: q.pageSize, total } };
}

/** 담당자 등 선택지(gen 의 ref(users) 필드). 이름만 내보낸다. roles 를 주면 그 역할만. */
export async function userOptions(roles?: Role[]): Promise<{ value: string; label: string }[]> {
  return db.select({ value: users.id, label: users.name }).from(users)
    .where(roles?.length ? inArray(users.role, roles) : undefined).orderBy(asc(users.name)).all();
}

export async function userRoleStats(actor: SessionUser): Promise<Record<Role, number>> {
  assertPermission(actor, "user.read");
  const rows = await db.select({ role: users.role, n: count() }).from(users).groupBy(users.role).all();
  const out = Object.fromEntries(ROLES.map((r) => [r, 0])) as Record<Role, number>;
  for (const r of rows) out[r.role] = r.n;
  return out;
}

export async function updateUserRole(actor: SessionUser, id: string, input: UpdateUserRoleInput): Promise<UserDto> {
  assertPermission(actor, "user.role.update");
  return db.transaction(async (tx) => {
    const u = await load(id, tx);
    if (!canChangeRole(actor, u)) throw new AppError(UserErrors.USER_SELF_ROLE_CHANGE_FORBIDDEN);
    if (u.role === input.role) return toDto(u);
    const result = await tx.update(users).set({ role: input.role })
      .where(and(eq(users.id, id), eq(users.role, u.role))).run();
    if (result.rowsAffected === 0) throw new AppError(UserErrors.USER_CONCURRENT_MODIFICATION);
    await audit(actor.id, `${ENTITY}.role_change`, ENTITY, id, { from: u.role, to: input.role }, tx);
    return toDto(await load(id, tx));
  });
}

/** 소속 부서 지정(null = 미지정). 본인 부서도 바꿀 수 있다(권한 범위가 아니라 소속 정보). */
export async function updateUserDepartment(actor: SessionUser, id: string, input: UpdateUserDepartmentInput): Promise<UserDto> {
  assertPermission(actor, "user.department.update");
  return db.transaction(async (tx) => {
    const u = await load(id, tx);
    if (u.department === input.department) return toDto(u);
    await tx.update(users).set({ department: input.department }).where(eq(users.id, id)).run();
    await audit(actor.id, `${ENTITY}.department_change`, ENTITY, id, { from: u.department, to: input.department }, tx);
    return toDto(await load(id, tx));
  });
}
