// 달력 날짜 계산 + 달력 query·이벤트 타입 (서버·클라이언트 공용).
// 날짜는 "YYYY-MM-DD"(KST 달력 날짜) 문자열. 시각이 아니라 날짜라 UTC 로 더하고 빼서 시간대 영향이 없다.
// 화면은 components/ui/Calendar.tsx, 조회는 gridRange 로 [from, to) 범위를 만든다(datetime 텍스트 열은 문자열 비교).
import { z } from "zod";

const utc = (date: string) => new Date(`${date}T00:00:00Z`);
const ymd = (d: Date) => d.toISOString().slice(0, 10);

export const kstToday = () => new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Seoul" }).format(new Date());
export const addDays = (date: string, n: number) => ymd(new Date(utc(date).getTime() + n * 86_400_000));
/** 0 = 일요일 */
export const weekday = (date: string) => utc(date).getUTCDay();
export const WEEKDAY_LABEL = ["일", "월", "화", "수", "목", "금", "토"] as const;
/** 달력은 일요일 시작 */
export const startOfWeek = (date: string) => addDays(date, -weekday(date));
export const weekDays = (date: string) => Array.from({ length: 7 }, (_, i) => addDays(startOfWeek(date), i));
/** "2026-10" + n개월 → "YYYY-MM" */
export const addMonths = (month: string, n: number) => {
  const d = utc(`${month}-01`);
  d.setUTCMonth(d.getUTCMonth() + n);
  return ymd(d).slice(0, 7);
};
/** 월 달력 칸: 주 단위 배열, 앞뒤 달 날짜로 첫·마지막 주를 채운다(4~6주). */
export function monthGrid(month: string): string[][] {
  const last = addDays(`${addMonths(month, 1)}-01`, -1);
  const weeks: string[][] = [];
  for (let start = startOfWeek(`${month}-01`); start <= last; start = addDays(start, 7)) weeks.push(weekDays(start));
  return weeks;
}
/** 보이는 날짜들의 조회 범위 [from, to). 예: gte(x.startAt, from), lt(x.startAt, to) */
export const gridRange = (days: string[]) => ({ from: days[0], to: addDays(days[days.length - 1], 1) });

const isDate = (s: string) => /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(utc(s).getTime()) && ymd(utc(s)) === s;
export const CALENDAR_VIEWS = ["month", "week"] as const;
export type CalendarView = (typeof CALENDAR_VIEWS)[number];
/** 달력 화면 query: ?view=month|week&date=YYYY-MM-DD (date 가 속한 달·주를 보여 준다). 잘못된 값은 기본값. */
export const CalendarQuery = z.object({
  view: z.enum(CALENDAR_VIEWS).catch("month"),
  date: z.string().refine(isDate).optional().catch(undefined),
});
export type CalendarQuery = z.infer<typeof CalendarQuery>;
/** 화면에 보이는 날짜 전체(월 = 4~6주, 주 = 7일). gridRange 에 넘긴다. */
export const visibleDays = (view: CalendarView, date: string) => (view === "week" ? weekDays(date) : monthGrid(date.slice(0, 7)).flat());

export type CalendarEvent = {
  id: string;
  /** YYYY-MM-DD (KST) */
  date: string;
  /** HH:mm. 없으면 종일 → 같은 날 맨 앞 */
  time?: string;
  title: string;
  href?: string;
  /** primary = 강조(내 일정 등), 기본 subtle */
  tone?: "primary" | "subtle";
};
