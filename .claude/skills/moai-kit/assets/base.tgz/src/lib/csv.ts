// CSV 직렬화 (서버·클라이언트 공용). RFC 4180 따옴표 + 엑셀 한글용 UTF-8 BOM + CRLF.
// 수식 주입(CSV injection) 방지: 문자열 셀이 = + - @ 탭 CR 로 시작하면 앞에 ' 를 붙여 텍스트로 만든다(OWASP 권고).
// 내려받기 응답은 server/http/handler.ts 의 download(). 개인정보 열은 lib/mask.ts 로 가린 뒤 넣는다.

export type CsvColumn<T> = { header: string; value: (row: T) => string | number | boolean | null | undefined };

const FORMULA = /^[=+\-@\t\r]/;

export function csvCell(value: string | number | boolean | null | undefined): string {
  if (value === null || value === undefined) return "";
  let s = String(value);
  if (typeof value === "string" && FORMULA.test(s)) s = `'${s}`;
  return /[",\r\n]/.test(s) ? `"${s.replaceAll('"', '""')}"` : s;
}

export function toCsv<T>(rows: T[], columns: CsvColumn<T>[]): string {
  const lines = [columns.map((c) => csvCell(c.header)), ...rows.map((row) => columns.map((c) => csvCell(c.value(row))))];
  return `\uFEFF${lines.map((cells) => cells.join(",")).join("\r\n")}\r\n`;
}

/** CSV 텍스트 → 행 배열(RFC 4180: 따옴표·"" 이스케이프·따옴표 안 줄바꿈). BOM 제거, CRLF·LF 모두 허용, 빈 줄은 빈 행으로 남겨 행 번호를 보존한다. */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  const s = text.startsWith("\uFEFF") ? text.slice(1) : text;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (quoted) {
      if (ch !== '"') cell += ch;
      else if (s[i + 1] === '"') { cell += '"'; i++; }
      else quoted = false;
    } else if (ch === '"') quoted = true;
    else if (ch === ",") { row.push(cell); cell = ""; }
    else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && s[i + 1] === "\n") i++;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else cell += ch;
  }
  if (cell !== "" || row.length) { row.push(cell); rows.push(row); }
  return rows;
}
