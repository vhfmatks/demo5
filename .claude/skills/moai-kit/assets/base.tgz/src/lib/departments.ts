// 부서 목록·라벨. 사용자 소속(users.department)과 부서 범위 조회(<x>.read.dept, server/scope.ts)의 기준.
// 프로젝트 조직에 맞게 고친다. DB 는 text 라 값을 바꿔도 마이그레이션이 필요 없다(이미 저장된 옛 값은 관리자 화면에서 다시 지정).
export const DEPARTMENTS = ["PLAN", "DEV", "SALES", "OPS"] as const;
export type Department = (typeof DEPARTMENTS)[number];
export const DEPARTMENT_LABEL: Record<Department, string> = { PLAN: "기획팀", DEV: "개발팀", SALES: "영업팀", OPS: "운영팀" };
