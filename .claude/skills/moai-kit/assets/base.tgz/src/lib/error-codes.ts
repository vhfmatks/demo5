// 서버·클라이언트 공용 오류 계약. category는 공통 처리, code는 도메인의 구체적인 원인.
export const ERROR_STATUS = {
  VALIDATION_ERROR: 400,
  UNAUTHENTICATED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  INVALID_STATE: 409,
  PAYLOAD_TOO_LARGE: 413,
  UNSUPPORTED_MEDIA_TYPE: 415,
  RATE_LIMITED: 429,
  INTERNAL: 500,
  UPSTREAM_ERROR: 502,
  SERVICE_UNAVAILABLE: 503,
  TIMEOUT: 504,
} as const;

export type ErrorCategory = keyof typeof ERROR_STATUS;
// 응답 소비자는 이후 추가되는 코드도 받아야 한다. 발생시키는 코드는 defineErrors로 선언한다.
export type ErrorCode = string;

type ErrorConfig = {
  category: ErrorCategory;
  /** 사용자에게 공개 가능한 기본 메시지. DB·외부 서비스의 원문 오류를 넣지 않는다. */
  message: string;
  /** 재시도 가능성 안내. 클라이언트의 자동 재시도를 지시하지 않는다. */
  retryable?: boolean;
};

export type ErrorDefinition<C extends string = string> = Readonly<{
  code: C;
  category: ErrorCategory;
  message: string;
  retryable: boolean;
}>;

/** 기능별 errors.ts에서 선언. 한 코드의 category·의미는 유지하고 새 원인은 새 코드로 추가한다. */
export function defineErrors<const T extends Record<string, ErrorConfig>>(definitions: T) {
  const entries = Object.entries(definitions).map(([code, config]) => {
    if (!/^[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)*$/.test(code)) {
      throw new TypeError(`오류 코드는 DOMAIN_REASON 형식이어야 합니다: ${code}`);
    }
    if (!isErrorCategory(config.category) || !config.message.trim()) {
      throw new TypeError(`오류 정의의 category·message를 확인해 주세요: ${code}`);
    }
    return [code, Object.freeze({ ...config, code, retryable: config.retryable ?? false })];
  });
  return Object.freeze(Object.fromEntries(entries)) as {
    readonly [C in keyof T & string]: ErrorDefinition<C> & Readonly<T[C]>;
  };
}

export function isErrorCategory(value: unknown): value is ErrorCategory {
  return typeof value === "string" && Object.hasOwn(ERROR_STATUS, value);
}

export const CommonErrors = defineErrors({
  VALIDATION_ERROR: { category: "VALIDATION_ERROR", message: "입력값을 확인해 주세요." },
  AUTH_REQUIRED: { category: "UNAUTHENTICATED", message: "로그인이 필요합니다." },
  AUTH_PERMISSION_REQUIRED: { category: "FORBIDDEN", message: "이 작업을 수행할 권한이 없습니다." },
  FORBIDDEN: { category: "FORBIDDEN", message: "권한이 없습니다." },
  NOT_FOUND: { category: "NOT_FOUND", message: "대상을 찾을 수 없습니다." },
  CONFLICT: { category: "CONFLICT", message: "이미 존재하거나 다른 자료와 충돌합니다." },
  INVALID_STATE: { category: "INVALID_STATE", message: "현재 상태에서는 처리할 수 없습니다." },
  HTTP_INVALID_JSON: { category: "VALIDATION_ERROR", message: "JSON 형식이 올바르지 않습니다." },
  HTTP_CONTENT_TYPE_UNSUPPORTED: {
    category: "UNSUPPORTED_MEDIA_TYPE", message: "Content-Type: application/json 이어야 합니다.",
  },
  HTTP_PAYLOAD_TOO_LARGE: { category: "PAYLOAD_TOO_LARGE", message: "요청 크기가 허용 범위를 초과했습니다." },
  HTTP_ORIGIN_REQUIRED: { category: "FORBIDDEN", message: "쓰기 요청에는 Origin이 필요합니다." },
  HTTP_INVALID_ORIGIN: { category: "FORBIDDEN", message: "요청의 출처 형식이 올바르지 않습니다." },
  HTTP_ORIGIN_REJECTED: { category: "FORBIDDEN", message: "허용되지 않은 출처의 요청입니다." },
  HTTP_RATE_LIMITED: { category: "RATE_LIMITED", message: "요청이 많습니다. 잠시 후 다시 시도해 주세요.", retryable: true },
  INTERNAL: { category: "INTERNAL", message: "일시적인 오류가 발생했습니다." },
  UPSTREAM_ERROR: { category: "UPSTREAM_ERROR", message: "외부 서비스의 응답을 처리하지 못했습니다." },
  SERVICE_UNAVAILABLE: { category: "SERVICE_UNAVAILABLE", message: "서비스를 일시적으로 사용할 수 없습니다.", retryable: true },
  UPSTREAM_TIMEOUT: { category: "TIMEOUT", message: "외부 서비스의 응답 시간이 초과되었습니다.", retryable: true },
});

export const ClientErrors = defineErrors({
  CLIENT_INVALID_API_URL: { category: "VALIDATION_ERROR", message: "허용되지 않은 API 경로입니다." },
  CLIENT_SERIALIZATION_ERROR: { category: "VALIDATION_ERROR", message: "요청 데이터를 JSON으로 변환하지 못했습니다." },
  CLIENT_NETWORK_ERROR: { category: "SERVICE_UNAVAILABLE", message: "네트워크 오류가 발생했습니다.", retryable: true },
  CLIENT_INVALID_RESPONSE: { category: "INTERNAL", message: "서버의 응답을 처리하지 못했습니다." },
});

export type FieldErrors = Record<string, string[]>;
export type ValidationIssue = {
  path: (string | number)[];
  /** 필드별 검증 규칙(Zod의 invalid_type, too_small, custom 등). 입력값은 포함하지 않는다. */
  code: string;
  message: string;
};

export type ApiErrorPayload = {
  code: ErrorCode;
  category: ErrorCategory;
  message: string;
  traceId: string;
  retryable: boolean;
  retryAfterSeconds?: number;
  fieldErrors?: FieldErrors;
  issues?: ValidationIssue[];
};

// api()로 처리하는 응답 봉투(Envelope). 미등록 경로·미지원 메서드는 Next 기본 응답.
export type ApiSuccess<T> = { data: T; meta?: PageMeta };
export type ApiFailure = { error: ApiErrorPayload };
export type PageMeta = { page: number; pageSize: number; total: number };
