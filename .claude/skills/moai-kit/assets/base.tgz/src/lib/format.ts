// 표시용 포맷터 (서버·클라이언트 공용). 날짜는 항상 Asia/Seoul 기준.
const dtf = new Intl.DateTimeFormat("ko-KR", {
  timeZone: "Asia/Seoul",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  hour12: false,
});
export const fmtDateTime = (iso: string | Date) => dtf.format(new Date(iso));
export const fmtNumber = (n: number) => n.toLocaleString("ko-KR");
