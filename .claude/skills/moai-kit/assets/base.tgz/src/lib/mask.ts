// 개인정보 보호 (서버·클라이언트 공용, 순수 함수). 규칙은 docs/conventions/rbac.md "민감 필드".
//  - 볼 권한이 없으면 마스킹보다 제거(omitUnless)가 먼저다. 마스킹은 "일부만 보여줘야 하는" 화면·내보내기용.
//  - 판단은 서버 toDto 에서 한다. 클라이언트에서 가리는 것은 보호가 아니다(응답에 원문이 남는다).

/** 가운데를 * 로 가린다. 앞뒤 keep 글자만 남긴다. 짧으면 전부 가린다. */
export function maskMiddle(value: string, keep = 1): string {
  const chars = Array.from(value);
  if (chars.length <= keep * 2) return "*".repeat(chars.length);
  return chars.slice(0, keep).join("") + "*".repeat(chars.length - keep * 2) + chars.slice(-keep).join("");
}

/** 홍길동 → 홍*동, 남궁민수 → 남**수, 이산 → 이* */
export const maskName = (name: string) => (Array.from(name).length === 2 ? `${Array.from(name)[0]}*` : maskMiddle(name));

/** 010-1234-5678 → 010-****-5678 (구분자 없어도 동작) */
export const maskPhone = (phone: string) =>
  phone.replace(/(\d{2,3})[-\s.]?(\d{3,4})[-\s.]?(\d{4})/, (_, a: string, b: string, c: string) => `${a}-${"*".repeat(b.length)}-${c}`);

/** hong.gd@kt.com → ho*****@kt.com */
export function maskEmail(email: string): string {
  const at = email.lastIndexOf("@");
  if (at < 1) return maskMiddle(email);
  const id = email.slice(0, at);
  return `${id.slice(0, 2)}${"*".repeat(Math.max(1, id.length - 2))}${email.slice(at)}`;
}

/** allowed 가 아니면 keys 를 DTO 에서 지운다(값·길이·존재 모두 숨김). DTO 타입에서 해당 필드는 선택(?)으로 선언한다. */
export function omitUnless<T extends object, K extends keyof T>(allowed: boolean, dto: T, ...keys: K[]): Omit<T, K> & Partial<Pick<T, K>> {
  if (allowed) return dto;
  const out = { ...dto };
  for (const key of keys) delete out[key];
  return out;
}
