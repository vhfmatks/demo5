// 역할 목록·라벨만 둔다. 역할이 무엇을 할 수 있는지는 lib/permissions.ts 가 단일 기준.
export const ROLES = ["USER", "MANAGER", "APPROVER", "AUDITOR", "ADMIN"] as const;
export type Role = (typeof ROLES)[number];
export const ROLE_LABEL: Record<Role, string> = { USER: "일반", MANAGER: "부서장", APPROVER: "승인자", AUDITOR: "감사 담당", ADMIN: "관리자" };
