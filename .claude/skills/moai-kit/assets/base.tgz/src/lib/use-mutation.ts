"use client";
// [클라이언트] 쓰기 동작 표준 훅. 폼·버튼은 모두 이 훅으로 처리한다.
//   const m = useMutation((v: Input) => apiClient.post("/api/v1/x", v), { onSuccess: () => router.push("/x") })
//   m.run(values) / m.pending / m.error(전체 메시지) / m.fieldErrors.title
// 성공하면 기본으로 router.refresh() → Server Component 목록이 최신화된다.
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import type { ZodType } from "zod";
import { ApiError } from "./api-client";
import { CommonErrors, type FieldErrors } from "./error-codes";

type Options<R> = { onSuccess?: (result: R) => void; refresh?: boolean; schema?: Pick<ZodType, "safeParse"> };

export function useMutation<V, R>(fn: (v: V) => Promise<R>, opts: Options<R> = {}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [failure, setFailure] = useState<ApiError | null>(null);

  function run(values: V) {
    setFailure(null);
    if (opts.schema) {
      const parsed = opts.schema.safeParse(values);
      if (!parsed.success) {
        const fieldErrors: FieldErrors = Object.create(null);
        const issues = parsed.error.issues.map((issue) => {
          const key = issue.path.join(".") || "_";
          fieldErrors[key] ??= [];
          fieldErrors[key].push(issue.message);
          return { path: issue.path.map((part) => typeof part === "number" ? part : String(part)), code: issue.code, message: issue.message };
        });
        setFailure(new ApiError({ ...CommonErrors.VALIDATION_ERROR, fieldErrors, issues }, 0));
        return;
      }
    }
    startTransition(async () => {
      try {
        const result = await fn(values);
        opts.onSuccess?.(result);
        if (opts.refresh !== false) router.refresh();
      } catch (e) {
        if (e instanceof ApiError) {
          // 세션 만료 → 로그인 화면으로 (로그인 화면 자체의 실패는 제외)
          if (e.category === "UNAUTHENTICATED" && window.location.pathname !== "/login") router.push("/login");
          setFailure(e);
        } else {
          setFailure(new ApiError(CommonErrors.INTERNAL, 0));
        }
      }
    });
  }

  return { run, pending, error: failure?.message ?? null, fieldErrors: failure?.fieldErrors ?? {}, failure };
}

/** <form> 의 값을 객체로 (빈 문자열 유지 — 공유 zod 스키마로 검증) */
export const formValues = (form: HTMLFormElement) =>
  Object.fromEntries(new FormData(form).entries()) as Record<string, string>;
