import "server-only";
import { db, type DbExecutor } from "@/server/db/client";
import { auditLogs } from "@/server/db/schema";

/** 모든 쓰기(생성·수정·삭제·상태전이)는 서비스에서 이 함수로 기록한다. 민감정보는 detail 에 넣지 않는다. */
export async function audit(
  actorId: string | null,
  action: string,
  entity: string,
  entityId: string | null,
  detail?: Record<string, unknown>,
  executor: DbExecutor = db,
) {
  await executor.insert(auditLogs).values({ actorId, action, entity, entityId, detail }).run();
}
