// 세션 표준: DB 세션 + httpOnly 쿠키. 쿠키에는 랜덤 토큰, DB에는 그 SHA-256 해시만 저장.
import "server-only";
import { createHash, randomBytes } from "node:crypto";
import { cache } from "react";
import { cookies } from "next/headers";
import { notFound, redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db, type DbExecutor } from "@/server/db/client";
import { sessions, users, type Role } from "@/server/db/schema";
import { getSettings } from "@/features/settings/service";
import { AppError } from "@/server/http/errors";
import { audit } from "@/server/audit";
import { CommonErrors } from "@/lib/error-codes";
import { can, type Permission } from "@/lib/permissions";
import type { Department } from "@/lib/departments";

export type SessionUser = { id: string; email: string; name: string; role: Role; department: Department | null };

const COOKIE = "sid";

const hash = (token: string) => createHash("sha256").update(token).digest("hex");

/** 현재 사용자 (없으면 null). 한 요청 안에서는 1회만 조회된다. */
export const getCurrentUser = cache(async (): Promise<SessionUser | null> => {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return null;
  const row = await db
    .select({ user: users, expiresAt: sessions.expiresAt })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(eq(sessions.id, hash(token)))
    .get();
  if (!row || row.expiresAt.getTime() < Date.now()) return null;
  const { id, email, name, role, department } = row.user;
  return { id, email, name, role, department };
});

/** Server Component 용: 로그인 안 했으면 /login 으로 보낸다. */
export async function requireUser(): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

/** 권한 제한 화면(관리자 포털·결재함 등). 권한이 없으면 존재를 숨긴다(404). */
export async function requirePermission(permission: Permission): Promise<SessionUser> {
  const user = await requireUser();
  if (!can(user, permission)) notFound();
  return user;
}

/** service 용: 권한이 없으면 403 AUTH_PERMISSION_REQUIRED. 자원별 조건은 각 policy 에서 추가로 판단한다. */
export function assertPermission(actor: SessionUser | null, permission: Permission): asserts actor is SessionUser {
  if (!can(actor, permission)) throw new AppError(CommonErrors.AUTH_PERMISSION_REQUIRED);
}

export async function createSession(userId: string) {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + (await getSettings()).sessionTtlHours * 60 * 60 * 1000); // 관리자 설정
  await db.insert(sessions).values({ id: hash(token), userId, expiresAt }).run();
  (await cookies()).set(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production" && process.env.INSECURE_COOKIE !== "1",
    path: "/",
    expires: expiresAt,
  });
}

/** 해당 사용자의 모든 세션 폐기 (비밀번호 변경 등) */
export async function revokeAllSessions(userId: string, executor: DbExecutor = db) {
  await executor.delete(sessions).where(eq(sessions.userId, userId)).run();
}

/** 로그아웃: 현재 세션 삭제·쿠키 제거. 실제로 끝낸 세션만 감사로 남긴다. */
export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(COOKIE)?.value;
  const ended = token ? await db.delete(sessions).where(eq(sessions.id, hash(token))).returning({ userId: sessions.userId }).get() : undefined;
  jar.delete(COOKIE);
  if (ended) await audit(ended.userId, "auth.logout", "user", ended.userId);
}
