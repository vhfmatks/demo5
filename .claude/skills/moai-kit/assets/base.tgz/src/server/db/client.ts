import "server-only";
import { openDb, type Db } from "./open";

// dev 서버 HMR 때 커넥션이 중복 생성되지 않도록 globalThis에 보관
const g = globalThis as unknown as { __db?: Db };

export const db: Db = g.__db ?? openDb(process.env.DATABASE_URL ?? "data/dev.db");
if (process.env.NODE_ENV !== "production") g.__db = db;

export type { Db, DbExecutor, DbTransaction } from "./open";
