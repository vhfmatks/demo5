// server-only 를 import 하지 않는다: scripts/·tests/ 에서도 재사용하기 위함
// 드라이버: @libsql/client — 플랫폼별 바이너리를 npm 레지스트리에서 받으므로 C++ 컴파일·외부 다운로드가 없다.
import fs from "node:fs";
import path from "node:path";
import { createClient } from "@libsql/client";
import { drizzle, type LibSQLDatabase } from "drizzle-orm/libsql";
import { migrate } from "drizzle-orm/libsql/migrator";
import * as schema from "./schema";

export type Db = LibSQLDatabase<typeof schema>;
export type DbTransaction = Parameters<Parameters<Db["transaction"]>[0]>[0];
export type DbExecutor = Db | DbTransaction;

export function openDb(file: string): Db {
  const memory = file === ":memory:";
  if (!memory) fs.mkdirSync(path.dirname(path.resolve(file)), { recursive: true });
  const client = createClient({ url: memory ? ":memory:" : `file:${path.resolve(file)}` });
  // 단일 연결에서 순서대로 실행되므로 이후 쿼리보다 먼저 적용된다
  void client.execute("PRAGMA foreign_keys = ON");
  if (!memory) void client.execute("PRAGMA journal_mode = WAL");
  return drizzle(client, { schema });
}

export async function migrateDb(db: Db) {
  await migrate(db, { migrationsFolder: path.resolve(process.cwd(), "drizzle") });
}
