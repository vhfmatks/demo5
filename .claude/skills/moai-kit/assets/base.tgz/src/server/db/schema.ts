// 모든 테이블은 이 파일 하나에 정의한다. (AI가 읽을 파일 수를 줄이기 위함)
// 규칙: id = text(UUID), 시간 = integer(timestamp_ms), enum = text({ enum }), FK는 references()
// enum 값 배열은 features/<도메인>/schema.ts 에 두고 여기서 import (클라이언트와 공유하기 위함)
import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";
// drizzle-kit 이 이 파일을 직접 읽으므로 "@/" 별칭 대신 상대경로를 쓴다
import { ROLES } from "../../lib/roles";
import { DEPARTMENTS } from "../../lib/departments";
import { AI_KINDS } from "../../features/ai/schema";
// @gen:imports
export type { Role } from "../../lib/roles";

const id = () =>
  text("id")
    .primaryKey()
    .$defaultFn(() => crypto.randomUUID());
const createdAt = () =>
  integer("created_at", { mode: "timestamp_ms" })
    .notNull()
    .default(sql`(unixepoch() * 1000)`)
    .$defaultFn(() => new Date()); // ms 정밀도 (정렬 안정성)
const updatedAt = () =>
  integer("updated_at", { mode: "timestamp_ms" })
    .notNull()
    .default(sql`(unixepoch() * 1000)`)
    .$defaultFn(() => new Date())
    .$onUpdateFn(() => new Date());

// ── 공통: 사용자·세션·감사로그 ──────────────────────────────
export const users = sqliteTable("users", {
  id: id(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  passwordHash: text("password_hash").notNull(),
  role: text("role", { enum: ROLES }).notNull().default("USER"),
  department: text("department", { enum: DEPARTMENTS }), // null = 미지정. 부서 범위 조회는 server/scope.ts
  createdAt: createdAt(),
});

export const sessions = sqliteTable("sessions", {
  id: text("id").primaryKey(), // 랜덤 토큰의 SHA-256 해시 (원문 토큰은 쿠키에만 존재)
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: integer("expires_at", { mode: "timestamp_ms" }).notNull(),
  createdAt: createdAt(),
});

export const auditLogs = sqliteTable(
  "audit_logs",
  {
    id: id(),
    actorId: text("actor_id").references(() => users.id, { onDelete: "set null" }),
    action: text("action").notNull(), // 예: request.create, request.approve
    entity: text("entity").notNull(),
    entityId: text("entity_id"),
    detail: text("detail", { mode: "json" }).$type<Record<string, unknown>>(),
    createdAt: createdAt(),
  },
  (t) => [index("audit_entity_idx").on(t.entity, t.entityId), index("audit_created_idx").on(t.createdAt)],
);

// 운영 설정 (key-value). 값 형식·기본값은 features/settings/schema.ts 의 SETTING_FIELDS 가 단일 기준. 비밀값은 넣지 않는다(.env 사용).
export const appSettings = sqliteTable("app_settings", {
  key: text("key").primaryKey(),
  value: text("value", { mode: "json" }).$type<unknown>().notNull(),
  updatedBy: text("updated_by").references(() => users.id, { onDelete: "set null" }),
  updatedAt: updatedAt(),
});

// ── AI 공급자·모델 (관리자 포털 > AI). 키는 server/secret.ts 로 암호화해 저장한다 ──
export const aiProviders = sqliteTable("ai_providers", {
  id: id(),
  name: text("name").notNull().unique(),
  kind: text("kind", { enum: AI_KINDS }).notNull(),
  baseUrl: text("base_url").notNull(),
  apiKeyEnc: text("api_key_enc"), // null = 키 없음(로컬 모델)
  apiKeyHint: text("api_key_hint"), // 끝 4자리 표시용
  createdAt: createdAt(),
});

export const aiModels = sqliteTable(
  "ai_models",
  {
    id: id(),
    providerId: text("provider_id")
      .notNull()
      .references(() => aiProviders.id, { onDelete: "cascade" }),
    model: text("model").notNull(), // 공급자의 모델 ID
    label: text("label").notNull(), // 기능 코드가 부르는 이름 (aiComplete({ model: label }))
    isDefault: integer("is_default", { mode: "boolean" }).notNull().default(false),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex("ai_models_label_idx").on(t.label), index("ai_models_provider_idx").on(t.providerId)],
);

// @gen:tables — `npm run gen` 이 이 줄 위에 새 테이블을 추가한다. 지우지 말 것.
