// 에러 표준: 서비스는 AppError 만 throw 한다. HTTP 변환은 handler.ts 가 담당.
// 클라이언트(src/lib/api-client.ts)도 같은 코드를 공유한다 → src/lib/error-codes.ts
import type { ZodError } from "zod";
import {
  CommonErrors, ERROR_STATUS, type ErrorDefinition, type FieldErrors, type ValidationIssue,
} from "@/lib/error-codes";

export type { FieldErrors } from "@/lib/error-codes";

type ErrorOptions = {
  /** 4xx용 공개 메시지. 5xx 응답에는 승인된 카탈로그 기본 메시지만 사용한다. */
  message?: string;
  fieldErrors?: FieldErrors;
  issues?: ValidationIssue[];
  /** 내부 원인. HTTP 응답에 직렬화하지 않는다. */
  cause?: unknown;
  /** 429·503에만 사용. 초 단위이며 음수가 아닌 정수. */
  retryAfterSeconds?: number;
};

export class AppError extends Error {
  constructor(
    public readonly definition: ErrorDefinition,
    private readonly options: ErrorOptions = {},
  ) {
    super(options.message ?? definition.message, { cause: options.cause });
    this.name = "AppError";
    if (options.retryAfterSeconds !== undefined && (
      !Number.isSafeInteger(options.retryAfterSeconds) || options.retryAfterSeconds < 0 ||
      !["RATE_LIMITED", "SERVICE_UNAVAILABLE"].includes(definition.category)
    )) {
      throw new TypeError("retryAfterSeconds는 429·503에 음수가 아닌 정수로 지정합니다.");
    }
  }
  get code() { return this.definition.code; }
  get category() { return this.definition.category; }
  get status() {
    return ERROR_STATUS[this.category];
  }
  get publicMessage() { return this.status >= 500 ? this.definition.message : this.message; }
  get retryable() { return this.definition.retryable; }
  get retryAfterSeconds() { return this.options.retryAfterSeconds; }
  get fieldErrors() { return this.status >= 500 ? undefined : this.options.fieldErrors; }
  get issues() { return this.status >= 500 ? undefined : this.options.issues; }
}

// 자주 쓰는 생성자 — 메시지는 사용자에게 그대로 보이므로 한국어로 짧게
export const Errors = {
  validation: (fieldErrors: FieldErrors, message = "입력값을 확인해 주세요.") =>
    new AppError(CommonErrors.VALIDATION_ERROR, { message, fieldErrors }),
  unauthenticated: (message = "로그인이 필요합니다.") => new AppError(CommonErrors.AUTH_REQUIRED, { message }),
  forbidden: (message = "권한이 없습니다.") => new AppError(CommonErrors.FORBIDDEN, { message }),
  notFound: (what = "대상") => new AppError(CommonErrors.NOT_FOUND, { message: `${what}을(를) 찾을 수 없습니다.` }),
  conflict: (message: string) => new AppError(CommonErrors.CONFLICT, { message }),
  invalidState: (message: string) => new AppError(CommonErrors.INVALID_STATE, { message }),
};

export function fromZod(err: ZodError): AppError {
  const fieldErrors: FieldErrors = Object.create(null);
  const issues: ValidationIssue[] = [];
  for (const issue of err.issues) {
    const key = issue.path.join(".") || "_";
    fieldErrors[key] ??= [];
    fieldErrors[key].push(issue.message);
    issues.push({
      path: issue.path.map((part) => typeof part === "number" ? part : String(part)),
      code: issue.code,
      message: issue.message,
    });
  }
  return new AppError(CommonErrors.VALIDATION_ERROR, { fieldErrors, issues });
}
