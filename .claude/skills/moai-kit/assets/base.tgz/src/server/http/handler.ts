// Route Handler 표준 래퍼. 모든 app/api/v1/**/route.ts 는 이것만 사용한다.
//   export const GET = api(async ({ user, req }) => ok(await svc.list(user!, query(req, ListQuery))));
// 책임: 인증·역할 검사 / CSRF(Origin) 검사 / 익명 쓰기 횟수 제한 / AppError·ZodError → 표준 에러 봉투 / 예상 못한 에러 은닉
import "server-only";
import { NextResponse, type NextRequest } from "next/server";
import { z, ZodError, type ZodType } from "zod";
import { CommonErrors, type ApiFailure, type PageMeta } from "@/lib/error-codes";
import { can, type Permission } from "@/lib/permissions";
import { getCurrentUser, type SessionUser } from "@/server/auth/session";
import { getSettings } from "@/features/settings/service";
import { SettingsErrors } from "@/features/settings/errors";
import { recordHit, retryAfterSeconds } from "@/server/rate-limit";
import { AppError, Errors, fromZod } from "./errors";

export const MAX_JSON_BYTES = 64 * 1024;
export const IdParams = z.strictObject({ id: z.uuid("올바른 ID 형식이 아닙니다.") });

type Options<P> = {
  /** 기본 "required". 공개 API만 "public" */
  auth?: "required" | "public";
  /** 지정 시 해당 권한이 있는 사용자만 허용 (역할이 아니라 권한으로 제한) */
  permission?: Permission;
  /** 동적 경로는 공유 경로 스키마로 파싱한다. */
  params?: ZodType<P>;
};

type Ctx<P> = { req: NextRequest; params: P; user: SessionUser | null };
type RequiredCtx<P> = { req: NextRequest; params: P; user: SessionUser };

export function api<P = Record<string, never>>(
  fn: (ctx: RequiredCtx<P>) => Promise<Response>,
  opts?: Options<P> & { auth?: "required" },
): (req: NextRequest, ctx: { params: Promise<P> }) => Promise<Response>;
export function api<P = Record<string, never>>(
  fn: (ctx: Ctx<P>) => Promise<Response>,
  opts: Options<P> & { auth: "public" },
): (req: NextRequest, ctx: { params: Promise<P> }) => Promise<Response>;
export function api<P>(fn: (ctx: never) => Promise<Response>, opts: Options<P> = {}) {
  const run = fn as (ctx: Ctx<P>) => Promise<Response>;
  return async (req: NextRequest, ctx: { params: Promise<P> }) => {
    const traceId = crypto.randomUUID();
    try {
      const write = req.method !== "GET" && req.method !== "HEAD";
      if (write) assertSameOrigin(req);
      const user = await getCurrentUser();
      // 점검 모드: 관리자 외 쓰기 거부. 로그인·로그아웃은 허용(관리자가 해제할 수 있도록).
      if (write && !can(user, "maintenance.bypass") && !["/api/v1/auth/login", "/api/v1/auth/logout"].includes(req.nextUrl.pathname) &&
        (await getSettings()).maintenanceMode) throw new AppError(SettingsErrors.SETTINGS_MAINTENANCE_MODE);
      if ((opts.auth ?? "required") === "required" && !user) throw Errors.unauthenticated();
      if (write && !user && !req.nextUrl.pathname.startsWith("/api/v1/auth/")) limitAnonymousWrite(req); // 로그인은 auth service 가 제한
      if (opts.permission && !can(user, opts.permission)) throw new AppError(CommonErrors.AUTH_PERMISSION_REQUIRED);
      const rawParams = await ctx.params;
      const params = opts.params ? opts.params.parse(rawParams) : rawParams;
      const response = await run({ req, params, user });
      response.headers.set("X-Trace-Id", traceId);
      response.headers.set("Cache-Control", "no-store");
      return response;
    } catch (e) {
      return toErrorResponse(e, traceId);
    }
  };
}

// ── 응답 헬퍼 ──────────────────────────────────────────────
export const ok = <T>(data: T, meta?: PageMeta) =>
  NextResponse.json(meta ? { data, meta } : { data }, { status: 200 });
export const created = <T>(data: T) => NextResponse.json({ data }, { status: 201 });
export const noContent = () => new NextResponse(null, { status: 204 });
/** 파일 내려받기 (CSV 등). 파일명은 RFC 5987 로 인코딩해 한글도 안전하다. 내용은 lib/csv.ts toCsv() 로 만든다. */
export const download = (filename: string, content: string | Uint8Array<ArrayBuffer>, contentType = "text/csv; charset=utf-8") =>
  new NextResponse(content, {
    status: 200,
    headers: {
      "Content-Type": contentType,
      "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`,
      "X-Content-Type-Options": "nosniff",
    },
  });

// ── 입력 파싱 헬퍼 (지원하지 않는 Content-Type은 415, 크기 초과 413, 잘못된 JSON·필드는 400) ──
export async function body<T>(req: NextRequest, schema: ZodType<T>): Promise<T> {
  if (mediaType(req) !== "application/json") throw new AppError(CommonErrors.HTTP_CONTENT_TYPE_UNSUPPORTED);
  const bytes = await readLimited(req, MAX_JSON_BYTES);
  let raw: unknown;
  try {
    raw = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch {
    throw new AppError(CommonErrors.HTTP_INVALID_JSON, { fieldErrors: { _: ["JSON 형식이 올바르지 않습니다."] } });
  }
  return schema.parse(raw);
}

export const MAX_UPLOAD_BYTES = 5 * 1024 * 1024;
/**
 * multipart/form-data 의 파일 하나. 내용 해석은 서비스에서 한다(표 → server/import.ts readTable).
 *   export const POST = api(async ({ req, user }) => created(await svc.importX(user!, await upload(req, { extensions: [".csv", ".xlsx"] }))));
 * 확장자는 안내용 1차 검사일 뿐이다. 실제 형식은 내용으로 다시 확인한다.
 */
export async function upload(
  req: NextRequest,
  { field = "file", maxBytes = MAX_UPLOAD_BYTES, extensions }: { field?: string; maxBytes?: number; extensions?: string[] } = {},
): Promise<File> {
  if (mediaType(req) !== "multipart/form-data") {
    throw new AppError(CommonErrors.HTTP_CONTENT_TYPE_UNSUPPORTED, { message: "Content-Type: multipart/form-data 여야 합니다." });
  }
  const bytes = await readLimited(req, maxBytes + 64 * 1024); // multipart 경계·헤더 여유분
  const form = await new Response(bytes, { headers: { "Content-Type": req.headers.get("content-type") ?? "" } }).formData()
    .catch(() => { throw Errors.validation({ [field]: ["업로드 형식이 올바르지 않습니다."] }); });
  const file = form.get(field);
  if (!(file instanceof File) || file.size === 0) throw Errors.validation({ [field]: ["파일을 선택해 주세요."] });
  if (file.size > maxBytes) throw new AppError(CommonErrors.HTTP_PAYLOAD_TOO_LARGE, { message: `파일은 ${Math.floor(maxBytes / 1024 / 1024)}MB 이하여야 합니다.` });
  if (extensions && !extensions.some((ext) => file.name.toLowerCase().endsWith(ext))) {
    throw Errors.validation({ [field]: [`${extensions.join(", ")} 파일만 올릴 수 있습니다.`] });
  }
  return file;
}

export function query<T>(req: NextRequest, schema: ZodType<T>): T {
  return schema.parse(Object.fromEntries(req.nextUrl.searchParams));
}

// ── 내부 ───────────────────────────────────────────────────
const mediaType = (req: NextRequest) => req.headers.get("content-type")?.split(";", 1)[0].trim().toLowerCase();

/** 본문을 max 바이트까지만 읽는다. Content-Length 를 믿지 않고 실제 읽은 양으로도 끊는다. */
async function readLimited(req: NextRequest, max: number): Promise<Uint8Array<ArrayBuffer>> {
  if (Number(req.headers.get("content-length")) > max) throw new AppError(CommonErrors.HTTP_PAYLOAD_TOO_LARGE);
  const reader = req.body?.getReader();
  if (!reader) return new Uint8Array();
  const parts: Uint8Array[] = [];
  let bytes = 0;
  try {
    while (true) {
      const chunk = await reader.read();
      if (chunk.done) break;
      bytes += chunk.value.byteLength;
      if (bytes > max) throw new AppError(CommonErrors.HTTP_PAYLOAD_TOO_LARGE);
      parts.push(chunk.value);
    }
  } catch (error) {
    await reader.cancel().catch(() => undefined);
    throw error;
  } finally {
    reader.releaseLock();
  }
  return new Uint8Array(Buffer.concat(parts));
}

// 익명 공개 쓰기: 클라이언트 주소당 분당 60회. 주소 = x-forwarded-for 마지막 값(가장 가까운 프록시가 붙인 값,
// 프록시가 없으면 next start 가 소켓 주소로 채운다).
// ponytail: 프록시 없이 직접 노출하면 클라이언트가 이 헤더를 바꿔 우회할 수 있다. 운영은 앞단 프록시·WAF 제한을 함께 둔다.
const ANON_WRITE = { limit: 60, windowMs: 60_000 };
function limitAnonymousWrite(req: NextRequest) {
  const key = `anon-write:${req.headers.get("x-forwarded-for")?.split(",").at(-1)?.trim() || "unknown"}`;
  const wait = retryAfterSeconds(key, ANON_WRITE);
  if (wait) throw new AppError(CommonErrors.HTTP_RATE_LIMITED, { retryAfterSeconds: wait });
  recordHit(key, ANON_WRITE.windowMs);
}

function assertSameOrigin(req: NextRequest) {
  const origin = req.headers.get("origin");
  if (!origin) throw new AppError(CommonErrors.HTTP_ORIGIN_REQUIRED);
  let originUrl: URL;
  try {
    originUrl = new URL(origin);
  } catch {
    throw new AppError(CommonErrors.HTTP_INVALID_ORIGIN);
  }
  if (!["http:", "https:"].includes(originUrl.protocol) || originUrl.origin !== origin) {
    throw new AppError(CommonErrors.HTTP_INVALID_ORIGIN);
  }
  const configured = process.env.APP_ORIGIN ?? req.nextUrl.origin;
  const target = new URL(configured);
  if (!["http:", "https:"].includes(target.protocol) || target.origin !== configured) {
    throw new Error("APP_ORIGIN은 경로가 없는 http(s) origin이어야 합니다.");
  }
  if (originUrl.origin !== target.origin) {
    throw new AppError(CommonErrors.HTTP_ORIGIN_REJECTED);
  }
}

export function toErrorResponse(e: unknown, traceId: string) {
  const err = e instanceof AppError ? e : e instanceof ZodError ? fromZod(e) : new AppError(CommonErrors.INTERNAL, { cause: e });
  if (err.status >= 500) {
    // 예외 원문에는 SQL·외부 응답·개인정보가 있을 수 있으므로 안전한 식별 정보만 기록한다.
    console.error("[api.error]", { traceId, code: err.code, category: err.category, errorName: e instanceof Error ? e.name : "UnknownError" });
  }
  const headers: Record<string, string> = { "X-Trace-Id": traceId, "Cache-Control": "no-store" };
  if (err.retryAfterSeconds !== undefined) headers["Retry-After"] = String(err.retryAfterSeconds);
  return NextResponse.json<ApiFailure>(
    { error: {
      code: err.code,
      category: err.category,
      message: err.publicMessage,
      fieldErrors: err.fieldErrors,
      issues: err.issues,
      traceId,
      retryable: err.retryable,
      retryAfterSeconds: err.retryAfterSeconds,
    } },
    { status: err.status, headers },
  );
}
