// Server Component 에서 서비스 호출 시 에러 처리 표준.
//   const item = await load(getRequest(user, id))   // category NOT_FOUND → 404 페이지, 그 외 → error.tsx
import "server-only";
import { notFound, redirect } from "next/navigation";
import { AppError } from "./errors";

export async function load<T>(p: Promise<T>): Promise<T> {
  try {
    return await p;
  } catch (e) {
    if (e instanceof AppError) {
      if (e.category === "NOT_FOUND") notFound();
      if (e.category === "UNAUTHENTICATED") redirect("/login");
    }
    throw e;
  }
}
