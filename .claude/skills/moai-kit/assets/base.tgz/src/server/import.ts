// 표 가져오기: 업로드 파일(.csv/.xlsx) → 문자열 표 → 머리행 매핑 + zod 행 검사.
//   const items = parseRows(await readTable(file), [{ header: "제목", key: "title" }, { header: "분류", key: "category", value: fromLabel(CATEGORY_LABEL) }], CreateXInput);
//   → 한 행이라도 틀리면 400(fieldErrors "3행 분류": [...]) 이므로 저장은 전부 아니면 전무(한 트랜잭션).
// 파일은 handler.ts upload() 로 받는다. XLSX 는 의존성 없이 첫 시트의 값만 읽는다(수식은 저장된 계산값, 서식·병합 무시).
import "server-only";
import { inflateRawSync } from "node:zlib";
import type { ZodType } from "zod";
import { parseCsv } from "@/lib/csv";
import { Errors } from "@/server/http/errors";

export const MAX_IMPORT_ROWS = 1000;
const MAX_COLS = 100;
const MAX_XML_BYTES = 30 * 1024 * 1024; // 압축 해제 상한(zip bomb 방지)

const fail = (message: string) => Errors.validation({ file: [message] }, message);

/** 파일 → 문자열 표. 인덱스 + 1 = 원본 행 번호(빈 행 포함). CSV 는 UTF-8, 실패하면 CP949(엑셀 한글판 기본). */
export async function readTable(file: File): Promise<string[][]> {
  const bytes = new Uint8Array(await file.arrayBuffer());
  const name = file.name.toLowerCase();
  let table: string[][];
  if (name.endsWith(".xlsx")) table = readXlsx(bytes);
  else if (name.endsWith(".csv")) table = parseCsv(decodeText(bytes));
  else throw fail(name.endsWith(".xls") ? "예전 엑셀 형식(.xls)입니다. .xlsx 또는 .csv 로 다시 저장해 주세요." : ".csv 또는 .xlsx 파일만 읽을 수 있습니다.");
  if (table.length > MAX_IMPORT_ROWS + 1) throw fail(`한 번에 ${MAX_IMPORT_ROWS}행까지 가져올 수 있습니다.`);
  return table;
}

export type ImportColumn = {
  /** 파일 머리행의 이름(앞뒤 공백 무시) */
  header: string;
  /** 스키마 필드 이름 */
  key: string;
  /** 셀 문자열 → 스키마 입력값. 생략 시 문자열 그대로 */
  value?: (cell: string) => unknown;
  /** 머리행에 없어도 되는 열(스키마 기본값 사용) */
  optional?: boolean;
};

/** 첫 비어 있지 않은 행 = 머리행. 빈 셀은 undefined 로 넘겨 스키마 기본값을 쓴다. 오류는 50개쯤 모이면 멈추고 한 번에 400. */
export function parseRows<T>(table: string[][], columns: ImportColumn[], schema: ZodType<T>): T[] {
  const isEmpty = (row: string[]) => row.every((c) => c.trim() === "");
  const head = table.findIndex((row) => !isEmpty(row));
  if (head < 0) throw fail("빈 파일입니다.");
  const headers = table[head].map((c) => c.trim());
  const missing = columns.filter((c) => !c.optional && !headers.includes(c.header)).map((c) => c.header);
  if (missing.length) throw fail(`머리행에 ${missing.join(", ")} 열이 없습니다.`);
  const present = columns.filter((c) => headers.includes(c.header)).map((c) => ({ ...c, index: headers.indexOf(c.header) }));

  const items: T[] = [];
  const errors: Record<string, string[]> = {};
  let errorCount = 0;
  for (let i = head + 1; i < table.length && errorCount < 50; i++) {
    if (isEmpty(table[i])) continue;
    const cells = present.map((c) => (table[i][c.index] ?? "").trim());
    const input = Object.fromEntries(present.map((c, j) => [c.key, cells[j] === "" ? undefined : c.value ? c.value(cells[j]) : cells[j]]));
    const parsed = schema.safeParse(input);
    if (parsed.success) {
      items.push(parsed.data);
      continue;
    }
    for (const issue of parsed.error.issues) {
      const j = present.findIndex((c) => c.key === issue.path[0]);
      const key = `${i + 1}행${j < 0 ? "" : ` ${present[j].header}`}`;
      errors[key] ??= [];
      errors[key].push(j >= 0 && cells[j] === "" && issue.code === "invalid_type" ? "값을 입력해 주세요." : issue.message);
      errorCount++;
    }
  }
  if (errorCount) throw Errors.validation(errors, `${Object.keys(errors).length}곳에 오류가 있습니다. 파일을 고쳐 다시 올려 주세요.`);
  if (!items.length) throw fail("가져올 데이터 행이 없습니다.");
  return items;
}

/** 라벨(장비) 또는 코드(EQUIPMENT) → 코드. 모르는 값은 그대로 넘겨 스키마가 거부한다. */
export const fromLabel = (labels: Record<string, string>) => (cell: string) =>
  Object.keys(labels).find((k) => labels[k] === cell) ?? cell;
/** "1,000" → 1000. 숫자가 아니면 NaN → 스키마 오류 */
export const toNumber = (cell: string) => Number(cell.replaceAll(",", ""));
/** 예·Y·O·TRUE·1 → true, 그 외 false */
export const toBool = (cell: string) => ["예", "Y", "O", "TRUE", "1"].includes(cell.toUpperCase());

// ── 내부: 텍스트 ─────────────────────────────────────────────
function decodeText(bytes: Uint8Array): string {
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    return new TextDecoder("euc-kr").decode(bytes); // WHATWG euc-kr = CP949
  }
}

// ── 내부: XLSX (zip + SpreadsheetML) ─────────────────────────
function unzip(buf: Uint8Array) {
  const v = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65_557); i--) {
    if (v.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw fail("엑셀 파일을 읽을 수 없습니다.");
  const entries = new Map<string, { method: number; size: number; local: number }>();
  let p = v.getUint32(eocd + 16, true);
  for (let n = v.getUint16(eocd + 10, true); n > 0 && p + 46 <= buf.length && v.getUint32(p, true) === 0x02014b50; n--) {
    const nameLen = v.getUint16(p + 28, true);
    const name = new TextDecoder().decode(buf.subarray(p + 46, p + 46 + nameLen));
    entries.set(name, { method: v.getUint16(p + 10, true), size: v.getUint32(p + 20, true), local: v.getUint32(p + 42, true) });
    p += 46 + nameLen + v.getUint16(p + 30, true) + v.getUint16(p + 32, true);
  }
  return (name: string): string | undefined => {
    const e = entries.get(name);
    if (!e) return undefined;
    if (e.local + 30 > buf.length || v.getUint32(e.local, true) !== 0x04034b50) throw fail("엑셀 파일이 손상되었습니다.");
    const start = e.local + 30 + v.getUint16(e.local + 26, true) + v.getUint16(e.local + 28, true);
    const raw = buf.subarray(start, start + e.size);
    try {
      const data = e.method === 0 ? raw : inflateRawSync(raw, { maxOutputLength: MAX_XML_BYTES });
      if (data.length > MAX_XML_BYTES) throw new RangeError("too large");
      return new TextDecoder().decode(data);
    } catch {
      throw fail("엑셀 파일이 너무 크거나 손상되었습니다.");
    }
  };
}

type Tag = { name: string; attrs: string; end: number };
/** 선형 태그 스캐너(정규식 백트래킹 없음). name 은 접두사 제거, 닫는 태그는 "/name". */
function* tags(xml: string): Generator<Tag> {
  for (let i = xml.indexOf("<"); i >= 0; i = xml.indexOf("<", i + 1)) {
    const end = xml.indexOf(">", i);
    if (end < 0) return;
    const body = xml.slice(i + 1, end);
    const m = /^(\/?)(?:[\w.-]+:)?([\w.-]+)/.exec(body);
    if (m) yield { name: m[1] + m[2], attrs: body, end };
    i = end;
  }
}
const attr = (t: Tag, name: string) => new RegExp(`(?:^|\\s)${name}="([^"]*)"`).exec(t.attrs)?.[1];
const textAfter = (xml: string, t: Tag) => unescapeXml(xml.slice(t.end + 1, xml.indexOf("<", t.end)));
const unescapeXml = (s: string) =>
  s.replace(/&(#x[0-9a-f]+|#\d+|lt|gt|amp|quot|apos);/gi, (_, e: string) =>
    e[0] === "#" ? String.fromCodePoint(Number.parseInt(e.slice(e[1] === "x" || e[1] === "X" ? 2 : 1), e[1] === "x" || e[1] === "X" ? 16 : 10))
      : ({ lt: "<", gt: ">", amp: "&", quot: '"', apos: "'" } as Record<string, string>)[e.toLowerCase()])
    .replace(/_x([0-9A-F]{4})_/g, (_, h: string) => String.fromCharCode(Number.parseInt(h, 16)));

function readXlsx(bytes: Uint8Array): string[][] {
  const read = unzip(bytes);
  const workbook = read("xl/workbook.xml");
  if (!workbook) throw fail("엑셀 파일을 읽을 수 없습니다.");
  // 첫 시트 경로: workbook.xml 첫 <sheet r:id> → rels Target
  let sheetPath = "xl/worksheets/sheet1.xml";
  const firstSheet = [...tags(workbook)].find((t) => t.name === "sheet");
  const rid = firstSheet && attr(firstSheet, "r:id");
  const rel = rid && [...tags(read("xl/_rels/workbook.xml.rels") ?? "")].find((t) => t.name === "Relationship" && attr(t, "Id") === rid);
  const target = rel && attr(rel, "Target");
  if (target) sheetPath = target.startsWith("/") ? target.slice(1) : `xl/${target}`;

  const shared: string[] = [];
  const ss = read("xl/sharedStrings.xml") ?? "";
  let cur: string[] | null = null;
  let phonetic = false;
  for (const t of tags(ss)) {
    if (t.name === "si") cur = [];
    else if (t.name === "/si" && cur) shared.push(cur.join(""));
    else if (t.name === "rPh") phonetic = true;
    else if (t.name === "/rPh") phonetic = false;
    else if (t.name === "t" && cur && !phonetic && !t.attrs.endsWith("/")) cur.push(textAfter(ss, t));
  }

  const dateStyles = readDateStyles(read("xl/styles.xml") ?? "");
  const sheet = read(sheetPath);
  if (!sheet) throw fail("엑셀 시트를 찾을 수 없습니다.");
  const table: string[][] = [];
  let r = 0;
  let c = -1;
  let cell: { r: number; c: number; type: string; style: number; value: string } | null = null;
  for (const t of tags(sheet)) {
    if (t.name === "row") {
      r = Number(attr(t, "r") ?? r + 1);
      c = -1;
      if (r > MAX_IMPORT_ROWS + 1) throw fail(`한 번에 ${MAX_IMPORT_ROWS}행까지 가져올 수 있습니다.`);
    } else if (t.name === "c") {
      const ref = attr(t, "r");
      c = ref ? colIndex(ref) : c + 1;
      if (c >= MAX_COLS) throw fail(`열은 ${MAX_COLS}개까지 읽을 수 있습니다.`);
      cell = { r, c, type: attr(t, "t") ?? "n", style: Number(attr(t, "s") ?? 0), value: "" };
      if (t.attrs.endsWith("/")) cell = null;
    } else if ((t.name === "v" || t.name === "t") && cell && !t.attrs.endsWith("/")) {
      cell.value += textAfter(sheet, t);
    } else if (t.name === "/c" && cell) {
      const { type, value, style } = cell;
      const out = type === "s" ? (shared[Number(value)] ?? "")
        : type === "b" ? (value === "1" ? "TRUE" : "FALSE")
        : type === "n" && value !== "" ? (dateStyles.has(style) ? excelDate(Number(value)) : String(Number(value)))
        : value;
      while (table.length < cell.r) table.push([]);
      const row = table[cell.r - 1];
      while (row.length < cell.c) row.push("");
      row[cell.c] = out;
      cell = null;
    }
  }
  return table;
}

const colIndex = (ref: string) => {
  let n = 0;
  for (const ch of ref) {
    if (ch < "A" || ch > "Z") break;
    n = n * 26 + ch.charCodeAt(0) - 64;
  }
  return n - 1;
};

/** cellXfs 순번 중 날짜·시간 서식인 것. 기본 서식 14~22·45~47, 사용자 서식은 [] "" 밖에 y·d·h 가 있으면 날짜로 본다. */
function readDateStyles(xml: string): Set<number> {
  const custom = new Map<number, string>();
  const result = new Set<number>();
  let inXfs = false;
  let index = 0;
  for (const t of tags(xml)) {
    if (t.name === "numFmt") custom.set(Number(attr(t, "numFmtId")), unescapeXml(attr(t, "formatCode") ?? ""));
    else if (t.name === "cellXfs") inXfs = true;
    else if (t.name === "/cellXfs") inXfs = false;
    else if (t.name === "xf" && inXfs) {
      const id = Number(attr(t, "numFmtId") ?? 0);
      const code = custom.get(id)?.replace(/"[^"]*"|\[[^\]]*\]/g, "");
      if ((id >= 14 && id <= 22) || (id >= 45 && id <= 47) || (code !== undefined && /[ydh]/i.test(code))) result.add(index);
      index++;
    }
  }
  return result;
}

/** 엑셀 일련값(1900 체계) → 날짜 YYYY-MM-DD / 일시 YYYY-MM-DDTHH:mm / 시각 HH:mm (gen date·datetime 형식과 같다) */
export function excelDate(serial: number): string {
  if (!(serial >= 0 && serial < 2_958_466)) return String(serial); // 9999-12-31 초과·음수는 숫자 그대로
  const iso = new Date(Date.UTC(1899, 11, 30) + Math.round(serial * 86_400) * 1000).toISOString();
  return serial < 1 ? iso.slice(11, 16) : Number.isInteger(serial) ? iso.slice(0, 10) : iso.slice(0, 16);
}
