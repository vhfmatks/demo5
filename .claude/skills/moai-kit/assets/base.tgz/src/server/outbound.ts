// 외부 HTTP 호출의 단일 지점 (서버 전용). 리다이렉트 거부·시간 제한·응답 크기 상한을 항상 건다.
// 주소 허용 규칙(SSRF)은 호출하는 쪽이 먼저 검사한다(예: features/ai/schema.ts isAllowedAiUrl). 키·본문을 로그에 남기지 않는다.
import "server-only";

export class OutboundError extends Error {
  constructor(public readonly reason: "network" | "timeout" | "too_large") {
    super(reason);
    this.name = "OutboundError";
  }
}

export async function outboundFetch(url: string, init: {
  method?: "GET" | "POST";
  headers?: Record<string, string>;
  /** JSON 본문 (Content-Type 자동) */
  json?: unknown;
  timeoutMs?: number;
  maxBytes?: number;
}): Promise<{ status: number; ok: boolean; text: string }> {
  const { method = init.json === undefined ? "GET" : "POST", timeoutMs = 30_000, maxBytes = 2_000_000 } = init;
  let res: Response;
  try {
    res = await fetch(url, {
      method,
      headers: { ...(init.json === undefined ? {} : { "content-type": "application/json" }), ...init.headers },
      body: init.json === undefined ? undefined : JSON.stringify(init.json),
      redirect: "error",
      cache: "no-store",
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch (error) {
    throw new OutboundError(error instanceof Error && error.name === "TimeoutError" ? "timeout" : "network");
  }
  const reader = res.body?.getReader();
  const parts: Uint8Array[] = [];
  let bytes = 0;
  try {
    while (reader) {
      const chunk = await reader.read();
      if (chunk.done) break;
      bytes += chunk.value.byteLength;
      if (bytes > maxBytes) throw new OutboundError("too_large");
      parts.push(chunk.value);
    }
  } catch (error) {
    await reader?.cancel().catch(() => undefined);
    throw error instanceof OutboundError ? error : new OutboundError(error instanceof Error && error.name === "TimeoutError" ? "timeout" : "network");
  }
  return { status: res.status, ok: res.ok, text: Buffer.concat(parts).toString("utf8") };
}
