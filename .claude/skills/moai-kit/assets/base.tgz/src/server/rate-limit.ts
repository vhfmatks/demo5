// 반복 시도 제한 (서버 전용). key 마다 최근 windowMs 안의 기록 수를 센다(슬라이딩 창).
// ponytail: 프로세스 메모리. 서버를 여러 대로 늘리거나 재시작에도 유지해야 하면 DB·Redis 카운터로 옮긴다.
import "server-only";

export type RateRule = { limit: number; windowMs: number };

const hits = new Map<string, { at: number[]; windowMs: number }>();
const MAX_KEYS = 10_000;

const recent = (key: string, now: number) => {
  const entry = hits.get(key);
  return entry ? entry.at.filter((t) => now - t < entry.windowMs) : [];
};

/** 제한에 걸렸으면 다시 시도까지 남은 초(1 이상), 아니면 0. 기록하지 않는다. */
export function retryAfterSeconds(key: string, rule: RateRule, now = Date.now()): number {
  const at = recent(key, now).filter((t) => now - t < rule.windowMs);
  return at.length >= rule.limit ? Math.max(1, Math.ceil((at[at.length - rule.limit] + rule.windowMs - now) / 1000)) : 0;
}

/** 시도 1회를 기록한다. 키가 너무 많으면 창이 지난 키부터 지운다. */
export function recordHit(key: string, windowMs: number, now = Date.now()) {
  if (hits.size >= MAX_KEYS) for (const [k] of hits) if (!recent(k, now).length) hits.delete(k);
  hits.set(key, { at: [...recent(key, now), now], windowMs });
}

/** 성공 등으로 기록을 지운다. */
export const clearHits = (key: string) => void hits.delete(key);
