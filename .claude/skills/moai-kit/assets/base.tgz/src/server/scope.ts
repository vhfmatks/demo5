// 목록 조회 범위 → where 조건. policy 의 listScope(actor) 결과("all" | "dept" | "own")를 소유자 열에 적용한다.
//   const scope = ownerScope(actor, listScope(actor), items.ownerId); if (scope) where.push(scope);
// dept = 소유자의 "현재" 부서가 actor 와 같은 행. 부서 미지정 actor 는 own 과 같다.
// ponytail: 사람이 부서를 옮기면 지난 자료도 따라간다. 작성 시점 부서로 고정하려면 행에 department 열을 두고 그 열로 거른다.
import "server-only";
import { eq, inArray, type SQL } from "drizzle-orm";
import type { SQLiteColumn } from "drizzle-orm/sqlite-core";
import { db } from "@/server/db/client";
import { users } from "@/server/db/schema";
import type { SessionUser } from "@/server/auth/session";

export type ListScope = "all" | "dept" | "own";

export function ownerScope(actor: SessionUser, scope: ListScope, ownerId: SQLiteColumn): SQL | undefined {
  if (scope === "all") return undefined;
  if (scope === "dept" && actor.department) {
    return inArray(ownerId, db.select({ id: users.id }).from(users).where(eq(users.department, actor.department)));
  }
  return eq(ownerId, actor.id);
}
