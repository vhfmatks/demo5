// 저장용 비밀값 암호화 (AES-256-GCM). DB 에는 암호문만, 화면·응답에는 hint(끝 4자리)만 둔다.
// 키 = APP_SECRET 환경변수(운영 필수), 개발에서 없으면 DB 파일 옆 app-secret.key(최초 1회 생성, git 제외). 메모리 DB(단위 시험)는 프로세스 동안만.
// 키가 바뀌거나 파일을 지우면 기존 암호문은 풀리지 않는다 → 해당 값을 다시 등록한다.
import "server-only";
import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";
import fs from "node:fs";
import path from "node:path";

let cached: Buffer | undefined;

function key(): Buffer {
  if (cached) return cached;
  let raw = process.env.APP_SECRET;
  if (!raw) {
    // 운영(next start)에서는 자동 생성 키를 쓰지 않는다: 서버 교체·백업 복원 시 암호문이 풀리지 않고 키가 DB 옆에 남는다.
    if (process.env.NODE_ENV === "production") throw new Error("운영 환경에는 APP_SECRET 환경변수가 필요합니다.");
    const dbFile = process.env.DATABASE_URL ?? "data/dev.db";
    if (dbFile === ":memory:") raw = randomBytes(32).toString("hex");
    else {
      // turbopackIgnore: 실행 중 정해지는 DB 경로라 빌드 추적 대상이 아니다
      const file = path.join(path.dirname(path.resolve(/*turbopackIgnore: true*/ dbFile)), "app-secret.key");
      fs.mkdirSync(path.dirname(file), { recursive: true });
      try {
        fs.writeFileSync(file, randomBytes(32).toString("hex"), { mode: 0o600, flag: "wx" });
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
      }
      raw = fs.readFileSync(file, "utf8").trim();
    }
  }
  cached = createHash("sha256").update(raw).digest();
  return cached;
}

export function encryptSecret(plain: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key(), iv);
  const data = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  return ["v1", iv.toString("base64url"), cipher.getAuthTag().toString("base64url"), data.toString("base64url")].join(".");
}

/** 위조·키 불일치면 throw */
export function decryptSecret(token: string): string {
  const [version, iv, tag, data] = token.split(".");
  if (version !== "v1" || !iv || !tag || !data) throw new Error("알 수 없는 암호문 형식");
  const decipher = createDecipheriv("aes-256-gcm", key(), Buffer.from(iv, "base64url"));
  decipher.setAuthTag(Buffer.from(tag, "base64url"));
  return Buffer.concat([decipher.update(Buffer.from(data, "base64url")), decipher.final()]).toString("utf8");
}

export const secretHint = (plain: string) => (plain ? `••••${plain.slice(-4)}` : null);
