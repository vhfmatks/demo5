"use client";
import { useRouter } from "next/navigation";
import { Alert, Button, Field, Input, Textarea } from "@/components/ui";
import { apiClient } from "@/lib/api-client";
import { formValues, useMutation } from "@/lib/use-mutation";
import { Create__Entity__Input, type __Entity__Dto } from "../schema";
// @f:imports

export function __Entity__Form({ initial }: { initial?: __Entity__Dto }) {
  const router = useRouter();
  const m = useMutation((values: Record<string, string>) => initial
    ? apiClient.patch<__Entity__Dto>(`/api/v1/__entities__/${initial.id}`, { ...values, version: initial.version })
    : apiClient.post<__Entity__Dto>("/api/v1/__entities__", values),
  { schema: Create__Entity__Input, onSuccess: (row) => router.push(`/__entities__/${row.id}`) });
  return (
    <form noValidate className="flex max-w-xl flex-col gap-4" onSubmit={(event) => {
      event.preventDefault();
      m.run(formValues(event.currentTarget));
    }}>
      <Field label="제목" name="title" required error={m.fieldErrors.title}>
        <Input name="title" defaultValue={initial?.title} invalid={!!m.fieldErrors.title} />
      </Field>
      <Field label="메모" name="memo" error={m.fieldErrors.memo}>
        <Textarea name="memo" defaultValue={initial?.memo} invalid={!!m.fieldErrors.memo} />
      </Field>
      {/* @f:form */}
      <Alert>{m.error}</Alert>
      <div className="kds-cta-bar kit-form-actions">
        <Button variant="secondary" onClick={() => router.back()}>취소</Button>
        <Button type="submit" loading={m.pending}>{initial ? "저장" : "등록"}</Button>
        {m.failure?.category === "CONFLICT" && <Button variant="tertiary" onClick={() => window.location.reload()}>새로고침</Button>}
      </div>
    </form>
  );
}
