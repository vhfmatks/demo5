import { DataTable, type Column } from "@/components/ui";
import { fmtDateTime } from "@/lib/format";
import type { __Entity__Dto } from "../schema";
// @f:imports

const columns: Column<__Entity__Dto>[] = [
  { key: "title", header: "제목", render: (row) => row.title },
  // @f:col
  { key: "memo", header: "메모", render: (row) => row.memo },
  { key: "updatedAt", header: "수정일", render: (row) => fmtDateTime(row.updatedAt), className: "whitespace-nowrap" },
];
export const __Entity__Table = ({ rows }: { rows: __Entity__Dto[] }) => (
  <DataTable rows={rows} columns={columns} empty="등록된 __label__이(가) 없습니다." rowHref={(row) => `/__entities__/${row.id}`} />
);
