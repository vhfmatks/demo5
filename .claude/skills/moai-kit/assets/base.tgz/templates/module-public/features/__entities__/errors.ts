import { defineErrors } from "../../lib/error-codes";

export const __Entity__Errors = defineErrors({
  __ENTITY___NOT_FOUND: { category: "NOT_FOUND", message: "__label__을(를) 찾을 수 없습니다." },
  __ENTITY___READ_FORBIDDEN: { category: "FORBIDDEN", message: "__label__ 공개 조회가 비활성화되어 있습니다." },
  __ENTITY___CREATE_FORBIDDEN: { category: "FORBIDDEN", message: "__label__ 공개 등록이 비활성화되어 있습니다." },
  __ENTITY___EDIT_FORBIDDEN: { category: "FORBIDDEN", message: "__label__ 공개 수정이 비활성화되어 있습니다." },
  __ENTITY___DELETE_FORBIDDEN: { category: "FORBIDDEN", message: "__label__ 공개 삭제가 비활성화되어 있습니다." },
  __ENTITY___VERSION_CONFLICT: { category: "CONFLICT", message: "다른 사용자가 변경했습니다. 새로고침 후 다시 시도해 주세요." },
});
