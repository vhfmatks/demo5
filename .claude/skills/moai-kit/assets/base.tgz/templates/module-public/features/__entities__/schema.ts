// [공유] __label__의 입력·DTO 계약. 생성 기본값을 PATCH에 적용하지 않는다.
import { z } from "zod";
// @f:enums

const __Entity__Fields = {
  title: z.string().trim().min(1, "제목을 입력해 주세요.").max(100, "100자 이하"),
  memo: z.string().trim().max(2000, "2000자 이하"),
  // @f:zod
};
export const Create__Entity__Input = z.strictObject({
  ...__Entity__Fields,
  memo: __Entity__Fields.memo.default(""),
  // @f:defaults
});
export type Create__Entity__Input = z.infer<typeof Create__Entity__Input>;

export const Update__Entity__Input = z.strictObject({
  title: __Entity__Fields.title.optional(),
  memo: __Entity__Fields.memo.optional(),
  // @f:upd
  version: z.int().min(1),
}).refine((input) => Object.entries(input).some(([key, value]) => key !== "version" && value !== undefined), {
  message: "수정할 항목을 하나 이상 입력해 주세요.",
});
export type Update__Entity__Input = z.infer<typeof Update__Entity__Input>;

export const Delete__Entity__Query = z.object({ version: z.coerce.number().int().min(1) });
export type Delete__Entity__Query = z.infer<typeof Delete__Entity__Query>;
export const List__Entity__Query = z.object({
  q: z.string().trim().max(50).optional().catch(undefined),
  page: z.coerce.number().int().min(1).default(1).catch(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(10).catch(10),
});
export type List__Entity__Query = z.infer<typeof List__Entity__Query>;

export type __Entity__Dto = {
  id: string;
  title: string;
  memo: string;
  // @f:dto
  version: number;
  createdAt: string;
  updatedAt: string;
};
