// [서버] actor는 선택적 세션이며 쓰기 감사에만 사용한다. 공개 데이터에는 소유자 조건이 없다.
import "server-only";
import { and, count, desc, eq, like, sql } from "drizzle-orm";
import { db, type DbExecutor } from "@/server/db/client";
import { __entities__ } from "@/server/db/schema";
import { AppError } from "@/server/http/errors";
import { audit } from "@/server/audit";
import type { SessionUser } from "@/server/auth/session";
import type { PageMeta } from "@/lib/error-codes";
import { canCreate, canDelete, canEdit, canView } from "./policy";
import { __Entity__Errors } from "./errors";
import type { Create__Entity__Input, __Entity__Dto, List__Entity__Query, Update__Entity__Input } from "./schema";

const ENTITY = "__entity__";
const toDto = (row: typeof __entities__.$inferSelect): __Entity__Dto => ({
  id: row.id, title: row.title, memo: row.memo, version: row.version,
  // @f:map
  createdAt: row.createdAt.toISOString(), updatedAt: row.updatedAt.toISOString(),
});
async function loadRow(id: string, executor: DbExecutor = db) {
  const row = await executor.select().from(__entities__).where(eq(__entities__.id, id)).get();
  if (!row) throw new AppError(__Entity__Errors.__ENTITY___NOT_FOUND);
  return row;
}

export async function list__Entities__(_actor: SessionUser | null, q: List__Entity__Query): Promise<{ items: __Entity__Dto[]; meta: PageMeta }> {
  if (!canView()) throw new AppError(__Entity__Errors.__ENTITY___READ_FORBIDDEN);
  const where = q.q ? like(__entities__.title, `%${q.q}%`) : undefined;
  const rows = await db.select().from(__entities__).where(where)
    .orderBy(desc(__entities__.createdAt), desc(__entities__.id)).limit(q.pageSize).offset((q.page - 1) * q.pageSize).all();
  const total = (await db.select({ n: count() }).from(__entities__).where(where).get())?.n ?? 0;
  return { items: rows.map(toDto), meta: { page: q.page, pageSize: q.pageSize, total } };
}

export async function get__Entity__(_actor: SessionUser | null, id: string): Promise<__Entity__Dto> {
  if (!canView()) throw new AppError(__Entity__Errors.__ENTITY___READ_FORBIDDEN);
  return toDto(await loadRow(id));
}

export async function create__Entity__(actor: SessionUser | null, input: Create__Entity__Input): Promise<__Entity__Dto> {
  if (!canCreate()) throw new AppError(__Entity__Errors.__ENTITY___CREATE_FORBIDDEN);
  return db.transaction(async (tx) => {
    const row = await tx.insert(__entities__).values(input).returning().get();
    await audit(actor?.id ?? null, `${ENTITY}.create`, ENTITY, row.id, undefined, tx);
    return toDto(row);
  });
}

export async function update__Entity__(actor: SessionUser | null, id: string, input: Update__Entity__Input): Promise<__Entity__Dto> {
  if (!canEdit()) throw new AppError(__Entity__Errors.__ENTITY___EDIT_FORBIDDEN);
  const { version, ...changes } = input;
  return db.transaction(async (tx) => {
    const row = await tx.update(__entities__).set({ ...changes, version: sql`${__entities__.version} + 1` })
      .where(and(eq(__entities__.id, id), eq(__entities__.version, version))).returning().get();
    if (!row) {
      await loadRow(id, tx);
      throw new AppError(__Entity__Errors.__ENTITY___VERSION_CONFLICT);
    }
    await audit(actor?.id ?? null, `${ENTITY}.update`, ENTITY, id, { fields: Object.keys(changes) }, tx);
    return toDto(row);
  });
}

export async function delete__Entity__(actor: SessionUser | null, id: string, version: number): Promise<void> {
  if (!canDelete()) throw new AppError(__Entity__Errors.__ENTITY___DELETE_FORBIDDEN);
  await db.transaction(async (tx) => {
    const result = await tx.delete(__entities__).where(and(eq(__entities__.id, id), eq(__entities__.version, version))).run();
    if (result.rowsAffected === 0) {
      await loadRow(id, tx);
      throw new AppError(__Entity__Errors.__ENTITY___VERSION_CONFLICT);
    }
    await audit(actor?.id ?? null, `${ENTITY}.delete`, ENTITY, id, undefined, tx);
  });
}
