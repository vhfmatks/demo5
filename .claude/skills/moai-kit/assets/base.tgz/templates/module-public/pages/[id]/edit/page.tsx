import { notFound } from "next/navigation";
import { Section, PageHeader } from "@/components/ui";
import { getCurrentUser } from "@/server/auth/session";
import { load } from "@/server/http/page";
import { get__Entity__ } from "@/features/__entities__/service";
import { canEdit } from "@/features/__entities__/policy";
import { __Entity__Form } from "@/features/__entities__/components/__Entity__Form";

export default async function Edit__Entity__Page({ params }: PageProps<"/__entities__/[id]/edit">) {
  const actor = await getCurrentUser();
  const row = await load(get__Entity__(actor, (await params).id));
  if (!canEdit()) notFound();
  return <><PageHeader title="__label__ 수정" /><Section><__Entity__Form initial={row} /></Section></>;
}
