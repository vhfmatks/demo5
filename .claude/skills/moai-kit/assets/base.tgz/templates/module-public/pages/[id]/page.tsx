import { Card, DescriptionList, PageHeader } from "@/components/ui";
import { getCurrentUser } from "@/server/auth/session";
import { load } from "@/server/http/page";
import { fmtDateTime } from "@/lib/format";
import { get__Entity__ } from "@/features/__entities__/service";
import { canDelete, canEdit } from "@/features/__entities__/policy";
import { __Entity__Actions } from "@/features/__entities__/components/__Entity__Actions";
// @f:imports

export default async function __Entity__DetailPage({ params }: PageProps<"/__entities__/[id]">) {
  const actor = await getCurrentUser();
  const row = await load(get__Entity__(actor, (await params).id));
  return <>
    <PageHeader title={row.title} />
    <div className="grid gap-4 md:grid-cols-2">
      <Card><DescriptionList items={[
        { label: "메모", value: row.memo || "-" },
        // @f:desc
        { label: "등록일", value: fmtDateTime(row.createdAt) },
        { label: "수정일", value: fmtDateTime(row.updatedAt) },
      ]} /></Card>
      <Card title="관리"><__Entity__Actions id={row.id} version={row.version} canEdit={canEdit()} canDelete={canDelete()} /></Card>
    </div>
  </>;
}
