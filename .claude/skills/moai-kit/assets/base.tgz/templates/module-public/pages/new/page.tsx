import { notFound } from "next/navigation";
import { Section, PageHeader } from "@/components/ui";
import { canCreate } from "@/features/__entities__/policy";
import { __Entity__Form } from "@/features/__entities__/components/__Entity__Form";

export default function New__Entity__Page() {
  if (!canCreate()) notFound();
  return <><PageHeader title="새 __label__" /><Section><__Entity__Form /></Section></>;
}
