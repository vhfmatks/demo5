import { ResultCount, SearchField, LinkButton, PageHeader, Pagination, FilterBar } from "@/components/ui";
import { getCurrentUser } from "@/server/auth/session";
import { list__Entities__ } from "@/features/__entities__/service";
import { List__Entity__Query } from "@/features/__entities__/schema";
import { canCreate } from "@/features/__entities__/policy";
import { __Entity__Table } from "@/features/__entities__/components/__Entity__Table";

export default async function __Entities__Page({ searchParams }: PageProps<"/__entities__">) {
  const actor = await getCurrentUser();
  const q = List__Entity__Query.parse(await searchParams);
  const { items, meta } = await list__Entities__(actor, q);
  return <>
    <PageHeader title="__label__" description="로그인 없이 함께 등록·조회·수정·삭제하는 공유 메모입니다."
      actions={canCreate() ? <LinkButton href="/__entities__/new" variant="tertiary">새 __label__</LinkButton> : undefined} />
    <FilterBar>
      <SearchField name="q" label="검색" defaultValue={q.q ?? ""} placeholder="제목 검색" />
    </FilterBar>
    <ResultCount total={meta.total} /><__Entity__Table rows={items} /><Pagination meta={meta} basePath="/__entities__" params={{ q: q.q }} />
  </>;
}
