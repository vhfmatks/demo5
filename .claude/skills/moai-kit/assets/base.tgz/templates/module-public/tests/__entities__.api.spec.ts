import { test, expect } from "./fixtures";
import { expectData, expectError, expectNoContent, uniqueTitle } from "./helpers";
import { CommonErrors } from "../../src/lib/error-codes";
import { __Entity__Errors } from "../../src/features/__entities__/errors";
import type { __Entity__Dto } from "../../src/features/__entities__/schema";

const URL = "/api/v1/__entities__";
const SAMPLE = {
  // @f:sample
};
test("TC-__ENTITY__-API-001 익명 생성·목록·조회·수정·삭제", async ({ apiAs }) => {
  const anon = await apiAs(null);
  const title = uniqueTitle("TC-__ENTITY__-API-001");
  const { data } = await expectData<__Entity__Dto>(await anon.post(URL, { data: { ...SAMPLE, title, memo: "합성 메모" } }), 201);
  expect(data).toMatchObject({ ...SAMPLE, title, memo: "합성 메모", version: 1 });
  const list = await expectData<__Entity__Dto[]>(await anon.get(`${URL}?q=${encodeURIComponent(title)}`));
  expect(list.meta).toMatchObject({ total: 1, page: 1, pageSize: 10 });
  expect(list.data[0].id).toBe(data.id);
  const itemURL = `${URL}/${data.id}`;
  await expectData<__Entity__Dto>(await anon.get(itemURL));
  const updated = await expectData<__Entity__Dto>(await anon.patch(itemURL, { data: { title: `${title} 수정`, version: 1 } }));
  expect(updated.data).toMatchObject({ memo: "합성 메모", version: 2 });
  expect((await expectData<__Entity__Dto>(await anon.get(itemURL))).data.title).toBe(`${title} 수정`);
  await expectNoContent(await anon.delete(`${itemURL}?version=2`));
  await expectError(await anon.get(itemURL), __Entity__Errors.__ENTITY___NOT_FOUND);
});

test("TC-__ENTITY__-API-002 오래된 version 수정·삭제 거부와 값 불변", async ({ apiAs }) => {
  const first = await apiAs(null);
  const second = await apiAs(null);
  const { data } = await expectData<__Entity__Dto>(await first.post(URL, { data: { ...SAMPLE, title: uniqueTitle("TC-__ENTITY__-API-002") } }), 201);
  const itemURL = `${URL}/${data.id}`;
  const updated = await expectData<__Entity__Dto>(await first.patch(itemURL, { data: { memo: "최신 메모", version: 1 } }));
  await expectError(await second.patch(itemURL, { data: { memo: "오래된 화면", version: 1 } }), __Entity__Errors.__ENTITY___VERSION_CONFLICT);
  await expectError(await second.delete(`${itemURL}?version=1`), __Entity__Errors.__ENTITY___VERSION_CONFLICT);
  expect((await expectData<__Entity__Dto>(await first.get(itemURL))).data).toMatchObject(updated.data);
});

test("TC-__ENTITY__-API-003 빈 값·version 누락·없는 대상 처리", async ({ apiAs }) => {
  const anon = await apiAs(null);
  const { data } = await expectData<__Entity__Dto>(await anon.post(URL, { data: { ...SAMPLE, title: uniqueTitle("TC-__ENTITY__-API-003") } }), 201);
  const itemURL = `${URL}/${data.id}`;
  await expectError(await anon.post(URL, { data: { title: "" } }), CommonErrors.VALIDATION_ERROR);
  await expectError(await anon.patch(itemURL, { data: { title: "버전 없음" } }), CommonErrors.VALIDATION_ERROR);
  await expectError(await anon.patch(itemURL, { data: { version: 1 } }), CommonErrors.VALIDATION_ERROR);
  await expectError(await anon.delete(itemURL), CommonErrors.VALIDATION_ERROR);
  await expectError(await anon.get(`${URL}/${crypto.randomUUID()}`), __Entity__Errors.__ENTITY___NOT_FOUND);
  expect((await expectData<__Entity__Dto>(await anon.get(itemURL))).data).toMatchObject({ title: data.title, version: 1 });
});

