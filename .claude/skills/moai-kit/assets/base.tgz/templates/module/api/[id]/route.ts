import { api, body, IdParams, noContent, ok } from "@/server/http/handler";
import { Update__Entity__Input } from "@/features/__entities__/schema";
import { delete__Entity__, get__Entity__, update__Entity__ } from "@/features/__entities__/service";

type P = { id: string };

export const GET = api<P>(async ({ params, user }) => ok(await get__Entity__(user, params.id)), { params: IdParams });
export const PATCH = api<P>(async ({ req, params, user }) => ok(await update__Entity__(user, params.id, await body(req, Update__Entity__Input))), { params: IdParams });
export const DELETE = api<P>(async ({ params, user }) => {
  await delete__Entity__(user, params.id);
  return noContent();
}, { params: IdParams });

export const runtime = "nodejs";
