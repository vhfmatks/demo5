import { api, body, created, ok, query } from "@/server/http/handler";
import { Create__Entity__Input, List__Entity__Query } from "@/features/__entities__/schema";
import { create__Entity__, list__Entities__ } from "@/features/__entities__/service";

export const GET = api(async ({ req, user }) => {
  const { items, meta } = await list__Entities__(user, query(req, List__Entity__Query));
  return ok(items, meta);
});

export const POST = api(async ({ req, user }) => created(await create__Entity__(user, await body(req, Create__Entity__Input))));

export const runtime = "nodejs";
