"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Alert, Button, ConfirmDialog, LinkButton } from "@/components/ui";
import { apiClient } from "@/lib/api-client";
import { useMutation } from "@/lib/use-mutation";

export function __Entity__Actions({ id, canEdit, canDelete }: { id: string; canEdit: boolean; canDelete: boolean }) {
  const router = useRouter();
  const [confirming, setConfirming] = useState(false);
  const d = useMutation(() => apiClient.del(`/api/v1/__entities__/${id}`), { onSuccess: () => router.push("/__entities__"), refresh: false });
  if (!canEdit && !canDelete) return <p className="text-sm text-muted">권한이 있는 작업이 없습니다.</p>;
  return (
    <div className="flex flex-col gap-3">
      <div className="flex gap-2">
        {canEdit && <LinkButton href={`/__entities__/${id}/edit`} variant="tertiary">수정</LinkButton>}
        {canDelete && <Button variant="tertiary" onClick={() => setConfirming(true)}>삭제</Button>}
      </div>
      <ConfirmDialog open={confirming} title="삭제할까요?" confirmLabel="삭제 확인"
        loading={d.pending} onConfirm={() => d.run(undefined)} onCancel={() => setConfirming(false)}>
        <Alert>{d.error}</Alert>
      </ConfirmDialog>
    </div>
  );
}
