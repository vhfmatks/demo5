"use client";
import { useRouter } from "next/navigation";
import { Alert, Button, Field, Input, Textarea } from "@/components/ui";
import { apiClient } from "@/lib/api-client";
import { formValues, useMutation } from "@/lib/use-mutation";
import { Create__Entity__Input, type __Entity__Dto } from "../schema";
// @f:imports

export function __Entity__Form({ initial }: { initial?: __Entity__Dto }) {
  const router = useRouter();
  const m = useMutation(
    (v: Record<string, string>) =>
      initial ? apiClient.patch<__Entity__Dto>(`/api/v1/__entities__/${initial.id}`, v) : apiClient.post<__Entity__Dto>("/api/v1/__entities__", v),
    { schema: Create__Entity__Input, onSuccess: (r) => router.push(`/__entities__/${r.id}`) },
  );
  const fe = m.fieldErrors;
  return (
    <form noValidate className="flex max-w-xl flex-col gap-4" onSubmit={(e) => { e.preventDefault(); m.run(formValues(e.currentTarget)); }}>
      <Field label="제목" name="title" required error={fe.title}>
        <Input name="title" defaultValue={initial?.title} invalid={!!fe.title} />
      </Field>
      <Field label="메모" name="memo" error={fe.memo}>
        <Textarea name="memo" defaultValue={initial?.memo} invalid={!!fe.memo} />
      </Field>
      {/* @f:form */}
      <Alert>{m.error}</Alert>
      <div className="kds-cta-bar kit-form-actions">
        <Button variant="secondary" onClick={() => router.back()}>취소</Button>
        <Button type="submit" loading={m.pending}>{initial ? "저장" : "등록"}</Button>
      </div>
    </form>
  );
}
