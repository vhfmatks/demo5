import { DataTable, type Column } from "@/components/ui";
import { fmtDateTime } from "@/lib/format";
import type { __Entity__Dto } from "../schema";
// @f:imports

const columns: Column<__Entity__Dto>[] = [
  { key: "title", header: "제목", render: (r) => r.title },
  // @f:col
  { key: "owner", header: "작성자", render: (r) => r.owner.name },
  { key: "createdAt", header: "등록일", render: (r) => fmtDateTime(r.createdAt), className: "whitespace-nowrap" },
];

export const __Entity__Table = ({ rows }: { rows: __Entity__Dto[] }) => (
  <DataTable rows={rows} columns={columns} empty="등록된 __label__이(가) 없습니다." rowHref={(r) => `/__entities__/${r.id}`} />
);
