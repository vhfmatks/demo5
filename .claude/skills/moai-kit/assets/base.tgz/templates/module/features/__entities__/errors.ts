// [공유] __label__ 공개 오류 계약. 새 원인은 __ENTITY___REASON 코드로 추가한다.
import { defineErrors } from "../../lib/error-codes";

export const __Entity__Errors = defineErrors({
  __ENTITY___NOT_FOUND: { category: "NOT_FOUND", message: "__label__을(를) 찾을 수 없습니다." },
  __ENTITY___EDIT_FORBIDDEN: { category: "FORBIDDEN", message: "__label__ 수정 권한이 없습니다." },
  __ENTITY___DELETE_FORBIDDEN: { category: "FORBIDDEN", message: "__label__ 삭제 권한이 없습니다." },
});
