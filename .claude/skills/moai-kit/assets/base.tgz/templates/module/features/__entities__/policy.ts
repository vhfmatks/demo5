// [공유] __label__ 권한 규칙 (순수 함수). 기본: 소유자만 조회·수정·삭제, __entity__.manage.any 권한은 전체 조회·삭제,
// __entity__.read.dept 권한(기본 MANAGER)은 같은 부서 구성원 것 조회만.
// 권한 키는 lib/permissions.ts (gen 이 추가). 어떤 역할에 줄지는 ROLE_DEFINITIONS 에서 정한다(ADMIN 은 자동 포함).
import { can } from "../../lib/permissions";
import type { Department } from "../../lib/departments";
import type { Role } from "../../lib/roles";

type Actor = { id: string; role: Role; department: Department | null };
type Owned = { ownerId: string };
type Visible = Owned & { ownerDepartment: Department | null };

const manager = (a: Actor) => can(a, "__entity__.manage.any");
const deptReader = (a: Actor) => can(a, "__entity__.read.dept") && a.department !== null;
export const canView = (a: Actor, t: Visible) =>
  manager(a) || a.id === t.ownerId || (deptReader(a) && a.department === t.ownerDepartment);
export const canEdit = (a: Actor, t: Owned) => a.id === t.ownerId;
export const canDelete = (a: Actor, t: Owned) => manager(a) || a.id === t.ownerId;
export const listScope = (a: Actor): "all" | "dept" | "own" => (manager(a) ? "all" : deptReader(a) ? "dept" : "own");
