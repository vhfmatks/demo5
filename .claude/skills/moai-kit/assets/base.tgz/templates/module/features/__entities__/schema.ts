// [공유] __label__ — enum·라벨·zod 입력·DTO. 필드를 바꾸면 db/schema.ts 의 __entities__ 테이블도 함께 바꾼다.
// 주의: "@/" 별칭 금지(drizzle-kit 호환), server-only 금지
import { z } from "zod";
// @f:enums

const __Entity__Fields = {
  title: z.string().trim().min(1, "제목을 입력해 주세요.").max(100, "100자 이하"),
  memo: z.string().trim().max(2000, "2000자 이하"),
  // @f:zod
};
export const Create__Entity__Input = z.strictObject({
  ...__Entity__Fields,
  memo: __Entity__Fields.memo.default(""),
  // @f:defaults
});
export type Create__Entity__Input = z.infer<typeof Create__Entity__Input>;

export const Update__Entity__Input = z.strictObject(__Entity__Fields).partial().refine(
  (input) => Object.keys(input).length > 0,
  { message: "수정할 항목을 하나 이상 입력해 주세요." },
);
export type Update__Entity__Input = z.infer<typeof Update__Entity__Input>;

export const List__Entity__Query = z.object({
  q: z.string().trim().max(50).optional().catch(undefined),
  page: z.coerce.number().int().min(1).default(1).catch(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(10).catch(10),
});
export type List__Entity__Query = z.infer<typeof List__Entity__Query>;

export type __Entity__Dto = {
  id: string;
  title: string;
  memo: string;
  // @f:dto
  owner: { id: string; name: string };
  createdAt: string;
  updatedAt: string;
};
// @f:options
