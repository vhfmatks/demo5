// [서버] __label__ 데이터 접근. 규칙은 features/requests/service.ts 와 동일.
import "server-only";
import { and, count, desc, eq, like, type SQL } from "drizzle-orm";
import { db, type DbExecutor } from "@/server/db/client";
import { __entities__, users } from "@/server/db/schema";
import { AppError } from "@/server/http/errors";
import { audit } from "@/server/audit";
import type { SessionUser } from "@/server/auth/session";
import { ownerScope } from "@/server/scope";
import type { Department } from "@/lib/departments";
import type { PageMeta } from "@/lib/error-codes";
import { canDelete, canEdit, canView, listScope } from "./policy";
import { __Entity__Errors } from "./errors";
import type { Create__Entity__Input, __Entity__Dto, List__Entity__Query, Update__Entity__Input } from "./schema";
// @f:svcimports

const ENTITY = "__entity__";

// @f:aliases
const baseSelect = (executor: DbExecutor = db) =>
  executor
    .select({
      r: __entities__,
      ownerName: users.name,
      ownerDepartment: users.department,
      // @f:select
    })
    .from(__entities__)
    // @f:joins
    .innerJoin(users, eq(users.id, __entities__.ownerId));

type Row = {
  r: typeof __entities__.$inferSelect;
  ownerName: string;
  ownerDepartment: Department | null;
  // @f:row
};
const toDto = ({ r, ownerName }: Row): __Entity__Dto => ({
  id: r.id,
  title: r.title,
  memo: r.memo,
  // @f:map
  owner: { id: r.ownerId, name: ownerName },
  createdAt: r.createdAt.toISOString(),
  updatedAt: r.updatedAt.toISOString(),
});

async function loadVisible(actor: SessionUser, id: string, executor: DbExecutor = db): Promise<Row> {
  const row = await baseSelect(executor).where(eq(__entities__.id, id)).get();
  if (!row || !canView(actor, { ownerId: row.r.ownerId, ownerDepartment: row.ownerDepartment })) throw new AppError(__Entity__Errors.__ENTITY___NOT_FOUND);
  return row;
}
// @f:checkrefs

export async function list__Entities__(actor: SessionUser, q: List__Entity__Query): Promise<{ items: __Entity__Dto[]; meta: PageMeta }> {
  const where: SQL[] = [];
  const scope = ownerScope(actor, listScope(actor), __entities__.ownerId);
  if (scope) where.push(scope);
  if (q.q) where.push(like(__entities__.title, `%${q.q}%`));
  const cond = where.length ? and(...where) : undefined;
  const items = (
    await baseSelect()
    .where(cond)
    .orderBy(desc(__entities__.createdAt), desc(__entities__.id))
    .limit(q.pageSize)
    .offset((q.page - 1) * q.pageSize)
    .all()
  ).map(toDto);
  const total = (await db.select({ n: count() }).from(__entities__).where(cond).get())?.n ?? 0;
  return { items, meta: { page: q.page, pageSize: q.pageSize, total } };
}

export async function get__Entity__(actor: SessionUser, id: string): Promise<__Entity__Dto> {
  return toDto(await loadVisible(actor, id));
}

export async function create__Entity__(actor: SessionUser, input: Create__Entity__Input): Promise<__Entity__Dto> {
  // @f:accesscall
  return db.transaction(async (tx) => {
    // @f:checkcall
    const r = await tx.insert(__entities__).values({ ...input, ownerId: actor.id }).returning({ id: __entities__.id }).get();
    await audit(actor.id, `${ENTITY}.create`, ENTITY, r.id, undefined, tx);
    return toDto(await loadVisible(actor, r.id, tx));
  });
}

export async function update__Entity__(actor: SessionUser, id: string, input: Update__Entity__Input): Promise<__Entity__Dto> {
  // @f:accesscall
  return db.transaction(async (tx) => {
    const { r } = await loadVisible(actor, id, tx);
    if (!canEdit(actor, r)) throw new AppError(__Entity__Errors.__ENTITY___EDIT_FORBIDDEN);
    // @f:checkcall
    await tx.update(__entities__).set(input).where(eq(__entities__.id, id)).run();
    await audit(actor.id, `${ENTITY}.update`, ENTITY, id, { fields: Object.keys(input) }, tx);
    return toDto(await loadVisible(actor, id, tx));
  });
}

export async function delete__Entity__(actor: SessionUser, id: string): Promise<void> {
  await db.transaction(async (tx) => {
    const { r } = await loadVisible(actor, id, tx);
    if (!canDelete(actor, r)) throw new AppError(__Entity__Errors.__ENTITY___DELETE_FORBIDDEN);
    await tx.delete(__entities__).where(eq(__entities__.id, id)).run();
    await audit(actor.id, `${ENTITY}.delete`, ENTITY, id, undefined, tx);
  });
}
// @f:optionsfn
