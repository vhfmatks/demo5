import { notFound } from "next/navigation";
import { Section, PageHeader } from "@/components/ui";
import { requireUser } from "@/server/auth/session";
import { load } from "@/server/http/page";
import { get__Entity__ } from "@/features/__entities__/service";
import { canEdit } from "@/features/__entities__/policy";
import { __Entity__Form } from "@/features/__entities__/components/__Entity__Form";

export default async function Edit__Entity__Page({ params }: PageProps<"/__entities__/[id]/edit">) {
  const user = await requireUser();
  const r = await load(get__Entity__(user, (await params).id));
  if (!canEdit(user, { ownerId: r.owner.id })) notFound();
  return (
    <>
      <PageHeader title="__label__ 수정" />
      <Section><__Entity__Form initial={r} /></Section>
    </>
  );
}
