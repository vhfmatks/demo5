import { Card, DescriptionList, PageHeader } from "@/components/ui";
import { requireUser } from "@/server/auth/session";
import { load } from "@/server/http/page";
import { fmtDateTime } from "@/lib/format";
import { get__Entity__ } from "@/features/__entities__/service";
import { canDelete, canEdit } from "@/features/__entities__/policy";
import { __Entity__Actions } from "@/features/__entities__/components/__Entity__Actions";
// @f:imports

export default async function __Entity__DetailPage({ params }: PageProps<"/__entities__/[id]">) {
  const user = await requireUser();
  const r = await load(get__Entity__(user, (await params).id));
  const t = { ownerId: r.owner.id };
  return (
    <>
      <PageHeader title={r.title} />
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="md:col-span-3">
          <DescriptionList items={[
            { label: "작성자", value: r.owner.name },
            { label: "등록일", value: fmtDateTime(r.createdAt) },
            { label: "메모", value: r.memo || "-" },
            // @f:desc
          ]} />
        </Card>
        <Card title="관리">
          <__Entity__Actions id={r.id} canEdit={canEdit(user, t)} canDelete={canDelete(user, t)} />
        </Card>
      </div>
    </>
  );
}
