import { Section, PageHeader } from "@/components/ui";
import { requireUser } from "@/server/auth/session";
import { __Entity__Form } from "@/features/__entities__/components/__Entity__Form";

export default async function New__Entity__Page() {
  await requireUser();
  return (
    <>
      <PageHeader title="새 __label__" />
      <Section><__Entity__Form /></Section>
    </>
  );
}
