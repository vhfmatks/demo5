import { ResultCount, SearchField, LinkButton, PageHeader, Pagination, FilterBar } from "@/components/ui";
import { requireUser } from "@/server/auth/session";
import { list__Entities__ } from "@/features/__entities__/service";
import { List__Entity__Query } from "@/features/__entities__/schema";
import { __Entity__Table } from "@/features/__entities__/components/__Entity__Table";

export default async function __Entities__Page({ searchParams }: PageProps<"/__entities__">) {
  const user = await requireUser();
  const q = List__Entity__Query.parse(await searchParams);
  const { items, meta } = await list__Entities__(user, q);
  return (
    <>
      <PageHeader title="__label__" description={`총 ${meta.total}건`} actions={<LinkButton href="/__entities__/new" variant="tertiary">새 __label__</LinkButton>} />
      <FilterBar>
        <SearchField name="q" label="검색" defaultValue={q.q ?? ""} placeholder="제목 검색" className="w-56" />
      </FilterBar>
      <ResultCount total={meta.total} />
        <__Entity__Table rows={items} />
        <Pagination meta={meta} basePath="/__entities__" params={{ q: q.q }} />

    </>
  );
}
