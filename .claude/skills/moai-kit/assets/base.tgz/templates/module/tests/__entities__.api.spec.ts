// 필드 수정 시 입력·DTO assertion을 함께 바꾸고 TC를 docs/e2e-test.md의 AC에 연결한다.
import { test, expect } from "./fixtures";
import { expectData, expectError, expectNoContent, uniqueTitle } from "./helpers";
import { CommonErrors } from "../../src/lib/error-codes";
import { __Entity__Errors } from "../../src/features/__entities__/errors";
import type { __Entity__Dto } from "../../src/features/__entities__/schema";

const URL = "/api/v1/__entities__";
const SAMPLE = {
  // @f:sample
};
// @f:refsfn
test("TC-__ENTITY__-API-001 생성·목록·조회·수정·삭제", async ({ apiAs }) => {
  const owner = await apiAs("user1");
  const title = uniqueTitle("TC-__ENTITY__-API-001");
  const { data } = await expectData<__Entity__Dto>(await owner.post(URL, { data: { ...SAMPLE, title, memo: "합성 메모" } }), 201);
  const itemURL = `${URL}/${data.id}`;
  expect((await expectData<__Entity__Dto[]>(await owner.get(`${URL}?q=${encodeURIComponent(title)}`))).data[0].id).toBe(data.id);
  await expectData<__Entity__Dto>(await owner.get(itemURL));
  await expectData<__Entity__Dto>(await owner.patch(itemURL, { data: { title: `${title} 수정` } }));
  expect((await expectData<__Entity__Dto>(await owner.get(itemURL))).data).toMatchObject({ ...SAMPLE, title: `${title} 수정`, memo: "합성 메모" });
  await expectNoContent(await owner.delete(itemURL));
  await expectError(await owner.get(itemURL), __Entity__Errors.__ENTITY___NOT_FOUND);
});

test("TC-__ENTITY__-API-002 입력 검증·저장값 불변 (SEC-04)", async ({ apiAs }) => {
  const owner = await apiAs("user1");
  const before = (await expectData<__Entity__Dto[]>(await owner.get(URL))).meta?.total;
  const error = await expectError(await owner.post(URL, { data: { title: "" } }), CommonErrors.VALIDATION_ERROR);
  expect(error.fieldErrors?.title).toBeTruthy();
  await expectError(await owner.post(URL, { data: { ...SAMPLE, title: "가".repeat(101) } }), CommonErrors.VALIDATION_ERROR); // 길이 상한
  await expectError(await owner.post(URL, { data: { ...SAMPLE, title: uniqueTitle("소유자 주입"), ownerId: "00000000-0000-4000-8000-000000000000" } }), CommonErrors.VALIDATION_ERROR); // 알 수 없는 키
  await expectError(await owner.get(`${URL}/not-a-uuid`), CommonErrors.VALIDATION_ERROR);
  expect((await expectData<__Entity__Dto[]>(await owner.get(URL))).meta?.total).toBe(before);
});

test("TC-__ENTITY__-API-003 비로그인 거부 (SEC-02)", async ({ apiAs }) => {
  const anon = await apiAs(null);
  const id = "00000000-0000-4000-8000-000000000000";
  await expectError(await anon.get(URL), CommonErrors.AUTH_REQUIRED);
  await expectError(await anon.post(URL, { data: { title: "익명 생성" } }), CommonErrors.AUTH_REQUIRED);
  await expectError(await anon.patch(`${URL}/${id}`, { data: { title: "익명 수정" } }), CommonErrors.AUTH_REQUIRED);
  await expectError(await anon.delete(`${URL}/${id}`), CommonErrors.AUTH_REQUIRED);
});

test("TC-__ENTITY__-API-004 타인 조회·목록·수정·삭제 거부와 값 불변 (SEC-03)", async ({ apiAs }) => {
  const owner = await apiAs("user1");
  const other = await apiAs("user2");
  const { data } = await expectData<__Entity__Dto>(await owner.post(URL, { data: { ...SAMPLE, title: uniqueTitle("TC-__ENTITY__-API-004") } }), 201);
  const itemURL = `${URL}/${data.id}`;
  await expectError(await other.get(itemURL), __Entity__Errors.__ENTITY___NOT_FOUND);
  await expectError(await other.patch(itemURL, { data: { title: "탈취" } }), __Entity__Errors.__ENTITY___NOT_FOUND);
  await expectError(await other.delete(itemURL), __Entity__Errors.__ENTITY___NOT_FOUND);
  expect((await expectData<__Entity__Dto[]>(await other.get(`${URL}?q=${encodeURIComponent(data.title)}`))).data).toEqual([]);
  expect((await expectData<__Entity__Dto>(await owner.get(itemURL))).data.title).toBe(data.title);
});

test("TC-__ENTITY__-API-006 부서장은 같은 부서 것만 조회, 수정·삭제 거부 (SEC-03)", async ({ apiAs }) => {
  const owner = await apiAs("user1");
  const [other, manager] = await Promise.all([apiAs("user2"), apiAs("manager")]);
  const title = uniqueTitle("TC-__ENTITY__-API-006");
  const { data: same } = await expectData<__Entity__Dto>(await owner.post(URL, { data: { ...SAMPLE, title: `${title} 개발팀` } }), 201);
  const { data: diff } = await expectData<__Entity__Dto>(await other.post(URL, { data: { ...SAMPLE, title: `${title} 영업팀` } }), 201);
  await expectData<__Entity__Dto>(await manager.get(`${URL}/${same.id}`));
  await expectError(await manager.get(`${URL}/${diff.id}`), __Entity__Errors.__ENTITY___NOT_FOUND);
  const listed = await expectData<__Entity__Dto[]>(await manager.get(`${URL}?q=${encodeURIComponent(title)}`));
  expect(listed.data.map((row) => row.id)).toEqual([same.id]);
  expect(listed.meta?.total).toBe(1);
  await expectError(await manager.patch(`${URL}/${same.id}`, { data: { title: "부서장 수정" } }), __Entity__Errors.__ENTITY___EDIT_FORBIDDEN);
  await expectError(await manager.delete(`${URL}/${same.id}`), __Entity__Errors.__ENTITY___DELETE_FORBIDDEN);
  expect((await expectData<__Entity__Dto>(await owner.get(`${URL}/${same.id}`))).data.title).toBe(same.title);
});
// @f:reftests
