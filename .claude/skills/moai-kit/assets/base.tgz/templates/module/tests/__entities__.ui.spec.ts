import { test, expect } from "./fixtures";
import { loginUI, uniqueTitle } from "./helpers";

test("TC-__ENTITY__-UI-001 로그인·생성·수정·새로고침·삭제", async ({ page }) => {
  await loginUI(page, "user1");
  const title = uniqueTitle("TC-__ENTITY__-UI-001");
  // @f:prefill
  await page.goto("/__entities__/new");
  await page.getByLabel("제목").fill(title);
  // @f:fill
  await page.getByRole("button", { name: "등록", exact: true }).click();
  await expect(page.getByRole("heading", { name: title, exact: true })).toBeVisible();
  await page.getByRole("link", { name: "수정", exact: true }).click();
  await page.getByLabel("제목").fill(`${title} 수정`);
  await page.getByRole("button", { name: "저장", exact: true }).click();
  await expect(page.getByRole("heading", { name: `${title} 수정`, exact: true })).toBeVisible();
  await page.reload();
  await expect(page.getByRole("heading", { name: `${title} 수정`, exact: true })).toBeVisible();
  await page.getByRole("button", { name: "삭제", exact: true }).click();
  await page.getByRole("button", { name: "삭제 확인", exact: true }).click();
  await expect(page).toHaveURL(/\/__entities__$/);
  await expect(page.getByText(`${title} 수정`, { exact: true })).toHaveCount(0);
});
