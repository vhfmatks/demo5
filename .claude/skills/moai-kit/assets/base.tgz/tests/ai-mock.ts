// 시험용 가짜 AI 공급자 (외부 키·네트워크 없이 AI 흐름을 검증). 단위·E2E 공용.
//  - OpenAI 호환: GET /v1/models, POST /v1/chat/completions (Authorization: Bearer)
//  - Anthropic : GET /v1/models, POST /v1/messages (x-api-key)
//  - 키는 MOCK_AI_KEY 만 통과(아니면 401). 모델 "missing" = 404, 경로 /redirect/** = 302(리다이렉트 거부 시험)
//  - 모델 "plain" = JSON 아닌 문장, "nousage" = usage 없음(OpenAI 호환 경로)
//  - 사내 Gateway 시늉: /gw/<이름>/ 접두 경로는 접두를 뗀 뒤 같은 규칙으로 처리(seen·gets 에는 원래 경로). 모델 "slow" = 1.5초 지연
//  - 응답: 프롬프트에 "JSON" 이 있으면 reply(prompt) 의 JSON, 아니면 "OK"
import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import type { AddressInfo } from "node:net";

export const MOCK_AI_KEY = "mock-secret-key-1234";
export const MOCK_MODELS = ["mock-large", "mock-small"];

type Seen = { path: string; body: Record<string, unknown>; auth: "bearer" | "x-api-key" | "none" };

export async function startMockAi(reply: (prompt: string) => unknown = () => ({ ok: true })) {
  const seen: Seen[] = [];
  /** GET(모델 목록) 요청 기록 */
  const gets: { path: string; auth: Seen["auth"] }[] = [];
  const read = (req: IncomingMessage) => new Promise<string>((resolve) => {
    let s = "";
    req.on("data", (c) => { s += c; });
    req.on("end", () => resolve(s));
  });
  const handle = async (req: IncomingMessage, res: ServerResponse) => {
    const send = (status: number, json: unknown) => {
      res.writeHead(status, { "content-type": "application/json" });
      res.end(JSON.stringify(json));
    };
    const raw = req.url ?? "/";
    const path = raw.replace(/^\/gw\/[^/]+/, "");
    const auth: Seen["auth"] = req.headers["x-api-key"] ? "x-api-key" : req.headers.authorization ? "bearer" : "none";
    if (path.startsWith("/redirect/")) {
      res.writeHead(302, { location: "http://127.0.0.1:1/" });
      return void res.end();
    }
    const key = req.headers["x-api-key"] ?? req.headers.authorization?.replace(/^Bearer /, "");
    if (key !== MOCK_AI_KEY) return send(401, { error: { message: "invalid api key" } });
    if (req.method === "GET") gets.push({ path: raw, auth });
    if (req.method === "GET" && path === "/v1/models") return send(200, { data: MOCK_MODELS.map((id) => ({ id })) });
    const body = JSON.parse((await read(req)) || "{}") as Record<string, unknown>;
    seen.push({ path: raw, body, auth });
    if (body.model === "slow") await new Promise((resolve) => setTimeout(resolve, 1500));
    if (body.model === "missing") return send(404, { error: { message: "model not found" } });
    const messages = (body.messages ?? []) as { content: string }[];
    const prompt = messages.map((m) => m.content).join("\n") + String(body.system ?? "");
    // 모델 "plain" = JSON 이 아닌 문장, "nousage" = usage 필드 없음
    const text = body.model === "plain" ? "JSON 이 아닌 그냥 문장입니다" : prompt.includes("JSON") ? `결과입니다:\n\`\`\`json\n${JSON.stringify(await reply(prompt))}\n\`\`\`` : "OK";
    if (path === "/v1/chat/completions") {
      return send(200, { choices: [{ message: { role: "assistant", content: text } }], ...(body.model === "nousage" ? {} : { usage: { prompt_tokens: 11, completion_tokens: 3 } }) });
    }
    if (path === "/v1/messages") return send(200, { content: [{ type: "text", text }], usage: { input_tokens: 12, output_tokens: 4 } });
    return send(404, { error: { message: "not found" } });
  };
  const server = createServer((req, res) => {
    void handle(req, res);
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const origin = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  return {
    /** OpenAI 호환 baseUrl */
    openai: `${origin}/v1`,
    /** Anthropic baseUrl */
    anthropic: origin,
    redirect: `${origin}/redirect/v1`,
    /** 경로 접두가 있는 Gateway 의 baseUrl (OpenAI 호환 / Anthropic) */
    gatewayOpenai: `${origin}/gw/corp/v1`,
    gatewayAnthropic: `${origin}/gw/corp`,
    seen,
    gets,
    close: () => new Promise<void>((resolve) => server.close(() => resolve())),
  };
}
