import { test, expect } from "./fixtures";
import { uniqueTitle } from "./helpers";

test("TC-ADMIN-UI-001 관리자가 공지 배너 저장 → 사용자 화면 표시 → 감사로그 확인 → 해제", async ({ pageAs }) => {
  const banner = uniqueTitle("공지");
  const admin = await pageAs("admin");
  await expect(admin.getByRole("link", { name: "관리자", exact: true })).toHaveCount(0);
  await admin.goto("/me");
  await expect(admin.getByRole("link", { name: "관리자 포털", exact: true })).toHaveAttribute("href", "/admin");
  const save = async () => {
    const saved = admin.waitForResponse((r) => r.url().endsWith("/api/v1/admin/settings") && r.request().method() === "PATCH");
    await admin.getByRole("button", { name: "저장", exact: true }).click();
    expect((await saved).status()).toBe(200);
  };
  await admin.goto("/admin/settings");
  await admin.getByLabel("공지 배너").fill(banner);
  await save();
  await admin.reload();
  await expect(admin.getByLabel("공지 배너")).toHaveValue(banner);

  const user = await pageAs("user1");
  await expect(user.getByTestId("notice")).toContainText(banner);

  await admin.goto("/admin/audit");
  await admin.getByLabel("행위").fill("settings.update");
  await admin.getByRole("button", { name: "검색", exact: true }).click();
  await expect(admin.getByTestId("row").first()).toContainText(banner);

  await admin.goto("/admin/settings");
  await admin.getByLabel("공지 배너").fill("");
  await save();
  await user.reload();
  await expect(user.getByTestId("notice")).toHaveCount(0);
});

test("TC-ADMIN-UI-002 잘못된 설정값은 필드 오류·저장 안 됨", async ({ pageAs }) => {
  const admin = await pageAs("admin");
  await admin.goto("/admin/settings");
  await admin.getByLabel("세션 유지 시간(시간)").fill("100");
  await admin.getByRole("button", { name: "저장", exact: true }).click();
  await expect(admin.getByRole("alert").filter({ hasText: "72 이하" })).toBeVisible();
  await admin.reload();
  await expect(admin.getByLabel("세션 유지 시간(시간)")).toHaveValue("8");
});

test("TC-ADMIN-UI-003 관리자 외 사용자는 포털 404·메뉴 미노출 (SEC-03)", async ({ pageAs, page }) => {
  const user = await pageAs("user1");
  await user.goto("/me");
  await expect(user.getByRole("link", { name: "관리자 포털", exact: true })).toHaveCount(0);
  const res = await user.goto("/admin/settings");
  expect(res?.status()).toBe(404);
  await page.goto("/admin");
  await expect(page).toHaveURL(/\/login$/);
});
