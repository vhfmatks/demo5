// AI 관리 API: 공급자 시험·등록 → 모델 시험·등록 → 기본 지정·삭제, 권한·주소 규칙. 가짜 공급자(tests/ai-mock.ts) 사용.
import { test, expect } from "./fixtures";
import { expectData, expectError, expectNoContent, uniqueTitle } from "./helpers";
import { CommonErrors } from "../../src/lib/error-codes";
import { AiErrors } from "../../src/features/ai/errors";
import type { AiModelDto, AiProviderDto, ModelTestResult, ProviderTestResult } from "../../src/features/ai/schema";
import type { AuditLogDto } from "../../src/features/auditLogs/schema";
import { MOCK_AI_KEY, startMockAi } from "../ai-mock";

const URL = "/api/v1/admin/ai";
let mock: Awaited<ReturnType<typeof startMockAi>>;
test.beforeAll(async () => {
  mock = await startMockAi();
});
test.afterAll(() => mock.close());

test("TC-AI-API-001 공급자 연결 시험 → 등록(키 비공개) → 모델 시험 → 등록·기본 지정 → 삭제 (SEC-01)", async ({ apiAs }) => {
  const admin = await apiAs("admin");
  const name = uniqueTitle("가짜 OpenAI");
  const input = { kind: "openai", baseUrl: mock.openai, apiKey: MOCK_AI_KEY };
  expect((await expectData<ProviderTestResult>(await admin.post(`${URL}/providers/test`, { data: input }))).data)
    .toMatchObject({ ok: true, models: ["mock-large", "mock-small"] });
  const bad = await expectError(await admin.post(`${URL}/providers`, { data: { ...input, name, apiKey: "wrong-key" } }), AiErrors.AI_TEST_FAILED);
  expect(bad.message).toContain("HTTP 401");

  const { data: provider } = await expectData<AiProviderDto>(await admin.post(`${URL}/providers`, { data: { ...input, name } }), 201);
  expect(provider).toMatchObject({ name, kind: "openai", apiKeyHint: "••••1234" });
  const listed = await admin.get(`${URL}/providers`);
  expect(await listed.text()).not.toContain(MOCK_AI_KEY);
  expect((await expectData<string[]>(await admin.get(`${URL}/providers/${provider.id}/models`))).data).toEqual(["mock-large", "mock-small"]);

  const modelTest = await expectData<ModelTestResult>(await admin.post(`${URL}/models/test`, { data: { providerId: provider.id, model: "mock-small" } }));
  expect(modelTest.data).toMatchObject({ ok: true, reply: "OK" });
  expect((await expectError(await admin.post(`${URL}/models/test`, { data: { providerId: provider.id, model: "missing" } }), AiErrors.AI_TEST_FAILED)).message)
    .toContain("HTTP 404");
  const label = uniqueTitle("요약");
  const { data: first } = await expectData<AiModelDto>(await admin.post(`${URL}/models`, { data: { providerId: provider.id, model: "mock-small", label } }), 201);
  const { data: second } = await expectData<AiModelDto>(await admin.post(`${URL}/models`, { data: { providerId: provider.id, model: "mock-large", label: `${label} 큰` } }), 201);
  await expectError(await admin.post(`${URL}/models`, { data: { providerId: provider.id, model: "mock-large", label } }), AiErrors.AI_NAME_TAKEN);
  await expectData<AiModelDto>(await admin.patch(`${URL}/models/${second.id}`, { data: { isDefault: true } }));
  const models = (await expectData<AiModelDto[]>(await admin.get(`${URL}/models`))).data.filter((m) => m.provider.id === provider.id);
  expect(models.find((m) => m.id === second.id)?.isDefault).toBe(true);
  expect(models.find((m) => m.id === first.id)?.isDefault).toBe(false);

  const logs = await admin.get(`${URL.replace("/ai", "")}/auditLogs?entity=ai&pageSize=20`);
  expect(await logs.text()).not.toContain(MOCK_AI_KEY);
  expect((await expectData<AuditLogDto[]>(logs)).data.map((l) => l.action)).toEqual(expect.arrayContaining(["ai.provider_create", "ai.model_create", "ai.model_default"]));

  await expectNoContent(await admin.delete(`${URL}/models/${first.id}`));
  await expectNoContent(await admin.delete(`${URL}/providers/${provider.id}`));
  expect((await expectData<AiModelDto[]>(await admin.get(`${URL}/models`))).data.some((m) => m.provider.id === provider.id)).toBe(false);
  await expectError(await admin.delete(`${URL}/providers/${provider.id}`), AiErrors.AI_PROVIDER_NOT_FOUND);
});

test("TC-AI-API-002 ai.manage 없는 역할 403·비로그인 401 (SEC-03)", async ({ apiAs }) => {
  const [anon, user, manager, auditor] = await Promise.all([apiAs(null), apiAs("user1"), apiAs("manager"), apiAs("auditor")]);
  const input = { kind: "openai", baseUrl: mock.openai, apiKey: MOCK_AI_KEY };
  await expectError(await anon.get(`${URL}/providers`), CommonErrors.AUTH_REQUIRED);
  for (const who of [user, manager, auditor]) {
    await expectError(await who.get(`${URL}/providers`), CommonErrors.AUTH_PERMISSION_REQUIRED);
    await expectError(await who.post(`${URL}/providers/test`, { data: input }), CommonErrors.AUTH_PERMISSION_REQUIRED);
    await expectError(await who.post(`${URL}/models/test`, { data: { providerId: crypto.randomUUID(), model: "mock-small" } }), CommonErrors.AUTH_PERMISSION_REQUIRED);
  }
});

test("TC-AI-API-003 주소 규칙: 외부 http·계정 포함 주소 400, 리다이렉트는 따라가지 않음 (SEC-06)", async ({ apiAs }) => {
  const admin = await apiAs("admin");
  for (const baseUrl of ["http://example.com/v1", "http://10.0.0.5/v1", "https://user:pw@api.example.com/v1", "file:///etc/passwd"]) {
    const e = await expectError(await admin.post(`${URL}/providers/test`, { data: { kind: "openai", baseUrl, apiKey: "x" } }), CommonErrors.VALIDATION_ERROR);
    expect(e.fieldErrors?.baseUrl).toBeTruthy();
  }
  const redirect = await expectError(await admin.post(`${URL}/providers/test`, { data: { kind: "openai", baseUrl: mock.redirect, apiKey: MOCK_AI_KEY } }), AiErrors.AI_TEST_FAILED);
  expect(redirect.message).toContain("연결할 수 없습니다");
});
