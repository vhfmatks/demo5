import { test, expect } from "./fixtures";
import { uniqueTitle } from "./helpers";
import { MOCK_AI_KEY, startMockAi } from "../ai-mock";

let mock: Awaited<ReturnType<typeof startMockAi>>;
test.beforeAll(async () => {
  mock = await startMockAi();
});
test.afterAll(() => mock.close());

test("TC-AI-UI-001 관리자: 공급자 연결 테스트 → 등록 → 모델 제안·시험 → 등록(기본) → 행 시험 → 공급자 삭제", async ({ pageAs }) => {
  const page = await pageAs("admin");
  const name = uniqueTitle("가짜 공급자");
  await page.goto("/admin");
  await page.getByRole("link", { name: "AI", exact: true }).click();
  await expect(page.getByRole("heading", { name: "AI", exact: true })).toBeVisible();

  await page.getByRole("textbox", { name: /^이름/ }).fill(name);
  await page.getByLabel("API 주소").fill(mock.openai);
  await page.getByLabel("API 키").fill("wrong-key");
  await page.getByRole("button", { name: "연결 테스트" }).click();
  await expect(page.getByRole("alert").filter({ hasText: "HTTP 401" })).toBeVisible();
  await page.getByLabel("API 키").fill(MOCK_AI_KEY);
  await page.getByRole("button", { name: "연결 테스트" }).click();
  await expect(page.getByText(/연결됨 · 모델 2개/)).toBeVisible();
  await page.getByRole("button", { name: "등록", exact: true }).first().click();
  const providerRow = page.getByRole("row").filter({ hasText: name });
  await expect(providerRow).toContainText("••••1234");

  await page.getByRole("combobox", { name: /^공급자/ }).selectOption({ label: name });
  await expect(page.getByText("공급자 제공 모델 2개 중에서 고르거나 직접 입력")).toBeVisible();
  const label = uniqueTitle("요약");
  await page.getByLabel("모델 ID").fill("mock-small");
  await page.getByLabel("호출 이름").fill(label);
  await page.getByLabel("기본 모델로 지정").check();
  await page.getByRole("button", { name: "모델 시험" }).click();
  await expect(page.getByText(/응답: OK · \d+ms/)).toBeVisible();
  await page.getByRole("button", { name: "등록", exact: true }).last().click();
  const modelRow = page.getByRole("row").filter({ hasText: label });
  await expect(modelRow.getByTestId("default-model")).toHaveText("기본");
  await modelRow.getByRole("button", { name: `${label} 시험` }).click();
  await expect(modelRow.getByText(/응답: OK/)).toBeVisible();

  await providerRow.getByRole("button", { name: `${name} 삭제` }).click();
  await page.getByRole("button", { name: "삭제 확인" }).click();
  await expect(page.getByRole("row").filter({ hasText: name })).toHaveCount(0);
  await expect(page.getByRole("row").filter({ hasText: label })).toHaveCount(0);
});
