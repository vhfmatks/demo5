import { randomUUID } from "node:crypto";
import { test, expect } from "./fixtures";
import { expectData, expectError, expectNoContent, expiredSessionToken, PASSWORD, USERS } from "./helpers";
import { CommonErrors } from "../../src/lib/error-codes";
import { AuthErrors } from "../../src/features/auth/errors";
import type { AuditLogDto } from "../../src/features/auditLogs/schema";

test("TC-AUTH-API-001 잘못된 비밀번호·없는 계정은 같은 공개 오류 (SEC-02)", async ({ apiAs }) => {
  const anon = await apiAs(null);
  const existing = await expectError(await anon.post("/api/v1/auth/login", { data: { email: USERS.user1, password: "WrongSyntheticPassword" } }), AuthErrors.AUTH_INVALID_CREDENTIALS);
  const missing = await expectError(await anon.post("/api/v1/auth/login", { data: { email: "missing@demo.local", password: "WrongSyntheticPassword" } }), AuthErrors.AUTH_INVALID_CREDENTIALS);
  expect(existing.message).toBe(missing.message);
  await expectError(await anon.get("/api/v1/auth/me"), CommonErrors.AUTH_REQUIRED);
});

test("TC-AUTH-API-002 로그인 쿠키·현재 사용자·로그아웃 후 세션 거부 (SEC-08)", async ({ apiAs }) => {
  const anon = await apiAs(null);
  const response = await anon.post("/api/v1/auth/login", { data: { email: USERS.user1, password: PASSWORD } });
  const { data } = await expectData<{ email: string; role: string }>(response);
  expect(data).toMatchObject({ email: USERS.user1, role: "USER" });
  expect(data).not.toHaveProperty("passwordHash");
  const flags = response.headers()["set-cookie"].split(";").slice(1).join(";").toLowerCase();
  expect(flags).toContain("httponly");
  expect(flags).toContain("samesite=lax");
  expect((await expectData<{ email: string }>(await anon.get("/api/v1/auth/me"))).data.email).toBe(USERS.user1);
  await expectNoContent(await anon.post("/api/v1/auth/logout"));
  await expectError(await anon.get("/api/v1/auth/me"), CommonErrors.AUTH_REQUIRED);
  await expectNoContent(await anon.post("/api/v1/auth/logout"));
});

test("TC-AUTH-API-003 비밀번호 변경: 현재 비밀번호·규칙 검증, 다른 세션 폐기·새 비밀번호로만 로그인 (SEC-08)", async ({ apiAs }) => {
  const URL = "/api/v1/auth/password";
  const NEW = "Synthetic2Pass";
  const [device1, device2, anon] = await Promise.all([apiAs("user3"), apiAs("user3"), apiAs(null)]);
  const wrong = await expectError(await device1.post(URL, { data: { currentPassword: "Wrong1234", newPassword: NEW, confirmPassword: NEW } }), AuthErrors.AUTH_CURRENT_PASSWORD_MISMATCH);
  expect(wrong.fieldErrors?.currentPassword).toBeTruthy();
  const weak = await expectError(await device1.post(URL, { data: { currentPassword: PASSWORD, newPassword: "short", confirmPassword: "other" } }), CommonErrors.VALIDATION_ERROR);
  expect(Object.keys(weak.fieldErrors ?? {})).toEqual(expect.arrayContaining(["newPassword", "confirmPassword"]));
  await expectError(await anon.post(URL, { data: { currentPassword: PASSWORD, newPassword: NEW, confirmPassword: NEW } }), CommonErrors.AUTH_REQUIRED);
  await expectData(await device2.get("/api/v1/auth/me"));

  await expectNoContent(await device1.post(URL, { data: { currentPassword: PASSWORD, newPassword: NEW, confirmPassword: NEW } }));
  await expectData(await device1.get("/api/v1/auth/me")); // 변경한 기기는 새 세션으로 유지
  await expectError(await device2.get("/api/v1/auth/me"), CommonErrors.AUTH_REQUIRED); // 다른 기기 세션은 폐기
  await expectError(await anon.post("/api/v1/auth/login", { data: { email: USERS.user3, password: PASSWORD } }), AuthErrors.AUTH_INVALID_CREDENTIALS);
  await expectData(await anon.post("/api/v1/auth/login", { data: { email: USERS.user3, password: NEW } }));
});

test("TC-AUTH-API-004 같은 이메일 반복 실패 → 429·Retry-After, 다른 계정은 로그인 가능 (SEC-09)", async ({ apiAs }) => {
  const anon = await apiAs(null);
  const email = `limit-${randomUUID()}@demo.local`; // 다른 시험과 잠금이 겹치지 않게 시험마다 새 이메일
  for (let i = 0; i < 5; i += 1) {
    await expectError(await anon.post("/api/v1/auth/login", { data: { email, password: "WrongSyntheticPassword" } }), AuthErrors.AUTH_INVALID_CREDENTIALS);
  }
  const locked = await anon.post("/api/v1/auth/login", { data: { email, password: "WrongSyntheticPassword" } });
  const error = await expectError(locked, AuthErrors.AUTH_TOO_MANY_ATTEMPTS);
  expect(error.retryAfterSeconds).toBeGreaterThan(0);
  expect(Number(locked.headers()["retry-after"])).toBe(error.retryAfterSeconds);
  await expectData(await anon.post("/api/v1/auth/login", { data: { email: USERS.user2, password: PASSWORD } }));
});

test("TC-AUTH-API-005 로그인 실패·로그아웃 감사 기록, 이메일 원문·비밀번호 미기록 (SEC-10)", async ({ apiAs }) => {
  const [anon, admin] = await Promise.all([apiAs(null), apiAs("admin")]);
  const email = `audit-${randomUUID()}@demo.local`;
  await expectError(await anon.post("/api/v1/auth/login", { data: { email, password: "WrongSyntheticPassword" } }), AuthErrors.AUTH_INVALID_CREDENTIALS);
  const failed = await expectData<AuditLogDto[]>(await admin.get("/api/v1/admin/auditLogs?action=auth.login_failed&pageSize=20"));
  const texts = failed.data.map((row) => JSON.stringify(row));
  expect(texts.some((t) => t.includes("emailRef"))).toBe(true);
  expect(texts.join("")).not.toContain(email);
  expect(texts.join("")).not.toContain("WrongSyntheticPassword");

  const { data: me } = await expectData<{ id: string }>(await anon.post("/api/v1/auth/login", { data: { email: USERS.user2, password: PASSWORD } }));
  await expectNoContent(await anon.post("/api/v1/auth/logout"));
  const logout = await expectData<AuditLogDto[]>(await admin.get(`/api/v1/admin/auditLogs?action=auth.logout&entityId=${me.id}&pageSize=1`));
  expect(logout.data[0]?.actor?.id).toBe(me.id);
});

test("TC-AUTH-API-006 만료된 세션은 보호 API 401, 거부된 쓰기는 저장되지 않음 (SEC-08)", async ({ apiAs }) => {
  const [anon, user1] = await Promise.all([apiAs(null), apiAs("user1")]);
  const expired = { Cookie: `sid=${expiredSessionToken()}` };
  const { data: before } = await expectData<{ department: string | null }>(await user1.get("/api/v1/auth/me"));
  await expectError(await anon.get("/api/v1/auth/me", { headers: expired }), CommonErrors.AUTH_REQUIRED);
  await expectError(await anon.post("/api/v1/auth/password", { headers: expired, data: { currentPassword: PASSWORD, newPassword: "Synthetic3Pass", confirmPassword: "Synthetic3Pass" } }), CommonErrors.AUTH_REQUIRED);
  expect((await expectData<{ department: string | null }>(await user1.get("/api/v1/auth/me"))).data).toEqual(before);
  await expectData(await anon.post("/api/v1/auth/login", { data: { email: USERS.user1, password: PASSWORD } })); // 비밀번호 그대로
});
