import { test, expect } from "./fixtures";
import { PASSWORD, USERS } from "./helpers";

test("TC-AUTH-UI-001 데모 계정 선택 로그인 → 내 정보 확인 → 비밀번호 규칙 오류·세션 유지", async ({ page }) => {
  await page.goto("/login");
  await page.getByRole("button", { name: "승인자", exact: true }).click();
  await expect(page.getByLabel("이메일")).toHaveValue(USERS.approver);
  await expect(page.getByLabel("비밀번호")).toBeFocused();
  await page.getByLabel("비밀번호").fill(PASSWORD);
  await page.getByRole("button", { name: "로그인", exact: true }).click();
  await expect(page).toHaveURL(/\/$/);
  await page.getByTestId("current-user").click();
  await expect(page.getByRole("heading", { name: "내 정보", exact: true })).toBeVisible();
  await expect(page.getByText(USERS.approver, { exact: true })).toBeVisible();
  await page.getByLabel("현재 비밀번호").fill(PASSWORD);
  await page.getByLabel(/^새 비밀번호\s*\*?$/).fill("short");
  await page.getByLabel("새 비밀번호 확인").fill("short");
  await page.getByRole("button", { name: "변경", exact: true }).click();
  await expect(page.getByText("8자 이상 입력해 주세요.", { exact: true })).toBeVisible();
  await expect(page.getByLabel("현재 비밀번호")).toHaveValue(PASSWORD);
  await expect(page.getByLabel(/^새 비밀번호\s*\*?$/)).toHaveValue("short");
  await expect(page.getByLabel("새 비밀번호 확인")).toHaveValue("short");
  await page.reload();
  await expect(page.getByRole("heading", { name: "내 정보", exact: true })).toBeVisible();
});

test("TC-AUTH-UI-002 로그인 입력 오류는 요청 전에 필드에 표시", async ({ page }) => {
  await page.goto("/login");
  let submissions = 0;
  page.on("request", (request) => {
    if (request.method() === "POST" && new URL(request.url()).pathname === "/api/v1/auth/login") submissions++;
  });
  await page.getByLabel("이메일").fill("invalid-email");
  await page.getByRole("button", { name: "로그인", exact: true }).click();
  await expect(page.getByText("이메일 형식이 아닙니다.", { exact: true })).toBeVisible();
  await expect(page.getByText("비밀번호를 입력해 주세요.", { exact: true })).toBeVisible();
  await expect(page.getByLabel("이메일")).toHaveAttribute("aria-invalid", "true");
  expect(submissions).toBe(0);
});
