// 레이아웃 규칙(docs/conventions/ui.md): 가로 넘침 없음 + FilterBar 항목은 한 줄에서 세로 가운데가 같다
import { test, expect } from "./fixtures";

// 새 목록 화면을 만들면 여기에 추가한다.
const SCREENS = [
  { who: "admin", path: "/admin/users" },
  { who: "admin", path: "/admin/audit" },
] as const;

test("TC-DENSITY-UI-004 360·1280 에서 목록 화면 가로 넘침 없음, PC FilterBar 항목 세로 정렬 일치", async ({ pageAs }) => {
  for (const s of SCREENS) {
    const page = await pageAs(s.who);
    for (const width of [360, 1280]) {
      await page.setViewportSize({ width, height: 800 });
      await page.goto(s.path);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), `${s.path} @${width}`).toBe(true);
    }
    const centers = await page.locator("main search form > *").evaluateAll((els) =>
      els.map((el) => { const r = el.getBoundingClientRect(); return Math.round(r.top + r.height / 2); }));
    expect(new Set(centers).size, `${s.path} FilterBar ${centers}`).toBe(1);
  }
});
