import { test as base, expect, request, type APIRequestContext, type BrowserContext, type Page } from "@playwright/test";
import { loginUI, PASSWORD, USERS, type Who } from "./helpers";

type Fixtures = {
  apiAs: (who: Who | null, options?: { origin?: string | false }) => Promise<APIRequestContext>;
  pageAs: (who: Who) => Promise<Page>;
};

export const test = base.extend<Fixtures>({
  apiAs: async ({ baseURL }, use) => {
    if (!baseURL) throw new Error("표준 baseURL이 필요합니다.");
    const contexts: APIRequestContext[] = [];
    try {
      await use(async (who, options) => {
        const origin = options?.origin === false ? undefined : options?.origin ?? baseURL;
        const ctx = await request.newContext({ baseURL, extraHTTPHeaders: origin ? { Origin: origin } : {} });
        contexts.push(ctx);
        if (who) {
          const response = await ctx.post("/api/v1/auth/login", {
            data: { email: USERS[who], password: PASSWORD }, headers: { Origin: baseURL },
          });
          expect(response.status()).toBe(200);
        }
        return ctx;
      });
    } finally {
      await Promise.all(contexts.map((ctx) => ctx.dispose()));
    }
  },
  pageAs: async ({ browser, baseURL }, use, testInfo) => {
    const contexts: { context: BrowserContext; page: Page; who: Who }[] = [];
    const errors: unknown[] = [];
    try {
      await use(async (who) => {
        const context = await browser.newContext({ baseURL });
        const page = await context.newPage();
        contexts.push({ context, page, who });
        await loginUI(page, who);
        return page;
      });
    } catch (error) { errors.push(error); }
    const cleaned = await Promise.allSettled(contexts.map(async (actor, index) => {
      try {
        if (!actor.page.isClosed()) await testInfo.attach(`${actor.who}-${index}`, {
          body: await actor.page.screenshot({ fullPage: true }), contentType: "image/png",
        });
      } finally { await actor.context.close(); }
    }));
    for (const result of cleaned) if (result.status === "rejected") errors.push(result.reason);
    if (errors.length === 1) throw errors[0];
    if (errors.length > 1) throw new AggregateError(errors, "UI context 근거 수집·정리 실패");
  },
});
export { expect };
