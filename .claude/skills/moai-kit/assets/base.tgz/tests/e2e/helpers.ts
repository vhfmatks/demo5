import fs from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { expect, type APIResponse, type Page } from "@playwright/test";
import { ERROR_STATUS, type ApiErrorPayload, type ApiSuccess, type ErrorDefinition } from "../../src/lib/error-codes";
import { runPaths } from "../../scripts/lib/e2e.mts";

// 합성 시험 계정만 사용한다. context 생성·정리는 fixtures.ts가 담당한다.
export const PASSWORD = "Credit!23";
export const USERS = {
  user1: "user1@demo.local", user2: "user2@demo.local", user3: "user3@demo.local", // user3: 비밀번호 변경 TC 전용
  approver: "approver@demo.local", auditor: "auditor@demo.local", admin: "admin@demo.local",
  manager: "manager@demo.local", // 개발팀 부서장 = user1·user3 와 같은 부서, user2 는 영업팀
} as const;
export type Who = keyof typeof USERS;
/** 격리 runner(scripts/e2e-server.mts)가 이 실행의 새 DB에 미리 만든, 이미 만료된 user1 합성 세션의 쿠키 값 */
export const expiredSessionToken = () =>
  fs.readFileSync(path.join(runPaths(process.env.E2E_RUN_ID ?? "").directory, "expired-session.token"), "utf8");
export const uniqueTitle = (prefix: string) => `${prefix} ${randomUUID().replaceAll("-", "").slice(0, 16)}`;

function expectHeaders(response: APIResponse, json = true) {
  expect(response.headers()["cache-control"]).toBe("no-store");
  expect(response.headers()["x-trace-id"]).toMatch(/^[0-9a-f-]{36}$/);
  if (json) expect(response.headers()["content-type"]).toContain("application/json");
}
export async function expectData<T>(response: APIResponse, status: 200 | 201 = 200): Promise<ApiSuccess<T>> {
  expect(response.status()).toBe(status);
  expectHeaders(response);
  const body: unknown = await response.json();
  expect(body).toHaveProperty("data");
  expect(body).not.toHaveProperty("error");
  return body as ApiSuccess<T>;
}
export async function expectError(response: APIResponse, definition: Pick<ErrorDefinition, "code" | "category">): Promise<ApiErrorPayload> {
  expect(response.status()).toBe(ERROR_STATUS[definition.category]);
  expectHeaders(response);
  const body = await response.json() as { error: ApiErrorPayload };
  expect(body).not.toHaveProperty("data");
  expect(body.error).toMatchObject({ code: definition.code, category: definition.category });
  expect(body.error.traceId).toBe(response.headers()["x-trace-id"]);
  expect(typeof body.error.message).toBe("string");
  expect(body.error.message.length).toBeGreaterThan(0);
  expect(typeof body.error.retryable).toBe("boolean");
  expect(body.error).not.toHaveProperty("stack");
  expect(body.error).not.toHaveProperty("cause");
  return body.error;
}
export async function expectNoContent(response: APIResponse) {
  expect(response.status()).toBe(204);
  expectHeaders(response, false);
  expect((await response.body()).byteLength).toBe(0);
}
export async function loginUI(page: Page, who: Who) {
  await page.goto("/login");
  await page.getByLabel("이메일").fill(USERS[who]);
  await page.getByLabel("비밀번호").fill(PASSWORD);
  await page.getByRole("button", { name: "로그인" }).click();
  await expect(page).toHaveURL(/\/$/);
}

/** Select through the public KDS calendar instead of filling a readonly display input. */
export async function selectKdsDate(page: Page, label: string, iso: string) {
  const [year, month, day] = iso.split("-").map(Number);
  await page.getByRole("combobox", { name: label, exact: true }).click();
  const calendar = page.getByRole("dialog", { name: `${label} 날짜 선택`, exact: true });
  for (let attempt = 0; attempt < 240; attempt++) {
    const title = await calendar.locator(".kds-calendar__title").innerText();
    const parts = /^(\d+)년 (\d+)월$/.exec(title);
    if (!parts) throw new Error(`달력 제목을 읽지 못했습니다: ${title}`);
    const difference = (year - Number(parts[1])) * 12 + month - Number(parts[2]);
    if (!difference) { await calendar.getByRole("button", { name: `${year}년 ${month}월 ${day}일`, exact: true }).click(); return; }
    await calendar.getByRole("button", { name: difference > 0 ? "다음 달" : "이전 달", exact: true }).click();
  }
  throw new Error(`달력 이동 범위를 초과했습니다: ${iso}`);
}
