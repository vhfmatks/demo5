import { test, expect } from "./fixtures";
import fs from "node:fs";
import path from "node:path";

test("TC-KDS-API-001 로컬 폰트 허용·정적 경로 차단·외부 Origin 거부", async ({ apiAs }) => {
  const api = await apiAs(null);
  expect((await api.get("/api/v1/local-fonts?weight=700")).status()).toBe(404);
  const available = fs.existsSync(path.join(process.cwd(), ".kds-private", "fonts", "KTFLOW-BOLD.woff2"));
  const css = await (await api.get("/api/v1/local-font-style")).text();
  const url = /url\("([^"]+)"\)/.exec(css)?.[1];
  if (available) {
    expect(url).toMatch(/^http:\/\/127\.0\.0\.1:/);
    if (!url) throw new Error("Expected loopback font URL");
    const font = await api.get(url);
    expect(font.status()).toBe(200);
    expect(font.headers()["content-type"]).toBe("font/woff2");
    expect((await font.body()).subarray(0, 4).toString()).toBe("wOF2");
    expect((await api.get(url, { headers: { Origin: "https://example.com" } })).status()).toBe(403);
  }
  expect((await api.get("/kds/fonts/private/KTFLOW-BOLD.woff2")).status()).toBe(404);
  expect((await api.get("/.kds-private/fonts/KTFLOW-BOLD.woff2")).status()).toBe(404);
});
