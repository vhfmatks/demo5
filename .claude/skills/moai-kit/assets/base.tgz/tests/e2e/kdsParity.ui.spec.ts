import { test, expect } from "./fixtures";
import type { Page, TestInfo } from "@playwright/test";

async function compareViewport(page: Page, testInfo: TestInfo, screen: string, width: number, height: number) {
    await page.setViewportSize({ width, height });
    await page.goto(`/kds/${screen}.html`);
    // Both screens must use the same participant-only font environment.
    await page.addStyleTag({ url: "/api/v1/local-font-style" });
    await page.evaluate(() => document.fonts.ready);
    const reference = await page.screenshot({ fullPage: true, animations: "disabled" });
    await page.goto(`/design-system/kds/${screen}`);
    await page.evaluate(() => document.fonts.ready);
    await expect(page.locator(`[data-kds-screen="${screen}"]`)).toBeVisible();
    const migrated = await page.screenshot({ fullPage: true, animations: "disabled" });
    await testInfo.attach(`organizer-${width}`, { body: reference, contentType: "image/png" });
    await testInfo.attach(`react-${width}`, { body: migrated, contentType: "image/png" });
    const diff = await page.evaluate(async ({ a, b }) => {
      const decode = (source: string) => new Promise<HTMLImageElement>((resolve, reject) => {
        const image = new window.Image();
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error("Screenshot decode failed"));
        image.src = `data:image/png;base64,${source}`;
      });
      const [left, right] = await Promise.all([decode(a), decode(b)]);
      if (left.width !== right.width || left.height !== right.height) return { dimensions: false, pixels: -1, left: [left.width, left.height], right: [right.width, right.height] };
      const canvas = document.createElement("canvas");
      canvas.width = left.width; canvas.height = left.height;
      const context = canvas.getContext("2d");
      if (!context) throw new Error("Canvas unavailable");
      context.drawImage(left, 0, 0);
      const x = context.getImageData(0, 0, canvas.width, canvas.height).data;
      context.clearRect(0, 0, canvas.width, canvas.height);
      context.drawImage(right, 0, 0);
      const y = context.getImageData(0, 0, canvas.width, canvas.height).data;
      let pixels = 0;
      for (let i = 0; i < x.length; i += 4) if (x[i] !== y[i] || x[i + 1] !== y[i + 1] || x[i + 2] !== y[i + 2] || x[i + 3] !== y[i + 3]) pixels++;
      return { dimensions: true, pixels, left: [left.width, left.height], right: [right.width, right.height] };
    }, { a: reference.toString("base64"), b: migrated.toString("base64") });
    await testInfo.attach(`pixel-diff-${width}`, { body: JSON.stringify(diff), contentType: "application/json" });
    expect(diff.dimensions, JSON.stringify(diff)).toBe(true);
    expect(diff.pixels, `${screen}: ${JSON.stringify(diff)}`).toBe(0);
}

async function compareScreen(page: Page, testInfo: TestInfo, screen: string, width: number, height: number) {
  const widths = width < 1280 ? [360, width, 480] : [1280, width, 1920];
  for (const size of widths) await compareViewport(page, testInfo, screen, size, height);
}

test("TC-KDS-UI-001 templates/mobile-task 원본과 React 화면 픽셀 일치", async ({ page }, testInfo) => { await compareScreen(page, testInfo, "templates/mobile-task", 390, 844); });
test("TC-KDS-UI-002 templates/mobile-feed 원본과 React 화면 픽셀 일치", async ({ page }, testInfo) => { await compareScreen(page, testInfo, "templates/mobile-feed", 390, 844); });
test("TC-KDS-UI-003 templates/pc-page 원본과 React 화면 픽셀 일치", async ({ page }, testInfo) => { await compareScreen(page, testInfo, "templates/pc-page", 1440, 1000); });
test("TC-KDS-UI-004 templates/pc-admin 원본과 React 화면 픽셀 일치", async ({ page }, testInfo) => { await compareScreen(page, testInfo, "templates/pc-admin", 1440, 1000); });
test("TC-KDS-UI-005 examples/mobile 원본과 React 화면 픽셀 일치", async ({ page }, testInfo) => { await compareScreen(page, testInfo, "examples/mobile", 390, 844); });
test("TC-KDS-UI-006 examples/mobile-pay-method 원본과 React 화면 픽셀 일치", async ({ page }, testInfo) => { await compareScreen(page, testInfo, "examples/mobile-pay-method", 390, 844); });
test("TC-KDS-UI-007 examples/mobile-benefit 원본과 React 화면 픽셀 일치", async ({ page }, testInfo) => { await compareScreen(page, testInfo, "examples/mobile-benefit", 390, 844); });
test("TC-KDS-UI-008 examples/pc 원본과 React 화면 픽셀 일치", async ({ page }, testInfo) => { await compareScreen(page, testInfo, "examples/pc", 1440, 1000); });

test("TC-KDS-UI-009 원본 치수·아이콘·모드·1280 전환", async ({ page }) => {
  await page.goto("/design-system");
  for (const width of [360, 768, 1279, 1280, 1920]) {
    await page.setViewportSize({ width, height: 1000 });
    const menu = page.getByRole("navigation", { name: "주 메뉴", exact: true });
    if (width < 1280) await expect(menu).toBeHidden(); else await expect(menu).toBeVisible();
    const input = page.getByLabel("시작일", { exact: true });
    expect(await input.evaluate((el) => Math.round(el.getBoundingClientRect().height))).toBe(52);
    expect(await page.locator(".kds-gnb__inner").first().evaluate((el) => Math.round(el.getBoundingClientRect().height))).toBe(width < 1280 ? 52 : 72);
    expect(await page.locator(".ic-line-menu").first().evaluate((el) => getComputedStyle(el).getPropertyValue("--icon"))).toMatch(/ic-line-menu[^)]*\.svg/);
  }
});

test("TC-KDS-UI-010 달력 onChange·제어 값·ISO 폼·윤년·경계", async ({ page }) => {
  await page.goto("/design-system");
  const input = page.getByRole("combobox", { name: "제어 날짜", exact: true });
  await expect(input).toHaveValue("2024.02.28");
  await input.click();
  const calendar = page.getByRole("dialog", { name: "제어 날짜 날짜 선택", exact: true });
  await calendar.getByRole("button", { name: "2024년 2월 29일", exact: true }).click();
  await expect(input).toHaveValue("2024.02.29");
  await expect(page.getByTestId("date-change")).toHaveText("1 · controlled · 2024-02-29");
  await page.getByRole("button", { name: "날짜 값 확인", exact: true }).click();
  await expect(page.getByTestId("date-form")).toHaveText("2024-02-29 · 1");
  await page.getByRole("button", { name: "제어 날짜 지우기", exact: true }).click();
  await expect(input).toHaveValue("");
  await page.getByRole("button", { name: "날짜 값 확인", exact: true }).click();
  await expect(page.getByTestId("date-form")).toHaveText(" · 1");
  await expect(page.getByTestId("date-change")).toHaveText("2 · controlled · ");
  await page.getByRole("button", { name: "부모 날짜 변경", exact: true }).click();
  await expect(input).toHaveValue("2024.02.02");
  await input.click();
  await calendar.getByRole("button", { name: "다음 달" }).click();
  await expect(calendar.getByRole("button", { name: "2024년 3월 1일", exact: true })).toBeDisabled();
  await page.keyboard.press("Escape");
  await expect(page.getByRole("combobox", { name: "비활성 날짜", exact: true })).toBeDisabled();
  const readonly = page.getByRole("combobox", { name: "읽기 전용 날짜", exact: true });
  await readonly.click();
  await expect(page.getByRole("dialog", { name: "읽기 전용 날짜 날짜 선택", exact: true })).toBeHidden();
  await expect(page.getByRole("combobox", { name: "오류 날짜", exact: true })).toHaveAttribute("aria-invalid", "true");
});
