// 엔티티별 합성 입력. gen 이 마커 위에 한 줄씩 추가한다(append-only). ref 필드 시험이 대상 행을 만들 때 쓴다.
import type { APIRequestContext } from "@playwright/test";
import { expectData, uniqueTitle } from "./helpers";

type Sample = { body: Record<string, unknown>; refs: Record<string, string> };
export const SAMPLES: Record<string, Sample> = {
  // @gen:samples
};

/** ref 대상 행을 api 사용자 소유로 만들고 id 를 돌려준다. users 는 api 사용자 자신. 대상의 ref 도 재귀로 만든다. */
export async function createRef(api: APIRequestContext, target: string): Promise<string> {
  if (target === "users") return (await expectData<{ id: string }>(await api.get("/api/v1/auth/me"))).data.id;
  const sample = SAMPLES[target];
  if (!sample) throw new Error(`tests/e2e/samples.ts 에 ${target} 합성 입력이 없습니다.`);
  const refs: Record<string, string> = {};
  for (const [field, next] of Object.entries(sample.refs)) refs[field] = await createRef(api, next);
  const response = await api.post(`/api/v1/${target}`, { data: { ...sample.body, ...refs, title: uniqueTitle(`REF-${target}`) } });
  return (await expectData<{ id: string }>(response, 201)).data.id;
}
