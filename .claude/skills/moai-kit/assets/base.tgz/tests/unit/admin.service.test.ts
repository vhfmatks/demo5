// 관리자 서비스 검증 (메모리 DB) — 설정 변경·기본값 복구·역할 변경·감사로그 조회 권한
import { describe, expect, it } from "vitest";
import { db } from "@/server/db/client";
import { and, inArray } from "drizzle-orm";
import { appSettings, auditLogs } from "@/server/db/schema";
import { audit } from "@/server/audit";
import { ownerScope, type ListScope } from "@/server/scope";
import type { SessionUser } from "@/server/auth/session";
import { AppError } from "@/server/http/errors";
import { CommonErrors } from "@/lib/error-codes";
import * as settings from "@/features/settings/service";
import * as usersSvc from "@/features/users/service";
import { listAuditLogs } from "@/features/auditLogs/service";
import { UpdateSettingsInput } from "@/features/settings/schema";
import { UserErrors } from "@/features/users/errors";
import { makeUser } from "./fixtures";

const code = async (p: Promise<unknown>) => {
  try {
    await p;
    return "OK";
  } catch (e) {
    return e instanceof AppError ? e.code : String(e);
  }
};

describe("admin services", () => {
  it("관리자 외에는 설정·사용자·감사로그 접근 거부", async () => {
    for (const role of ["USER", "APPROVER"] as const) {
      const u = await makeUser(role);
      for (const p of [
        settings.getSettingsForAdmin(u),
        settings.updateSettings(u, { noticeBanner: "x" }),
        usersSvc.listUsers(u, { page: 1, pageSize: 10 }),
        usersSvc.updateUserRole(u, u.id, { role: "ADMIN" }),
        listAuditLogs(u, { page: 1, pageSize: 10 }),
      ]) expect(await code(p)).toBe(CommonErrors.AUTH_PERMISSION_REQUIRED.code);
    }
  });

  it("설정 변경 → 적용값 반영 + 변경분만 감사로그(from/to)", async () => {
    const admin = await makeUser("ADMIN");
    const out = await settings.updateSettings(admin, { noticeBanner: "점검 안내", sessionTtlHours: 2 });
    expect(out.values).toMatchObject({ noticeBanner: "점검 안내", sessionTtlHours: 2, maintenanceMode: false });
    expect(await settings.getSettings()).toMatchObject({ noticeBanner: "점검 안내", sessionTtlHours: 2 });
    const { items } = await listAuditLogs(admin, { action: "settings.update", page: 1, pageSize: 1 });
    expect(items[0]).toMatchObject({
      actor: { id: admin.id },
      detail: { changes: { noticeBanner: { from: "", to: "점검 안내" }, sessionTtlHours: { from: 8, to: 2 } } },
    });
  });

  it("잘못된 입력은 스키마에서 거부, 저장값이 스키마와 맞지 않으면 기본값", async () => {
    expect(UpdateSettingsInput.safeParse({}).success).toBe(false);
    expect(UpdateSettingsInput.safeParse({ sessionTtlHours: 0 }).success).toBe(false);
    expect(UpdateSettingsInput.safeParse({ maintenanceMode: "true" }).success).toBe(false);
    expect(UpdateSettingsInput.safeParse({ unknown: 1 }).success).toBe(false);
    await db.insert(appSettings).values({ key: "sessionTtlHours", value: "abc" })
      .onConflictDoUpdate({ target: appSettings.key, set: { value: "abc" } }).run();
    expect((await settings.getSettings()).sessionTtlHours).toBe(8);
  });

  it("역할 변경: 타인은 가능·감사로그, 본인은 거부, 없는 사용자는 404", async () => {
    const [admin, u] = await Promise.all([makeUser("ADMIN"), makeUser()]);
    expect((await usersSvc.updateUserRole(admin, u.id, { role: "APPROVER" })).role).toBe("APPROVER");
    const { items } = await listAuditLogs(admin, { entity: "user", entityId: u.id, page: 1, pageSize: 5 });
    expect(items[0]).toMatchObject({ action: "user.role_change", detail: { from: "USER", to: "APPROVER" } });
    expect(await code(usersSvc.updateUserRole(admin, admin.id, { role: "USER" }))).toBe(UserErrors.USER_SELF_ROLE_CHANGE_FORBIDDEN.code);
    expect(await code(usersSvc.updateUserRole(admin, crypto.randomUUID(), { role: "USER" }))).toBe(UserErrors.USER_NOT_FOUND.code);
  });

  it("부서 지정: 지정·해제·감사로그, 권한 없으면 거부, 없는 사용자 404", async () => {
    const [admin, manager, u] = await Promise.all([makeUser("ADMIN"), makeUser("MANAGER", "DEV"), makeUser("USER", "SALES")]);
    expect((await usersSvc.updateUserDepartment(admin, u.id, { department: "OPS" })).department).toBe("OPS");
    const { items } = await listAuditLogs(admin, { entity: "user", entityId: u.id, page: 1, pageSize: 5 });
    expect(items[0]).toMatchObject({ action: "user.department_change", detail: { from: "SALES", to: "OPS" } });
    expect((await usersSvc.updateUserDepartment(admin, u.id, { department: null })).department).toBeNull();
    expect(await code(usersSvc.updateUserDepartment(manager, u.id, { department: "DEV" }))).toBe(CommonErrors.AUTH_PERMISSION_REQUIRED.code);
    expect(await code(usersSvc.updateUserDepartment(admin, crypto.randomUUID(), { department: "DEV" }))).toBe(UserErrors.USER_NOT_FOUND.code);
  });

  it("ownerScope: dept = 같은 부서 소유자, 부서 미지정은 own, all 은 조건 없음", async () => {
    const [mgr, dev, sales, lone] = await Promise.all([
      makeUser("MANAGER", "DEV"), makeUser("USER", "DEV"), makeUser("USER", "SALES"), makeUser("MANAGER"),
    ]);
    const everyone = [mgr, dev, sales, lone];
    for (const u of everyone) await audit(u.id, "scope.test", "scope", null);
    const owners = async (actor: SessionUser, scope: ListScope) =>
      (await db.select({ id: auditLogs.actorId }).from(auditLogs)
        .where(and(inArray(auditLogs.actorId, everyone.map((u) => u.id)), ownerScope(actor, scope, auditLogs.actorId))).all())
        .map((r) => r.id).sort();
    expect(await owners(mgr, "dept")).toEqual([mgr.id, dev.id].sort());
    expect(await owners(mgr, "own")).toEqual([mgr.id]);
    expect(await owners(lone, "dept")).toEqual([lone.id]);
    expect(await owners(mgr, "all")).toEqual(everyone.map((u) => u.id).sort());
  });

  it("감사로그 기간 필터(Asia/Seoul 날짜)", async () => {
    const admin = await makeUser("ADMIN");
    await settings.updateSettings(admin, { noticeBanner: `기간 ${admin.id}` });
    const today = new Intl.DateTimeFormat("sv-SE", { timeZone: "Asia/Seoul" }).format(new Date());
    const hit = await listAuditLogs(admin, { actor: admin.email, from: today, to: today, page: 1, pageSize: 5 });
    const miss = await listAuditLogs(admin, { actor: admin.email, to: "2000-01-01", page: 1, pageSize: 5 });
    expect(hit.meta.total).toBe(1);
    expect(miss.meta.total).toBe(0);
  });
});
