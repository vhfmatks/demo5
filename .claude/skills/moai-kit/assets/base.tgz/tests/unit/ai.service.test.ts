// AI: 비밀값 암호화·주소 규칙·등록 흐름(시험 → 등록)·기능 호출(aiComplete·aiJson)·오류 변환·호출 제한 (SEC-01, SEC-06, SEC-09)
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/server/db/client";
import { aiProviders, auditLogs } from "@/server/db/schema";
import { AppError } from "@/server/http/errors";
import { decryptSecret, encryptSecret } from "@/server/secret";
import { CommonErrors } from "@/lib/error-codes";
import { isAllowedAiUrl } from "@/features/ai/schema";
import { AiErrors } from "@/features/ai/errors";
import * as ai from "@/features/ai/service";
import { MOCK_AI_KEY, startMockAi } from "../ai-mock";
import { makeUser } from "./fixtures";

let mock: Awaited<ReturnType<typeof startMockAi>>;
beforeAll(async () => {
  mock = await startMockAi(() => ({ category: "EQUIPMENT", score: 3 }));
});
afterAll(() => mock.close());

const failure = async (p: Promise<unknown>) => {
  try {
    await p;
  } catch (e) {
    if (e instanceof AppError) return { code: e.code, message: e.message, status: e.status };
    throw e;
  }
  throw new Error("실패해야 합니다.");
};

describe("비밀값·주소 규칙", () => {
  it("암호화: 매번 다른 암호문, 복호화 일치, 위조는 거부", () => {
    const a = encryptSecret("sk-test-abcd");
    expect(a).not.toContain("sk-test");
    expect(encryptSecret("sk-test-abcd")).not.toBe(a);
    expect(decryptSecret(a)).toBe("sk-test-abcd");
    const [v, iv, tag, data] = a.split(".");
    expect(() => decryptSecret([v, iv, tag, `${data.slice(0, -2)}AA`].join("."))).toThrow();
  });

  it("https 는 허용, http 는 localhost 만, 계정·query 금지", () => {
    expect(isAllowedAiUrl("https://api.openai.com/v1")).toBe(true);
    expect(isAllowedAiUrl("http://localhost:11434/v1")).toBe(true);
    expect(isAllowedAiUrl("http://127.0.0.1:8080")).toBe(true);
    expect(isAllowedAiUrl("http://10.0.0.5/v1")).toBe(false);
    expect(isAllowedAiUrl("http://example.com/v1")).toBe(false);
    expect(isAllowedAiUrl("https://user:pw@api.example.com")).toBe(false);
    expect(isAllowedAiUrl("https://api.example.com/v1?x=1")).toBe(false);
    expect(isAllowedAiUrl("file:///etc/passwd")).toBe(false);
  });

  it("extractJson: 코드 블록·앞뒤 설명 허용, 깨지면 undefined", () => {
    expect(ai.extractJson('결과:\n```json\n{"a":1}\n```')).toEqual({ a: 1 });
    expect(ai.extractJson("없음")).toBeUndefined();
    expect(ai.extractJson("{깨짐}")).toBeUndefined();
  });
});

describe("AI 등록 → 사용", () => {
  it("등록 전: 기능 호출은 503 AI_NOT_CONFIGURED, 일반 사용자는 관리 거부", async () => {
    const user = await makeUser();
    expect((await failure(ai.aiComplete(user, { feature: "t", prompt: "hi" }))).code).toBe(AiErrors.AI_NOT_CONFIGURED.code);
    expect((await failure(ai.listAiProviders(user))).code).toBe(CommonErrors.AUTH_PERMISSION_REQUIRED.code);
    expect((await failure(ai.testAiProvider(user, { kind: "openai", baseUrl: mock.openai, apiKey: MOCK_AI_KEY }))).code)
      .toBe(CommonErrors.AUTH_PERMISSION_REQUIRED.code);
  });

  it("공급자: 시험 → 잘못된 키·리다이렉트는 원인과 함께 400, 등록은 다시 시험, 키는 암호문 + 끝 4자리", async () => {
    const admin = await makeUser("ADMIN");
    expect(await ai.testAiProvider(admin, { kind: "openai", baseUrl: mock.openai, apiKey: MOCK_AI_KEY }))
      .toMatchObject({ ok: true, models: ["mock-large", "mock-small"] });
    const bad = await failure(ai.testAiProvider(admin, { kind: "openai", baseUrl: mock.openai, apiKey: "wrong" }));
    expect(bad).toMatchObject({ code: AiErrors.AI_TEST_FAILED.code, status: 400 });
    expect(bad.message).toContain("HTTP 401");
    expect((await failure(ai.testAiProvider(admin, { kind: "openai", baseUrl: mock.redirect, apiKey: MOCK_AI_KEY }))).message).toContain("연결할 수 없습니다");
    expect((await failure(ai.createAiProvider(admin, { name: "나쁜 키", kind: "openai", baseUrl: mock.openai, apiKey: "wrong" }))).code)
      .toBe(AiErrors.AI_TEST_FAILED.code);
    expect(await db.select().from(aiProviders).where(eq(aiProviders.name, "나쁜 키")).get()).toBeUndefined();

    const p = await ai.createAiProvider(admin, { name: "가짜 OpenAI", kind: "openai", baseUrl: mock.openai, apiKey: MOCK_AI_KEY });
    expect(p).toMatchObject({ name: "가짜 OpenAI", apiKeyHint: "••••1234" });
    expect(JSON.stringify(p)).not.toContain(MOCK_AI_KEY);
    const row = await db.select().from(aiProviders).where(eq(aiProviders.id, p.id)).get();
    expect(row?.apiKeyEnc).not.toContain(MOCK_AI_KEY);
    expect((await failure(ai.createAiProvider(admin, { name: "가짜 OpenAI", kind: "openai", baseUrl: mock.openai, apiKey: MOCK_AI_KEY }))).code)
      .toBe(AiErrors.AI_NAME_TAKEN.code);
    const logs = await db.select().from(auditLogs).where(eq(auditLogs.entityId, p.id)).all();
    expect(JSON.stringify(logs)).not.toContain(MOCK_AI_KEY);
    expect(await ai.listAiProviderModels(admin, p.id)).toEqual(["mock-large", "mock-small"]);
  });

  it("모델: 시험 → 등록(첫 모델 = 기본), 기본 변경, 없는 모델 400, 이름 중복 409 → aiComplete·aiJson·감사로그", async () => {
    const admin = await makeUser("ADMIN");
    const user = await makeUser();
    const [openai] = await ai.listAiProviders(admin);
    const claude = await ai.createAiProvider(admin, { name: "가짜 Anthropic", kind: "anthropic", baseUrl: mock.anthropic, apiKey: MOCK_AI_KEY });
    expect(await ai.testAiModel(admin, { providerId: openai.id, model: "mock-small" })).toMatchObject({ ok: true, reply: "OK" });
    expect((await failure(ai.testAiModel(admin, { providerId: openai.id, model: "missing" }))).message).toContain("HTTP 404");

    const small = await ai.createAiModel(admin, { providerId: openai.id, model: "mock-small", label: "", isDefault: false });
    expect(small).toMatchObject({ label: "mock-small", isDefault: true });
    const sum = await ai.createAiModel(admin, { providerId: claude.id, model: "mock-large", label: "요약", isDefault: false });
    expect(sum.isDefault).toBe(false);
    expect((await failure(ai.createAiModel(admin, { providerId: claude.id, model: "mock-small", label: "요약", isDefault: false }))).code)
      .toBe(AiErrors.AI_NAME_TAKEN.code);

    expect(await ai.aiComplete(user, { feature: "unit.default", prompt: "안녕" })).toMatchObject({ text: "OK", model: "mock-small" });
    expect(mock.seen.at(-1)).toMatchObject({ path: "/v1/chat/completions", body: { model: "mock-small", max_tokens: 1024 } });
    expect(await ai.aiComplete(user, { feature: "unit.label", prompt: "안녕", model: "요약", system: "짧게" })).toMatchObject({ model: "요약" });
    expect(mock.seen.at(-1)).toMatchObject({ path: "/v1/messages", body: { model: "mock-large", system: "짧게" } });

    const Out = z.object({ category: z.enum(["EQUIPMENT", "ETC"]), score: z.number() });
    expect(await ai.aiJson(user, { feature: "unit.json", prompt: "분류", schema: Out })).toEqual({ category: "EQUIPMENT", score: 3 });
    const Strict = z.object({ category: z.enum(["ETC"]) });
    expect((await failure(ai.aiJson(user, { feature: "unit.json", prompt: "분류", schema: Strict }))).code).toBe(CommonErrors.UPSTREAM_ERROR.code);

    await ai.updateAiModel(admin, sum.id, { isDefault: true });
    expect((await ai.listAiModels(admin)).filter((m) => m.isDefault).map((m) => m.label)).toEqual(["요약"]);
    expect((await ai.aiComplete(user, { feature: "unit.default2", prompt: "안녕" })).model).toBe("요약");

    const calls = await db.select().from(auditLogs).where(eq(auditLogs.action, "ai.call")).all();
    expect(calls.find((c) => (c.detail as { feature?: string })?.feature === "unit.default")?.detail)
      .toMatchObject({ ok: true, model: "mock-small", inputTokens: 11, outputTokens: 3 });
    expect(JSON.stringify(calls)).not.toContain("안녕");
  });

  it("공급자 오류는 기능 쪽에 502 로 숨기고 감사로그에 원인, 공급자 삭제 = 모델도 삭제", async () => {
    const admin = await makeUser("ADMIN");
    const user = await makeUser();
    const [model] = (await ai.listAiModels(admin)).filter((m) => m.isDefault);
    await db.update(aiProviders).set({ baseUrl: mock.redirect }).where(eq(aiProviders.id, model.provider.id)).run();
    expect(await failure(ai.aiComplete(user, { feature: "unit.down", prompt: "x" }))).toMatchObject({ code: CommonErrors.UPSTREAM_ERROR.code, status: 502 });
    const log = await db.select().from(auditLogs).where(eq(auditLogs.action, "ai.call")).all();
    expect(log.find((c) => (c.detail as { feature?: string })?.feature === "unit.down")?.detail).toMatchObject({ ok: false, reason: "network" });

    for (const p of await ai.listAiProviders(admin)) await ai.deleteAiProvider(admin, p.id);
    expect(await ai.listAiModels(admin)).toEqual([]);
    expect((await failure(ai.aiComplete(user, { feature: "t", prompt: "x" }))).code).toBe(AiErrors.AI_NOT_CONFIGURED.code);
  });

  it("호출 제한: 사용자당 분당 20회, 넘으면 429 + Retry-After", async () => {
    const admin = await makeUser("ADMIN");
    const user = await makeUser();
    const p = await ai.createAiProvider(admin, { name: "제한 시험", kind: "openai", baseUrl: mock.openai, apiKey: MOCK_AI_KEY });
    await ai.createAiModel(admin, { providerId: p.id, model: "mock-small", label: "제한", isDefault: true });
    for (let i = 0; i < 20; i++) await ai.aiComplete(user, { feature: "unit.rate", prompt: "x" });
    const e = await failure(ai.aiComplete(user, { feature: "unit.rate", prompt: "x" }));
    expect(e).toMatchObject({ code: AiErrors.AI_RATE_LIMITED.code, status: 429 });
    expect((await ai.aiComplete(await makeUser(), { feature: "unit.rate", prompt: "x" })).text).toBe("OK");
  });
});

const callLogs = async (feature: string) =>
  (await db.select().from(auditLogs).where(eq(auditLogs.action, "ai.call")).all())
    .filter((c) => (c.detail as { feature?: string } | null)?.feature === feature);

describe("호출 제한·추적 (A)", () => {
  it("옵션 경계: 범위 밖은 외부 호출 전에 400, 경계값·기본값은 통과", async () => {
    const user = await makeUser();
    const before = mock.seen.length;
    const bad: Partial<ai.AiCompleteOptions>[] = [
      { timeoutMs: 999 }, { timeoutMs: 60_001 }, { timeoutMs: 1500.5 }, { timeoutMs: Number.NaN },
      { maxTokens: 0 }, { maxTokens: 4097 }, { maxTokens: 1.5 },
      { prompt: "가".repeat(16_001) }, { prompt: "가".repeat(8000), system: "나".repeat(8001) },
    ];
    for (const o of bad) {
      expect(await failure(ai.aiComplete(user, { feature: "unit.bound", prompt: "x", ...o }))).toMatchObject({ code: CommonErrors.VALIDATION_ERROR.code, status: 400 });
    }
    // aiJson 이 덧붙이는 system 지시도 합계에 포함된다
    expect((await failure(ai.aiJson(user, { feature: "unit.bound", prompt: "가".repeat(16_000), schema: z.object({}) }))).status).toBe(400);
    expect(mock.seen.length).toBe(before);
    expect(await callLogs("unit.bound")).toEqual([]);

    expect((await ai.aiComplete(user, { feature: "unit.bound", prompt: "가".repeat(16_000), maxTokens: 4096, timeoutMs: 1000 })).text).toBe("OK");
    expect(mock.seen.at(-1)?.body).toMatchObject({ max_tokens: 4096 });
    await ai.aiComplete(user, { feature: "unit.bound", prompt: "x", maxTokens: 1, timeoutMs: 60_000 });
    expect(mock.seen.at(-1)?.body).toMatchObject({ max_tokens: 1 });
    await ai.aiComplete(user, { feature: "unit.bound", prompt: "x" });
    expect(mock.seen.at(-1)?.body).toMatchObject({ max_tokens: 1024 });
  });

  it("aiComplete: 기존 값 + meta(callId·공급자·실제 모델 ID·사용량), 감사와 callId 일치", async () => {
    const user = await makeUser();
    const r = await ai.aiComplete(user, { feature: "unit.meta", prompt: "비밀-프롬프트-본문" });
    expect(r).toMatchObject({ text: "OK", model: "제한" });
    expect(typeof r.ms).toBe("number");
    expect(r.meta.callId).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
    expect(r.meta).toMatchObject({ modelId: "mock-small", inputTokens: 11, outputTokens: 3 });
    const [log] = await callLogs("unit.meta");
    expect(log.detail).toMatchObject({
      callId: r.meta.callId, providerId: r.meta.providerId, model: "제한", modelId: "mock-small", ok: true, inputTokens: 11, outputTokens: 3,
    });
    expect(typeof (log.detail as { ms: unknown }).ms).toBe("number");
    expect((await ai.aiComplete(user, { feature: "unit.meta", prompt: "x" })).meta.callId).not.toBe(r.meta.callId);
    expect(JSON.stringify(await callLogs("unit.meta"))).not.toContain("비밀-프롬프트-본문");
  });

  it("timeoutMs: 응답이 늦으면 504, 감사에 실패 ms·공급자·모델·null 사용량", async () => {
    const admin = await makeUser("ADMIN");
    const user = await makeUser();
    const p = (await ai.listAiProviders(admin)).find((x) => x.baseUrl === mock.openai);
    if (!p) throw new Error("공급자 없음");
    await ai.createAiModel(admin, { providerId: p.id, model: "slow", label: "느림", isDefault: false });
    expect(await failure(ai.aiComplete(user, { feature: "unit.slow", prompt: "x", model: "느림", timeoutMs: 1000 })))
      .toMatchObject({ code: CommonErrors.UPSTREAM_TIMEOUT.code, status: 504 });
    const [log] = await callLogs("unit.slow");
    expect(log.detail).toMatchObject({
      ok: false, reason: "timeout", providerId: p.id, model: "느림", modelId: "slow", inputTokens: null, outputTokens: null,
    });
    expect((log.detail as { ms: number }).ms).toBeGreaterThanOrEqual(900);
  });

  it("aiJson: 유효하면 감사 1건(ok), 형식·스키마 위반이면 감사 1건(format 실패)만", async () => {
    const user = await makeUser();
    const Out = z.object({ category: z.string(), score: z.number() });
    expect(await ai.aiJson(user, { feature: "unit.final.ok", prompt: "분류", schema: Out })).toEqual({ category: "EQUIPMENT", score: 3 });
    const ok = await callLogs("unit.final.ok");
    expect(ok).toHaveLength(1);
    expect(ok[0].detail).toMatchObject({ ok: true, inputTokens: 11, outputTokens: 3 });

    const Strict = z.object({ category: z.literal("ETC") });
    expect((await failure(ai.aiJson(user, { feature: "unit.final.bad", prompt: "분류", schema: Strict }))).code).toBe(CommonErrors.UPSTREAM_ERROR.code);
    const bad = await callLogs("unit.final.bad");
    expect(bad).toHaveLength(1);
    expect(bad[0].detail).toMatchObject({ ok: false, reason: "format", inputTokens: null, outputTokens: null });
    expect(JSON.stringify(bad)).not.toContain("EQUIPMENT");
  });

  it("사용량 미제공 성공은 null 로 기록(0·추정 아님), meta 도 null", async () => {
    const admin = await makeUser("ADMIN");
    const user = await makeUser();
    const p = (await ai.listAiProviders(admin)).find((x) => x.baseUrl === mock.openai);
    if (!p) throw new Error("공급자 없음");
    await ai.createAiModel(admin, { providerId: p.id, model: "nousage", label: "무사용량", isDefault: false });
    const r = await ai.aiComplete(user, { feature: "unit.nousage", prompt: "x", model: "무사용량" });
    expect(r.meta).toMatchObject({ inputTokens: null, outputTokens: null });
    expect((await callLogs("unit.nousage"))[0].detail).toMatchObject({ ok: true, inputTokens: null, outputTokens: null });
  });

  it("aiJson: JSON 이 아닌 응답(파싱 불가)도 감사 1건(format 실패) + 502", async () => {
    const admin = await makeUser("ADMIN");
    const user = await makeUser();
    const p = (await ai.listAiProviders(admin)).find((x) => x.baseUrl === mock.openai);
    if (!p) throw new Error("공급자 없음");
    await ai.createAiModel(admin, { providerId: p.id, model: "plain", label: "평문", isDefault: false });
    expect(await failure(ai.aiJson(user, { feature: "unit.plain", prompt: "분류", model: "평문", schema: z.object({}) }))).toMatchObject({ code: CommonErrors.UPSTREAM_ERROR.code, status: 502 });
    const logs = await callLogs("unit.plain");
    expect(logs).toHaveLength(1);
    expect(logs[0].detail).toMatchObject({ ok: false, reason: "format", inputTokens: null, outputTokens: null });
    expect(JSON.stringify(logs)).not.toContain("그냥 문장");
  });

  it("감사 기록 실패는 호출자에게 그대로 전파(기존 정책: 성공·실패 경로 모두), 호출 전 키 복호화 실패는 감사 대상 아님", async () => {
    const admin = await makeUser("ADMIN");
    const user = await makeUser();
    const spy = vi.spyOn(db, "insert").mockImplementationOnce(() => {
      throw new Error("audit down");
    });
    await expect(ai.aiComplete(user, { feature: "unit.auditfail", prompt: "x" })).rejects.toThrow("audit down");
    spy.mockRestore();

    const p = await ai.createAiProvider(admin, { name: "깨진 키", kind: "openai", baseUrl: mock.openai, apiKey: MOCK_AI_KEY });
    await ai.createAiModel(admin, { providerId: p.id, model: "mock-small", label: "깨진키", isDefault: false });
    await db.update(aiProviders).set({ apiKeyEnc: "broken.cipher" }).where(eq(aiProviders.id, p.id)).run();
    expect((await failure(ai.aiComplete(user, { feature: "unit.secret", prompt: "x", model: "깨진키" }))).code).toBe(AiErrors.AI_SECRET_UNREADABLE.code);
    expect(await callLogs("unit.secret")).toEqual([]);
  });

  it("공급자 오류 원문·키는 감사/공개 오류에 없다", async () => {
    const admin = await makeUser("ADMIN");
    const user = await makeUser();
    const p = await ai.createAiProvider(admin, { name: "키 오류", kind: "openai", baseUrl: mock.openai, apiKey: MOCK_AI_KEY });
    await ai.createAiModel(admin, { providerId: p.id, model: "mock-small", label: "키오류", isDefault: false });
    await db.update(aiProviders).set({ apiKeyEnc: encryptSecret("wrong-key-9999") }).where(eq(aiProviders.id, p.id)).run();
    const e = await failure(ai.aiComplete(user, { feature: "unit.leak", prompt: "비밀-질문", model: "키오류" }));
    expect(e).toMatchObject({ code: CommonErrors.UPSTREAM_ERROR.code, status: 502 });
    const logs = await callLogs("unit.leak");
    expect(logs[0].detail).toMatchObject({ ok: false, reason: "http", status: 401, inputTokens: null });
    const text = JSON.stringify(logs) + JSON.stringify(e);
    for (const secret of ["invalid api key", "wrong-key-9999", MOCK_AI_KEY, "비밀-질문"]) expect(text).not.toContain(secret);
  });
});

describe("사내 Gateway 호환 (B)", () => {
  it("경로 prefix baseUrl: 모델 목록·모델 시험·일반 호출이 같은 경로 + 종류별 인증을 쓴다", async () => {
    const admin = await makeUser("ADMIN");
    const user = await makeUser();
    const oa = await ai.createAiProvider(admin, { name: "GW OpenAI", kind: "openai", baseUrl: mock.gatewayOpenai, apiKey: MOCK_AI_KEY });
    const an = await ai.createAiProvider(admin, { name: "GW Anthropic", kind: "anthropic", baseUrl: mock.gatewayAnthropic, apiKey: MOCK_AI_KEY });
    expect(mock.gets.filter((g) => g.path === "/gw/corp/v1/models").map((g) => g.auth)).toEqual(expect.arrayContaining(["bearer", "x-api-key"]));
    expect(await ai.listAiProviderModels(admin, oa.id)).toEqual(["mock-large", "mock-small"]);
    await ai.createAiModel(admin, { providerId: oa.id, model: "mock-small", label: "gw-oa", isDefault: false });
    await ai.createAiModel(admin, { providerId: an.id, model: "mock-large", label: "gw-an", isDefault: false });
    expect(mock.seen.filter((s) => s.path.startsWith("/gw/corp/"))).toEqual(expect.arrayContaining([
      expect.objectContaining({ path: "/gw/corp/v1/chat/completions", auth: "bearer" }),
      expect.objectContaining({ path: "/gw/corp/v1/messages", auth: "x-api-key" }),
    ]));

    expect((await ai.aiComplete(user, { feature: "unit.gw", prompt: "x", model: "gw-oa" })).text).toBe("OK");
    expect(mock.seen.at(-1)).toMatchObject({ path: "/gw/corp/v1/chat/completions", auth: "bearer" });
    expect((await ai.aiComplete(user, { feature: "unit.gw", prompt: "x", model: "gw-an" })).text).toBe("OK");
    expect(mock.seen.at(-1)).toMatchObject({ path: "/gw/corp/v1/messages", auth: "x-api-key" });

    expect((await failure(ai.testAiProvider(admin, { kind: "openai", baseUrl: mock.gatewayOpenai, apiKey: "wrong" }))).message).toContain("HTTP 401");
  });

  it("URL 제한은 그대로: 사설 http·query 주소는 외부 호출 없이 거부", async () => {
    const admin = await makeUser("ADMIN");
    const user = await makeUser();
    const gw = (await ai.listAiModels(admin)).find((m) => m.label === "gw-oa");
    if (!gw) throw new Error("gw-oa 없음");
    for (const baseUrl of ["http://10.0.0.5/gw/v1", `${mock.gatewayOpenai}?token=1`]) {
      await db.update(aiProviders).set({ baseUrl }).where(eq(aiProviders.id, gw.provider.id)).run();
      const before = mock.seen.length;
      expect(await failure(ai.aiComplete(user, { feature: "unit.gw.url", prompt: "x", model: "gw-oa" }))).toMatchObject({ status: 502 });
      expect(mock.seen.length).toBe(before);
    }
    expect((await callLogs("unit.gw.url")).map((c) => (c.detail as { reason: string }).reason)).toEqual(["url", "url"]);
    expect((await failure(ai.testAiProvider(admin, { kind: "openai", baseUrl: "http://10.0.0.5/v1", apiKey: "" }))).message).toContain("허용되지 않은 주소");
  });
});
