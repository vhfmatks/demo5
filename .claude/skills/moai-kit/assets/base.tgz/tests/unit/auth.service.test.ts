// 로그인 반복 실패 제한·감사 (메모리 DB) — 잠금 중 맞는 비밀번호 거부, 잠금 시간 후 복구, 동시 시도 상한, 감사에 원문 없음 (SEC-09, SEC-10)
// 비밀번호 저장: bcrypt 해시만 저장·원문 미저장, bcrypt 72바이트 상한 (SEC-05)
import { afterEach, describe, expect, it, vi } from "vitest";
import bcrypt from "bcryptjs";
import { and, eq } from "drizzle-orm";
import { db } from "@/server/db/client";
import { auditLogs, users } from "@/server/db/schema";
import { AppError } from "@/server/http/errors";
import { changePassword, login } from "@/features/auth/service";
import { ChangePasswordInput } from "@/features/auth/schema";
import { AuthErrors } from "@/features/auth/errors";

vi.mock("next/headers", () => ({ cookies: async () => ({ get: () => undefined, set: () => undefined, delete: () => undefined }) }));

const PASSWORD = "Synthetic1Pass";
const hash = bcrypt.hashSync(PASSWORD, 4);
let n = 0;
async function makeAccount() {
  n += 1;
  const email = `login${n}-${Date.now()}@test.local`;
  await db.insert(users).values({ email, name: `로그인${n}`, role: "USER", passwordHash: hash }).run();
  return email;
}
const attempt = async (email: string, password: string) => {
  try {
    await login({ email, password });
    return "OK";
  } catch (e) {
    if (!(e instanceof AppError)) throw e;
    return e.code;
  }
};

describe("login 반복 실패 제한 (기본 5회·15분)", () => {
  afterEach(() => vi.useRealTimers());

  it("5회 실패 후 맞는 비밀번호도 429, 다른 계정은 영향 없음, 잠금 시간이 지나면 복구", async () => {
    vi.useFakeTimers({ toFake: ["Date"] });
    const [email, other] = [await makeAccount(), await makeAccount()];
    for (let i = 0; i < 5; i += 1) expect(await attempt(email, "WrongPass1")).toBe(AuthErrors.AUTH_INVALID_CREDENTIALS.code);
    const locked = await login({ email, password: PASSWORD }).catch((e: AppError) => e);
    expect(locked).toMatchObject({ code: AuthErrors.AUTH_TOO_MANY_ATTEMPTS.code, status: 429 });
    expect((locked as AppError).retryAfterSeconds).toBeGreaterThan(0);
    expect(await attempt(other, PASSWORD)).toBe("OK");
    vi.setSystemTime(Date.now() + 15 * 60_000 + 1);
    expect(await attempt(email, PASSWORD)).toBe("OK");
  });

  it("성공하면 실패 기록을 지운다", async () => {
    const email = await makeAccount();
    for (let i = 0; i < 4; i += 1) await attempt(email, "WrongPass1");
    expect(await attempt(email, PASSWORD)).toBe("OK");
    for (let i = 0; i < 4; i += 1) expect(await attempt(email, "WrongPass1")).toBe(AuthErrors.AUTH_INVALID_CREDENTIALS.code);
  });

  it("동시 시도도 허용 횟수를 넘기지 못하고, 없는 계정도 같은 방식으로 제한", async () => {
    const email = `missing-${Date.now()}@test.local`;
    const results = await Promise.all(Array.from({ length: 12 }, () => attempt(email, "WrongPass1")));
    expect(results.filter((r) => r === AuthErrors.AUTH_INVALID_CREDENTIALS.code)).toHaveLength(5);
    expect(results.filter((r) => r === AuthErrors.AUTH_TOO_MANY_ATTEMPTS.code)).toHaveLength(7);
  });

  it("실패·잠금 감사에는 이메일 원문·비밀번호가 없다", async () => {
    const email = await makeAccount();
    const [u] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).all();
    for (let i = 0; i < 6; i += 1) await attempt(email, "WrongPass1");
    const rows = await db.select().from(auditLogs).where(and(eq(auditLogs.action, "auth.login_failed"), eq(auditLogs.entityId, u.id))).all();
    expect(rows).toHaveLength(6);
    expect(rows.filter((r) => (r.detail as { locked?: boolean } | null)?.locked)).toHaveLength(1);
    const text = JSON.stringify(rows.map((r) => r.detail));
    expect(text).toMatch(/emailRef/);
    expect(text).not.toContain(email);
    expect(text).not.toContain("WrongPass1");
  });
});

describe("비밀번호 저장 (SEC-05)", () => {
  it("변경한 비밀번호는 bcrypt 해시로만 저장되고 원문은 남지 않는다", async () => {
    const email = await makeAccount();
    const [u] = await db.select().from(users).where(eq(users.email, email)).all();
    const NEW = "Synthetic9Pass";
    await changePassword({ id: u.id, email, name: u.name, role: u.role, department: u.department }, { currentPassword: PASSWORD, newPassword: NEW, confirmPassword: NEW });
    const [{ passwordHash }] = await db.select({ passwordHash: users.passwordHash }).from(users).where(eq(users.id, u.id)).all();
    expect(passwordHash).toMatch(/^\$2[aby]\$10\$/);
    expect(passwordHash).not.toContain(NEW);
    expect(await bcrypt.compare(NEW, passwordHash)).toBe(true);
    const audits = await db.select().from(auditLogs).where(and(eq(auditLogs.action, "auth.password_change"), eq(auditLogs.entityId, u.id))).all();
    expect(JSON.stringify(audits)).not.toContain(NEW);
  });

  it("새 비밀번호는 72바이트까지만 받는다(bcrypt 가 뒤를 무시하므로)", () => {
    const input = (newPassword: string) => ChangePasswordInput.safeParse({ currentPassword: PASSWORD, newPassword, confirmPassword: newPassword });
    expect(input(`a1${"x".repeat(70)}`).success).toBe(true);
    expect(input(`a1${"x".repeat(71)}`).success).toBe(false);
    expect(input(`a1${"가".repeat(23)}`).success).toBe(true); // 2 + 69 바이트
    expect(input(`a1${"가".repeat(24)}`).success).toBe(false);
  });
});
