import { describe, expect, test } from "vitest";
import { addDays, addMonths, calendarDays, formatDate, isDateInRange, parseDate } from "@/components/ui/date-values";

describe("date-values", () => {
  test("TC-DESIGN-UNIT-001 엄격한 ISO 날짜 파싱과 화면 표시", () => {
    expect(parseDate("2026-10-12")).toBe("2026-10-12");
    expect(parseDate(20261012)).toBeNull();
    expect(parseDate("2026.10.12")).toBeNull();
    expect(parseDate("2026-10-1")).toBeNull();
    expect(parseDate("2026-13-01")).toBeNull();
    expect(parseDate("2026-00-01")).toBeNull();
    expect(parseDate("2026-02-30")).toBeNull();
    expect(parseDate("2023-02-29")).toBeNull();
    expect(parseDate("2024-02-29")).toBe("2024-02-29");
    expect(formatDate("2026-10-12")).toBe("2026.10.12");
    expect(formatDate("2026-02-30")).toBe("");
  });

  test("TC-DESIGN-UNIT-002 월 이동·일 이동의 월말과 윤년 경계", () => {
    expect(addMonths("2026-01-31", 1)).toBe("2026-02-28");
    expect(addMonths("2024-01-31", 1)).toBe("2024-02-29");
    expect(addMonths("2026-01-31", -1)).toBe("2025-12-31");
    expect(addDays("2024-02-28", 1)).toBe("2024-02-29");
    expect(addDays("2023-02-28", 1)).toBe("2023-03-01");
    expect(addDays("2026-12-31", 1)).toBe("2027-01-01");
  });

  test("TC-DESIGN-UNIT-003 주별 grid·일요일·min/max 경계", () => {
    const days = calendarDays({ year: 2026, month: 1, min: "2026-02-05", max: "2026-02-20", today: "2026-02-10" });
    expect(days).toHaveLength(28);
    expect(days.filter((day) => day?.sunday).map((day) => day?.value)).toEqual(["2026-02-01", "2026-02-08", "2026-02-15", "2026-02-22"]);
    expect(days.find((day) => day?.value === "2026-02-04")?.disabled).toBe(true);
    expect(days.find((day) => day?.value === "2026-02-05")?.disabled).toBe(false);
    expect(days.find((day) => day?.value === "2026-02-10")?.today).toBe(true);
    expect(days.find((day) => day?.value === "2026-02-20")?.disabled).toBe(false);
    expect(days.find((day) => day?.value === "2026-02-21")?.disabled).toBe(true);
    expect(isDateInRange("2026-02-20", "2026-02-05", "2026-02-20")).toBe(true);
    expect(isDateInRange("2026-02-21", "2026-02-05", "2026-02-20")).toBe(false);
  });
});
