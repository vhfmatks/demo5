import { db } from "@/server/db/client";
import { users, type Role } from "@/server/db/schema";
import type { SessionUser } from "@/server/auth/session";
import type { Department } from "@/lib/departments";

let n = 0;
/** 테스트용 사용자 생성 (비밀번호 해시는 의미 없는 값) */
export async function makeUser(role: Role = "USER", department: Department | null = null): Promise<SessionUser> {
  n += 1;
  const u = await db
    .insert(users)
    .values({ email: `t${n}-${Date.now()}@test.local`, name: `테스터${n}`, role, department, passwordHash: "x" })
    .returning()
    .get();
  return { id: u.id, email: u.email, name: u.name, role: u.role, department: u.department };
}
