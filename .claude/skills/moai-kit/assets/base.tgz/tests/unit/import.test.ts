// 표 가져오기: parseCsv · readTable(CSV UTF-8/CP949, XLSX) · parseRows(머리행·행 오류·라벨)
import { readFileSync } from "node:fs";
import path from "node:path";
import { deflateRawSync } from "node:zlib";
import { describe, expect, it } from "vitest";
import { z } from "zod";
import { parseCsv } from "@/lib/csv";
import { AppError } from "@/server/http/errors";
import { excelDate, fromLabel, parseRows, readTable, toBool, toNumber } from "@/server/import";

const file = (name: string, bytes: Uint8Array<ArrayBuffer> | string) => new File([bytes], name);
const failure = (fn: () => unknown) => {
  try {
    fn();
  } catch (e) {
    if (e instanceof AppError) return { message: e.message, fieldErrors: e.fieldErrors };
    throw e;
  }
  throw new Error("오류가 나야 합니다.");
};

describe("parseCsv", () => {
  it("따옴표·이스케이프·따옴표 안 줄바꿈·BOM·CRLF/LF·빈 줄 보존", () => {
    expect(parseCsv('\uFEFFa,b\r\n"x,1","say ""hi"""\n\n"줄1\r\n줄2",\n')).toEqual([
      ["a", "b"], ["x,1", 'say "hi"'], [""], ["줄1\r\n줄2", ""],
    ]);
    expect(parseCsv("a,b")).toEqual([["a", "b"]]);
    expect(parseCsv("")).toEqual([]);
  });
});

describe("readTable", () => {
  it("CSV: UTF-8, 실패하면 CP949", async () => {
    expect(await readTable(file("a.csv", "\uFEFF이름,수량\r\n홍길동,3\r\n"))).toEqual([["이름", "수량"], ["홍길동", "3"]]);
    const cp949 = Buffer.from("c0ccb8a72cbcf6b7ae0d0ac8abb1e6b5bf2c22312c303030220d0a", "hex");
    expect(await readTable(file("a.csv", cp949))).toEqual([["이름", "수량"], ["홍길동", "1,000"]]);
  });

  it("XLSX(openpyxl 생성): 첫 시트, 공유 문자열·숫자·날짜 서식·일시·불리언, 빈 행 보존", async () => {
    const bytes = readFileSync(path.resolve(__dirname, "../fixtures/import.xlsx"));
    const table = await readTable(file("import.xlsx", bytes));
    expect(table[0]).toEqual(["제목", "분류", "내용", "수량", "날짜", "일시", "확인"]);
    expect(table[1]).toEqual(["엑셀 가져오기 1", "장비", "모니터 교체", "1200", "2026-01-05", "2026-01-05T09:30", "TRUE"]);
    expect(table[2] ?? []).toEqual([]);
    expect(table[3]).toEqual(["엑셀 가져오기 2", "권한", "줄1\n줄2 & <특수>", "3.5", "2026-12-31", "2026-12-31T18:00", "FALSE"]);
  });

  it("형식·크기 거부: .xls, 확장자 위장, 압축 해제 상한", async () => {
    await expect(readTable(file("a.xls", "x"))).rejects.toThrow("예전 엑셀");
    await expect(readTable(file("a.txt", "x"))).rejects.toThrow(".csv 또는 .xlsx");
    await expect(readTable(file("a.xlsx", "이름,수량"))).rejects.toThrow("엑셀 파일을 읽을 수 없습니다");
    await expect(readTable(file("bomb.xlsx", zip({ "xl/workbook.xml": "<workbook/>", "xl/worksheets/sheet1.xml": "<a/>".repeat(9_000_000) }))))
      .rejects.toThrow("너무 크거나");
    await expect(readTable(file("big.csv", "a\n".repeat(1002)))).rejects.toThrow("1000행");
  });

  it("XLSX 인라인 문자열·rels 의 첫 시트·XML 엔티티", async () => {
    const xlsx = zip({
      "xl/workbook.xml": '<workbook xmlns:r="r"><sheets><sheet name="A" r:id="rId9"/></sheets></workbook>',
      "xl/_rels/workbook.xml.rels": '<Relationships><Relationship Id="rId9" Target="worksheets/data.xml"/></Relationships>',
      "xl/worksheets/data.xml": '<worksheet><sheetData><row r="1"><c r="B1" t="inlineStr"><is><t>A&amp;B &#54620;_x000D_</t></is></c></row></sheetData></worksheet>',
    });
    expect(await readTable(file("x.xlsx", xlsx))).toEqual([["", "A&B 한\r"]]);
  });
});

describe("parseRows", () => {
  const Schema = z.strictObject({
    title: z.string().min(2, "제목은 2자 이상"),
    kind: z.enum(["A", "B"], { error: "분류를 선택해 주세요." }),
    qty: z.number().int().default(0),
    ok: z.boolean().default(false),
  });
  const COLUMNS = [
    { header: "제목", key: "title" },
    { header: "분류", key: "kind", value: fromLabel({ A: "가", B: "나" }) },
    { header: "수량", key: "qty", value: toNumber, optional: true },
    { header: "확인", key: "ok", value: toBool, optional: true },
  ];

  it("머리행 매핑·라벨/코드·쉼표 숫자·빈 셀 = 기본값·빈 행 건너뜀·없는 선택 열", () => {
    const table = [[], ["  제목 ", "분류", "수량", "기타"], ["첫째", "가", "1,000", "x"], [], ["둘째", "B", "", ""]];
    expect(parseRows(table, COLUMNS, Schema)).toEqual([
      { title: "첫째", kind: "A", qty: 1000, ok: false },
      { title: "둘째", kind: "B", qty: 0, ok: false },
    ]);
  });

  it("행 오류는 원본 행 번호 + 열 이름으로 모은다(빈 필수 칸 = 스키마 메시지, 없으면 \"값을 입력해 주세요.\")", () => {
    const table = [["제목", "분류", "수량"], ["가", "다", "1"], [], ["", "", "x"]];
    const e = failure(() => parseRows(table, COLUMNS, Schema));
    expect(e.fieldErrors).toEqual({
      "2행 제목": ["제목은 2자 이상"],
      "2행 분류": ["분류를 선택해 주세요."],
      "4행 제목": ["값을 입력해 주세요."],
      "4행 분류": ["분류를 선택해 주세요."],
      "4행 수량": [expect.any(String)],
    });
    expect(e.message).toContain("5곳에 오류");
  });

  it("머리행 누락·빈 파일·데이터 없음", () => {
    expect(failure(() => parseRows([["제목"]], COLUMNS, Schema)).message).toContain("분류 열이 없습니다");
    expect(failure(() => parseRows([[""], []], COLUMNS, Schema)).message).toBe("빈 파일입니다.");
    expect(failure(() => parseRows([["제목", "분류"], [" "]], COLUMNS, Schema)).message).toBe("가져올 데이터 행이 없습니다.");
  });

  it("excelDate: 날짜·일시·시각·범위 밖", () => {
    expect(excelDate(46027)).toBe("2026-01-05");
    expect(excelDate(46027.395833333336)).toBe("2026-01-05T09:30");
    expect(excelDate(0.75)).toBe("18:00");
    expect(excelDate(-1)).toBe("-1");
  });
});

/** 시험용 최소 zip(deflate). 중앙 디렉터리만 정확하면 리더가 읽는다. */
function zip(files: Record<string, string>): Uint8Array<ArrayBuffer> {
  const locals: Buffer[] = [];
  const central: Buffer[] = [];
  let offset = 0;
  for (const [name, text] of Object.entries(files)) {
    const nameBytes = Buffer.from(name);
    const data = deflateRawSync(Buffer.from(text));
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(8, 8);
    local.writeUInt32LE(data.length, 18);
    local.writeUInt16LE(nameBytes.length, 26);
    const dir = Buffer.alloc(46);
    dir.writeUInt32LE(0x02014b50, 0);
    dir.writeUInt16LE(8, 10);
    dir.writeUInt32LE(data.length, 20);
    dir.writeUInt16LE(nameBytes.length, 28);
    dir.writeUInt32LE(offset, 42);
    locals.push(local, nameBytes, data);
    central.push(dir, nameBytes);
    offset += 30 + nameBytes.length + data.length;
  }
  const dirBytes = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(Object.keys(files).length, 10);
  end.writeUInt32LE(dirBytes.length, 12);
  end.writeUInt32LE(offset, 16);
  return new Uint8Array(Buffer.concat([...locals, dirBytes, end]));
}
