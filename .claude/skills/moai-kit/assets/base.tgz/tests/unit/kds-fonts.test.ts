import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import http from "node:http";
import { allowsLocalKdsFonts } from "../../src/features/kdsFonts/policy";
import { startKdsFontServer } from "../../scripts/kds-font-server.mts";

describe("participant font distribution", () => {
  it("denies ordinary production and public E2E origins", () => {
    expect(allowsLocalKdsFonts({ NODE_ENV: "production", APP_ORIGIN: "http://localhost:3000" })).toBe(false);
    expect(allowsLocalKdsFonts({ NODE_ENV: "production", E2E_RUN_ID: "test", E2E_SOURCE_SHA256: "a".repeat(64), APP_ORIGIN: "https://example.com" })).toBe(false);
    expect(allowsLocalKdsFonts({ NODE_ENV: "production", E2E_RUN_ID: "test", APP_ORIGIN: "http://localhost:3000" })).toBe(false);
  });
  it("allows local development and isolated loopback E2E", () => {
    expect(allowsLocalKdsFonts({ NODE_ENV: "development" })).toBe(true);
    expect(allowsLocalKdsFonts({ NODE_ENV: "production", E2E_RUN_ID: "test", E2E_SOURCE_SHA256: "a".repeat(64), APP_ORIGIN: "http://127.0.0.1:1234" })).toBe(true);
  });
  it("binds only to loopback and rejects remote browser origins", async () => {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), "kds-font-test-"));
    fs.mkdirSync(path.join(root, ".kds-private", "fonts"), { recursive: true });
    fs.mkdirSync(path.join(root, "public", "kds", "fonts"), { recursive: true });
    for (const name of ["KTFLOW-MEDIUM.woff2", "KTFLOW-BOLD.woff2"]) fs.writeFileSync(path.join(root, ".kds-private", "fonts", name), "wOF2synthetic");
    const server = await startKdsFontServer(root);
    if (!server) throw new Error("Expected local font companion");
    const get = (origin: string) => new Promise<number>((resolve, reject) => {
      const request = http.get(server.fontUrl, { headers: { Origin: origin } }, (response) => { response.resume(); resolve(response.statusCode ?? 0); });
      request.on("error", reject);
    });
    try {
      expect(server.address).toBe("127.0.0.1");
      expect(await get("http://localhost:3000")).toBe(200);
      expect(await get("https://example.com")).toBe(403);
      expect(await get("http://192.168.1.9:3000")).toBe(403);
    } finally { await server.close(); }
  });
});
