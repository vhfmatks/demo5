// 공용 유틸 계약: 마스킹·CSV(수식 주입 방지)·차트 눈금·달력 날짜 (SEC-07, SEC-04)
import { describe, expect, it } from "vitest";
import { maskEmail, maskMiddle, maskName, maskPhone, omitUnless } from "@/lib/mask";
import { csvCell, toCsv } from "@/lib/csv";
import { niceTicks } from "@/components/ui/Chart";
import { pageWindow } from "@/components/ui/Pagination";
import { addDays, addMonths, CalendarQuery, gridRange, monthGrid, visibleDays, weekDays } from "@/lib/calendar";

describe("mask", () => {
  it("이름·전화·이메일을 가린다", () => {
    expect(maskName("홍길동")).toBe("홍*동");
    expect(maskName("남궁민수")).toBe("남**수");
    expect(maskName("이산")).toBe("이*");
    expect(maskName("A")).toBe("*");
    expect(maskPhone("010-1234-5678")).toBe("010-****-5678");
    expect(maskPhone("01012345678")).toBe("010-****-5678");
    expect(maskEmail("hong.gd@kt.com")).toBe("ho*****@kt.com");
    expect(maskEmail("a@kt.com")).toBe("a*@kt.com");
    expect(maskMiddle("1234567890", 2)).toBe("12******90");
  });
  it("권한이 없으면 필드를 응답에서 지운다", () => {
    const dto = { id: "1", reason: "민감" };
    expect(omitUnless(true, dto, "reason")).toEqual(dto);
    expect(omitUnless(false, dto, "reason")).toEqual({ id: "1" });
    expect(dto.reason).toBe("민감"); // 원본 불변
  });
});

describe("csv", () => {
  it("따옴표·쉼표·줄바꿈을 감싼다", () => {
    expect(csvCell('a,"b"')).toBe('"a,""b"""');
    expect(csvCell("줄\n바꿈")).toBe('"줄\n바꿈"');
    expect(csvCell(null)).toBe("");
  });
  it("수식으로 시작하는 문자열은 텍스트로 만든다 (숫자 음수는 그대로)", () => {
    for (const s of ["=CMD|'/c calc'!A1", "+1", "-1+2", "@SUM(A1)", "\t=1"]) expect(csvCell(s).replace(/^"/, "")).toMatch(/^'/);
    expect(csvCell(-5)).toBe("-5");
  });
  it("BOM·헤더·CRLF", () => {
    const out = toCsv([{ n: "홍", v: 1 }], [{ header: "이름", value: (r) => r.n }, { header: "값", value: (r) => r.v }]);
    expect(out).toBe("\uFEFF이름,값\r\n홍,1\r\n");
  });
});

describe("niceTicks", () => {
  it("0 을 포함하고 범위를 덮는 1·2·5 배수 눈금", () => {
    expect(niceTicks(3, 97)).toEqual([0, 50, 100]);
    expect(niceTicks(0, 7)).toEqual([0, 2, 4, 6, 8]); // 최댓값이 눈금 사이면 한 칸 더
    expect(niceTicks(0, 8)).toEqual([0, 2, 4, 6, 8]);
    expect(niceTicks(-12, 30)[0]).toBeLessThanOrEqual(-12);
    expect(niceTicks(0, 0)).toEqual([0, 1]);
    expect(niceTicks(0, 0.3)).toEqual([0, 0.1, 0.2, 0.3]);
  });
});

describe("calendar", () => {
  it("monthGrid: 일요일 시작, 앞뒤 달로 주를 채움(2026-10 = 9/27~10/31, 5주), 4주·6주 달", () => {
    const oct = monthGrid("2026-10");
    expect(oct).toHaveLength(5);
    expect(oct[0][0]).toBe("2026-09-27");
    expect(oct[4][6]).toBe("2026-10-31");
    expect(monthGrid("2026-02").flat()).toHaveLength(28); // 2/1 일요일·2/28 토요일 → 딱 4주
    expect(monthGrid("2026-08")).toHaveLength(6); // 8/1 토요일 → 6주
    expect(monthGrid("2026-08").flat().every((d, i, all) => i === 0 || d === addDays(all[i - 1], 1))).toBe(true);
  });

  it("주·월 이동, 조회 범위 [from, to)", () => {
    expect(weekDays("2026-10-08")).toEqual(["2026-10-04", "2026-10-05", "2026-10-06", "2026-10-07", "2026-10-08", "2026-10-09", "2026-10-10"]);
    expect(addMonths("2026-12", 1)).toBe("2027-01");
    expect(addMonths("2026-01", -1)).toBe("2025-12");
    expect(addDays("2028-02-28", 1)).toBe("2028-02-29");
    expect(gridRange(visibleDays("month", "2026-10-15"))).toEqual({ from: "2026-09-27", to: "2026-11-01" });
    expect(gridRange(visibleDays("week", "2026-10-08"))).toEqual({ from: "2026-10-04", to: "2026-10-11" });
  });

  it("CalendarQuery: 잘못된 view·date 는 기본값", () => {
    expect(CalendarQuery.parse({})).toEqual({ view: "month" });
    expect(CalendarQuery.parse({ view: "week", date: "2026-10-08" })).toEqual({ view: "week", date: "2026-10-08" });
    expect(CalendarQuery.parse({ view: "year", date: "2026-02-30" })).toEqual({ view: "month" });
    expect(CalendarQuery.parse({ date: "2026-13-45" })).toEqual({ view: "month" });
  });
});

describe("pageWindow", () => {
  it("처음·끝·현재±1 만 남기고 사이는 생략한다", () => {
    expect(pageWindow(1, 1)).toEqual([1]);
    expect(pageWindow(2, 4)).toEqual([1, 2, 3, 4]);
    expect(pageWindow(1, 40)).toEqual([1, 2, null, 40]);
    expect(pageWindow(20, 40)).toEqual([1, null, 19, 20, 21, null, 40]);
    expect(pageWindow(40, 40)).toEqual([1, null, 39, 40]);
    expect(pageWindow(3, 40)).toEqual([1, 2, 3, 4, null, 40]);
  });
});
