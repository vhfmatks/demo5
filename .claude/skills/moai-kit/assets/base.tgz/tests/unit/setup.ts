// 테스트마다 메모리 DB를 마이그레이션 (파일 DB 를 건드리지 않음)
import { db } from "@/server/db/client";
import { migrateDb } from "@/server/db/open";

await migrateDb(db);
